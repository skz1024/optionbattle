// 타입의 이름
const typeName = {
	unused:0,  hyper:1,  missile:2,  multishot:3,  direct:4,  splash:5,  heal:6,  metal:7,
	laser:8,  whiteflash:9,  allarea:10,  // 0 ~ 10: base type // 기본 타입
	bombrocket:11, linelaser:12, _3wayshot:13
	
	,maxcount:13 // 타입의 종류 최대값
};

function Type(){
// Type을 이 함수에서 전부 만들고 처리함.
var sectionstage = {  unused:0,  lv1:1,  lv2:2,  lv3:3,  lv4:4,  lv5:5,  lv6:6,  lv7:7,  lv8:8  };
function setattackTypeValue(strAttacktype){
	if(strAttacktype == "")  return 1;
	else if(strAttacktype == "splash")  return 0.17;
	else if(strAttacktype == "whiteflash")  return 0.55;
	else if(strAttacktype == "missile")  return 1.20;
	else if(strAttacktype == "laser")  return 0.14;
	else if(strAttacktype == "heal")  return 0.40;
	else if(strAttacktype == "linelaser")  return 0.32;
	else if(strAttacktype == "shot")  return 1.04;
	else if(strAttacktype == "???")  return 1;
	else  return 1;
}
function create(strName, strColor, sectionstagePosition, percentNormal, strAttacktype, percentTechnical, strAttacktypeTechnical){
	// percent는 최대가 100이며, technical과 normal의 합이 최대 100을 넘길 수 없음.
	// 타입에 따른 스킬을 정의해야 한다면, 보통 테크니컬을 사용하거나 또는 스킬칸을 따로 정하는 함수를 사용해야함.
	// 복합적인 공격형태(타격 + 스플래시)와 같은것은 이 함수외에도 다른 형태의 함수를 추가로 사용해야함.
	this.name = strName; // 타입의 이름
	this.color = strColor; // 타입의 색깔
	this.sectionstage = sectionstagePosition;
	this.percentnormal = percentNormal;
	this.percenttechnical = percentTechnical;
	this.attacktype = strAttacktype;
	this.attacktypetechnical = strAttacktypeTechnical;
	
	this.technicalmultiple = 1;
	this.technicalshotcount = 1;
	
	// 기본적인 타입의 구간레벨에 따른 값의 패턴 결정
	// 섹션스테이지포지션(구간단계위치)가 0 미만이거나 8 초과일경우 0으로 강제로 변경(unused 로 처리)
	// rangemin: 공격력 범위 최소,  rangemax: 공격력 범위 최대,  standard = damage per frame percent
	if(sectionstagePosition < 0 || sectionstagePosition > 8)  sectionstagePosition = 0;
	switch(sectionstagePosition){
		case 1: this.rangemin = 50;   this.rangemax = 60;   this.standard = 480;  break; // 멀티샷
		case 2: this.rangemin = 70;   this.rangemax = 90;   this.standard = 420;  break; // 낮음
		case 3: this.rangemin = 100;  this.rangemax = 130;  this.standard = 360;  break; // 약간낮음
		case 4: this.rangemin = 140;  this.rangemax = 165;  this.standard = 320;  break; // 중간
		case 5: this.rangemin = 170;  this.rangemax = 200;  this.standard = 300;  break; // 약간높음
		case 6: this.rangemin = 210;  this.rangemax = 240;  this.standard = 280;  break; // 높음
		case 7: this.rangemin = 250;  this.rangemax = 290;  this.standard = 260;  break; // 매우높음
		case 8: this.rangemin = 300;  this.rangemax = 1000; this.standard = 240;  break; // 하이퍼
		default:this.rangemin = 0;    this.rangemax = 1000; this.standard = 0;    break; // 데이터없음
	}
	
	// 표준 규칙의 예외 타입에 대한 값의 패턴 결정
	if(this.name == "direct"){
		this.rangemin = 100;  this.rangemax = 1000;  this.standard = 150;
	} else if(this.name == "allarea"){
		this.rangemin = 0;    this.rangemax = 1000;  this.standard = 8;
	} else if(this.name == "metal"){
		this.rangemin = 50;   this.rangemax = 70;    this.standard = 50;
	}
	
	
	// 값을 정의한 후, 타입의 공격 패턴 형태에 따라서 나머지 값들을 결정
	if(percentNormal + percentTechnical > 100){
		alert("[ "+ strName + "] 타입이 기준 밸런스 규칙을 무시하였습니다. 이 타입의 규칙을 수정하시기 바랍니다.\n" +
		"문제가 되는 부분은, percentNormal + percentTechincal의 합이 100을 넘어갑니다. 이 숫자들의 합은 100을 "+
		"초과할 수 없습니다.");
	} else if(this.name == "bombrocket"){
		var normalAttack = (percentNormal / 9) * this.standard / 100 / 1;
		var splashAttack = (percentNormal / 9) * setattackTypeValue("splash") * this.standard / 100 / 8;
		this.normal = normalAttack + splashAttack;
		this.technical = percentTechnical * setattackTypeValue(strAttacktypeTechnical)  * this.standard / 100;
		this.skill = 0;
	} else {
		this.normal = percentNormal * setattackTypeValue(strAttacktype) * this.standard / 100;
		this.technical = percentTechnical * setattackTypeValue(strAttacktypeTechnical)  * this.standard / 100;
		this.skill = 0;
	}
}
create.prototype.settechnicaloption = function(multiple, shotcount){
	this.technicalmultiple = multiple || 1; // 기본값으로 1로 처리
	this.technicalshotcount = shotcount || 1; // 기본값으로 1로 처리
	
	if(this.technicalmultiple <= 0)   this.technicalmultiple = 1; // 공격 배수
	if(this.technicalshotcount <= 0)  this.technicalshotcount = 1; // 공격 횟수
	
	// 공식이 매우 길어서 두줄로 처리
	var setvalue = this.percenttechnical * setattackTypeValue(this.attacktypetechnical) * this.standard;
	this.technical = setvalue / 100 / this.technicalmultiple / this.technicalshotcount;
};

// function create(str/name, str/color, sectionstage, percent/normal, str/attacknormaltype, per/technical, count/techincal, type/techincal)
var data = new Array(100); // 타입 정보를 저장하는 배열 생성
// unused: 타입을 정의할 필요가 없는 공격을 할때 사용한다. 보통의 유닛들은 사용하지 않는다.
data[typeName.unused] = new create("unused", "black", sectionstage.unused, 100, "", 0, 0, "");

// hyper: 하이퍼 계열의 타입, 타겟추적형
// 공격력이 전체적으로 높으며, 테크니컬으로 4배수를 공격하는 기술을 갖고있음.
data[typeName.hyper] = new create("hyper", "darkgreen", sectionstage.lv8, 18, "", 82, "");
data[typeName.hyper].settechnicaloption(4, 1);

// missile: 미사일 계열의 타입, 직진형
// 공격력은 중간정도, 직선으로 직진만 한다는 특성때문에 적을 맞추기는 어려우나 대신 프레임당 데미지 배율이 추가적용됨
data[typeName.missile] = new create("missile", "slategrey", sectionstage.lv5, 100, "", 0, "");

// multishot: 멀티샷, 타겟추적형
// 공격력이 매우 낮은 대신 방어력이 0인 적을 상대로는 하이퍼에 비해 2배의 효율을 발휘한다.
data[typeName.multishot] = new create("multishot", "brown", sectionstage.lv1, 50, "", 50, "");

// direct: 다이렉트, 특수형
// 데미지 효율은 적지만, 적의 모든 효과(방어력, 공격무효, 버프, 회피등...)을 무시하고 공격할 수 있따.
data[typeName.direct] = new create("direct", "darkblue", sectionstage.unused, 100, "", 0, "");

// splash: 스플래시, 다수타격형, 타겟추적형
// 프레임당 데미지는 낮은 편이지만, 타겟수 제한이 없으며, 여러 적을 동시에 때릴 수 있으므로 필드전에서 좋은 능력을 발휘한다.
data[typeName.splash] = new create("splash", "red", sectionstage.lv4, 100, "splash", 0, "");

// heal: 힐, 체력회복형, 타겟추적형
// 체력을 회복할 수 있으며, 체력도 다른 유닛보다는 높은편이다. 단, 공격효율은 낮다.
data[typeName.heal] = new create("heal", "pink", sectionstage.lv3, 50, "heal", 50, "");

// metal: 메탈, 높은체력형, 타겟추적형
// 체력이 다른 유닛에 비해 매우 높다. 그러나 공격효율은 매우 낮다.
data[typeName.metal] = new create("metal", "silver", sectionstage.unused, 100, "", 0, "");

// laser: 레이저, 직진관통형, 단, 일반공격은 타겟추적형이다.
// 레이져는 좌표 첫부분부터 좌표 끝까지 앞으로 나아가는 형태, 관통이 있기 때문에 다수를 상대할때 더욱 좋다.
data[typeName.laser] = new create("laser", "gold", sectionstage.lv6, 40, "", 60, "laser");

// whiteflash: 화이트플래시, 발사관통형
// 다수의 발사체를 발사하여 관통하는 방식으로써, 다수를 상대할때 효과적이나 공격력이 낮아 사용에 주의가 필요하다.
data[typeName.whiteflash] = new create("whiteflash", "#EFEFEF", sectionstage.lv1, 0, "", 100, "whiteflash");
data[typeName.whiteflash].settechnicaloption(1, 8);

// allarea: 올에리아, 전부때린다.
// 화면 안에 있는 모든 유닛을 타격한다. 그리고 모든 요소를 무시한다.
// 그러나 dpf가 1유닛당 8%밖에 안되어서 적의 수가 적은 스테이지는 망했어요.
data[typeName.allarea] = new create("allarea", "darkkhaki", sectionstage.unused, 100, "", 0, "");

//------------------------//
// advanced type list

// bombrocket: 봄로켓, 적 한대를 때린 직후, 폭발형 공격을 8회 시도하는 특수한 유닛, 타겟추적형
// 스플래시 + 일반타격, 그러나 스플래시비중이 매우 높기 때문에 다수를 상대할때 더 유리하다.
data[typeName.bombrocket] = new create("bombrocket", "#3E5E7E", sectionstage.lv5, 100, "", 0, "");

// linelaser: 한줄 전체를 연속적으로 공격하는 레이저(직선연속공격형)
// 레이져와는 다르게 y좌표 40정도의 크기를 일정시간동안 연속 공격한다.
data[typeName.linelaser] = new create("linelaser", "yellow", sectionstage.lv6, 100, "linelaser", 0, "");

// _3wayshot: 3way의 형태로 총알을 발사하는 타입... 정확하게는 탐사선을 위해서 만든 타입
// 미사일과 원리는 같지만, 예는 방향이 3개임.
data[typeName._3wayshot] = new create("_3wayshot", "skyblue", sectionstage.lv2, 0, "", 100, "shot");
data[typeName._3wayshot].settechnicaloption(1, 3);

// 각 스탯들을 리턴하는 함수들. get메서드를 사용
this.getrangemin = function(constType){  return data[constType].rangemin; };
this.getrangemax = function(constType){  return data[constType].rangemax; };
this.getstandard = function(constType){  return data[constType].standard; };
this.getnormal = function(constType){  return data[constType].normal; };
this.gettechnical = function(constType){  return data[constType].technical; };
this.getskill = function(constType){  return data[constType].skill; };
this.getname = function(constType){  return data[constType].name; };
this.getcolor = function(constType){  return data[constType].color; };
this.getsectionstage = function(constType){  return data[constType].sectionstage; };
this.gettechnicalmultiple = function(constType){  return data[constType].technicalmultiple; };
this.gettechnicalshotcount = function(constType){  return data[constType].technicalshotcount; };
};

optionbattle.type = new Type(); // 객체 생성