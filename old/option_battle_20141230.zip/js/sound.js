// 사운드 파일 이름을 그대로 쓰시고 번호는 중복되지만 않게 하면 됩니다.
const soundName = { none:0, select_move:1, select_enter:2, select_back:3, select_menu:4,
	 system_buzzer:5, system_score:6, system_upgrade:7, system_notice:8, type_hyper:9, type_heal:10,
	 arrowshot:11, bubble:12, dongrami_fail:13, highattack:14, splashdamage:15, swordattack:16,
	 전자기장:17, multishot:18, laserA:19, whiteflash:20,  bombmissile:21, bomb:22, light_break:23,
	 system_pause:24, bombattack:25, meteorite_break:26, levelup:27, wall_break:28, warning_strong_missile_detected:29,
	 strong_missile_detected:30, strong_missile_bomb:31, blackhole:32, linelaser:33
	};

function Sound(){
//사운드는 이 객체에서 처리합니다.
var sound = new Array(100); // 사운드 파일 저장
function create(constSound, src){
	sound[constSound] = new Audio();
	sound[constSound].src = src;
}

this.play = function(constSound){
	if(optionbattle.game.getsoundOn() == false)  return;
	
	if(sound[constSound].paused == true){
		sound[constSound].play(); // 사운드 출력
	} else {
		sound[constSound].pause();
		sound[constSound].currentTime = 0;
		sound[constSound].play();
	}
};
this.test = function(constSound){
	if(sound[constSound].paused == true){
		sound[constSound].play(); // 사운드 출력
	} else {
		sound[constSound].pause();
		sound[constSound].currentTime = 0;
		sound[constSound].play();
	}
};

// 사운드 만들기
create(soundName.none, "sound/none.wav");
create(soundName.select_move, "sound/select_move.wav");
create(soundName.select_enter, "sound/select_enter.wav");
create(soundName.select_back, "sound/select_back.wav");
create(soundName.select_menu, "sound/select_menu.wav");
create(soundName.system_buzzer, "sound/system_buzzer.wav");
create(soundName.system_notice, "sound/system_notice.wav");
create(soundName.system_score, "sound/system_score.wav");
create(soundName.system_upgrade, "sound/system_upgrade.wav");
create(soundName.type_heal, "sound/type_heal.wav");
create(soundName.type_hyper, "sound/type_hyper.wav");
create(soundName.arrowshot, "sound/arrowshot.wav");
create(soundName.bubble, "sound/bubble.wav");
create(soundName.dongrami_fail, "sound/dongrami_fail.wav");
create(soundName.highattack, "sound/highattack.wav");
create(soundName.splashdamage, "sound/splashdamage.wav");
create(soundName.swordattack, "sound/swordattack.wav");
create(soundName.전자기장, "sound/전자기장.wav");
create(soundName.bombmissile, "sound/bombmissile.wav");
create(soundName.whiteflash, "sound/whiteflash.wav");
create(soundName.multishot, "sound/multishot.wav");
create(soundName.laserA, "sound/laserA.wav");
create(soundName.bomb, "sound/bomb.wav");
create(soundName.light_break, "sound/light_break.wav");
create(soundName.system_pause, "sound/system_pause.wav");
create(soundName.bombattack, "sound/bombattack.wav");
create(soundName.meteorite_break, "sound/meteorite_break.wav");
create(soundName.levelup, "sound/levelup.wav");
create(soundName.wall_break, "sound/wall_break.wav");
create(soundName.warning_strong_missile_detected, "sound/warning_strong_missile_detected.wav");
create(soundName.strong_missile_detected, "sound/strong_missile_detected.wav");
create(soundName.strong_missile_bomb, "sound/strong_missile_bomb.wav");
create(soundName.blackhole, "sound/blackhole.wav");
create(soundName.linelaser, "sound/linelaser.wav");
//var soundPlayCount = new Array(100*5);
//for(var a=0, length = soundPlayCount.length; a < length; a++) soundPlayCount[a] = 0;
} // 객체 종료






//---------------------------//
//이 파일은 배경음악과 관련 있는 파일입니다.
var musicName = { none:0, skz1024:1, title:2, roundclear:3, music01:4, music02_paran_planet:5, music03_donggrami_maeul:6 };
function Music(){
//--------------------//
var music = new Array(100);
var currentmusicCode = 0;
var musicEndCheck = false;
var musicStopCheck = false;
var musicCount = -1;
function create(constMusic, src, loopOption){
	musicCount++;
	music[constMusic] = new Audio();
	music[constMusic].src = src; // 경로 지정
	if(loopOption != false){
		music[constMusic].loop = true; // music은 루프를 활성화.
	}
}

this.play = function(constMusic){
	musicStopCheck = false;
	music[currentmusicCode].pause(); // 현재 음악 정지
	music[currentmusicCode].currentTime = 0; // 재생 시간을 0초로 변경
	
	currentmusicCode = constMusic; // 재생중인 musicCode를 저장
	if(optionbattle.game.getmusicOn() == false)  return;
	music[constMusic].play(); // 배경음악 재생
	
};
this.test = function(constMusic){
	musicStopCheck = false;
	music[currentmusicCode].pause(); // 현재 음악 정지
	music[currentmusicCode].currentTime = 0; // 재생 시간을 0초로 변경
	
	music[constMusic].play(); // 배경음악 재생
	currentmusicCode = constMusic; // 재생중인 musicCode를 저장
};
this.reset = function(){
	music[currentmusicCode].pause(); // 현재 음악 정지
	music[currentmusicCode].currentTime = 0; // 재생 시간을 0초로 변경
	music[currentmusicCode].play(); // 배경음악 재생
};
this.check = function(){
	if(currentmusicCode == 0){ // 코드가 0일경우 아무것도 처리하지 않음.
		
	} else if(optionbattle.game.getmusicOn() == false || musicStopCheck == true){ // 음악설정이 OFF로 되어있을경우 또는 음악을 정지하였을경우
		music[currentmusicCode].pause(); // 현재 음악 정지
	} else {
		if(music[currentmusicCode].paused == true && music[currentmusicCode].loop == true){
			music[currentmusicCode].play();
		}
	}
};
this.stop = function(){ musicStopCheck = true; };
this.continue = function(){ musicStopCheck = false; };
this.time = function(){ return music[currentmusicCode].currentTime.toFixed(2); };
this.getmusicCount = function(){  return musicCount; };
this.duration = function(){  
	var argumentsData = arguments[0] || currentmusicCode;
	var durationData = music[argumentsData].duration;
    return durationData.toFixed(2);
};

create(musicName.none, "sound/none.wav", false);
create(musicName.skz1024, "music/skz1024.ogg", false);
create(musicName.title, "music/title.ogg", false);
create(musicName.music01, "music/music01.ogg");
create(musicName.music02_paran_planet, "music/music02_paran_planet.ogg");
create(musicName.roundclear, "music/roundclear.ogg", false);
create(musicName.music03_donggrami_maeul, "music/music03_donggrami_maeul.ogg");
}//function end


//객체 생성
optionbattle.sound = new Sound();
optionbattle.music = new Music();


