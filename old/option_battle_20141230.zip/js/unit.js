// 모든 유닛(unit)은 이 함수 내부의 create를 이용하여 만든다.
function Unit(){
// function Unit Start //
function create(strName, number, constType, rank, maxlv, attack, hp, strTechnical, strSkill){
	this.name = strName; // 유닛의 이름
	this.number = number; // 유닛의 번호
	this.type = constType; // 유닛의 타입(또는 속성), 타입 이름을 적는게 아니라 상수로 정의된 이름을 사용해야함.
	this.technical = strTechnical; // 유닛의 테크니컬 공격(아무것도 안쓰면 타입공격)
	this.techshot = 0; // 테크니컬 공격을 기준으로 테크샷 결정(이 역할을 하는 함수가 따로 있음.)
	this.techshotdelay = 5; // 테크샷 딜레이, 유닛에 따라 다르게 사용
	this.skill = strSkill; // 유닛의 스킬
	this.rank = rank; // 유닛의 랭크
	this.maxlv = maxlv; // 유닛의 최대레벨
	this.hp = hp; // 유닛의 체력
	this.mp = 0; // 유닛의 마력(정의 안하면 0)
	this.attack = attack; // 공격력
	this.attackTechnical = 0; // 테크니컬형 공격력
	this.attackSkill = 0; // 스킬형 공격력
	this.delay = 0; // 지연시간
	this.delayTechnical = 0; // 테크니컬형 지연시간
	this.delaySkill = 0; // 스킬형 지연시간
	this.defense = 0; // 방어력?
	this.attackSound = soundName.none;
	this.attackTechnicalSound = soundName.none;
	this.attackSkillSound = soundName.none;
	
	//이미지 관련 변수
	this.image = new Image();  this.image.src = ""; // 유닛의 이미지 경로
	this.attackImage = { }; // 공격 이미지 객체 생성
	this.attackImage.normal = new Image();  this.attackImage.normal.src = "";
	this.attackImage.technical = new Image();  this.attackImage.technical.src = "";
	this.attackImage.skill = new Image();  this.attackImage.skill.src = "";
	
	// 자동실행함수, 함수의 호출이 끝난 후 해당 함수는 자동삭제
	this.autorun = function(){
		// 공격력과 딜레이는 소수점 이하를 무조건 버림한다.
		// rankAttack : 랭크의 기준 공격력, rankStandard : 랭크의 기준 효율 : (attack / rankstandard) = delay
		var rankAttack = 0, rankStandard = 0, rankHp = 0; // 랭크와 관련된 정보 변수 생성
		switch(this.rank){ // 랭크에 따라서 관련 정보를 처리
			case 0: this.rank = 1; // 랭크 1로 처리
			case 1: rankAttack = 1200, rankStandard = 30, rankHp = 1000; break;
		}
    
	    // 해당 타입의 맞게 유닛을 설정
	    var rangemin = rankAttack * optionbattle.type.getrangemin(this.type) / 100 | 0; //공격력 범위 최소치
	    var rangemax = rankAttack * optionbattle.type.getrangemax(this.type) / 100 | 0; //공격력 범위 최대치
	    var percentNormal = rankStandard * optionbattle.type.getnormal(this.type) / 100 | 0; //일반 공격력 효율
	    var percentTechnical = rankStandard * optionbattle.type.gettechnical(this.type) / 100 | 0; //테크니컬 공격력 효율
	    var percentSkill = rankStandard * optionbattle.type.getskill(this.type) / 100 | 0; //스킬 공격력 효율
	    
	    // 공격력의 범위가 타입의 범위를 초과하는지 조사후, 공격력의 범위가 초과될경우 그에 맞게 공격력을 조정.
	    if(this.attack >= rangemax)  this.attack = rangemax;
	    else if(this.attack <= rangemin)  this.attack = rangemin;
	    
	    this.delay = this.attack / percentNormal | 0; //일반공격 딜레이 설정 -> 정수로 처리
	    
	    // 테크니컬 관련 설정
	    if(this.technical == ""){  // 테크니컬이 공백(없음)일 경우
	    	this.attackTechnical = this.attack * optionbattle.type.gettechnicalmultiple(this.type) | 0;
	    	this.techshot = optionbattle.type.gettechnicalshotcount(this.type);
	    	
	    	if(this.type == typeName.whiteflash)  this.techshotdelay = 1;
	    } else { // 테크니컬의 스킬이 존재
	    	//여러발 형태로 쏘는 테크니컬일경우 techshot을 설정해야 함.
	    	if(this.technical == "arrowshot_20"){  this.attackTechnical = this.attack * 1.5 | 0;  this.techshot = 20;  this.techshotdelay = 12; }
	    }
	    if(this.techshot != 0)  this.delayTechnical = (this.attackTechnical / percentTechnical) * this.techshot | 0; // 여러 발 쏘는 딜레이 계산
	    else if(percentTechnical != 0)  this.delayTechnical = this.attackTechnical / percentTechnical | 0; // 딜레이 설정
	    else  this.delayTechnical = 0;
	    
	    //스킬은 구현 안함. 나중에 할지는 모르겠음.
	    this.delaySkill = 0;
	};  this.autorun();  delete this.autorun();
}
create.prototype.display = function(x, y, width, height){
    //유닛의 그림을 그립니다.
    if( width == null || height == null )  ctx.drawImage(this.image, x, y);
    else  ctx.drawImage(this.image, x, y, width, height);
};
create.prototype.attackDisplay = function(x, y, stringType){
	if(stringType == 0 || stringType == null || stringType == "normal"){
		ctx.drawImage(this.attackImage.normal, x, y);
	} else if(stringType == 1 || stringType == "technical"){
		ctx.drawImage(this.attackImage.technical, x, y);
	} else if(stringType == 2 || stringType == "skill"){
		ctx.drawImage(this.attackImage.skill, x, y);
	}
};
create.prototype.getattack = function(stringType, lv){
	if(lv == "normal" || lv == "technical" || lv == "skill"){
		stringType = lv;   lv = 0;
	}  else if (lv == null)  lv = 0;
	
    if(stringType == 0 || stringType == null || stringType == "normal")  returndata = this.attack;
    else if(stringType == 1 || stringType == "technical")  returndata = this.attackTechnical;
    else if(stringType == 2 || stringType == "skill")  returndata = this.attackSkill;
    return (returndata * 0.02 * lv + returndata) | 0;  // 정수값으로 리턴
};
create.prototype.getdelay = function(stringType){
	if(stringType == 0 || stringType == null || stringType == "normal")  return this.delay;
    else if(stringType == 1 || stringType == "technical")  return this.delayTechnical;
    else if(stringType == 2 || stringType == "skill")  return this.delaySkill;
};
create.prototype.gethp = function(lv){
	if(lv == null)  return hp; 
	else  return  ( this.hp * 0.02 * lv + this.hp ) | 0; // 정수값으로 리턴;
};
create.prototype.gettypeName = function(){
	return optionbattle.type.getname(this.type);
};
create.prototype.attackSoundPlay = function(stringType){
	if(stringType == "normal")  optionbattle.sound.play(this.attackSound);
	else if(stringType == "technical")  optionbattle.sound.play(this.attackTechnicalSound);
	else if(stringType == "skill")  optionbattle.sound.play(this.attackSkillSound);
};
//----------------------------------//

var unit = new Array(100);

// 유닛 생성
unit[0] = new create("", 0, typeName.unused, 0, 0, 0, 0, "", "");
unit[0].image.src = "image/system/unused.png";
unit[0].attackImage.normal.src = "image/system/unused.png";
unit[1] = new create("대포", 1, typeName.hyper, 1, 40, 2800, 1000, "", "");
unit[1].image.src = "image/unit/unit[1].png";
unit[1].attackImage.normal.src = "image/attack/unit[1].attack.png";
unit[1].attackImage.technical.src = "image/attack/unit[1].technical.png";
unit[1].attackSound = soundName.type_hyper;  unit[1].attackTechnicalSound = soundName.type_hyper;
unit[2] = new create("캐논", 2, typeName.hyper, 1, 40, 3200, 1000, "", "");
unit[2].image.src = "image/unit/unit[2].png";
unit[2].attackImage.normal.src = "image/attack/unit[2].attack.png";
unit[2].attackImage.technical.src = "image/attack/unit[2].technical.png";
unit[2].attackSound = soundName.type_hyper;  unit[2].attackTechnicalSound = soundName.type_hyper;
unit[3] = new create("멀티샷 장치", 3, typeName.multishot, 1, 40, 500, 1000, "", "");
unit[3].image.src = "image/unit/unit[3].png";
unit[3].attackImage.normal.src = "image/attack/unit[3].attack.png";
unit[3].attackImage.technical.src = "image/attack/unit[3].technical.png";
unit[4] = new create("나무 활", 4, typeName.multishot, 1, 40, 770, 1000, "arrowshot_20", "");
unit[4].image.src = "image/unit/unit[4].png";
unit[4].attackImage.normal.src = "image/attack/unit[4].attack.png";
unit[4].attackImage.technical.src = "image/attack/unit[4].technical.png";
unit[4].attackTechnicalSound = soundName.arrowshot;
unit[5] = new create("약한 검", 5, typeName.direct, 1, 40, 1700, 1000, "swordattack", "");
unit[5].image.src = "image/unit/unit[5].png";
unit[5].attackImage.normal.src = "image/attack/unit[5].attack.png";
unit[5].attackImage.technical.src = "image/attack/unit[5].technical.png";
unit[5].attackSound = soundName.swordattack;
unit[6] = new create("전자기장 직접장치", 6, typeName.missile, 1, 40, 1900, 1100, "전자기장", "");
unit[6].image.src = "image/unit/unit[6].png";
unit[6].attackImage.normal.src = "image/attack/unit[6].attack.png";
unit[6].attackSound = soundName.전자기장;
unit[7] = new create("폭발물 연구원", 7, typeName.splash, 1, 40, 1768, 200, "", "");
unit[7].image.src = "image/unit/unit[7].png";
unit[7].attackImage.normal.src = "image/attack/unit[7].attack.png";
unit[7].attackSound = soundName.bombmissile;
unit[8] = new create("공구상자", 8, typeName.heal, 1, 40, 1832, 2400, "", "");
unit[8].image.src = "image/unit/unit[8].png";
unit[8].attackImage.normal.src = "image/attack/unit[8].attack.png";
unit[8].attackImage.technical.src = "image/attack/unit[8].technical.png";
unit[8].attackTechnicalSound = soundName.type_heal;
unit[9] = new create("수레차", 9, typeName.laser, 1, 40, 3036, 700, "", "");
unit[9].image.src = "image/unit/unit[9].png";
unit[9].attackImage.normal.src = "image/attack/unit[9].attack.png";
unit[9].attackImage.technical.src = "image/attack/unit[9].technical.png";
unit[9].attackImage.skill.src = "image/attack/unit[9].skill.png";
unit[9].attackSound = soundName.laserA;  unit[9].attackTechnicalSound = soundName.laserA;
unit[10] = new create("강철-공격장치", 10, typeName.metal, 1, 40, 1098, 5000, "", "");
unit[10].image.src = "image/unit/unit[10].png";
unit[10].attackImage.normal.src = "image/attack/unit[10].attack.png";
unit[10].attackImage.technical.src = "image/attack/unit[10].attack.png";
unit[11] = new create("화이트플래시 장치", 11, typeName.whiteflash, 1, 40, 900, 200, "", "");
unit[11].image.src = "image/unit/unit[11].png";
unit[11].attackImage.normal.src = "image/attack/unit[11].attack.png";
unit[11].attackImage.technical.src = "image/attack/unit[11].technical.png";
unit[11].attackSound = soundName.whiteflash;  //unit[11].attackTechnicalSound = soundName.whiteflash;
unit[12] = new create("미사일 연구원", 12, typeName.bombrocket, 1, 40, 1879, 1, "", "");
unit[12].image.src = "image/unit/unit[12].png";
unit[12].attackImage.normal.src = "image/attack/unit[12].attack.png";
unit[12].attackSound = soundName.bombmissile;


this.getunit = function(code){  return unit[code]; };
this.getname = function(code){  return unit[code].name; };
this.getnumber = function(code){  return unit[code].number; };
this.gethp = function(code, lv){  return unit[code].gethp(lv); };
this.gettype = function(code){  return unit[code].type; };
this.gettypeName = function(code){  return unit[code].gettypeName(); };
this.getrank = function(code){  return unit[code].rank; };
this.getmaxlv = function(code){  return unit[code].maxlv; };
this.getattack = function(code, lv){  return unit[code].getattack(lv, "normal"); };
this.getattackTechnical = function(code, lv){  return unit[code].getattack(lv, "technical"); };
this.getattackSkill = function(code, lv){  return unit[code].getattack(lv, "skill"); };
this.getdelay = function(code){  return unit[code].getdelay("normal"); };
this.getdelayTechnical = function(code){  return unit[code].getdelay("technical"); };
this.getdelaySkill = function(code){  return unit[code].getdelay("skill"); };
this.gettechnical = function(code){  return unit[code].technical; };
this.gettechshot = function(code){  return unit[code].techshot; };
this.gettechshotdelay = function(code){  return unit[code].techshotdelay; };
this.getskill = function(code){  return unit[code].skill; };
this.getimage = function(code){  return unit[code].image; };
this.display = function(code, x, y, width, height){  
	if(width == null || height == null)  unit[code].display(x, y);
	else  unit[code].display(x, y, width, height);
};
this.attackDisplay = function(code, x, y, strAttackType){
	if(strAttackType == "normal"){
		unit[code].attackDisplay(x, y, "normal");
	} else if(strAttackType == "technical"){
		unit[code].attackDisplay(x, y, "technical");
	} else if(strAttackType == "skill"){
		unit[code].attackDisplay(x, y, "skill");
	}
};
this.attackSoundPlay = function(code){  unit[code].attackSoundPlay("normal"); };
this.attackTechnicalSoundPlay = function(code){  unit[code].attackSoundPlay("technical"); };
this.attackSkillSoundPlay = function(code){  unit[code].attackSoundPlay("skill"); };
//-------- function end---------//
};// new Unit();

optionbattle.unit = new Unit();
