//모드 이름은 상수로 정의한다.
var modeName = { title:0, option:1 , opening:2, main:3, dungeon:4, party:5, upgrade:6, combination:7, 
    inventory:8, shop:9, unitview:10, unitselect:11, dungeon:12, loading:13, round:14, field:15, round_1:16,
    story:17, storyview:18, titlethema:19 };

//키를 입력받는 함수와 변수 처리
onkeydown = game_keyinput;
var keyboard = { enter:13, esc:27, z:90, x:88, up:38, down:40, left:37, right:39, p:80, a:65, s:83 };
var inputkey = 0;
function game_keyinput(event){
    inputkey = event.keyCode;
    
    //event.returnValue = false;
    if(inputkey != 116) event.preventDefault();
    if(inputkey == keyboard.z) inputkey = keyboard.enter; // ENTER key == Z
    else if(inputkey == keyboard.x) inputkey = keyboard.esc; // ESC key == X
}

//-------------------------------//
//start function Game
function Game(){ // 게임 함수...
//게임 모드 관련 설정
var mode = 0; // 게임의 모드, 타이틀, 옵션 화면등을 오갈때 사용하는 변수
function modeChange(constMode){ mode = constMode; }
function modeCheck(){  return mode; }
this.modeChange = function(constMode){ mode = constMode; };
this.getmode = function(){  return mode; };
this.cursorDefault = function(){  menu = 0; select = 0; };

//경험치 테이블
var expTable = [0, 181100, 181200, 181300, 181400, 181500, 255500, 256000, 256500, 257000, 257500
				, 361200, 362400, 363600, 364800, 366000, 482400, 484800, 487200, 489600, 492000];
this.getexpTable = function(lv){  return expTable[lv]; };

//게임 사운드 설정값
var soundVolume = 100; // 사운드 볼륨, 주의 : 브라우저에서 사용시에는 100으로 나눠야함.(범위가 0 ~ 1) 
var soundOn = true; // 사운드가 켜져있는지에 관한 변수, true일경우 켜짐
var musicVolume = 100; // 음악 볼륨, 위와 같음.
var musicOn = false; // 음악이 켜져있는지(재생중이냐와는 별개)에 관한 변수, true일경우 켜짐
this.getsoundOn = function(){  return soundOn; };
this.getmusicOn = function(){  return musicOn; };
function soundStatusChange(){
    if(soundOn == true)  soundOn = false;
    else  soundOn = true;
}
function musicStatusChange(){
    if(musicOn == true)  musicOn = false;
    else  musicOn = true;
}
this.soundStatusChange = function(){  soundStatusChange(); };
this.musicStatusChange = function(){  musicStatusChange(); };

//화면의 메뉴에 관한 설정
var menu = 0, select = 0, select2 = 0; selectDungeon = 0, selectRound = 0, selectTeamunit = 0, page = 0;
this.getmenu = function(){  return menu; };
this.getselect = function(){  return select; };
this.getselect2 = function(){  return select2; };
this.getselectDungeon = function(){  return selectDungeon; };
this.getselectRound = function(){  return selectRound; };
this.getselectTeamunit = function(){  return selectTeamunit; };
this.getpage = function(){  return page; };

//게임 타이틀 화면
function title(){
    if(inputkey == keyboard.up && menu > 0){  menu--;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.down && menu < 2){  menu++;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.enter){
        optionbattle.sound.play(soundName.select_enter);
        switch(menu){
            case 0: modeChange(modeName.main);  menu = 0; break;
            case 1: modeChange(modeName.option);  break;
            case 2: modeChange(modeName.titlethema);  currentTime = 0; break;
        }
    }
}

var currentTime = 0;
this.getcurrenTtime = function(){  return currentTime; };
function titlethema(){
	if(inputkey == keyboard.esc || inputkey == keyboard.enter){
		modeChange(modeName.title);
		optionbattle.music.stop();
	}
	currentTime += 0.02;
	currentTime = currentTime.toFixed(2);
	currentTime = Number(currentTime);
	
	if(currentTime == 1.00){
		optionbattle.music.play(1);
	} else if(currentTime == 6.00){
		optionbattle.music.play(2);
	} else if(currentTime >= 15.00){
		modeChange(modeName.title);
		optionbattle.music.stop();
	}
}


var soundNumber = 0, musicNumber = 0;
this.getsoundNumber = function(){  return soundNumber; };
this.getmusicNumber = function(){  return musicNumber; };
//게임 옵션 화면
function option(){
    if(inputkey == keyboard.up && select > 0){  select--;  optionbattle.sound.play(soundName.select_move); }
    else if( inputkey == keyboard.down && select < 5){  select++;  optionbattle.sound.play(soundName.select_move); }
    else if( inputkey == keyboard.left){
        switch(select){
            case 0: soundStatusChange(); break;
            case 1: musicStatusChange(); break;
            case 2: if(soundNumber > 0)  soundNumber--; break;
            case 3: if(musicNumber > 0)  musicNumber--; break;
        }
    } else if( inputkey == keyboard.right){
        switch(select){
            case 0: soundStatusChange(); break;
            case 1: musicStatusChange(); break;
            case 2: if(soundNumber < 33)  soundNumber++; break;
            case 3: if(musicNumber < optionbattle.music.getmusicCount())  musicNumber++; break;
        }
    } else if( inputkey == keyboard.enter){
        switch(select){
            case 0: soundStatusChange(); break;
            case 1: musicStatusChange(); break;
            case 2: optionbattle.sound.test(soundNumber); break;
            case 3: optionbattle.music.test(musicNumber); break;
            case 4: optionbattle.music.continue(); break;
            case 5: optionbattle.sound.play(soundName.select_back);
            		optionbattle.music.stop();
                    modeChange(modeName.title);
                    menu = 0;  select = 0;
                    break;
        }
    } else if( inputkey == keyboard.esc ){
    	optionbattle.music.stop();
    }
}

// 게임 메인화면
function main(){
    if( inputkey == keyboard.up && menu != 0){  menu--;  optionbattle.sound.play(soundName.select_move); }
    else if( inputkey == keyboard.down && menu != 7){  menu++;  optionbattle.sound.play(soundName.select_move); }
    else if( inputkey == keyboard.enter){
        optionbattle.sound.play(soundName.select_menu);
        switch(menu){
            case 0: modeChange(modeName.dungeon); break; // 던전
            case 1: modeChange(modeName.party); break; // 파티
            case 2: modeChange(modeName.inventory); break; // 인벤토리
            case 3: break; // 조합
            case 4: modeChange(modeName.story); // 이야기 
            		menu = 0;  select = 0;  break;
            case 5: break; // 마을
            case 6: break; // 캐시 상점
            case 7: modeChange(modeName.title);
                    menu = 0;  select = 0;
                    break; // 나가기
        }
    }
}

//게임 파티화면
function party(){
    if(inputkey == keyboard.left && (select_teamunit%3) > 0 ){  select_teamunit--;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.right && (select_teamunit%3) < 2 ){  select_teamunit++;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.up && Math.floor(select_teamunit/3) > 0 ){  select_teamunit-=3;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.down && Math.floor(select_teamunit/3) < 3 ){  select_teamunit+=3;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.esc){  modeChange(modeName.main);  optionbattle.sound.play(soundName.select_back); }
    else if(inputkey == keyboard.enter ){  modeChange(modeName.unitselect);  optionbattle.sound.play(soundName.select_menu); }
}

//유닛 선택 화면
function unitselect(){
    ctx.clearRect(0,0,500,50);
    ctx.font = "24px arial";
    ctx.fillText("파티에 편성할 유닛을 선택해 주세요.",20,30);
    
    if(inputkey == keyboard.esc){  modeChange(modeName.party);  optionbattle.sound.play(soundName.select_back); }
    else if(inputkey == keyboard.up && Math.floor(select%49) > 10){  select -= 10;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.down && Math.floor(select%49) < 40){  select += 10;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.left && select != 0){
        optionbattle.sound.play(soundName.select_move);
        if(select%10 == 0 && select > 50)  select -= 41;
        else  select--;
    } else if(inputkey == keyboard.right && select != 999){
        optionbattle.sound.play(soundName.select_move);
        if(select%10 == 9 && select < 950)  select += 41;
        else  select++;
    } else if(inputkey == keyboard.enter){
        var type_data = user.inventory_data(select);
        var type = type_data[invenconst.type];
        if(type == itemType.unit){
            var good = user.teamunit_setting(select_teamunit, select);
            if(good == true){
                optionbattle.sound.play(soundName.select_menu);
                modeChange(modeName.party);
            }
        } else {
            optionbattle.sound.play(soundName.system_notice);
            alert("유닛만 팀에 편성할 수 있습니다.\n아이템 또는 업그레이드는 팀에 편성할 수 없습니다.");
        }
    }
}

//업그레이드 처리 함수
function upgrade(){
    var data = user.inventory_data(select);
    var code = data[invenconst.code],  type = data[invenconst.type];
    var lv = data[invenconst.lv],  rank = data[invenconst.rank];
    var gold = unitUpgradeGold[lv];
    var maxlv = option_battle.unit[code].get_maxlv();
    if(type != itemType.unit){  optionbattle.sound.play(soundName.system_buzzer); alert("유닛만 강화할 수 있습니다.(아이템은 불가능)"); }
    else if(lv >= maxlv){  optionbattle.sound.play(soundName.system_buzzer); alert("해당 유닛은 레벨이 최대치이기 때문에 더이상 강화를 할 수 없습니다."); }
    else if(user.get_gold() < gold){  optionbattle.sound.play(soundName.system_buzzer); alert("골드가 부족하여 강화를 할 수 없습니다."); }
    else {  user.inventory_unitlvup(select);  user.minus_gold(gold);  optionbattle.sound.play(soundName.system_upgrade); }
}

//판매 처리 함수
function sell(){
    var data = user.inventory_data(select);
    var lv = data[invenconst.lv];
    var gold = unitSellGold[lv];
    if(data[invenconst.type] == itemType.nodata){  optionbattle.sound.play(soundName.system_buzzer); alert("해당 유닛 또는 아이템이 존재하지 않습니다."); }
    else{
        optionbattle.sound.play(soundName.system_notice);
        if(confirm("정말로 판매하시겠습니까? 이 작업은 되돌릴 수 없습니다.\n판매가격은 "+ gold +"gold 입니다.\n팀에 포함되어있을경우 유닛은 삭제할 수 없습니다.")){
            user.inventory_delete(select);
            user.inventory_clean();
            user.plus_gold(gold);
        }
    }
}

//크리스탈(현질...) 상점
function shop(){
    if(gamekey == keyboard.esc){  modeChange(modeName.main);  optionbattle.sound.play(soundName.select_back); }
}

//인벤토리 함수
function inventory(){
    if(inputkey == keyboard.up && Math.floor(select%49) > 10){  select -= 10;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.down && Math.floor(select%49) < 40){  select += 10;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.left && select != 0){
        optionbattle.sound.play(soundName.select_move);
        if(select%10 == 0 && select > 50)  select -= 41;
        else  select--;
    }
    else if(inputkey == keyboard.right && select != 999){
        optionbattle.sound.play(soundName.select_move);
        if(select%10 == 9 && select < 950)  select += 41;
        else  select++;
    }
    else if(inputkey == keyboard.esc){  menu = 4; modeChange(modeName.main); optionbattle.sound.play(soundName.select_back); }
    else if(inputkey == keyboard.enter){  menu = 0; modeChange(modeName.unitview); optionbattle.sound.play(soundName.select_menu); }
}

//유닛 보기 함수
function unitview(){
    if(inputkey == keyboard.esc){  modeChange(modeName.inventory);  optionbattle.sound.play(soundName.select_back); }
    else if(inputkey == keyboard.left && select2 > 0){  select2--;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.right && select2 < 2){  select2++;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.enter){
        if(select2 == 0){  modeChange(modeName.inventory);  optionbattle.sound.play(soundName.select_back); }
        else if(select2 == 1){  upgrade();  }
        else if(select2 == 2){  sell();  }
    }
}


//던전 목록 나타내는 함수
function dungeon(){
    if(inputkey == keyboard.esc){  optionbattle.sound.play(soundName.select_back);  modeChange(modeName.main); }
    else if(inputkey == keyboard.up && selectDungeon > -1){  selectDungeon--;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.down && selectDungeon < 0){  selectDungeon++;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.enter){
        if(selectDungeon == -1){  modeChange(modeName.main);  optionbattle.sound.play(soundName.select_back);  }
        else{  modeChange(modeName.round);  optionbattle.sound.play(soundName.select_menu);  }
    }
}

//라운드 목록 나타내는 함수
function round(){
	var roundMax = optionbattle.dungeon.getroundCount(selectDungeon);
    if(inputkey == keyboard.esc){  modeChange(modeName.dungeon);  optionbattle.sound.play(soundName.select_back); }
    else if(inputkey == keyboard.up && selectRound > -1){  selectRound--;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.down && selectRound < roundMax){  selectRound++;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.enter){
        if(selectRound == -1){  modeChange(modeName.dungeon);  optionbattle.sound.play(soundName.select_back); }
        else{  modeChange(modeName.loading);  optionbattle.sound.play(soundName.select_enter); }
    }
}

function loading(){
    modeChange(modeName.field);
    optionbattle.field.init();
}

var pausecheck = false;
function field(){
    optionbattle.field.process();
}
function pause_display(){
	ctx.fillStyle = "white";  ctx.fillRect(170, 200, 350, 50);
    ctx.fillStyle = "black";  ctx.font = "36px arial";  ctx.fillText("PAUSE(일시정지)", 220, 240);
}
function change_pause(){
    if(pausecheck == true){  music_continue(); pausecheck = false;  }
    else{ pausecheck = true;  optionbattle.music.stop();  optionbattle.sound.play(soundName.system_pause); }
}

function story(){
	if(inputkey == keyboard.esc){
        optionbattle.sound.play(soundName.select_back);
        menu = 2;  select = 0;  modeChange(modeName.main);
    }
    else if(inputkey == keyboard.up && menu > 0){  menu--;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.down && menu < 10){  menu++;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.enter){
        if(menu == 0){  menu = 2;  select = 0;  modeChange(modeName.main);  optionbattle.sound.play(soundName.select_back); }
        else{  page = 0; user.story_read(menu);  modeChange(modeName.storyview);  optionbattle.sound.play(soundName.select_menu); }
    }
}

function storyview(){
	if(inputkey == keyboard.enter || inputkey == keyboard.right){
		optionbattle.sound.play(soundName.select_move);
		page++;
	} else if(inputkey == keyboard.left && page > 0){
		optionbattle.sound.play(soundName.select_move);
		page--;
	} else if(inputkey == keyboard.esc){
		optionbattle.sound.play(soundName.select_back);
		modeChange(modeName.story);
	}
	
	if(page >= option_battle.story[menu].get_text_length()){
		modeChange(modeName.story);
	} 
}

//게임 진행 함수//
this.process = function(){
    switch(modeCheck()){
        case modeName.title: title(); break;
        case modeName.option: option(); break;
        case modeName.main: main(); break;
        case modeName.inventory: inventory(); break;
        case modeName.party: party(); break;
        case modeName.unitselect: unitselect(); break;
        case modeName.unitview: unitview(); break;
        case modeName.dungeon: dungeon(); break;
        case modeName.round: round(); break;
        case modeName.loading: loading(); break;
        case modeName.field: field(); break;
        case modeName.story: story(); break;
        case modeName.storyview: storyview(); break;
        case modeName.titlethema: titlethema(); break;
    }
    inputkey = 0; // 누른 키 초기화;
};

//---------------------//
}//function Game
optionbattle.game = new Game(); // 게임 객체 생성




/*function game_combination()
{
	background_combination.display();
	inventory_check();
	if(gamekey == keyboard.esc){ // X key
		sound_output("select_back");
		if(background_combination.mode==1) background_combination.mode=0;
		else gamestatus = gamemode.main;
	}
	else if(gamekey == 38){ // UP
		sound_output("select_move");
		if(background_combination.mode==0&&background_combination.round>1) background_combination.round--;
	}
	else if(gamekey == 40){ // DOWN
		sound_output("select_move");
		if(background_combination.mode==0&&background_combination.round<7) background_combination.round++;
	}
	else if(gamekey == 37){ // LEFT
		sound_output("select_move");
		if(background_combination.mode==1&&background_combination.select>0) background_combination.select--;
	}
	else if(gamekey == 39){ // RIGHT
		sound_output("select_move");
		if(background_combination.mode==1&&background_combination.select<8) background_combination.select++;
	}
	else if(gamekey == 13){
		if(background_combination.mode==0){
			background_combination.mode=1;
		}
		else if(background_combination.mode==1){
			if(background_combination.select!=0&&confirm("정말로 조합하시겠습니까?")){
				if(user.gold < combination[background_combination.select].gold){
					alert("골드가 부족하여 조합할 수 없습니다.");
				}
				else{
				    combination_progress();
				}
			}
		}
	}
}
function combination_progress()
{
	var make=0;
	var material = new Array(6);
	var delete_item = new Array(6);
	var a=0;
	for(a=0;a<6;a++){
		material[a] = combination[background_combination.select].material[a];
		if(material[a]==0){ delete_item[a]=null; make++; continue; }
					    
		for(b=0;b<user.inventory_max;b++){
			var type = user.inventory[b][inventoryoption.type];
			if(type!=inventory_type.item) continue;
					    	
			if(material[a]==user.inventory[b][inventoryoption.code]){
			var ok=0;
			for(c=0;c<6;c++){
			    if(delete_item[c]==b) ok++;
			}
			        	    	
			if(ok>0) {}
			else { make++; delete_item[a]=b; break; }
			    }
			}
	}
			        
	if(make<=5){
		alert("재료가 부족하여 조합할 수 없습니다.");
	}
	else{
		alert("조합이 완료되었습니다.");
	var result_unit = combination[background_combination.select].result[1];
	var result_type = combination[background_combination.select].result[0];
	user.inventory[user.inventory_use+1][inventoryoption.type] = result_type;
	user.inventory[user.inventory_use+1][inventoryoption.code] = result_unit;
	user.gold -= combination[background_combination.select].gold;
			        	
	for(a=0;a<6;a++){
		if(delete_item[a]!=null){
			user.inventory[delete_item[a]][0] = 0;
			user.inventory[delete_item[a]][1] = 0;
			user.inventory[delete_item[a]][2] = 0;
			user.inventory[delete_item[a]][3] = 0;
			user.inventory[delete_item[a]][4] = 0;
		    }
	    }
    }
}  */