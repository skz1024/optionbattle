function User(strName){
//function User start
//-----------------------------//
var name = strName; // 유저의 이름, 생성될 때 선언
var lv = 1, maxLv = 20, exp = 0; // 레벨, 최대레벨, 경험치
var fuel = 1000, fuelMax = 1000; // 연료, 연료최대치
var gold = 100000, crystal = 10; // 골드(게임머니), 크리스탈(현질...)

//각 스탯들을 리턴하는 함수는 get 메서드에 정의한다.
this.getname = function(){  return name; };
this.getlv = function(){  return lv; };
this.getmaxLv = function(){  return maxLv; };
this.getexp = function(){  return exp; };
this.getfuel = function(){  return fuel; };
this.getfuelMax = function(){  return fuelMax; };
this.getcrystal = function(){  return crystal; };
this.getgold = function(){  return gold; };

//각 스탯들의 능력치를 추가하거나 감소하거나 변경하는 함수들
//plus : 더하기(증가), minus : 빼기(감소), set : 변경
this.plusgold = function(value){  gold += value; };
this.minusgold = function(value){  gold -= value; };
this.setgold = function(value){  gold = value; };
this.plusfuel = function(value){  fuel += value;  if(fuel >= fuelmax) fuel = fuelmax; };
this.minusfuel = function(value){  fuel -= value;  if(fuel <= 0)  fuel = 0;  };
this.setfuel = function(value){  fuel = value;  if(fuel >= fuelMax) fuel = fuelMax; }; 
this.pluscrystal = function(value){  crystal += value; };
this.minuscrystal = function(value){  crystal -= value; };
this.plusexp = function(value){ // 경험치 추가 함수(감소함수는 없음)
	exp += value;
	if(exp >= optionbattle.game.getexpTable(lv)){ // 경험치 초과되는지 체크
		for(;;){ // 초과가 될경우
			if( lv >= maxLv && exp >= optionbattle.game.getexpTable(lv)){ lv = maxlv;  exp = optionbattle.game.getexpTable(lv);  break; }
			else if( exp <= optionbattle.game.getexpTable(lv) )  break;
			else{  exp -= optionbattle.game.getexpTable(lv);  lv++;  }
		}
	}
};


function Teamunit(){
	const teamunitMax = 12;
	var data = new Array(teamunitMax);
	for(var a = 0; a < data.length; a++){
		data[a] = -1; // 팀유닛은 인벤토리 번호만 저장함
	}
	
	this.getteamunit = function(index){
		if(index == null || index < 0)  return data;
		else  return data[index];
	};
	
	this.getteamunitinventory = function(index){
		var value = data[index];
		if(index == null || index < 0){  alert("잘못된 인수의 값을 사용하였습니다."); }
		else{  return optionbattle.user.inventory.getdata(index);  }
	};
	
	this.setteamunit = function(index, inventoryNumber){
		data[index] = inventoryNumber;
	};
}

function Inventory(){
	const inventoryMaxCount = 1000;
	var data = new Array(inventoryMaxCount);
	for(var a = 0; a < data.length; a++){  data[a] = new InventoryArray(); }
	var useCount = 0;
	
	function InventoryArray(){
		this.type = "";
		this.code = 0;
		this.rank = 0;
		this.lv = 0;
		this.team = 0;
	}
	
	this.getdata = function(index){  return data[index]; };
	this.gettype = function(index){  return data[index].type; };
	this.getcode = function(index){  return data[index].code; };
	this.getrank = function(index){  return data[index].rank; };
	this.getlv = function(index){  return data[index].lv; };
	this.getteam = function(index){  return data[index].team; };
	this.setteam = function(index, value){  data[index].team = value;  };
	this.getinventoryMaxCount = function(){  return inventoryMaxCount; };
	
	this.isfull = function(){
		//주의: useCount는 인벤토리가 꽉찼는지 판단하지 못함.
		for(var a = 0; a < data.length; a++){
			//데이터의 타입이 ""일경우 해당 아이템은 없는것으로 간주함. 따라서 빈 아이템 공간이 됨.
			if(data[a].type == "")  return false;
		}
		
		return true; // 데이터의 최대치까지 조사했는데도 ""가 아무것도 없을경우 모든 아이템이 있다는 뜻이므로 true를 리턴
	};
	this.createdata = function(strType, code, rank, lv){
		if(this.isfull == true){  alert("인벤토리가 꽉 차 더이상 아이템을 생성할 수 없습니다."); return; }
		else if(strType == ""){  alert("아이템의 타입이 정의되지 않으면 아이템을 생성할 수 없습니다."); return; }
		else if(useCount >= data.length) {
			this.spacedelete();
		}
		
		data[useCount].type = strType;
		data[useCount].code = code;
		data[useCount].rank = rank;
		data[useCount].lv = lv;
		useCount++;
	};
	this.setdata = function(index, strType_Or_Data, code, rank, lv){
		if(arguments.length == 2){ //strType부분에 data와 일치하는 객체가 사용된경우
			data = strType_Or_Data;
		} else {
			data[index].type = strType_Or_Data;
    		data[index].code = code;
    		data[index].rank = rank;
    		data[index].lv = lv;
		}
		
	};
	this.deletedata = function(index){
		data[index].type = "";
		data[index].code = 0;
		data[index].rank = 0;
		data[index].lv = 0;
	};
	
	this.spacedelete = function(index){
		var process = 0;
		for(var a = 0, process = 0; a < data.length; a++){
			if(data[a].type != ""){  process++;  }
		} // 현재 가지고 있는 아이템의 수를 조사
		
		for(var a = 0, b = 0; a < data.length || b < process; a++){
			// a = 조사하는 데이터 번호, b = 진행 구간
			if(a == process && data[a].type != ""){
				b++;  continue; // 진행 구간을 더하고 그대로 넘어감
			} else if(data[a].type != ""){
				this.setdata(b, data[a]);
				b++; // 진행 구간을 더하고 아이템의 위치를 변경
			}
		} // 해당 for문에서 빈 공간 전부 삭제
		
		for(var a = process; a < data.length; a++){
			this.deletedata(a);
		} // 남은 공간에 있는 아이템은 전부 삭제
	};
}
this.inventory = new Inventory();
this.teamunit = new Teamunit();

for(var a = 0; a < 12; a++){
	this.inventory.createdata("unit", a+1, 0, 0);
	this.teamunit.setteamunit(a, a);
}
//-------------------------------//
} // function end;

optionbattle.user = new User("user"); // 유저란 이름을 사용하는 유저 객체 생성