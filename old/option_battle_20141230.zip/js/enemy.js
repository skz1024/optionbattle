function Enemy(){
//function start
var createCount = 0;
function create(strName, attack, defense, hp, score, constDiesound, strDiemotion){
	this.name = strName;
	this.number = createCount;
	this.attack = attack;
	this.defense = defense;
	this.hp = hp;
	this.score = score;
	this.diesound = constDiesound;
	this.diemotion = strDiemotion || "out";
	
	this.image = new Image();
	this.image.src = "";
	
	this.speedx = 5;
	this.speedy = 5;
	this.technical = "";
	this.skill = "";
	createCount++;
}
create.prototype.display = function(x, y, width, height)
{
	if( width == null || height == null )
        ctx.drawImage(this.image, x, y);
    else
        ctx.drawImage(this.image, x, y, width, height);
};
create.prototype.advanced = function(speedx, speedy, moveType, technical, skill){
	this.speedx = speedx;
	this.speedy = speedy;
	this.moveType = moveType || "";
	this.technical = technical || "";
	this.skill = skill || "";
};

var data = new Array(100);

data[0] = new create("unused", 0, 0, 0, 0, 0, soundName.select_none, "");
data[0].image.src = "image/system/unused.png";
//-------------------------------------//
data[1] = new create("약한 빨간색 빛", 2, 10, 20000, 40, soundName.light_break, "out");  
data[2] = new create("약한 주황색 빛", 2, 10, 20000, 40, soundName.light_break, "out");  
data[3] = new create("약한 초록색 빛", 2, 10, 20000, 40, soundName.light_break, "out");  
data[4] = new create("약한 파란색 빛", 2, 10, 20000, 40, soundName.light_break, "out");  
data[5] = new create("약한 노란색 빛", 2, 10, 20000, 40, soundName.light_break, "out");
for(var a = 1; a <= 5; a++)  data[a].advanced(12, 12);
data[6] = new create("하얀색 운석", 11, 20, 25000, 44, soundName.light_break, "out");  
data[7] = new create("회색의 운석", 11, 55, 24000, 45, soundName.light_break, "out");  
data[8] = new create("갈색의 운석", 11, 30, 27000, 46, soundName.light_break, "out");  
data[9] = new create("핑크색 운석", 11, 50, 26000, 47, soundName.light_break, "out");  
data[10] = new create("청록색 운석", 11, 40, 28000, 48, soundName.light_break, "out");  
data[11] = new create("대형 운석", 198, 120, 823000, 1380, soundName.light_break, "out");  
//-------------------------------//
data[12] = new create("평범한 파란색 동그라미", 20, 60, 35000, 70, soundName.dongrami_fail);
data[13] = new create("어두운 파란색 동그라미", 20, 62, 35600, 72, soundName.dongrami_fail);
data[14] = new create("밝은빛 파란색 동그라미", 21, 63, 36332, 74, soundName.dongrami_fail);
data[15] = new create("평범한 하늘색 동그라미", 22, 64, 37000, 76, soundName.dongrami_fail);
data[16] = new create("어두운 하늘색 동그라미", 23, 65, 37755, 78, soundName.dongrami_fail);
data[17] = new create("밝은빛 하늘색 동그라미", 24, 67, 38426, 81, soundName.dongrami_fail);
data[18] = new create("평범한 초록색 동그라미", 24, 69, 39132, 83, soundName.dongrami_fail);
data[19] = new create("어두운 초록색 동그라미", 25, 70, 39959, 85, soundName.dongrami_fail);
data[20] = new create("밝은빛 초록색 동그라미", 26, 71, 40800, 87, soundName.dongrami_fail);
data[21] = new create("평범한 연두색 동그라미", 26, 73, 41540, 89, soundName.dongrami_fail);
data[22] = new create("어두운 연두색 동그라미", 27, 74, 42257, 92, soundName.dongrami_fail);
data[23] = new create("밝은빛 연두색 동그라미", 27, 75, 43000, 94, soundName.dongrami_fail);
//-------------------------------//
data[24] = new create("평범한 노란색 동그라미", 27, 76, 43535, 97, soundName.dongrami_fail);
data[25] = new create("어두운 노란색 동그라미", 27, 77, 44169, 101, soundName.dongrami_fail);
data[26] = new create("밝은빛 노란색 동그라미", 28, 79, 44820, 103, soundName.dongrami_fail);
data[27] = new create("평범한 주황색 동그라미", 29, 80, 45100, 104, soundName.dongrami_fail);
data[28] = new create("어두운 주황색 동그라미", 30, 82, 45780, 105, soundName.dongrami_fail);
data[29] = new create("밝은빛 주황색 동그라미", 30, 83, 46182, 107, soundName.dongrami_fail);
data[30] = new create("평범한 분홍색 동그라미", 31, 85, 46930, 110, soundName.dongrami_fail);
data[31] = new create("어두운 분홍색 동그라미", 32, 86, 47530, 112, soundName.dongrami_fail);
data[32] = new create("밝은빛 분홍색 동그라미", 33, 87, 48000, 113, soundName.dongrami_fail);
data[33] = new create("평범한 주황색 동그라미", 34, 89, 49150, 115, soundName.dongrami_fail);
data[34] = new create("어두운 주황색 동그라미", 35, 90, 49657, 117, soundName.dongrami_fail);
data[35] = new create("밝은빛 주황색 동그라미", 36, 92, 50000, 118, soundName.dongrami_fail);
//-------------------------------//
data[36] = new create("하얀색 동그라미", 40, 110, 71000, 140, soundName.dongrami_fail);
data[37] = new create("회색 동그라미  ", 42, 115, 72430, 142, soundName.dongrami_fail);
data[38] = new create("검은색 동그라미", 44, 120, 74470, 144, soundName.dongrami_fail);
data[39] = new create("분파색 동그라미", 55, 130, 76030, 146, soundName.dongrami_fail);
data[40] = new create("보초색 동그라미", 55, 135, 78257, 149, soundName.dongrami_fail);
data[41] = new create("노갈색 동그라미", 55, 140, 79000, 152, soundName.dongrami_fail);
//-------------------------------//
data[42] = new create("대형 동그라미", 367, 780, 851300, 1670, soundName.dongrami_fail);

//-------------------------------//
for(var a = 1; a <= 42; a++)  data[a].image.src = "image/enemy/enemy"+"["+a+"]"+".png";


this.getname = function(code){  return data[code].name; };
this.getnumber = function(code){  return data[code].number; };
this.getattack = function(code){  return data[code].attack; };
this.getdefense = function(code){  return data[code].defense; };
this.gethp = function(code){  return data[code].hp; };
this.getscore = function(code){  return data[code].score; };
this.gettechnical = function(code){  return data[code].technical; };
this.getskill = function(code){  return data[code].skill; };
this.getdiesound = function(code){  return data[code].diesound; };
this.getdiemotion = function(code){  return data[code].diemotion; };
this.getspeedx = function(code){  return data[code].speedx; };
this.getspeedy = function(code){  return data[code].speedy; };
this.display = function(code, x, y, width, height){  data[code].display(x, y, width, height); };
this.getimage = function(code){  return data[code].image; };
//-------------------------//
}//function Enemy end

optionbattle.enemy = new Enemy();




