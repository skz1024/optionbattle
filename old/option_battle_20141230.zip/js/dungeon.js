const dungeonName = {  파란행성_Part1:0,  파란행성_Part2:1, 파란행성_Part3:2 };

function Dungeon(){
//function Dungeon Start
function create(stringName, chapter, part, maxRoundCount){
	this.round = new Array(maxRoundCount);
	this.roundCount = -1; // 라운드카운트가 -1일경우 라운드가 아무것도 없는 상태를 의미, 라운드는 0번부터 시작
	this.name = stringName; // 던전 이름
	this.chapter = chapter; // 챕터의 번호
	this.part = part; // 파트의 번호
	this.maxRoundCount = maxRoundCount; // 라운드의 최대 카운트
	
	function Round(strName, enemyCount, time, mapScore, constMusic){
		this.number = this.roundCount; // 라운드카운트가 현재 라운드 번호를 지정
		this.name = strName; // 라운드 이름
		this.enemyCount = enemyCount; // 적의 개수
		this.mapScore = mapScore; // 맵의 점수(참고: 클리어보너스 = 맵점수 * 제한시간)
		this.time = time; // 제한시간
		this.music = constMusic; // 음악(음악 이름은 musicName에 상수로 정의한것을 사용.)
		this.enemylist = [0]; // 적의 리스트, 코드로 작성하며 배열의 형태
		this.boss = 0; // 보스, 적의 코드랑 공유, 보스가 0일경우 보스는 없음.
		this.item = [0]; // 던전을 클리어할시 획득하는 아이템  목록
		this.enemyMax = 30; // 해당 라운드에서 적이 몇마리까지 나올것인가를 결정하는 함수, 기본값은 30 
		//------------------------//
		this.image = new Image(); // 백그라운드 이미지(배경화면)
		this.isscrollx = false; // x좌표 스크롤 여부
		this.isscrolly = false; // y좌표 스크롤 여부
		this.scrollspeedx = 0; // x좌표 스크롤 속도
		this.scrollspeedy = 0; // y좌표 스크롤 속도
	};
	
	this.createround = function(strName, enemyCount, timeLimit, mapScore, constMusicName){
		this.roundCount++;
		this.round[this.roundCount] = new Round(strName, enemyCount, timeLimit, mapScore, constMusicName);
	};
	this.setround = function(arrayEnemylist, enemyMax, bossCode, arrayGetItem){
		this.round[this.roundCount].enemylist = arrayEnemylist;
		this.round[this.roundCount].enemyMax = enemyMax;
		this.round[this.roundCount].boss = bossCode;
		this.round[this.roundCount].item = arrayGetItem;
	};
	this.setmap = function(image_src, isscrollx, isscrolly, scrollspeedx, scrollspeedy){
		this.round[this.roundCount].image.src = image_src;
		this.round[this.roundCount].isscrollx = isscrollx;
		this.round[this.roundCount].isscrolly = isscrolly;
		this.round[this.roundCount].scrollspeedx = scrollspeedx;
		this.round[this.roundCount].scrollspeedy = scrollspeedy;
	};
}



//주의: set메소드의 적용 라운드는 다음 create구문 나오기 전 라운드에 해당.
//create으로 30번째 라운드를 만들고 바로 set메소드를 쓰면 30번째 라운드가 설정됨.
var dungeon = new Array(10); // 던전를 저장하는 배열 생성

//파란 행성 Part 1 - 1. 파란 행성으로의 출발
dungeon[0] = new create("파란 행성 Part 1", 1, 1, 48);
dungeon[0].createround("우주 비행 경로 1", 200, 120, 100, musicName.music01);
dungeon[0].setround([1,2,3,4,5], 30, 0, 0);
dungeon[0].setmap("image/background/test.png", false, false, 0, 0);
dungeon[0].createround("우주 비행 경로 2", 250, 140, 102, musicName.music01);
dungeon[0].setround([1,2,3,4,5], 30, 0, 0);
dungeon[0].setmap("image/background/round1_image1.png", false, false, 0, 0);
dungeon[0].createround("우주 비행 경로 3", 270, 160, 115, musicName.music01);
dungeon[0].setround([6,7,8,9,10], 30, 0, 0);
dungeon[0].setmap("image/background/round1_image1.png", false, false, 0, 0);
dungeon[0].createround("우주 비행 경로 4", 220, 160, 115, musicName.music01);
dungeon[0].setround([6,7,8,9,10], 30, 11, 0);
dungeon[0].setmap("image/background/round1_image1.png", false, false, 0, 0);
dungeon[0].createround("파란행성 진입구간", 90, 83, 115, musicName.music01);
dungeon[0].setround([6,7,8,9,10], 30, 0, 0);
dungeon[0].setmap("image/background/round1_image2.png", false, false, 0, 0);
dungeon[0].createround("파란행성 하늘 구역 / 높이: 300km", 150, 180, 140, musicName.music02_paran_planet);
dungeon[0].setround([12,13,14], 15, 0, 0);
dungeon[0].setmap("image/background/round1_image3.png", false, false, 0, 0);
dungeon[0].createround("파란행성 하늘 구역 / 높이: 280km", 163, 180, 147, musicName.music02_paran_planet);
dungeon[0].setround([12,13,14,15,16,17], 21, 0, 0);
dungeon[0].setmap("image/background/round1_image4.png", false, false, 0, 0);
dungeon[0].createround("파란행성 하늘 구역 / 높이: 260km", 177, 180, 154, musicName.music02_paran_planet);
dungeon[0].setround([12,13,14,15,16,17], 25, 0, 0);
dungeon[0].setmap("image/background/round1_image5.png", false, false, 0, 0);
// 파란행성 Part 1 - 2. 동그라미 마을
dungeon[0].createround("동그라미 마을 입구", 60, 80, 200, musicName.music03_donggrami_maeul);
dungeon[0].setround([12,13,14,15,16,17,18,19,20,21,22,23], 38, 0, 0);
dungeon[0].setmap("image/background/round1_image5.png", false, false, 0, 0);
dungeon[0].createround("동그라미 아파트 1단지", 240, 203, 212, musicName.music03_donggrami_maeul);
dungeon[0].setround([12,13,14,15,16,17,18,19,20,21,22,23], 50, 0, 0);
dungeon[0].setmap("image/background/round1_image8.png", false, false, 0, 0);
dungeon[0].createround("동그라미 아파트 2단지", 251, 212, 212, musicName.music03_donggrami_maeul);
dungeon[0].setround([12,13,14,15,16,17,18,19,20,21,22,23], 50, 0, 0);
dungeon[0].setmap("image/background/round1_image8.png", false, false, 0, 0);
dungeon[0].createround("마을 회관", 1, 90, 220, musicName.none);
dungeon[0].setround([42], 1, 0, 0);
dungeon[0].setmap("image/background/round1_image6.png", false, false, 0, 0);
dungeon[0].createround("수많은 동그라미", 140, 210, 225, musicName.none);
dungeon[0].setround([12,13,14,15,16,17,18,19,20,21,22,23], 30, 42, 0);
dungeon[0].setmap("image/background/round1_image6.png", false, false, 0, 0);

//---------------------//

// 단축 용어 설명
// D: constDungeonName, R: roundNumber // D: 던전번호, R: 라운드번호, 타이핑 하는 글자길이가 너무 길어서 이렇게 축약함.
this.getname = function(D){  return dungeon[D].name; };
this.getchapter = function(D){  return dungeon[D].chapter; };
this.getpart = function(D){  return dungeon[D].part; };
this.getroundCount = function(D){  return dungeon[D].roundCount; };
this.getmaxRoundCount = function(D){  return dungeon[D].maxRoundCount; };
this.getcount = function(){  return dungeon.length; };
this.getroundname = function(D, R){  return dungeon[D].round[R].name; };
this.getroundenemyCount = function(D, R){  return dungeon[D].round[R].enemyCount; };
this.getroundmapScore = function(D, R){  return dungeon[D].round[R].mapScore; };
this.getroundtime = function(D, R){  return dungeon[D].round[R].time; };
this.getroundmusic = function(D, R){  return dungeon[D].round[R].music; };
this.getroundenemylist = function(D, R){  return dungeon[D].round[R].enemylist; };
this.getroundboss = function(D, R){  return dungeon[D].round[R].boss; };
this.getrounditem = function(D, R){  return dungeon[D].round[R].item; };
this.getroundenemyMax = function(D, R){  return dungeon[D].round[R].enemyMax; };
this.getroundimage = function(D, R){  return dungeon[D].round[R].image; };
this.getroundisscrollx = function(D, R){  return dungeon[D].round[R].isscrollx; };
this.getroundisscrolly = function(D, R){  return dungeon[D].round[R].isscrolly; };
this.getroundscrollspeedx = function(D, R){  return dungeon[D].round[R].scrollspeedx; };
this.getroundscrollspeedy = function(D, R){  return dungeon[D].round[R].scrollspeedy; };
//------------------//
};//function Dungeon end

optionbattle.dungeon = new Dungeon(); //던전 생성

