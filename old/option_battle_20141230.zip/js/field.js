function Field(){
// function start //

// 상속을 위해 만들어진 클래스
function BaseClass(){
	this.data = new Array(100);
	for(var a = 0; a < this.data.length; a++)  this.data[a] = new SubClass();
	
	var data = this.data; // this.data를 data변수에 넣어서 data를 this.data처럼 사용
}
//변수를 얻어오는 함수
BaseClass.prototype.getdatalength = function(){  return this.data.length; };
BaseClass.prototype.getx = function(index){  return this.data[index].x; };
BaseClass.prototype.gety = function(index){  return this.data[index].y; };
BaseClass.prototype.getisusing = function(index){  return this.data[index].isusing; };
BaseClass.prototype.gettype = function(index){  return this.data[index].type; };
BaseClass.prototype.getcode = function(index){  return this.data[index].code; };
BaseClass.prototype.getattack = function(index){  return this.data[index].attack; };
BaseClass.prototype.getdefense = function(index){  return this.data[index].defense; };
BaseClass.prototype.getcount = function(index){  return this.data[index].count; };
BaseClass.prototype.getdelay = function(index){  return this.data[index].delay; };
BaseClass.prototype.getcolor = function(index){  return this.data[index].color; };
BaseClass.prototype.getspeedx = function(index){  return this.data[index].speedx; };
BaseClass.prototype.getspeedy = function(index){  return this.data[index].speedy; };
BaseClass.prototype.getmovex = function(index){  return this.data[index].movex; };
BaseClass.prototype.getmovey = function(index){  return this.data[index].movey; };
BaseClass.prototype.gethp = function(index){  return this.data[index].hp; };
BaseClass.prototype.getmaxhp = function(index){  return this.data[index].maxhp; };

// 변수를 설정하는 함수
BaseClass.prototype.setx = function(index, value){  this.data[index].x = value; };
BaseClass.prototype.sety = function(index, value){  this.data[index].y = value; };
BaseClass.prototype.setisusing = function(index, isBoolean){  this.data[index].isusing = isBoolean; };
BaseClass.prototype.settype = function(index, constType){  this.data[index].type = constType; };
BaseClass.prototype.setcode = function(index, value){  this.data[index].code = value; };
BaseClass.prototype.setattack = function(index, value){  this.data[index].attack = value; };
BaseClass.prototype.setdefense = function(index, value){  this.data[index].defense = value; };
BaseClass.prototype.setcount = function(index, value){  this.data[index].count = value; };
BaseClass.prototype.setdelay = function(index, value){  this.data[index].delay = value; };
BaseClass.prototype.setcolor = function(index, string){  this.data[index].color = string; };
BaseClass.prototype.setspeedx = function(index, value){  this.data[index].speedx = value; };
BaseClass.prototype.setspeedy = function(index, value){  this.data[index].speedy = value; };
BaseClass.prototype.setmovex = function(index, value){  this.data[index].movex = value; };
BaseClass.prototype.setmovey = function(index, value){  this.data[index].movey = value; };
BaseClass.prototype.sethp = function(index, value){  this.data[index].hp = value; };
BaseClass.prototype.setmaxhp = function(index, value){  this.data[index].maxhp = value; };

// 일종의 인터페이스 함수?
BaseClass.prototype.init = function(){}; // 초기화 함수
BaseClass.prototype.process = function(){}; // 처리 함수
BaseClass.prototype.display = function(){}; // 표시(화면에 그림 출력) 함수
BaseClass.prototype.create = function(index){}; // 내부 데이터 생성함수(주의: 동적 생성이 아님)
BaseClass.prototype.delete = function(index){}; // 내부 데이터 초기화함수(주의: 객체를 삭제하는게 아님)

// 베이스 클래스 내부 데이터의 상속을 위해 만들어진 클래스
function SubClass(){
	this.x = 0; // x좌표
	this.y = 0; // y좌표
	this.isusing = false; // 사용중인지 판단하는 변수
	this.type = 0; // 타입 번호
	this.code = 0; // 코드(용도에 따라서 다르게 쓰일 수 있음.)
	this.attack = 0; // 공격력
	this.defense = 0; // 방어력
	this.hp = 0; // 체력
	this.maxhp = 0; // 최대체력
	this.count = 0; // 카운트
	this.delay = 0; // 딜레이(지연시간 / 프레임단위)
	this.color = "#000000"; // 색깔: html코드 또는 스트링?으로 결정
	this.speedx = 0; // x좌표 속도 기준점
	this.speedy = 0; // y좌표 속도 기준점
	this.movex = 0; // 이동되는 속도
	this.movey = 0; // 이동되는 속도
	this.combo = 0; // 콤보 또는 타격 수
}



// class Force
function Force(){
	function ForceArray(){
		this.attack = 0;   this.attackTechnical = 0;   this.attackSkill = 0; // 공격력 관련 수치
		this.delay = 0;    this.delayTechnical = 0;    this.delaySkill = 0; // 딜레이 관련 수치
		this.count = 0;    this.countTechnical = 0;    this.countSkill = 0; // 카운트 관련 수치
		this.techshot = 0; this.techshotLeft = 0;  this.techshotCount = 0;  this.techshotDelay = 5; // 테크니컬(공격횟수) 관련 수치
	}  ForceArray.prototype = new SubClass();
	
	var data = this.data; // 데이터의 객체를 복사
	data.length = 12; // 배열의 개수를 12개로 강제로 변경
	for(var a = 0; a < data.length; a++)  data[a] = new ForceArray();
	
	this.getattackTechnical = function(index){  return data[index].attackTechnical; };
	this.getattackSkill     = function(index){  return data[index].attackSkill; };
	this.getdelayTechnical  = function(index){  return data[index].delayTechncial; };
	this.getdelaySkill      = function(index){  return data[index].delaySkill; };
	this.getcountTechncial  = function(index){  return data[index].countTechnical; };
	this.getcountSkill      = function(index){  return data[index].countSkill; };
	
	function setForce(){
		for(var a = 0; a < data.length; a++){
			var teamunit = optionbattle.user.teamunit.getteamunitinventory(a);
			var code = teamunit.code;
			var lv = teamunit.lv;
			data[a].attack          = optionbattle.unit.getattack(code, lv);
			data[a].attackTechnical = optionbattle.unit.getattackTechnical(code, lv);
			data[a].attackSkill     = optionbattle.unit.getattackSkill(code, lv);
			data[a].delay           = optionbattle.unit.getdelay(code);
			data[a].delayTechnical  = optionbattle.unit.getdelayTechnical(code);
			data[a].delaySkill      = optionbattle.unit.getdelaySkill(code);
			data[a].techshot        = optionbattle.unit.gettechshot(code);
			data[a].techshotDelay   = optionbattle.unit.gettechshotdelay(code);
			data[a].count           = 0;
			data[a].countTechnical  = 0;
			data[a].countSkill      = 0;
			data[a].hp              = optionbattle.unit.gethp(code, lv);
			data[a].type            = optionbattle.unit.gettype(code);
			data[a].x               = 10 + (80 * (a%3));
			data[a].y               = 120 + (70 * Math.floor(a/3));
			data[a].code            = code;
		}
	};
	
	function countUp(){  // 해당 유저의 유닛의 카운트 증가, 단 딜레이가 0일경우는 카운트가 증가하지 않음.
	  for(var a = 0; a < data.length; a++){
		if(data[a].count          < data[a].delay)         {  data[a].count++; }
		if(data[a].countTechnical < data[a].delayTechnical){  data[a].countTechnical++; }
		if(data[a].countSkill     < data[a].delaySkill)    {  data[a].countSkill++; }
		if(data[a].techshotCount  < data[a].techshotDelay) {  data[a].techshotCount++; }
	  }
	}
	
	function attackCheck(){
	  for(var a = 0; a < data.length; a++){
	  	
		// 일반 공격 처리
		if(data[a].count >= data[a].delay && data[a].delay != 0){  
			data[a].count -= data[a].delay; // 카운트는 딜레이만큼 감소
			attack.create(data[a].code, "normal", data[a].attack, data[a].type, data[a].x, data[a].y);
			optionbattle.unit.attackSoundPlay(data[a].code); // 사운드 재생
		}
		
		// 테크니컬 공격 처리
		if(data[a].countTechnical >= data[a].delayTechnical && data[a].delayTechnical != 0){  
			data[a].countTechnical -= data[a].delayTechnical; // 카운트테크니컬는 딜레이테크니컬만큼 감소
			data[a].techshotLeft += data[a].techshot; // 테크샷을 증가시켜 테크니컬로 공격함.
			
			// 화이트 플래시 타입의 경우, 공격 사운드를 여기서 처리(중복 출력 방지용)
			if(data[a].type == typeName.whiteflash)  optionbattle.unit.attackSoundPlay(data[a].code);
		}
		
		// 스킬 공격(사실상 미구현)
		if(data[a].countSkill >= data[a].delaySkill && data[a].delaySkill != 0 ){  
			data[a].countSkill -= data[a].delaySkill;
			attack.create(data[a].code, "skill", data[a].attackSkill, data[a].type, data[a].x, data[a].y);
			optionbattle.unit.attackSkillSoundPlay(data[a].code);
		}
		
		// 테크니컬 공격시 테크샷이 1 이상일 경우 처리되는 함수
		if(data[a].techshotCount >= data[a].techshotDelay && data[a].techshotLeft > 0){
			data[a].techshotLeft--; // 테크샷 남은갯수 감소
			data[a].techshotCount -= data[a].techshotDelay; // 카운트테크샷은 딜레이테크샷만큼 감소
			
			attack.create(data[a].code, "technical", data[a].attackTechnical, data[a].type, data[a].x, data[a].y);
			optionbattle.unit.attackTechnicalSoundPlay(data[a].code);
		}
	  }// for end
	}// function end
	
	this.init = function(){  setForce();  }; // 초기화 함수
	this.process = function(){  countUp();  attackCheck(); }; // 진행, 처리 함수
	this.display = function(){ // 출력함수
		for(var a = 0; a < this.data.length; a++){
			ctx.drawImage(optionbattle.unit.getimage(data[a].code), data[a].x, data[a].y);
			
			var percentNormal = data[a].count / data[a].delay;
			var percentTechnical = data[a].countTechnical / data[a].delayTechnical;
			var percentSkill = data[a].countSkill / data[a].delaySkill;
			
			ctx.fillStyle = "#a1ab9e";
			ctx.fillRect(data[a].x, data[a].y+50, 70, 5);
			ctx.fillRect(data[a].x, data[a].y+55, 70, 5);
			ctx.fillRect(data[a].x, data[a].y+60, 70, 5);
			
			ctx.strokeStyle = "black";
			ctx.fillStyle = "orange";
			ctx.strokeRect(data[a].x, data[a].y+50, 70, 5);  ctx.fillRect(data[a].x, data[a].y+50, 70*percentNormal, 5);
			ctx.fillStyle = "skyblue";
			ctx.strokeRect(data[a].x, data[a].y+55, 70, 5);  ctx.fillRect(data[a].x, data[a].y+55, 70*percentTechnical, 5);
			ctx.fillStyle = "lightgreen";
			ctx.strokeRect(data[a].x, data[a].y+60, 70, 5);  ctx.fillRect(data[a].x, data[a].y+60, 70*percentSkill, 5);
		}
	};
}  Force.prototype = new BaseClass(); // 베이스 클래스 상속, 12개의 데이터 정의
//---------------------------------//

// class Attack
function Attack(){
	var data = this.data; // this.data객체를 참조복사하여 data처럼 사용
	for(var a = 0; a < data.length; a++)  data[a] = new AttackArray();
	
	function AttackArray(){
		this.target = 0; // 적을 타겟할 대상의 번호(적의 코드가 아님)
		this.mode = ""; // 공격을 한 유닛의 공격 정의 패턴(normal, technical, skill)
		this.combo = 0;
		this.moveon = true;
	}  AttackArray.prototype = new SubClass(); // 서브 클래스 상속
	
	// 변수를 얻어오는 함수
	this.gettarget = function(index){  return data[index].target; };
	this.getmode = function(inedx){  return data[index].mode; };
	this.getcombo = function(index){  return data[index].combo; };
	this.getmoveon = function(index){  return data[index].moveon; };
	
	// 변수를 설정하는 함수
	this.settarget = function(index, number){  data[index].target = number; };
	this.setmode = function(index, strMode){  data[index].mode = strMode; };
	this.setcombo = function(index, value){  data[index].combo = value; };
	this.setmoveon = function(index, isBoolean){  data[index].moveon = isBoolean; };
	
	function attackMove(){
		for(var a = 0; a < data.length; a++){
			if(data[a].moveon == false)  continue;
			
			var movesizex = (enemy.getx(data[a].target) - data[a].x) / 10;
			var movesizey = (enemy.gety(data[a].target) - data[a].y) / 5;
			if(enemy.getisusing(data[a].target) == false){
				movesizex = 10;  movesizey = 0;
			}
			
			
			if(movesizex <= 10 && movesizex >= 4)  movesizex = 10;
			else if(movesizex >= 4 && movesizex <= -4)  movesizex = 0;
			else if(movesizex <= -4)  movesizex = -10;
			
			if(movesizey <= 10 && movesizey >= 4)  movesizey = 10;
			else if(movesizey >= 4 && movesizey <= -4)  movesizey = 0;
			else if(movesizey <= -4)  movesizey = -10;
			
			if(data[a].type == typeName.whiteflash){
				movesizex = 15;
			} else if(data[a].type == typeName.laser && data[a].mode == "technical"){
				movesizex = 10;
				movesizey = 0;
			} else if(data[a].type == typeName.missile){
				movesizex = 10;
				movesizey = 0;
			} else if(data[a].type == typeName._3wayshot){
				movesizex = data[a].speedx;
				movesizey = data[a].speedy;
			}
			
			data[a].x += movesizex;
			data[a].y += movesizey;
			
			if(data[a].x >= 900 || data[a].y < -100 || data[a].y > 600)  attack.delete(a);
			if(data[a].type != typeName.laser && data[a].x < -100)  attack.delete(a);
		}
	}
	
	function targetAttack(){
	  for(var a = 0; a < data.length; a++){ // 데이터의 최대치까지 조사
		if(data[a].isusing == false)  continue; //데이터를 사용하고 있지 않으면 처리를 건너 뜀
		if(enemy.getisusing(data[a].target) == false)  continue;
		//------------------//
		var enemyx = enemy.getx(data[a].target);
		var enemyy = enemy.gety(data[a].target);
		
		if(data[a].type == typeName.linelaser){
			for(var b = 0; b < enemy.getdatalength(); b++){
				if(enemy.getisusing(b) == false)  continue;
				
				enemyx = enemy.getx(b);
				enemyy = enemy.gety(b);
				if(data[a].y > enemyy - 20 && data[a].y < enemyy + 40){
					var damageValue = data[a].attack - enemy.getdefense(data[a].target);
					enemy.minushp(b, damageValue);
					damage.create(damageValue, enemy.getx(b), enemy.gety(b), data[a].type);
				}
			}
			
			attack.delete(a);
		} else if(data[a].type == typeName.missile || data[a].type == typeName._3wayshot){
			for(var b = 0; b < enemy.getdatalength(); b++){
				if(enemy.getisusing(b) == false)  continue;
				
				enemyx = enemy.getx(b);
				enemyy = enemy.gety(b);
				if(data[a].x > enemyx - 20 && data[a].x < enemyx + 60 && data[a].y > enemyy - 20 && data[a].y < enemyy + 60){
					var damageValue = data[a].attack - enemy.getdefense(data[a].target);
					enemy.minushp(b, damageValue);
					damage.create(damageValue, enemy.getx(b), enemy.gety(b), data[a].type);
					attack.delete(a);
					break;
				}
			}
		} else if(data[a].type == typeName.allarea){
			for(var b = 0; b < enemy.getdatalength(); b++){
				if(enemy.getisusing(b) == false)  continue;
				
				var damageValue = data[a].attack;
				enemy.minushp(b, damageValue);
				damage.create(damageValue, enemy.getx(b), enemy.gety(b), data[a].type);
			}
			attack.delete(a);
		} else if(data[a].type == typeName.bombrocket){  //타입이 봄미사일일경우
	   		if(data[a].combo == 9 && data[a].x > enemyx - 20 && data[a].x < enemyx + 60 && data[a].y > enemyy - 20 && data[a].y < enemyy + 60){
	   			var damageValue = data[a].attack - enemy.getdefense(data[a].target);
	   			if(damageValue <= 0)  damageValue = 1;
	   			enemy.minushp(data[a].target, damageValue);
	   			damage.create(damageValue, data[a].x, data[a].y, data[a].type);
	   			optionbattle.sound.play(soundName.bombattack);
	   			data[a].combo--;
	   			data[a].moveon = false;
	   		} else if(data[a].combo > 0 && data[a].combo <= 8 && data[a].count >= data[a].delay) {
	   			data[a].count -= data[a].delay;
	 			for(var b = 0; b < enemy.getdatalength(); b++){
	 				if(enemy.getisusing(b) == false)  continue; // 적의 데이터가 없으면 처리를 건너뜀
	 				
	 				var targetx = enemy.getx(b);
	 				var targety = enemy.gety(b);
	 				if(data[a].x - 100 <= targetx && data[a].x + 100 >= targetx && data[a].y - 100 <= targety && data[a].y + 100 >= targety){
	 					var damageValue = data[a].attack - enemy.getdefense(b);
	 					enemy.minushp(b, damageValue);
	 					damage.create(damageValue, targetx, targety, data[a].type);
	 				}
	 			}
	 			data[a].combo--;
	 			optionbattle.sound.play(soundName.bomb);
	   		} else if(data[a].combo == 0){
	   			attack.delete(a);
	   		} else {
	   			data[a].count++;
	   		}
	   		continue; // 반복문 처리를 건너 뜀.
		} else if(data[a].type == typeName.whiteflash){
			if(data[a].count >= data[a].delay){
				data[a].count -= data[a].delay;
				for(var b = 0; b < enemy.getdatalength(); b++){
		   			if(enemy.getisusing(b) == false)  continue; // 적의 데이터가 없으면 처리를 건너뜀
		   			
		   			var targetx = enemy.getx(b);
		   			var targety = enemy.gety(b);
		   			if(data[a].x - 40 <= targetx && data[a].x + 40 >= targetx && data[a].y - 40 <= targety && data[a].y + 40 >= targety){
		   				var damageValue = data[a].attack - enemy.getdefense(b);
		   				if(damageValue <= 0)  damageValue = 1;
		   				enemy.minushp(b, damageValue);
		   				damage.create(damageValue, targetx, targety, data[a].type);
		   			}
		   		}
			}
			data[a].count++;
		} else if(data[a].type == typeName.laser && data[a].mode == "technical"){
			if(data[a].count >= data[a].delay){
				data[a].count -= data[a].delay;
				for(var b = 0; b < enemy.getdatalength(); b++){
		   			if(enemy.getisusing(b) == false)  continue; // 적의 데이터가 없으면 처리를 건너뜀
		   			
		   			var targetx = enemy.getx(b);
		   			var targety = enemy.gety(b);
		   			if(data[a].x - 20 <= targetx && data[a].x + 650 >= targetx && data[a].y - 10 <= targety && data[a].y + 40 >= targety){
		   				var damageValue = data[a].attack - enemy.getdefense(b);
		   				if(damageValue <= 0)  damageValue = 1;
		   				enemy.minushp(b, damageValue);
		   				damage.create(damageValue, targetx, targety, data[a].type);
		   			}
		   		}
			}
			data[a].count++;
		} else if(data[a].type == typeName.splash2){
			for(var b = 0; b < enemy.getdatalength(); b++){
	   			if(enemy.getisusing(b) == false)  continue; // 적의 데이터가 없으면 처리를 건너뜀
	   			
	   			var targetx = enemy.getx(b);
	   			var targety = enemy.gety(b);
	   			if(data[a].x - 150 <= targetx && data[a].x + 150 >= targetx && data[a].y - 150 <= targety && data[a].y + 150 >= targety){
	   				var damageValue = data[a].attack - enemy.getdefense(b);
	   				if(damageValue <= 0)  damageValue = 1;
	   				enemy.minushp(b, damageValue);
	   				damage.create(damageValue, targetx, targety, data[a].type);
	   			}
	   		}
	   		attack.delete(a);
	   		optionbattle.sound.play(soundName.splashdamage);
		} else if(data[a].x > enemyx - 20 && data[a].x < enemyx + 60 && data[a].y > enemyy - 20 && data[a].y < enemyy + 60 ){
		   	if(data[a].type == typeName.splash){ // 타입이 스플래시일경우
		   		for(var b = 0; b < enemy.getdatalength(); b++){
		   			if(enemy.getisusing(b) == false)  continue; // 적의 데이터가 없으면 처리를 건너뜀
		   			
		   			var targetx = enemy.getx(b);
		   			var targety = enemy.gety(b);
		   			if(data[a].x - 150 <= targetx && data[a].x + 150 >= targetx && data[a].y - 150 <= targety && data[a].y + 150 >= targety){
		   				var damageValue = data[a].attack - enemy.getdefense(b);
		   				if(damageValue <= 0)  damageValue = 1;
		   				enemy.minushp(b, damageValue);
		   				damage.create(damageValue, targetx, targety, data[a].type);
		   			}
		   		}
		   		attack.delete(a);
		   		optionbattle.sound.play(soundName.splashdamage);
		   	} else {
		   		var damageValue = data[a].attack - enemy.getdefense(data[a].target);
		   		if(damageValue <= 0)  damageValue = 1;
		   		if(data[a].type == typeName.direct)  damageValue = data[a].attack;
		   		
		   		enemy.minushp(data[a].target, damageValue);
		   		damage.create(damageValue, data[a].x, data[a].y, data[a].type);
		   		attack.delete(a);
		   	}
		  }
		}// for // function end
	}
	
	function targetCheck(){
	  for(var a = 0; a < data.length; a++){
		if(enemy.getdied(data[a].target) == true || enemy.getisusing(data[a].target) == false){
			var targetCheckSuccess = false;
			for(var b = 0; b < 10; b++){
				data[a].target = Math.random () * enemy.getdatalength() | 0;
				if(enemy.getdied(data[a].target) == false && enemy.getisusing(data[a].target) == true){
					targetCheckSuccess = true;
					break;
				}
			}
			
			if(targetCheckSuccess == true)  continue;
			for(var b = 0; b < enemy.getdatalength(); b++){
				if(enemy.getisusing(data[a].target) == true && enemy.getdied(data[a].target) == false){
					data[a].target = b;
				}
			}
		}//if
	  }//for
	}
	
	this.init = function(){  for(var a = 0; a < data.length; a++)  data[a] = new AttackArray(); };
	this.create = function(code, strMode, attack, type, x, y, target, arrow){
		var arrayNumber = 0;
		for(var a = 0; a < data.length; a++){
			if(data[a].isusing == false)  arrayNumber = a; // 배열에 비어있는 공간이 있을경우 비어있는 번호를 리턴
		}
		if(arrayNumber >= data.length)  return;
		
		data[arrayNumber].code = code;
		data[arrayNumber].mode = strMode;
		data[arrayNumber].attack = attack;
		data[arrayNumber].type = type;
		data[arrayNumber].x = x;
		data[arrayNumber].y = y;
		data[arrayNumber].isusing = true;
		
		if(type == typeName.bombrocket){
			data[arrayNumber].combo = 9;
			data[arrayNumber].delay = 12;
		} else if(type == typeName.whiteflash){
			data[arrayNumber].delay = 4;
		} else if(type == typeName.laser && strMode == "technical"){
			targetCheck();
			data[arrayNumber].x = -600;
			data[arrayNumber].y = enemy.gety(data[arrayNumber].target);
			data[arrayNumber].delay = 7;
		} else if(type == typeName._3wayshot){
			if(arrow == "right"){
				data[arrayNumber].speedx = 10;  data[arrayNumber].speedy = 0;
			} else if(arrow == "up_right"){
				data[arrayNumber].speedx = 10;  data[arrayNumber].speedy = 2;
			} else if(arrow == "down_right"){
				data[arrayNumber].speedx = 10;  data[arrayNumber].speedy = -2;
			} else {
				data[arrayNumber].speedx = 10;  data[arrayNumber].speedy = 0;
			}
		}
		
		
		
		if(target == null){
			targetCheck();
		} else {
			data[arrayNumber].target = target;
		}
	};
	this.delete = function(index){  data[index] = new AttackArray(); }; //주의: delete함수는 객체를 삭제하는게 아니고 객체를 초기화하는 함수입니다.
	this.process = function(){  
		attackMove();  
		targetAttack();  
		targetCheck();
	};
	this.display = function(){
		for(var a = 0; a < data.length; a++){
			if(data[a].isusing == true){
				ctx.font = "24px arial";
				optionbattle.unit.attackDisplay(data[a].code, data[a].x, data[a].y, data[a].mode);
		}	}//for와 if의 가로를 한줄에 다 처리했으므로 참고바람.
	};
}  Attack.prototype = new BaseClass();
//--------------------------------//

// class damage
function Damage(){
	var data = this.data;
	for(var a = 0; a < data.length; a++)  data[a] = new DamageArray();
	
	function DamageArray(){}
	DamageArray.prototype = new SubClass(); // 상속만으로 구현 끝(...)
	
	this.init = function(){  for(var a = 0; a < data.length; a++)  data[a] = new DamageArray();  };
	this.create = function(attack, x, y, type){
		for(var arrayNumber = 0; arrayNumber < data.length; arrayNumber++){
			if(data[arrayNumber].isusing == false)  break; // 빈 배열을 찾을경우 for문을 빠져나오고 그 배열에 데이터를 입력한다.
		}
		if(arrayNumber >= data.length)  return; // 배열의 길이를 초과했을경우 강제로 함수 종료
		
		data[arrayNumber].attack = attack;
		data[arrayNumber].x = x;
		data[arrayNumber].y = y;
		data[arrayNumber].color = optionbattle.type.getcolor(type);
		data[arrayNumber].count = 50; // displayTime(Frame 단위)
		data[arrayNumber].isusing = true;
	};
	this.process = function(){  //진행함수는 데미지 출력을 조정하는 역할만함.
		for(var a = 0; a < data.length; a++){  
			data[a].count--;  data[a].y--;
			if(data[a].count <= 0)  data[a].isusing = false;
		}  
	};
	this.display = function(){  //출력함수
		for(var a = 0; a < data.length; a++){
			if(data[a].isusing == true){
				ctx.font = "24px arial";
				ctx.fillStyle = data[a].color;
				ctx.fillText(data[a].attack, data[a].x, data[a].y);
		}	} // 중괄호 한줄에 싹다 몰아넣음.
	};
}  Damage.prototype = new BaseClass();

// class Enemy
function Enemy () {
	function EnemyArray(){
    	this.score = 0;
    	this.diemotion = "";
    	this.diemotiontime = 0;
    	this.died = false;
    }  EnemyArray.prototype = new SubClass();
	
	var data = this.data;
	for(var a = 0; a < data.length; a++)  data[a] = new EnemyArray();
	
    var enemyCurrentCount = 0;
    var enemylist = [0];
    var arrayNumber = 0;
    var enemyMax = 0;
    this.getenemyCurrentCount = function(){  return enemyCurrentCount; };
    this.getenemyMax = function(){  return enemyMax; };
    this.getdied = function(index){  return data[index].died; };
	this.getdiemotiontime = function(index){  return data[index].diemotiontime; };
	this.minushp = function(index, value){  if(value <= 0){  value = 1;}  data[index].hp -= value; };
	this.plushp = function(index, value){  data[index].hp += value; };
	
	function enemyMove(){
		for(var a = 0; a < data.length; a++){
			if(data[a].isusing == true && data[a].died == false){
				data[a].x += data[a].movex;
				data[a].y += data[a].movey;
				
				if(data[a].x <= 250){
					data[a].x = 640;
					data[a].movex = data[a].speedx - Math.random() * 4 | 0;
				} else if(data[a].x >= 680){
					data[a].movex = -data[a].speedx - Math.random() * 4 | 0;
				}
				
				if(data[a].y <= -20){
					data[a].movey = data[a].speedy + Math.random() * 4 | 0;
				} else if(data[a].y >= 500){
					data[a].movey = -data[a].speedy - Math.random() * 4 | 0;
				}
			}
		}
	}
	
	function enemyDie(){
		for(var a = 0; a < data.length; a++){
			if(data[a].isusing == true && data[a].died == false && data[a].hp <= 0){
				enemyCurrentCount--;
				data[a].diemotiontime = 50;
				data[a].died = true;
				system.plusscoreBonus(data[a].score);
				optionbattle.sound.play(data[a].diesound);
			}
		}
	}
	
	function enemyDieMotion(){
		for(var a = 0; a < data.length; a++){
			if(data[a].diemotiontime > 0 && data[a].died == true){
				data[a].y += 5;
				data[a].diemotiontime--;
			} else if(data[a].diemotiontime <= 0 && data[a].died == true){
				enemy.delete(a);
			}
		}
	}
    
    function create(code, isboss){
    	var isBoss = isboss || false;
    	if(enemyCurrentCount < enemyMax && (system.getenemyCreateCount() > 0 || isBoss == true) ){
    		for(var arrayNumber = 0; arrayNumber < data.length; arrayNumber++){
    			if(data[arrayNumber].isusing == false && data[arrayNumber].died == false)  break; // 비어있는 배열번호를 찾음.
    		}
    		if(arrayNumber >= data.length)  return; // 배열번호가 배열의 길이를 초과할경우 함수 강제종료
    		
    		enemyCurrentCount++;
    		system.minusenemyCreateCount();
	    	data[arrayNumber].code = code;
	    	data[arrayNumber].x = (Math.random() * 300) + 400 | 0;
	    	data[arrayNumber].y = (Math.random() * 400) + 0   | 0;
	    	data[arrayNumber].hp = optionbattle.enemy.gethp(code);
	    	data[arrayNumber].maxhp = optionbattle.enemy.gethp(code);
	    	data[arrayNumber].attack = optionbattle.enemy.getattack(code);
	    	data[arrayNumber].defense = optionbattle.enemy.getdefense(code);
	    	data[arrayNumber].score = optionbattle.enemy.getscore(code);
	    	data[arrayNumber].speedx = optionbattle.enemy.getspeedx(code);
	    	data[arrayNumber].speedy = optionbattle.enemy.getspeedy(code);
	    	data[arrayNumber].movex = data[arrayNumber].speedx * -1;
	    	data[arrayNumber].movey = data[arrayNumber].speedy;
	    	data[arrayNumber].diesound = optionbattle.enemy.getdiesound(code);
	    	data[arrayNumber].diemotion = optionbattle.enemy.getdiemotion(code);
	    	data[arrayNumber].isusing = true;
	    	data[arrayNumber].died = false;
    	}
    }
    this.bosscreate = function(){  create(system.getboss(), true ); };
    this.create = function(code, x, y){  create(code); };
    this.delete = function(index){  data[index] = new EnemyArray();  }; //주의: 이 함수는 객체를 삭제하는게 아니고 객체를 초기화하는 함수입니다.
    this.init = function(){
    	enemylist = system.getenemylist();
    	enemyMax = system.getenemyMax();
    	for(var a = 0; a < data.length; a++){  data[a] = new EnemyArray();  }
    };
    this.process = function(){
    	var selectEnemy = enemylist[Math.random() * enemylist.length | 0];
    	create(selectEnemy, 10, 10);
    	enemyMove();  enemyDie();  enemyDieMotion();
    };
    
    this.display = function(){
    	for(var a = 0; a < data.length; a++){
    		if(data[a].isusing == true){
    			optionbattle.enemy.display(data[a].code, data[a].x, data[a].y);
    	}	}
    	ctx.fillText(data[0].hp, 540, 440);
    };
}  Enemy.prototype = new BaseClass();

// class System
function System(){
	var time = 150, timeMax = 0; // 제한시간, 제한시간최대
	var enemyMax = 0; // 적의 한 화면당 최대로 나올 수 있는 개수
	var constMusic = 0; // 음악번호
	var dungeonNumber = 0, roundNumber = 0; // 던전번호와 라운드번호
	var enemyCreateCount = 0; // 적을만드는개수
	var clearBonus = 0, scoreBonus = 0, timeBonus = 0, totalBonus = 0; // 보너스 점수들: 클리어, 점수, 시간, 총합
	var scoreCount = 0, scoreDelay = 0, scorePlus = 0;
	var enemylist = []; // 적의 리스트
	var backgroundimage = new Image(); // 배경화면이미지
	this.plusscoreBonus = function(value){  scoreBonus += value; };
	this.getclearBonus = function(){  return clearBonus; };
	this.getscoreBonus = function(){  return scoreBonus; };
	this.gettimeBonus = function(){  return timeBonus; };
	this.gettotalBonus = function(){  return totalBonus; };
	this.scoreCheck = function(){
		totalBonus = 0;  scoreCount = 0;
		timeBonus = Number(time * 100) | 0;
		totalBonus = clearBonus + timeBonus + scoreBonus;
		scorePlus = totalBonus;
	};
	
	var boss = 0;
	this.getboss = function(){  return boss; };
	this.deleteboss = function(){  boss = 0; };
	
	function timeDown(){
		time -= 0.02;
		time = time.toFixed(2);
		Number(time);
	};
	this.gettime = function(){ return time; };
	this.getenemyCreateCount = function(){  return enemyCreateCount; };
	this.getenemylist = function(){  return enemylist; };
	this.minusenemyCreateCount = function(){  enemyCreateCount--; };
	this.getenemyMax = function(){  return enemyMax; };
	
	this.init = function(){
		dungeonNumber = optionbattle.game.getselectDungeon();
		roundNumber = optionbattle.game.getselectRound();
		time = timeMax = optionbattle.dungeon.getroundtime(dungeonNumber, roundNumber);
		constMusic = optionbattle.dungeon.getroundmusic(dungeonNumber, roundNumber);
		enemyCreateCount = optionbattle.dungeon.getroundenemyCount(dungeonNumber, roundNumber);
		clearBonus = timeMax * optionbattle.dungeon.getroundmapScore(dungeonNumber, roundNumber);
		optionbattle.music.play(constMusic);
		enemyMax = optionbattle.dungeon.getroundenemyMax(dungeonNumber, roundNumber);
		scoreBonus = 0;
		enemylist = optionbattle.dungeon.getroundenemylist(dungeonNumber, roundNumber);
		backgroundimage = optionbattle.dungeon.getroundimage(dungeonNumber, roundNumber);
		boss = optionbattle.dungeon.getroundboss(dungeonNumber, roundNumber);
	};
	
	this.process = function(){
		if(clearCheck == true){
		scoreDelay++;
			if(scoreDelay % 4 == 0 && scorePlus > 0){
				if(scorePlus > totalBonus * 0.05){
					var plusExp = (totalBonus * 0.04) | 0;
					scorePlus -= plusExp;
				} else{
					var plusExp = scorePlus;
					scorePlus = 0;
				}
				
				optionbattle.user.plusexp(plusExp);
				optionbattle.sound.play(soundName.system_score);
			}
		} else {
			timeDown();
		}
	};
	
	this.display = function(){
		//if(backgroundimage.src != "")  ctx.drawImage(backgroundimage, 0, 0);
	};
	
} // 이 클래스는 상속 안받음.

function Background(){
	var image = new Image();  image.src = "";
	this.data.length = 1;
	var data = this.data[0];
	
	this.init = function(){
		image = optionbattle.dungeon.getroundimage(optionbattle.game.getselectDungeon(), optionbattle.game.getselectRound() );
	};
	this.display = function(){
		var sizex = image.width;
		var sizey = image.height;
		var x = data.x;
		var y = data.y;
		var wx = sizex - x;
		var hy = sizey - y;
		var nonex = 0;
		var noney = 0;
		
		/* ctx.drawImage(image, x, y, sizex - x, sizey - y, 0, 0, sizex - x, sizey - y);
		ctx.drawImage(image, 0, 0, x, sizey, sizex - x, y, x, sizey);
		ctx.drawImage(image, 0, 0, sizex, y, x, sizey - y, sizex, y); */
		
		
		if(x == 0 && y == 0)  ctx.drawImage(image, 0, 0); // 이미지 출력, x좌표 and y좌표가 0일경우
		
		//고작 이미지 스크롤 처리하는데 9번씩이나 그려야 한다니 헐... 빌어먹을 파이어폭스, IE
		//하지만 어느게 표준인거지? 도무지 알수없군...
		//crop 크기가 0, 0 이면 에러가 나서 일일히 이래야 한다니 멘붕
		
		// ie, firefox, chrome, opera // y is 0 or x is 0
		// ie and firefox have zero size error.
		if(wx != 0)  ctx.drawImage(image, x, noney, wx, sizey, 0, 0, wx, sizey);
		if(hy != 0)  ctx.drawImage(image, nonex, y, sizex, hy, 0, 0, sizex, hy);
		if(x != 0)  ctx.drawImage(image, 0, 0, x, sizey, wx, noney, x, sizey);
		if(y != 0)  ctx.drawImage(image, 0, 0, sizex, y, nonex, hy, sizex, y);
		
		// chrome, opera // 4 way
		if(x != 0  && y != 0)  ctx.drawImage(image, wx, hy, x, y, 0, 0, x, y);
		if(wx != 0 && y != 0)  ctx.drawImage(image, 0, hy, wx, y, x, 0, wx, y);
		if(x != 0  && hy != 0)  ctx.drawImage(image, wx, 0, x, hy, 0, y, x, hy);
		if(wx != 0 && hy != 0)  ctx.drawImage(image, 0, 0, wx, hy, x, y, wx, hy);
	};
	this.process = function(){
		data.x -= 4;//data.movex;
		//data.y -= 1;//data.movey;
		data.count++;
		if(data.x >= image.width)  data.x = 0;
		else if(data.x <= -1)  data.x = image.width;
		
		if(data.y >= image.height)  data.y = 0;
		else if(data.y <= -1)  data.y = image.height;
		
		if(data.count >= 50){
			data.movex = -10 + (Math.random() * 20) | 0;
			data.movey = -10 + (Math.random() * 20) | 0;
			data.count = 0;
		}
	};
} Background.prototype = new BaseClass();


// Class Tamsaseon
function Tamsaseon(){
	// class
	function createweapon(strName, constWeaponNumber, attack, constType, attackcount, cooltime){
		this.name = strName || "";
		this.number = constWeaponNumber || 0;
		this.attack = attack || 0;
		this.type = constType || typeName.unused;
		this.attackcount = attackcount || 1;
		this.cooltime = cooltime || 10;
		this.image = new Image();
	} createweapon.prototype = new SubClass();
	
	function createskill(strName, constSkillNumber, attack, delay, constType, combocount, time){
		this.name = strName;
		this.number = constSkillNumber;
		this.attack = attack;
		this.delay = delay;
		this.type = constType;
		this.combocount = combocount;
		this.time = time;
		this.lefttime = 0;
		this.image = new Image();
	} createskill.prototype = new SubClass();
	
	// variable
	var cursor = { image:new Image(),  x:0,  y:0 }; // 커서의 값. 상수가 아님
	cursor.image.src = "image/system/arrow.png";
	var tamsaseon = { attack:1500,  count:0,  mana:0,  hp:0,  weapon:0,  skill:0,  delay:0  }; // 탐사선의 데이터, 상수가 아님
	var weaponNumber = {  maxcount:4,
		direct:0,  _3wayshot:1,  splash:2,  linelaser:3 };
	var skillNumber = {  maxcount:2,
		strongmissile:0,  blackhole:1 };
	var weapon = new Array(weaponNumber.maxcount);
	for(var a = 0; a < weapon.length; a++)  weapon[a] = new createweapon();
	weapon[0] = new createweapon("direct", weaponNumber.direct, tamsaseon.attack * 1.300|0, typeName.direct);
	weapon[1] = new createweapon("_3wayshot", weaponNumber._3wayshot, tamsaseon.attack * 1, typeName._3wayshot);
	weapon[2] = new createweapon("splash", weaponNumber.splash, tamsaseon.attack * 1.377|0, typeName.splash);
	weapon[3] = new createweapon("linelaser", weaponNumber.linelaser, tamsaseon.attack * 1.132|0, typeName.linelaser);
	
	var skill = new Array(skillNumber.maxcount);
	skill[0] = new createskill("strongmissile", skillNumber.strongmissile, tamsaseon.attack * 1.982|0, 50*60, typeName.allarea, 20, 13*50);
	skill[0].image.src = "image/strong_missile.png";
	skill[1] = new createskill("blackhole", skillNumber.blackhole, tamsaseon.attack * 0.1|0, 50*29, typeName.allarea, 0, 4*50);
	
	//----------------------//
	this.init = function(){
		tamsaseon.count = 0;
		tamsaseon.mana = 0;
		for(var i = 0; i < weapon.length; i++){
			weapon[i].isusing = false;
			weapon[i].hp = 0;
		}
		
		for(var i = 0; i < skill.length; i++){
			skill[i].isusing = false;
			skill[i].lefttime = 0;
			skill[i].count = 0;
		}
	};
	this.process = function(){
		if(inputkey == keyboard.up    && cursor.y > 0)    cursor.y -= 20;
		if(inputkey == keyboard.down  && cursor.y < 480)  cursor.y += 20;
		if(inputkey == keyboard.left  && cursor.x > 0)    cursor.x -= 20;
		if(inputkey == keyboard.right && cursor.x < 640)  cursor.x += 20;
		
		tamsaseon.mana++;
		tamsaseon.count++;
		
		var rankStandard = 70 + (optionbattle.user.getlv() * 2);
		var typeStandard = optionbattle.type.getnormal(weapon[tamsaseon.weapon].type) + optionbattle.type.gettechnical(weapon[tamsaseon.weapon].type);
		var percentNormal = rankStandard * typeStandard / 100 | 0;
		
		tamsaseon.delay = weapon[tamsaseon.weapon].attack / percentNormal | 0;
		if(inputkey == keyboard.enter && tamsaseon.count >= tamsaseon.delay && weapon[tamsaseon.weapon].hp <= 0){
			tamsaseon.count -= tamsaseon.delay;
			if(tamsaseon.weapon == weaponNumber.direct){
				weapon[tamsaseon.weapon].hp = 8;
				optionbattle.sound.play(soundName.type_hyper);
				attack.create(1, "normal", weapon[tamsaseon.weapon].attack, weapon[tamsaseon.weapon].type, cursor.x, cursor.y);
			} else if(tamsaseon.weapon == weaponNumber._3wayshot){
				optionbattle.sound.play(soundName.multishot);
				weapon[tamsaseon.weapon].hp = 8;
				attack.create(3, "normal", weapon[tamsaseon.weapon].attack, weapon[tamsaseon.weapon].type, cursor.x, cursor.y, null, "right");
				attack.create(3, "normal", weapon[tamsaseon.weapon].attack, weapon[tamsaseon.weapon].type, cursor.x, cursor.y, null, "up_right");
				attack.create(3, "normal", weapon[tamsaseon.weapon].attack, weapon[tamsaseon.weapon].type, cursor.x, cursor.y, null, "down_right");
			} else if(tamsaseon.weapon == weaponNumber.splash){
				weapon[tamsaseon.weapon].hp = 20;
				optionbattle.sound.play(soundName.bombmissile);
				attack.create(7, "normal", weapon[tamsaseon.weapon].attack, weapon[tamsaseon.weapon].type, cursor.x, cursor.y, null, "right");
			} else if(tamsaseon.weapon == weaponNumber.linelaser){
				optionbattle.sound.play(soundName.linelaser);
				attack.create(0, "normal", weapon[tamsaseon.weapon].attack, weapon[tamsaseon.weapon].type, cursor.x, cursor.y);
				weapon[tamsaseon.weapon].isusing = true;
				weapon[tamsaseon.weapon].hp = 14;
			}
		}
		for(var i = 0; i < weapon.length; i++)  weapon[i].hp--;
		
		if(inputkey == keyboard.esc){
			optionbattle.sound.play(soundName.select_move);
			tamsaseon.weapon++;
			if(tamsaseon.weapon >= weaponNumber.maxcount)  tamsaseon.weapon = 0;
		}
		
		if(inputkey == keyboard.a && tamsaseon.mana >= skill[tamsaseon.skill].delay && skill[tamsaseon.skill].isusing == false){
			tamsaseon.mana -= skill[tamsaseon.skill].delay;
			skill[tamsaseon.skill].isusing = true;
			if(tamsaseon.skill == skillNumber.strongmissile){
				optionbattle.sound.play(soundName.warning_strong_missile_detected);
				optionbattle.sound.play(soundName.strong_missile_detected);
			}
			
			skill[tamsaseon.skill].lefttime = skill[tamsaseon.skill].time;
			skill[tamsaseon.skill].count = skill[tamsaseon.skill].combocount;
		}
		
		if(inputkey == keyboard.s){
			optionbattle.sound.play(soundName.select_move);
			tamsaseon.skill++;
			if(tamsaseon.skill >= skillNumber.maxcount)  tamsaseon.skill = 0;
		}
		
		if(skill[tamsaseon.skill].isusing == true){
			if(tamsaseon.skill == skillNumber.strongmissile){
				if(skill[skillNumber.strongmissile].lefttime <= 0 && skill[skillNumber.strongmissile].count > 0){
					skill[skillNumber.strongmissile].count--;  skill[skillNumber.strongmissile].lefttime += 10;
				
					var strongMissileDamage = (skill[skillNumber.strongmissile].attack * (20 + enemy.getenemyCurrentCount() * 0.7 ) ) / enemy.getenemyCurrentCount() | 0;
					if(strongMissileDamage <= skill[skillNumber.strongmissile].attack)  strongMissileDamage = skill[skillNumber.strongmissile].attack;
					attack.create(0, "normal", strongMissileDamage, typeName.allarea, 0, 0);
					optionbattle.sound.play(soundName.strong_missile_bomb);
				} else {
					skill[skillNumber.strongmissile].lefttime--;
				}
			}
			
			if(tamsaseon.skill == skillNumber.blackhole){
				if(skill[skillNumber.blackhole].lefttime % 50 == 0){
					optionbattle.sound.play(soundName.blackhole);
					attack.create(0, "normal", skill[skillNumber.blackhole].attack, typeName.allarea, 0, 0);
				}
				
				if(skill[skillNumber.blackhole].lefttime % 2 == 0){
					for(var i = 0; i < enemy.getdatalength(); i++){
						if(enemy.getisusing(i) == false)  continue;
						
						var movesize_x = (480 - enemy.getx(i));
						
						if(movesize_x <= 10 && movesize_x >= 0)  movesize_x = 10;
						else if(movesize_x >= -10 && movesize_x <= 0)  movesize_x = -10;
						
						var movesize_y = (240 - enemy.gety(i));
						if(movesize_y <= 10 && movesize_y >= 0)  movesize_y = 10;
						else if(movesize_y >= -10 && movesize_y <= 0)  movesize_y = -10;
						
						enemy.setx(i, enemy.getx(i) + movesize_x);  
						enemy.sety(i, enemy.gety(i) + movesize_y);
					}
				}
				
				skill[skillNumber.blackhole].lefttime--;
			}
			
			if(skill[tamsaseon.skill].lefttime <= 0 && skill[tamsaseon.skill].count <= 0)  skill[tamsaseon.skill].isusing = false;
		}
		
	};
	this.display = function(){
		ctx.drawImage(cursor.image, cursor.x, cursor.y);
		ctx.font = "18px arial";  ctx.fillStyle = "black";  ctx.strokeStyle = "white";
		ctx.fillText("H: "+tamsaseon.hp+" / ?" , 20, 430);
		ctx.fillText("C: "+tamsaseon.count+" / "+ tamsaseon.delay, 20, 455);
		ctx.fillText("M: "+tamsaseon.mana+" / "+ skill[tamsaseon.skill].delay, 20, 480);  //ctx.strokeText("M: "+mana, 20, 480);
		
		if(skill[skillNumber.strongmissile].isusing == true){
			ctx.drawImage(skill[skillNumber.strongmissile].image, 320, -skill[skillNumber.strongmissile].lefttime + 240 );
		}
		if(skill[skillNumber.blackhole].isusing == true){
			
		}
		if(weapon[weaponNumber.linelaser].hp > 0){
			ctx.fillStyle = "yellow";
			ctx.fillRect(0, cursor.y-20, 640, 40);
		}
	};
} Tamsaseon.prototype = new BaseClass();

//-----------------------------//
var force = new Force();
var attack = new Attack();
var system = new System();
var enemy = new Enemy();
var damage = new Damage();
var background = new Background();
var tamsaseon = new Tamsaseon();

var clearCheck = false;
var pauseCheck = false;
var scoreImage = new Image();  scoreImage.src = "image/system/score.png";
var waitTime = 0;
var pauseImage = new Image();  pauseImage.src = "image/system/pause.png";
var backgroundimage = new Image();  backgroundimage.src = "";

this.init = function(){
	system.init();
	force.init();
	enemy.init();
	attack.init();
	damage.init();
	background.init();
	tamsaseon.init();
	clearCheck = false;
	pauseCheck = false;
	waitTime = 0;
};

// function process
this.process = function(){
	if(clearCheck == false && pauseCheck == false){
		optionbattle.music.continue();
		attack.process();
		force.process();
		system.process();
		enemy.process();
		damage.process();
		background.process();
		tamsaseon.process();
		
		if(inputkey == keyboard.p){  pauseCheck = true;  optionbattle.sound.play(soundName.system_pause); }
		if(system.getenemyCreateCount() <= 0 && enemy.getenemyCurrentCount() <= 0 && system.getboss() == 0){
			system.scoreCheck();
			optionbattle.music.play(musicName.roundclear);
			clearCheck = true;
		} else if(system.getenemyCreateCount() <= 0 && enemy.getenemyCurrentCount() <= 0 && system.getboss() != 0){
			enemy.bosscreate();
			system.deleteboss();
		}
	} else if(pauseCheck == true){
		optionbattle.music.stop();
		
		if(inputkey == keyboard.p){  pauseCheck = false;  optionbattle.sound.play(soundName.system_pause); }
	} else if(clearCheck == true){
		system.process();
		waitTime++;
		
		if(inputkey == keyboard.p){  pauseCheck = true;  optionbattle.sound.play(soundName.system_pause); }
		if(waitTime > 300){
			optionbattle.game.modeChange(modeName.main);
		}
	}
};

// function display
var fieldtop = new Image();  fieldtop.src = "image/system/fieldtop.png";
this.display = function(){
	background.display();
	system.display();
	ctx.drawImage(fieldtop, 0, 0);
	optionbattle.background.numberDisplay(system.gettime(), 73, 3);
	force.display();
	attack.display();
	enemy.display();
	damage.display();
	tamsaseon.display();
	ctx.fillText(system.getenemyCreateCount(), 250, 200);
	ctx.fillText(enemy.getenemyCurrentCount(), 250, 240);
	if(pauseCheck == true){  ctx.drawImage(pauseImage, 300, 20); }
	
	if(clearCheck == true){
		ctx.drawImage(scoreImage, 300, 100);
		optionbattle.background.numberDisplay(system.getclearBonus(), 300+300, 100+40, 0, true);
		optionbattle.background.numberDisplay(system.gettimeBonus(), 300+300, 100+70, 0, true);
		optionbattle.background.numberDisplay(system.getscoreBonus(), 300+300, 100+100, 0, true);
		optionbattle.background.numberDisplay(system.gettotalBonus(), 300+300, 100+130, 0, true);
		optionbattle.background.numberDisplay(optionbattle.user.getexp(), 300+150, 100+160, 0, true);
		optionbattle.background.numberDisplay(optionbattle.game.getexpTable(optionbattle.user.getlv()), 300+200, 100+160);
		var expPercent = optionbattle.user.getexp() / optionbattle.game.getexpTable(optionbattle.user.getlv());
		ctx.fillStyle = "black";
		ctx.fillRect(300+10, 100+185, expPercent*300, 10);
	}
};

//-----------------------//
}// function end
//-----------------------//
optionbattle.field = new Field();