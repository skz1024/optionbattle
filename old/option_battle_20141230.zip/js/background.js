//배경화면, 여기에 있는 모든 객체는 이미지만 저장된다.
function Background(){ // function Background Start.
var title = {}; // 타이틀 이미지 객체 생성
title.image = new Image();  title.image.src = "image/background/title.png";
title.arrow = new Image();  title.arrow.src = "image/system/arrow.png";
title.title = new Image();  title.title.src = "image/system/title.png";
title.createdby = new Image();  title.createdby.src = "image/system/createdby.png";
title.tamsaseon = new Image();  title.tamsaseon.src = "image/system/tamsaseon.png";
title.display = function(){ //타이틀을 출력하는 함수
    ctx.drawImage(title.image, 0, 0); // 이미지 표시
    ctx.drawImage(title.title, 0, 0); // 타이틀 표시
    ctx.drawImage(title.arrow, 330, 150+(optionbattle.game.getmenu()*35)); // 화살표 표시

    ctx.fillStyle = "black";  ctx.font = "20px arial";
    ctx.fillText("created by skz1024, 2014/12/04, ver 0.70",10,470);
};

var titlethema = {}; // 타이틀 테마 객체 생성
titlethema.block = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
for(var a = 0; a < titlethema.block.length; a++)  titlethema.block[a] = [0, 0, 0];
titlethema.count = 0;

titlethema.display = function(){
	var currentTime = game.getcurrenttime();
	if(currentTime == 0.00){
		titlethema.count = 0;
		titlethema.block_init();
	}
	
	if(currentTime >= 1.00 && currentTime <= 6.00){
		titlethema.block_add();
		titlethema.block_delete();
		for(var a = 0; a < 20; a++){
			var color = titlethema.block[a][2];
			if(color == 0)  continue;
			
			switch(color){
				case 1: ctx.fillStyle = "black";  break;
				case 2: ctx.fillStyle = "yellow"; break;
				case 3: ctx.fillStyle = "skyblue"; break;
				case 4: ctx.fillStyle = "green"; break;
				case 5: ctx.fillStyle = "blue"; break;
				case 6: ctx.fillStyle = "brown"; break;
				case 7: ctx.fillStyle = "orange"; break;
				case 8: ctx.fillStyle = "pink"; break;
				case 9:	ctx.fillStyle = "grey"; break;
			}
			
			var x = titlethema.block[a][0];
			var y = titlethema.block[a][1];
			ctx.fillRect(x, y, 10, 10);
			
			titlethema.block[a][0] -= titlethema.block[a][2] * 5;
			
			titlethema.count++;
			var timecount = (titlethema.count/100) | 0;
			if(timecount > 35)  timecount = 35;
			if(timecount > 25)  ctx.drawImage(title.createdby, 0, 0, (timecount-25)*20, 70, 300, 200, (timecount-25)*20, 70 );
		}
	} else if(currentTime >= 6.00 && currentTime <= 15.00){
		ctx.drawImage(title.image, 0, 0);
		if(currentTime == 6.02){
			titlethema.count = 0;
		}
		
		titlethema.count++;
		ctx.drawImage(title.tamsaseon, titlethema.count*4, 240);
		
		if(currentTime == 10.00){
			titlethema.count = 0;
		}
		if(currentTime >= 10.00 && currentTime <= 13.70){
			ctx.drawImage(title.title, 100, titlethema.count-150);
		} else if(currentTime >= 13.70){
			ctx.drawImage(title.title, 100, 40);
		}
	}
};
titlethema.block_add = function(){
	for(var a = 0; a < 20; a++){
		if(titlethema.block[a][2] != 0)  continue; // 블럭의 2번 정보가 0인경우 패스
		
		titlethema.block[a][0] = 640;
		titlethema.block[a][1] = Math.random() * 480 | 0;
		titlethema.block[a][2] = Math.random() * 10 | 0;
	}
};
titlethema.block_delete = function(){
	for(var a = 0; a < 20; a++){
		if(titlethema.block[a][0] <= 0){
			titlethema.block[a][2] = 0;
		}
	}
};
titlethema.block_init = function(){
	for(var a = 0; a < 20; a++){
		titlethema.block[a][0] = 0;
		titlethema.block[a][1] = 0;
		titlethema.block[a][2] = 0;
	}
};


var option = {};
option.display = function(){ // 옵션화면을 출력하는 함수
	var alignline = 200;
    ctx.drawImage(title.image, 0, 0); // 이미지 표시(title과 같음)
    ctx.drawImage(title.arrow, alignline-100, 190+(optionbattle.game.getselect()*40) ); // 화살표 표시(title과 같음)
    
    ctx.fillStyle = "#004C63";  ctx.font = "20px arial";
    ctx.fillText("game option", alignline, 150);
    ctx.fillText("SOUND : "+optionbattle.game.getsoundOn(), alignline, 220);
    ctx.fillText("MUSIC : "+optionbattle.game.getmusicOn(), alignline, 260);
    ctx.fillText("SOUND TEST : "+optionbattle.game.getsoundNumber(), alignline, 300);
    ctx.fillText("MUSIC TEST : "+optionbattle.game.getmusicNumber(), alignline, 340);
    ctx.fillText("current music time : "+ optionbattle.music.time() + " / " + optionbattle.music.duration(optionbattle.game.getmusicNumber()) , alignline, 380);
    ctx.fillText("EXIT", alignline, 420);
    
    
};

var main = {}; // 메인 이미지 객체 생성
main.image = new Image();  main.image.src = "image/background/main.png";
main.exp_meter = new Image();  main.exp_meter.src = "image/system/user_exp.png";
main.fuel_meter = new Image();  main.fuel_meter.src = "image/system/user_fuel.png";
main.arrow = new Image();  main.arrow.src = "image/system/arrow2.png";
main.user_status = new Image();  main.user_status.src = "image/system/user_status.png";
main.menu = new Image();  main.menu.src = "image/system/menu.png";
main.keyhelp = new Image();  main.keyhelp.src = "image/system/keyhelp.png";
main.display = function(){
    var exp_percent = optionbattle.user.getexp() / optionbattle.game.getexpTable(optionbattle.user.getlv());
    
    ctx.drawImage(main.image,0,0); // 메인 이미지 출력
    ctx.drawImage(main.user_status,0,0); // 유저 스테더스 출력
    if(exp_percent > 0)  ctx.drawImage(main.exp_meter, 0, 0, (exp_percent*300), 25, 2, 29, (exp_percent*635), 9); // 경험치 미터 출력 
    //ctx.drawImage(main.menu, 0, 90); // 메뉴 출력
    ctx.drawImage(main.arrow, 250, 80+(optionbattle.game.getmenu()*40) ); // 화살표 출력
    
    numberDisplay(optionbattle.user.getlv(), 40, 5);
    numberDisplay(optionbattle.user.getexp(), 380, 5, "green", true);
    numberDisplay(optionbattle.game.getexpTable(optionbattle.user.getlv()), 410, 5, "green");
    numberDisplay(optionbattle.user.getgold(), 620, 65, "yellow", true);
    numberDisplay(optionbattle.user.getfuel(), 520, 42, "skyblue", true);
    numberDisplay(1000, 560, 42, "skyblue");
    
};

var party = {}; // 파티 이미지 표시하는 객체 생성
party.image = new Image();  party.image.src = "image/background/main.png";
party.party = new Image();  party.party.src = "image/background/party.png";
party.select = new Image();  party.select.src = "image/system/select.png";
party.display = function(){
    ctx.drawImage(party.image,0,0); // 파티 이미지 출력
    ctx.drawImage(party.party,0,0); // 파티 파티 출력(정확하게는 파티.파티 이미지)
    var select = game.getselect_teamunit(); // 팀유닛 선택
    var unithp = 0, userhp = user.gethp(user.getlv()), totalhp = 0;
    
    for(var a = 0; a < 12; a++){
        var team = user.teamunit_data(a),  data = user.inventory_data(team);
        var code = data[invenconst.code],  lv = data[invenconst.lv];
        
        unithp += optionbattle.unit.gethp(lv);
        optionbattle.unit.display((64*[a%3])+80,(64*[Math.floor(a/3)])+120);
    }
    ctx.drawImage(party.select, (64*(select%3))+75, (64*Math.floor(select/3))+115);
    ctx.font = "24px arial";  ctx.fillStyle = "black";  totalhp = unithp + userhp;
    ctx.fillText("TOTAL HP : " + unithp + " + " + userhp + " = " + totalhp, 50, 420);
};

var shop = {}; // 상점(현질용) 이미지 표시하는 객체 생성
shop.image = new Image();  shop.image.src = "image/background/shop.png";
shop.display = function(){  ctx.drawImage(shop.image,0,0); };

var inventory = {}; // 인벤토리 이미지 객체 생성
inventory.image = new Image();  inventory.image.src = "image/background/main.png";
inventory.select = new Image();  inventory.select.src = "image/system/select.png";
inventory.inventory = new Image();  inventory.inventory.src = "image/system/inventory.png";
inventory.display = function(){
    ctx.drawImage(inventory.image,0,0); // 이미지 출력
    ctx.drawImage(inventory.inventory,0,0); // 인벤토리 이미지 출력
    ctx.fillStyle = "black";  ctx.font = "18px arial";
    ctx.fillText(optionbattle.game.getselect(), 260, 45); // 현재 선택한 번호를 출력
    
    var cursor = optionbattle.game.getselect() % 50;
    var start = Math.floor(optionbattle.game.getselect()/50) * 50;
    var page = (start / 50) + 1;
    ctx.fillText(page + " / " + optionbattle.user.inventory.getinventoryMaxCount() / 50, 150, 70); // 페이지 출력
    ctx.fillText(optionbattle.user.inventory.getinventoryMaxCount(), 260, 95);
    
    for(var a = start, b = 0; b < 50; a++, b++){
        var data = optionbattle.user.inventory.getdata(a);
        
        if(data.type == "unit"){
            optionbattle.unit.display(data.code, 10+((b%10)*60), 150+( Math.floor(b/10)*60) );
        }
        else if(data.type == "item"){
            optionbattle.item[data.code].display(10+((b%10)*60), 150+( Math.floor(b/10)*60) );
        }
    }
    ctx.drawImage(inventory.select, 4+((cursor%10)*60), 145+(Math.floor(cursor/10)*60));
};

var unitview = {}; // 유닛뷰 객체 생성
unitview.image = new Image();  unitview.image.src = "image/background/main.png";
unitview.unitview = new Image();  unitview.unitview.src = "image/system/unitview.png";
unitview.upgrade = new Image();  unitview.upgrade.src = "image/system/upgrade.png";
unitview.back = new Image();  unitview.back.src = "image/system/back.png";
unitview.sell = new Image();  unitview.sell.src = "image/system/sell.png";
unitview.button = new Image();  unitview.button.src = "image/system/button.png";
unitview.display = function(){
    ctx.drawImage(unitview.image,0,0);
    ctx.drawImage(unitview.unitview,0,0);
    ctx.drawImage(unitview.back,10,390);
    ctx.drawImage(unitview.upgrade,130,390);
    ctx.drawImage(unitview.sell,250,390);
    ctx.drawImage(unitview.button,10+(optionbattle.game.getselect2()*120),390);
    
    ctx.font = "18px arial";
    var data = optionbattle.user.inventory.getdata(optionbattle.game.getselect());
    var type = data.type;
    var code = data.code;
    var rank = data.rank;
    var lv = data.lv;
    if(type == "unit"){
        ctx.fillStyle = "#0C0200";  ctx.fillRect(240,100,380,280);
        optionbattle.unit.display(code, 20, 100, 192, 192);
        
        ctx.fillStyle = "orange";  ctx.fillText("NAME : "+optionbattle.unit.getname(code), 250, 130);
        ctx.fillStyle = "skyblue";  ctx.fillText("TYPE : "+optionbattle.unit.gettypeName(code),250,160);
        ctx.fillStyle = "pink";  ctx.fillText("HP : "+optionbattle.unit.gethp(code, lv), 450, 160);
        ctx.fillStyle = "#6B9900";  ctx.fillText("LV : "+lv+" / "+optionbattle.unit.getmaxlv(code), 250, 190);
        ctx.fillText("RANK : "+optionbattle.unit.getrank(code),450,190);

        ctx.fillStyle = "#A84E19";  ctx.fillText("ATTACK : "+optionbattle.unit.getattack(code, lv),250,220);
        ctx.fillStyle = "#FFBA85";  ctx.fillText("DELAY : "+optionbattle.unit.getdelay(code), 450, 220);
        
        ctx.fillStyle = "#E0B94F";  
        ctx.fillText("ATTACK2 : "+optionbattle.unit.getattackTechnical(code, lv), 250, 250);
        ctx.fillText("DELAY : "+optionbattle.unit.getdelayTechnical(code), 450, 250);
        ctx.fillText("ATTACK3 : "+optionbattle.unit.getattackSkill(code, lv), 250, 280);
        ctx.fillText("DELAY : "+optionbattle.unit.getdelaySkill(code), 450, 280);
        
        ctx.fillStyle = "#C0E783";
        ctx.fillText("TECHNICAL(ATTACK2) : "+optionbattle.unit.gettechnical(code), 250, 310);
        ctx.fillText("SKILL(ATTACK3) : "+optionbattle.unit.getskill(code), 250, 340);
        
        ctx.fillStyle = "white";
        ctx.fillText("UPGRADE COST(강화 비용) : ", 250, 370);
        //ctx.fillText(optionbattle.game.getunitUpgradeGold(lv), 500, 370);
    }
    else if(type == itemType.item){
        var name = optionbattle.item[code].stat_name();
        optionbattle.item[code].display(20,100,192,192);
        ctx.fillStyle = "darkgreen";  ctx.fillText(name,10,320);
    }
    else if(type == itemType.upgrade){
        //var name = optionbattle.upgrade[code].stat_name();
        //optionbattle.item[code].display(20,100,192,192);
        //ctx.fillStyle = "darkgreen";
        //ctx.fillText(name,10,320);
    }
};

var dungeon = {};
dungeon.main = new Image();  dungeon.main.src = "image/background/main.png";
dungeon.image = new Image();  dungeon.image.src = "image/background/dungeonselect.png";
dungeon.select = new Image();  dungeon.select.src = "image/system/arrow2.png";
dungeon.clear = new Image();  dungeon.clear.src = "image/system/clear.png";
dungeon.new = new Image();  dungeon.new.src = "image/system/new.png";
dungeon.display = function(){
    ctx.drawImage(dungeon.main, 0, 0);
    ctx.drawImage(dungeon.image, 0, 0);
    ctx.drawImage(dungeon.select, 150, 100+(30*optionbattle.game.getselectDungeon()));
    for(var a = 0; a < optionbattle.dungeon.getcount(); a++){
    	numberDisplay(optionbattle.dungeon.getchapter(a), 40, 110+(a*30), "", true);
    	numberDisplay(optionbattle.dungeon.getpart(a), 100, 110+(a*30), "", true);
    	ctx.fillText(optionbattle.dungeon.getname(a), 150, 130+(a*30));
    }
};

var round = {};
round.image = new Image();  round.image.src = "image/background/roundselect.png";
round.display = function(){
	ctx.drawImage(dungeon.main, 0, 0);
	ctx.drawImage(round.image, 0, 0);
    if(optionbattle.game.getselectRound() <= 9){  ctx.fillText("뒤로가기(back)", 10, 80);  }
    else  ctx.fillText("△△△△△△△△", 10, 80);
    
    ctx.drawImage(dungeon.select, 150, 80+(30*(optionbattle.game.getselectRound()%10) ) );
    var start = (optionbattle.game.getselectRound()/10 | 0) * 10;
    var end = optionbattle.dungeon.getroundCount(optionbattle.game.getselectDungeon());
    for(var a = start, b = 0; b < 10 && a <= end; a++, b++){
        ctx.fillText(a+ " : "+optionbattle.dungeon.getroundname(optionbattle.game.getselectDungeon(), a), 10, 110+(30*b));
        //var clear = user.getround_clear(game.getmenu(), a);
        //var open = user.getround_open(game.getmenu(), a);
        
        //if(clear == true){ ctx.drawImage(dungeon.clear, 180, 140+(30*b) ); }
        //if(clear == false && open == true){  ctx.drawImage(dungeon.new, 180, 140+(30*b) );}
        //if(open == false){ ctx.strokeRect(10, 145+(30*b), 200, 1); }
    }
    if(end >= start+10){
        ctx.fillText("▽▽▽▽▽▽▽▽", 10, 450);
    }
};

var loading = {};
loading.image = new Image();  loading.image.src = "image/background/loading.png";
loading.display = function(){ ctx.drawImage(this.image,0,0); };

var round_1 = {};
round_1.image1_1 = new Image();  round_1.image1_1.src = "image/background/round1_image1.png";
round_1.image1_2 = new Image();  round_1.image1_2.src = "image/background/round1_image2.png";
round_1.image1_3 = new Image();  round_1.image1_3.src = "image/background/round1_image3.png";
round_1.image1_4 = new Image();  round_1.image1_4.src = "image/background/round1_image4.png";
round_1.image1_5 = new Image();  round_1.image1_5.src = "image/background/round1_image5.png";
round_1.image1_6 = new Image();  round_1.image1_6.src = "image/background/round1_image6.png";
round_1.image1_7 = new Image();  round_1.image1_7.src = "image/background/round1_image7.png";
round_1.image1_8 = new Image();  round_1.image1_8.src = "image/background/round1_image8.png";
round_1.display = function(roundNumber, stringInputOption){
    var imageX = 0;
    var imageY = 0;
    switch(roundNumber){
        case 0: case 1: case 2: case 3: case 4: case 5: ctx.drawImage(round_1.image1_1,imageX,imageY,640,480,0,0,640,480); break;
        case 6: case 7: ctx.drawImage(round_1.image1_2,imageX,imageY,640,480,0,0,640,480); break;
        case 8: case 9: ctx.drawImage(round_1.image1_3,imageX,imageY,640,480,0,0,640,480); break;
        case 10: case 11: case 12: ctx.drawImage(round_1.image1_4,imageX,imageY,640,480,0,0,640,480); break;
        case 13: case 14: case 15: case 16: ctx.drawImage(round_1.image1_5,imageX,imageY,640,480,0,0,640,480); break;
    	case 17: case 18: ctx.drawImage(round_1.image1_6,imageX,imageY,640,480,0,0,640,480); break;
    }
};

var story = {};
story.new = new Image();  story.new.src = "image/system/new.png";
story.display = function(){
	main.display();
    ctx.clearRect(0, 120, 196, 360);
    ctx.drawImage(dungeon.menu, 0, 90);
    ctx.drawImage(dungeon.select, 150, 150+(30*game.getmenu()) );
    ctx.fillText("스토리 선택(story select)", 10, 120);
    ctx.fillText("---------------", 10, 150);
    ctx.fillText("뒤로가기(back)", 10, 180);
    for(var a = 1; a < 5; a++){
        ctx.fillText(optionbattle.story[a].getname(), 10, 180+(30*a));
        var isNew = user.getstoryread(a);
        if(isNew == true)  ctx.drawImage(story.new, 180, 170+(30*a));
    }
};

var storyview = {};
storyview.image = new Array(12);
for(var a = 0; a < storyview.image.length; a++){
	storyview.image[a] = new Image();
	storyview.image[a].src = "image/story/image[" + a + "].png";
}
storyview.display = function(){
	var menu = game.getmenu();
	var page = game.getpage();
	
	var character = optionbattle.story[menu].gettext_character(page);
	var textline1 = optionbattle.story[menu].gettext_line1(page);
	var textline2 = optionbattle.story[menu].gettext_line2(page);
	var textline3 = optionbattle.story[menu].gettext_line3(page);
	var imagenumber = optionbattle.story[menu].gettext_imagenumber(page);

	ctx.drawImage(storyview.image[imagenumber], 0, 0);
	if(character != ""){
		ctx.fillStyle = "darkblue";
		ctx.fillRect(0, 340, 320, 30);
		ctx.fillStyle = "yellow";
		ctx.fillText(character, 30, 360);
	}
	
	if(textline1 == "" && textline2 == "" && textline3 == ""){
		//이미지만 출력...
	} else {
		ctx.fillStyle = "#D8D8D8";
		ctx.fillRect(0, 370, 640, 90);
		ctx.fillStyle = "black";
		ctx.font = "18px arial";
		ctx.fillText(textline1, 30, 400);
		ctx.fillText(textline2, 30, 425);
		ctx.fillText(textline3, 30, 450);
	}
};

var numberPng = new Image();
numberPng.src = "image/system/numberPng.png";
this.numberDisplay = function(number, x, y, strColor, isAlignRight){
	numberDisplay(number, x, y, strColor, isAlignRight);
};

function numberDisplay(number, x, y, strColor, isAlignRight){
	// 여기에 있는 const 변수는 이미지 출력 좌표를 간단히 하기 위해 만든 변수임
	// 위 함수와 다른점은 이 함수는 해당 객체 내부에서 사용할 수 있게 한 함수임.
	const cw = 12, ch = 20, sw = 12, sh = 20; // c = crop, s = imagesize, w = width, h = height
	var p = 0; // p = color;
	if(strColor == "green")  p = 1;
	else if(strColor == "skyblue")  p = 2;
	else if(strColor == "yellow")  p = 3;
	
	var strnumber = number.toString();
	
	if(isAlignRight == true){ // 오른쪽 정렬일때, length에서 1을 빼주는것은 스트링 배열은 0번부터 시작하기때문
		for(var a = strnumber.length-1 , b = 0 ; a >= 0; a--, b++){
			var outputnumber = strnumber.charAt(a);
			switch(outputnumber){
				case '0': ctx.drawImage(numberPng, cw*0, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
				case '1': ctx.drawImage(numberPng, cw*1, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
				case '2': ctx.drawImage(numberPng, cw*2, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
				case '3': ctx.drawImage(numberPng, cw*3, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
				case '4': ctx.drawImage(numberPng, cw*4, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
				case '5': ctx.drawImage(numberPng, cw*5, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
				case '6': ctx.drawImage(numberPng, cw*6, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
				case '7': ctx.drawImage(numberPng, cw*7, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
				case '8': ctx.drawImage(numberPng, cw*8, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
				case '9': ctx.drawImage(numberPng, cw*9, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
				case '.': ctx.drawImage(numberPng, cw*10, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
			}
		}
	} else {
		for(var a = 0; a < strnumber.length; a++){
			var outputnumber = strnumber.charAt(a);
			switch(outputnumber){
				case '0': ctx.drawImage(numberPng, cw*0, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
				case '1': ctx.drawImage(numberPng, cw*1, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
				case '2': ctx.drawImage(numberPng, cw*2, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
				case '3': ctx.drawImage(numberPng, cw*3, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
				case '4': ctx.drawImage(numberPng, cw*4, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
				case '5': ctx.drawImage(numberPng, cw*5, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
				case '6': ctx.drawImage(numberPng, cw*6, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
				case '7': ctx.drawImage(numberPng, cw*7, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
				case '8': ctx.drawImage(numberPng, cw*8, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
				case '9': ctx.drawImage(numberPng, cw*9, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
				case '.': ctx.drawImage(numberPng, cw*10, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
			}
		}
	}
	
}

//배경화면을 지우는 함수, 1frame당 전부 지우고 계속해서 다시 그린다.
function display_clear(){ ctx.clearRect(0, 0, 640, 480); }
this.display_clear = function(){ ctx.clearRect(0, 0, 640, 480); };

this.display = function(){
	display_clear();
	ctx.font = "18px arial";
	var constmodeName = optionbattle.game.getmode();
    switch(constmodeName){
        case modeName.title: title.display(); break;
        case modeName.option: option.display(); break;
        case modeName.main: main.display(); break;
        case modeName.inventory: inventory.display(); break;
        case modeName.party: party.display(); break;
        case modeName.unitselect: inventory.display(); break;
        case modeName.unitview: unitview.display(); break;
        case modeName.dungeon: dungeon.display(); break;
        case modeName.round: round.display(); break;
        case modeName.loading: loading.display(); break;
        case modeName.field: 
        					optionbattle.field.display(); break;
        case modeName.story: stroy.display(); break;
        case modeName.storyview: stroyview.display(); break;
        case modeName.titlethema: titlethema.display(); break;
    }
    
};

//-------------------------//
}// function Background end;

optionbattle.background = new Background();