function NAMESPACE_OPTION_BATTLE(){
	this.unit = new Array(100); // 유닛의 정보를 저장하는 배열 생성
	this.item = new Array(100); // 아이템의 정보를 저장하는 배열 생성
	this.combination = new Array(100); // 아이템의 조합 정보를 저장하는 배열 생성
	this.dungeon = new Array(100); // 던전의 정보를 저장하는 배열 생성
	this.enemy = new Array(100); // 적의 정보를 저장하는 배열 생성
	this.story = new Array(100);
	this.game;
	this.sound;
	this.music;
	this.background;
	this.user;
}

// 네임스페이스 사용하기
var optionbattle = new NAMESPACE_OPTION_BATTLE();// namespace 선언
var ctx = document.getElementById("canvas").getContext('2d'); // canvas 기능 사용
delete NAMESPACE_OPTION_BATTLE;
