#readme
music created by skz1024
all music used optionbattle
copyright 2015, skz1024, all rights reserved

name / date
-- part 1 --
music01_space_tour            / 2014.08.25
music02_paran_planet          / 2014.12.30
music03_donggrami_maeul       / 2014.12.30
music04_donggrami_maeul_part2 / 2015.01.19
music05_down_tower            / 2015.02.03
music06_down_tower_passage    / 2015.02.04
music07_down_tower_boss       / 2015.09.28
music08_space_music           / 2015.09.29
music09_battle_music          / 2015.11.07


-- part 2 --
???