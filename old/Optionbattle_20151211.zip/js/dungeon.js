// 스트릭트 모드 사용, 엄격한 구문 처리
function Dungeon(){
const dungeonName = { 파란행성_Part1:0,  파란행성_Part2:1, 파란행성_Part3:2 };
const NOTHING = -1;
var data = new Array(); // 던전의 데이터
var dungeonCount = NOTHING;

function createDungeon(number, name){
    dungeonCount++;
    this.number = number;
    this.name = name;
    
    this.round = new Array();
    var roundCount = NOTHING;
    this.getRoundCount = function(){  return roundCount; };
    function Group(number, enemyList, enemyCount, enemyMax, enemyMap){
        this.number = number;
        this.enemylist = enemyList;
        this.enemycount = enemyCount;
        this.enemymax = enemyMax;
        if(enemyMap == null)  this.enemymap = enemyMap;   else  this.enemymap = 0;
        
    }
    
    function Round(name, time, mapscore, mapgold, musicNumber){
        this.name = name;
        this.time = time;
        this.mapscore = mapscore;
        this.mapgold = mapgold;
        this.musicNumber = musicNumber;
        this.boss = NOTHING;
        
        this.group = new Array();
        this.groupCount = NOTHING;
        
        this.map = new Array();
        this.mapCount = NOTHING;
        
        this.script = new Array();
        this.scriptCount = NOTHING;
    }
    this.createRound = function(name, time, mapscore, mapgold, musicNumber){
        roundCount++;
        this.round[roundCount] = new Round(name, time, mapscore, mapgold, musicNumber);
    };
    this.addRoundEnemy = function(enemyList, enemyCount, enemyMax){
        this.round[roundCount].groupCount++;
        var groupCount = this.round[roundCount].groupCount;
        this.round[roundCount].group[groupCount] = new Group(groupCount, enemyList, enemyCount, enemyMax);
    };
    this.setBoss = function(boss){
        this.round[roundCount].boss = boss;
    };
    //------------------------
    function Map(imageNumber, speedx, speedy, loopx, loopy, option){
    	this.imageNumber = imageNumber;
    	this.speedx = speedx;
    	this.speedy = speedy;
    	this.loopx = loopx;
    	this.loopy = loopy;
    	this.option = option;
    }
    this.addMap = function(imageNumber, speedx, speedy, loopx, loopy, array_groupNumber, option){
        this.round[roundCount].mapCount++;
        var mapCount = this.round[roundCount].mapCount;
        this.round[roundCount].map[mapCount] = new Map(imageNumber, speedx, speedy, loopx, loopy, option);
    };
    //------------------------
    function Script(condition, action){
    	this.condition = new Array();
    	this.action = new Array();
    	// 모든 스크립트는 한번만 사용 가능
    	
    	if(typeof condition != "object"){  // 스크립트가 1개만 있는경우 강제로 객체로 만듬
    		this.condition[0] = condition;
    	} else {  // 스크립트가 여러개 있는경우 배열을 복사
    		this.condition = condition; 
    	}
    	
    	// 이건 액션도 마찬가지
    	if(typeof action != "object"){
    		this.action[0] = action;
    	} else {
    		this.action = action;
    	}
    }
    this.addScript = function(conditon, action){
    	this.round[roundCount].scriptCount++;
    	var scriptCount = this.round[roundCount].scriptCount;
    	this.round[roundCount].script[scriptCount] = new Script(conditon, action);
    };
    
    //------------------------
    this.enemy = new Array();
    var enemyCount = NOTHING;
    function Enemy(number, name, hp, attack, defense, imagenumber){
        this.number = number;
        this.name = name;
        this.hp = hp;
        this.attack = attack;
        this.defense = defense;
        this.imagenumber = imagenumber;
        this.score = (hp/1000) + (attack/10) + (defense/10) |0;
        this.shot = false;
        
        this.diesound = soundName.dongrami_fail; // soundNumber, default: donggrami_fail
        this.diemotion = "";
        this.speedx = 0;
        this.speedy = 0;
        this.speedType = "";
    }
    this.createEnemy = function(number, name, hp, attack, defense, imagenumber){
        enemyCount++;
        this.enemy[number] = new Enemy(number, name, hp, attack, defense, imagenumber);
    };
    this.setEnemy = function(number, speedx, speedy, speedType, diesound, diemotion){
        this.enemy[number].speedx = speedx;
        this.enemy[number].speedy = speedy;
        this.enemy[number].speedType = speedType;
        this.enemy[number].diesound = diesound;
        this.enemy[number].diemotion = diemotion;
    };
    this.setAttack = function(number){
    	this.enemy[number].shot = true;
    };
}


//---------------------------------//
data[0] = new createDungeon(0, "파란행성 part1: 동그라미 마을");
data[0].createRound("듀토리얼", 120, 100, 100, musicName.none);
data[0].addRoundEnemy([0,1,2,3,4], 115, 20);
data[0].addMap(10, 0, 0, false, false);
data[0].createRound("우주 여행 1, 정거장 출발", 120, 100, 100, musicName.music01_space_tour);
data[0].addRoundEnemy([0,1,2,3,4], 350, 20);
data[0].addMap(11, 3, 0, true, false);
data[0].addScript(["variable 1 = 0","enemy currentcount < 1"], ["map change 12", "variable 1 = 1", "system round clear impossible"]);
data[0].addScript(["variable 1 = 1", "variable 2 < 200"], ["variable 2 + 1", "infinity"]);
data[0].addScript(["variable 2 = 200"], ["group 0 createcount + 80", "system round clear possible"]);
data[0].createRound("우주 여행 2, 센티멘탈행성계 가는길 1", 180, 104, 100, musicName.music01_space_tour);
data[0].addRoundEnemy([0,1,2,3,4], 1100, 50);
data[0].addMap(12, 7, 0, true, false);
data[0].createRound("우주 여행 3, 센티멘탈행성계 가는길 2", 180, 104, 100, musicName.music01_space_tour);
data[0].addRoundEnemy([0,1,2,3,4], 1020, 65);
data[0].addRoundEnemy([5,6,7,8,9], 0, 37);
data[0].addScript(["variable 1 = 0","enemy currentcount < 1"], ["music change "+musicName.music08_space_music+"", "map change 13", "variable 1 = 1", "system round clear impossible"]);
data[0].addScript(["variable 1 = 1", "variable 2 < 200"], ["variable 2 + 1", "infinity"]);
data[0].addScript(["variable 2 = 200"], ["group 1 createcount + 55", "system round clear possible"]);
data[0].addMap(12, 7, 0, true, false);
data[0].createRound("운석지대 1", 170, 110, 400, musicName.music08_space_music);
data[0].addRoundEnemy([0,1,2,3,4], 170, 9);
data[0].addRoundEnemy([5,6,7,8,9], 240, 32);
data[0].addMap(13, 4, 0, true, false);
data[0].createRound("운석지대 2", 170, 110, 400, musicName.music08_space_music);
data[0].addRoundEnemy([0,1,2,3,4], 107, 4);
data[0].addRoundEnemy([5,6,7,8,9], 255, 32);
data[0].addMap(13, 4, 0, true, false);
data[0].createRound("운석지대 3, 무인기 충돌 구역?", 220, 120, 700, musicName.music08_space_music);
data[0].addRoundEnemy([5,6,7,8,9], 80, 44);
data[0].addRoundEnemy([29], 0, 1);
data[0].addScript(["variable 1 = 0","enemy currentcount < 1","enemy createcount = 0"], ["music change "+musicName.music09_battle_music+"", "variable 1 = 1", "group 1 createcount + 1"]);
data[0].addScript(["variable 1 = 1","enemy currentcount < 1","enemy createcount = 0"], ["music change "+musicName.music08_space_music+"",  "variable 1 = 2", "group 0 createcount + 80"]);
data[0].addScript(["variable 1 = 2","enemy currentcount < 1","enemy createcount = 0"], ["music change "+musicName.music09_battle_music+"", "variable 1 = 3", "group 1 createcount + 1" ]);
data[0].addScript(["variable 1 = 3","enemy currentcount < 1","enemy createcount = 0"], ["music change "+musicName.music08_space_music+"",  "variable 1 = 4", "group 0 createcount + 100"]);
data[0].addMap(13, 4, 0, true, false);
data[0].createRound("운석지대 4, 자주 충돌하는 무인기", 220, 120, 800, musicName.music08_space_music);
data[0].addRoundEnemy([5,6,7,8,9], 25, 51);
data[0].addRoundEnemy([29], 0, 1);
data[0].addScript(["variable 1 = 0","enemy currentcount < 1","enemy createcount = 0"], ["music change "+musicName.music09_battle_music+"", "variable 1 = 1", "group 1 createcount + 1"]);
data[0].addScript(["variable 1 = 1","enemy currentcount < 1","enemy createcount = 0"], ["music change "+musicName.music08_space_music+"",  "variable 1 = 2", "group 0 createcount + 25"]);
data[0].addScript(["variable 1 = 2","enemy currentcount < 1","enemy createcount = 0"], ["music change "+musicName.music09_battle_music+"", "variable 1 = 3", "group 1 createcount + 1" ]);
data[0].addScript(["variable 1 = 3","enemy currentcount < 1","enemy createcount = 0"], ["music change "+musicName.music08_space_music+"",  "variable 1 = 4", "group 0 createcount + 30"]);
data[0].addScript(["variable 1 = 4","enemy currentcount < 1","enemy createcount = 0"], ["music change "+musicName.music09_battle_music+"", "variable 1 = 5", "group 1 createcount + 1"]);
data[0].addScript(["variable 1 = 5","enemy currentcount < 1","enemy createcount = 0"], ["variable 1 = 6", "group 1 createcount + 1", "group 0 createcount + 60" ]);
data[0].addMap(13, 4, 0, true, false);
data[0].createRound("운석지대 5, 알수없는 의식의 공간", 180, 132, 600, musicName.music09_battle_music);
data[0].addRoundEnemy([5,6,7,8,9], 25, 51);
data[0].addRoundEnemy([30], 1, 1);
data[0].addMap(18, 0, 0, true, false);
data[0].createRound("운석지대 6", 170, 125, 400, musicName.music08_space_music);
data[0].addRoundEnemy([5,6,7,8,9], 272, 42);
data[0].addMap(13, 4, 0, true, false);
data[0].addScript(["variable 1 = 0","enemy currentcount < 1","enemy createcount = 0"], ["music change "+musicName.music09_battle_music+"", "variable 1 = 1", "group 1 createcount + 1"]);
data[0].addScript(["variable 1 = 1","enemy currentcount < 1","enemy createcount = 0"], ["music change "+musicName.music08_space_music+"",  "variable 1 = 2", "group 0 createcount + 117"]);
data[0].createRound("운석지대 7", 170, 125, 400, musicName.music08_space_music);
data[0].addRoundEnemy([5,6,7,8,9], 210, 36);
data[0].addRoundEnemy([0,1,2,3,4], 0, 36);
data[0].addMap(13, 4, 0, true, false);
data[0].addScript(["variable 1 = 0","enemy currentcount < 1","enemy createcount = 0"], ["music change "+musicName.music01_space_tour+"", "variable 1 = 1", "group 1 createcount + 242", "map change 12"]);
data[0].createRound("우주 여행 4, 센티멘탈 은하계 여행", 180, 133, 200, musicName.music01_space_tour);
data[0].addRoundEnemy([0,1,2,3,4], 1120, 48);
data[0].addMap(12, 5, 0, true, false);
data[0].createRound("우주 여행 5, 파란행성 가는길", 180, 133, 200, musicName.music01_space_tour);
data[0].addRoundEnemy([0,1,2,3,4], 690, 20);
data[0].addMap(12, 5, 0, true, false);
data[0].createRound("우주 여행 6, 파란행성 진입구간", 80, 125, 100, musicName.music01_space_tour);
data[0].addRoundEnemy([0,1,2,3,4], 29, 12);
data[0].addRoundEnemy([11,12,13,14], 37, 4);
data[0].addMap(12, 3, 0, true, false);
data[0].addScript(["variable 2 < 500"], ["variable 2 + 1", "infinity"]);
data[0].addScript(["variable 2 = 500"], ["map change 14"]);
//---------------------------------//
data[0].createRound("파란 행성 1, 높이: 300km ~ 290km", 180, 140, 500, musicName.music02_paran_planet);
data[0].addRoundEnemy([11,12,13,14], 112, 4);
data[0].addMap(15, 0, 4, false, true);
data[0].createRound("파란 행성 2, 높이: 290km ~ 280km", 180, 142, 500, musicName.music02_paran_planet);
data[0].addRoundEnemy([11,12,13,14], 125, 7);
data[0].addMap(16, 0, 4, false, true);
data[0].createRound("파란 행성 3, 높이: 280km ~ 270km", 180, 142, 500, musicName.music02_paran_planet);
data[0].addRoundEnemy([11,12,13,14], 135, 10);
data[0].addMap(16, 0, 4, false, true);
data[0].createRound("파란 행성 4, 높이: 270km ~ 260km", 180, 144, 540, musicName.music02_paran_planet);
data[0].addRoundEnemy([11,12,13,14], 172, 22);
data[0].addMap(17, 4, 4, true, true);
data[0].createRound("파란 행성 5, 높이: 260km ~ 250km", 180, 144, 540, musicName.music02_paran_planet);
data[0].addRoundEnemy([11,12,13,14], 200, 30);
data[0].addMap(17, 4, 4, true, true);
//---------------------------------//
data[0].createRound("동그라미 마을 1, 마을 입구와 통로", 180, 150, 700, musicName.music03_donggrami_maeul);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18], 32, 32);
data[0].addRoundEnemy([19,20,21,22,23,24,25,26], 32, 32);
data[0].addMap(20, 1, 0, false, false);
data[0].addScript(["variable 1 = 0","enemy currentcount < 1","enemy createcount = 0"], ["variable 1 = 1", "system round clear impossible"]);
data[0].addScript(["variable 1 = 1", "variable 2 < 400"], ["variable 2 + 1", "infinity"]);
data[0].addScript(["variable 2 = 150"], ["variable 3 = 1", "group 0 createcount + 73", "group 1 createcount + 73", "map change 21"]);
data[0].addScript(["variable 3 = 1", "variable 2 = 300"], ["map speedx = 4", "map loopx true", "system round clear possible"]);
data[0].createRound("동그라미 마을 2, 동그라미 아파트 1, 2단지", 177, 155, 700, musicName.music03_donggrami_maeul);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 270, 60);
data[0].addMap(22, 2, 0, true, false);
data[0].createRound("동그라미 마을 3, 동그라미 아파트 3, 4단지", 177, 155, 700, musicName.music03_donggrami_maeul);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 287, 72);
data[0].addMap(23, 2, 0, true, false);
data[0].createRound("동그라미 마을 4, 동그라미 아파트 공원", 191, 158, 700, musicName.music03_donggrami_maeul);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 254, 34);
data[0].addMap(24, 2, 0, true, false);
data[0].createRound("동그라미 마을 5, 마을 회관 복도", 160, 171, 500, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 75, 15);
data[0].addMap(25, 2, 0, true, false);
data[0].createRound("동그라미 마을 6, 마을 회관 중앙", 150, 171, 500, musicName.none);
data[0].addRoundEnemy([28], 1, 1);
data[0].addMap(26, 0, 0, true, false);
data[0].createRound("동그라미 마을 7, 수많은 동그라미", 200, 171, 500, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(26, 0, 0, true, false);
data[0].createRound("동그라미 마을 8, 상가 지역", 233, 186, 1350, musicName.music04_donggrami_maeul_part2);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(27, 2, 0, true, false);
data[0].createRound("동그라미 마을 9, 동그라미 아파트 5, 6단지", 217, 186, 1350, musicName.music04_donggrami_maeul_part2);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(28, 2, 0, true, false);
data[0].createRound("동그라미 마을 10, 건물지대 1", 233, 186, 1420, musicName.music04_donggrami_maeul_part2);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(29, 2, 0, true, false);
data[0].createRound("동그라미 마을 11, 건물지대 2", 233, 186, 1420, musicName.music04_donggrami_maeul_part2);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(30, 2, 0, true, false);
data[0].createRound("동그라미 마을 12, 조용한 도로", 214, 191, 1440, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(31, 2, 0, true, false);
data[0].createRound("동그라미 마을 13, 동그라미마을의 끝지점, 다운 타워 입구", 144, 191, 1440, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(32, 2, 0, false, false);
//---------------------------------//
data[0].createRound("다운타워 1, 50km 지점", 280, 240, 2200, musicName.music05_down_tower);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(40, 1, 4, true, true);
data[0].createRound("다운타워 2, 45km 지점", 280, 244, 2270, musicName.music05_down_tower);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(40, 1, 4, true, true);
data[0].createRound("다운타워 3, 40km 지점", 280, 248, 2340, musicName.music05_down_tower);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(41, 1, 4, true, true);
data[0].createRound("다운타워 4, 35km 지점", 280, 252, 2420, musicName.music05_down_tower);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(41, 1, 4, true, true);
data[0].createRound("다운타워 5, 30km 지점", 280, 256, 2460, musicName.music05_down_tower);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(42, 1, 4, true, true);
data[0].createRound("다운타워 6, 25km 지점", 280, 260, 2500, musicName.music05_down_tower);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(42, 1, 4, true, true);
data[0].createRound("다운타워 7, 23km 지점, 안티 레이져 보스 처치", 380, 300, 4000, musicName.music05_down_tower);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(42, 1, 4, true, true);
data[0].createRound("다운타워 8, 다운타워 통로 1, 23km 지점", 170, 242, 2370, musicName.music06_down_tower_passage);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(44, 22, 11, true, true);
data[0].createRound("다운타워 9, 다운타워 통로 2, 17km 지점", 170, 245, 2370, musicName.music06_down_tower_passage);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(44, 22, 11, true, true);
data[0].createRound("다운타워 10, 다운타워 통로 3, 10km 지점", 170, 248, 2370, musicName.music06_down_tower_passage);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(45, 22, 11, true, true);
data[0].createRound("다운타워 11, 다운타워 통로 4, 3km 지점", 170, 251, 2370, musicName.music06_down_tower_passage);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(45, 22, 11, true, true);
data[0].createRound("다운타워 12, 타워의 바깥 1, 2km 지점", 166, 266, 2660, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(46, 0, -3, true, true);
data[0].createRound("다운타워 13, 타워의 바깥 2, 5km 지점, end of part 1", 217, 266, 2660, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].addMap(46, 0, -3, true, true);

//---------------------------------//
data[0].createRound("Test", 180, 125, 600, musicName.none);
data[0].addRoundEnemy([27], 199, 1);
data[0].setBoss(10);
data[0].addMap("image/round/round46.png", 0, -3, true, true);
//---------------------------------// part 1의 적
data[0].createEnemy(0, "약한 빨간색 빛", 18000, 2, 0, 1); // 0
data[0].createEnemy(1, "약한 주황색 빛", 18000, 2, 0, 2); // 1
data[0].createEnemy(2, "약한 초록색 빛", 18000, 2, 0, 3);
data[0].createEnemy(3, "약한 파란색 빛", 18000, 2, 0, 4);
data[0].createEnemy(4, "약한 노란색 빛", 18000, 2, 0, 5);
for(var a = 0; a <= 4; a++)  data[0].setEnemy(a, 10, 10, "random", soundName.light_break, "");
//------------------//
data[0].createEnemy(5, "하얀색 운석", 43000, 131, 244, 6);
data[0].createEnemy(6, "갈색 운석",   44000, 137, 250, 7);
data[0].createEnemy(7, "회색 운석",   45000, 140, 255, 8);
data[0].createEnemy(8, "분홍색 운석", 46000, 135, 240, 9);
data[0].createEnemy(9, "하늘색 운석", 47000, 129, 253, 10);
data[0].createEnemy(10, "대형 운석",  48000, 136, 844, 11);
for(var a = 5; a <= 10; a++)  data[0].setEnemy(a, 7, 7, "random", soundName.meteorite_break, "");
//------------------//
data[0].createEnemy(11, "파랑색 동그라미", 75000, 232, 109, 12);
data[0].createEnemy(12, "검파랑 동그라미", 75440, 242, 111, 13);
data[0].createEnemy(13, "하늘색 동그라미", 76180, 251, 113, 14);
data[0].createEnemy(14, "검하늘 동그라미", 76655, 260, 115, 15);
for(var a = 11; a <= 14; a++)  data[0].setEnemy(a, 5, 5, "random", soundName.dongrami_fail, "");
//------------------//
data[0].createEnemy(15, "초록색 동그라미", 77000, 270, 120, 16);
data[0].createEnemy(16, "검초록 동그라미", 77232, 274, 122, 17);
data[0].createEnemy(17, "연두색 동그라미", 77966, 278, 123, 18);
data[0].createEnemy(18, "검연두 동그라미", 78410, 282, 124, 19);
for(var a = 15; a <= 18; a++)  data[0].setEnemy(a, 4, 4, "random", soundName.dongrami_fail, "");
//------------------//
data[0].createEnemy(19, "노랑색 동그라미", 79000, 286, 125, 20);
data[0].createEnemy(20, "검노랑 동그라미", 79230, 290, 128, 21);
data[0].createEnemy(21, "주황색 동그라미", 79550, 294, 129, 22);
data[0].createEnemy(22, "검주황 동그라미", 80110, 298, 131, 23);
for(var a = 19; a <= 22; a++)  data[0].setEnemy(a, 3, 3, "random", soundName.dongrami_fail, "");
//------------------//
data[0].createEnemy(23, "빨강색 동그라미", 81150, 300, 132, 24);
data[0].createEnemy(24, "검빨강 동그라미", 81420, 303, 134, 25);
data[0].createEnemy(25, "분홍색 동그라미", 81770, 306, 136, 26);
data[0].createEnemy(26, "검분홍 동그라미", 82000, 309, 138, 27);
data[0].createEnemy(27, "???", 444444, 0, 1555, 27);  data[0].setEnemy(27, 2, 2, "noexit", soundName.dongrami_fail, "");
for(var a = 23; a <= 26; a++)  data[0].setEnemy(a, 2, 2, "random", soundName.dongrami_fail, "");
//------------------//
data[0].createEnemy(28, "대형 동그라미", 1873500, 4390, 2667, 34);      data[0].setEnemy(28, 5, 5, "noexit", soundName.dongrami_fail, "");
data[0].createEnemy(29, "무인기 탐사선", 1024250, 2469, 1732, 54);       data[0].setEnemy(29, 0, 2, "noexit", soundName.wall_break, "");  data[0].setAttack(29);
data[0].createEnemy(30, "무인기 탐사선 금색", 4024250, 3469, 3087, 55);  data[0].setEnemy(30, 0, 1, "noexit", soundName.wall_break, "");  data[0].setAttack(30);

this.getDungeonCount = function(){  return dungeonCount; };
this.getDungeonName = function(index){  return data[index].name; };
this.getRoundCount = function(D){  return data[D].getRoundCount(); };
this.getRoundName = function(D, R){  return data[D].round[R].name; };

this.getRound = function(D, R){  return data[D].round[R]; };
this.getEnemy = function(D){  return data[D].enemy; };
};//function Dungeon end
optionbattle.dungeon = new Dungeon(); //던전 생성
