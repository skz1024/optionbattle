function User(){
//function User start
//-----------------------------//
var name = "user"; // 유저의 이름, 생성될 때 선언
var lv = 1, maxLv = 40, exp = 0; // 레벨, 최대레벨, 경험치
var fuel = 1000, fuelMax = 1000; // 연료, 연료최대치
var gold = 100000, crystal = 10; // 골드(게임머니), 크리스탈(현질...)

var expTable = [0, 181100, 181200, 181300, 181400, 181500, 181600, 181700, 181800, 181900, 182000,
                255500, 256000, 256500, 257000, 257500, 258000, 258500, 259000, 259500, 260000,
                361200, 362400, 363600, 364800, 366000, 367200, 368400, 369600, 370800, 372000,
                511100, 512200, 513300, 514400, 515500, 516600, 517700, 518800, 519900, 521000];

//각 스탯들을 리턴하는 함수는 get 메서드에 정의한다.
this.getname = function(){  return name; };
this.getlv = function(){  return lv; };
this.getmaxLv = function(){  return maxLv; };
this.getexp = function(){  return exp; };
this.getfuel = function(){  return fuel; };
this.getfuelMax = function(){  return fuelMax; };
this.getcrystal = function(){  return crystal; };
this.getgold = function(){  return gold; };
this.getexpTable = function(){  return expTable; };

//각 스탯들의 능력치를 추가하거나 감소하거나 변경하는 함수들
//plus : 더하기(증가), minus : 빼기(감소), set : 변경
this.plusgold = function(value){  gold += value; };
this.minusgold = function(value){  gold -= value; };
this.setgold = function(value){  gold = value; };
this.plusfuel = function(value){  fuel += value;  if(fuel >= fuelmax) fuel = fuelmax; };
this.minusfuel = function(value){  fuel -= value;  if(fuel <= 0)  fuel = 0;  };
this.setfuel = function(value){  fuel = value;  if(fuel >= fuelMax) fuel = fuelMax; }; 
this.pluscrystal = function(value){  crystal += value; };
this.minuscrystal = function(value){  crystal -= value; };
this.plusexp = function(value){ // 경험치 추가 함수(감소함수는 없음)
	exp += value;
	if(exp >= expTable[lv]){ // 경험치 초과되는지 체크
		for(;;){ // 초과가 될경우
			if( lv >= maxLv && exp >= expTable[lv]){ lv = maxlv;  exp = expTable[lv];  break; }
			else if( exp <= expTable[lv] )  break;
			else{  exp -= expTable[lv];  lv++;  optionbattle.sound.play(soundName.levelup);  }
		}
	}
};


const UNUSED = -1;
const TEAM_SYSTEM_HEAL = 20,  TEAM_SYSTEM_METAL = 21;
var teamunit = [UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, 
    			UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED, UNUSED]; // 팀유닛 초기화
function teamunitCheck(){
    for(var i = 0; i < teamunit.length; i++){
    	teamunit[i] = UNUSED;
    }
    
    for(var a = 0; a < inventory.data.length; a++){  // 팀유닛 체크
        var teamNumber = inventory.data[a].teamunit;
        if(teamNumber != UNUSED){ 
            teamunit[teamNumber] = a;
        }
    }
}
function getInventoryUnit(inventoryNumber){
	if(inventoryNumber != UNUSED){
		return optionbattle.unit.getUnit(inventory.data[inventoryNumber].code);
	} else {
		return 0;
	}
}

function setTeamunit(inventoryNumber){
	// 타입이름이 힐인지 메탈인지를 구분한다.
	if(getInventoryUnit(inventoryNumber).type == typeName.HEAL){
    	if(teamunit[TEAM_SYSTEM_HEAL] == UNUSED){
    		inventory.data[inventoryNumber].teamunit = TEAM_SYSTEM_HEAL;
    		teamunitCheck();  return true;
    	} else {
    		changeTeamunit(TEAM_SYSTEM_HEAL, inventoryNumber);
    		return true;
    	}
	} else if(getInventoryUnit(inventoryNumber).type == typeName.METAL){
		if(teamunit[TEAM_SYSTEM_METAL] == UNUSED){
    		inventory.data[inventoryNumber].teamunit = TEAM_SYSTEM_METAL;
    		teamunitCheck();  return true;
    	} else {
    		changeTeamunit(TEAM_SYSTEM_METAL, inventoryNumber);
    		return true;
    	}
	}
    
    // 팀유닛은 22마리.. 이중 2마리는 고정이므로 20마리까지 넣을 수 있음.	
    for(var a = 0; a < teamunit.length - 2; a++){
        if(teamunit[a] == UNUSED){
            inventory.data[inventoryNumber].teamunit = a;
            teamunitCheck();  return true;
        }
    }
    return false; // 팀유닛 지정 실패
}
function changeTeamunit(teamunitNumber, inventoryNumber){
	// 인벤토리에 있는 팀유닛번호를 삭제
	inventory.data[teamunit[teamunitNumber]].teamunit = UNUSED;
	
	// 새로운 팀유닛 삽입
	inventory.data[inventoryNumber].teamunit = teamunitNumber;
	teamunitCheck();
}

var inventory = {};
inventory.data = new Array(1000);
for(var a = 0; a < inventory.data.length; a++){  inventory.data[a] = new InventoryArray(); }
inventory.useCount = 0;
inventory.maxLimit = inventory.data.length;

inventory.spaceDelete = function(){
    var process = 0;
    var data = inventory.data;
    for(var a = 0, process = 0; a < inventory.data.length; a++){
        if(data[a].type != ""){  process++;  }
    } // 현재 가지고 있는 아이템의 수를 조사
    
    for(var a = 0, b = 0; a < data.length || b < process; a++){
        // a = 조사하는 데이터 번호, b = 진행 구간
        if(a == process && data[a].type != ""){
            b++;  continue; // 진행 구간을 더하고 그대로 넘어감
        } else if(data[a].type != ""){
            inventory.change(b, a);
            b++; // 진행 구간을 더하고 아이템의 위치를 변경
        }
    } // 해당 for문에서 빈 공간 전부 삭제
    
    for(var a = process; a < data.length; a++){
        inventory.deleteData(a);
    } // 남은 공간에 있는 아이템은 전부 삭제
};

inventory.change = function(index1, index2){
    var temp = inventory.data[index1];
    inventory.data[index1] = inventory.data[index2];
    inventory.data[index2] = temp;
};

inventory.deleteData = function(index){
    inventory.data[index] = new InventoryArray();
};

inventory.add = function(type, code, lv){
    if(inventory.isFull() == true){  alert("인벤토리가 꽉 차 더이상 아이템을 생성할 수 없습니다."); return; }
    
    //inventory.spaceDelete();
    inventory.checkUseCount();
    
    inventory.data[inventory.useCount].type = type;
    inventory.data[inventory.useCount].code = code;
    inventory.data[inventory.useCount].lv = lv;
};

inventory.checkUseCount = function(){
    inventory.useCount = 0;
    for(var a = 0; a < inventory.data.length; a++){
        if(inventory.data[a].type != ""){
            inventory.useCount++;
        }
    }
};

inventory.isFull = function(){
    for(var a = 0; a < inventory.data.length; a++){
        if(inventory.data[a].type == ""){
            return false;
    }   }
    return true;
};

inventory.setTeamunit = function(index, teamNumber){
    inventory.data[index].teamunit = teamNumber;
    teamunitCheck();
};

function InventoryArray(){
    this.type = "";
    this.code = 0;
    this.lv = 0;
    this.extend = 0;
    this.teamunit = UNUSED;
}


this.addInventoryData = function(type, code, lv){
    inventory.add(type, code, lv);
};
this.deleteInventoryData = function(index){
    inventory.deleteData(index);
    teamunitCheck();
};
this.getTeamunit = function(){
    return teamunit;
};
this.getInventoryData = function(index){
    if(index != null)  return inventory.data[index];
    else  return inventory.data;
};
this.getInventory = function(){
    return inventory;
};
this.setTeamunit = function(inventoryNumber){
    return setTeamunit(inventoryNumber);
};
this.deleteTeamunit = function(number){
    var inventoryNumber = teamunit[number];
    inventory.data[inventoryNumber].teamunit = UNUSED;
    teamunitCheck();
};

(function(){
	// 기본 유닛
    inventory.add("unit", 1, 0);   setTeamunit(0);
    inventory.add("unit", 1, 0);   setTeamunit(1);
    inventory.add("unit", 2, 0);   setTeamunit(2);
    inventory.add("unit", 2, 0);   setTeamunit(3);
    inventory.add("unit", 3, 0);   setTeamunit(4);
    inventory.add("unit", 3, 0);   setTeamunit(5);
    inventory.add("unit", 4, 0);   setTeamunit(6);
    inventory.add("unit", 4, 0);   setTeamunit(7);
    inventory.add("unit", 5, 0);   setTeamunit(8);
    inventory.add("unit", 6, 0);   setTeamunit(9);
    inventory.add("unit", 7, 0);   setTeamunit(10);
    inventory.add("unit", 8, 0);   setTeamunit(11);
    inventory.add("unit", 9, 0);   setTeamunit(12);
    inventory.add("unit", 10, 0);  setTeamunit(13);
    inventory.add("unit", 11, 0);  setTeamunit(14);
    inventory.add("unit", 12, 0);  setTeamunit(15);
    inventory.add("unit", 12, 0);  setTeamunit(16);
    inventory.add("unit", 13, 0);  setTeamunit(17);
    inventory.add("unit", 13, 0);  setTeamunit(18);
    inventory.add("unit", 14, 0);  setTeamunit(19);
    inventory.add("unit", 15, 0);  setTeamunit(20);
    inventory.add("unit", 16, 0);  setTeamunit(21);
})();


//-------------------------------//
} // function end;

optionbattle.user = new User(); // 유저란 이름을 사용하는 유저 객체 생성