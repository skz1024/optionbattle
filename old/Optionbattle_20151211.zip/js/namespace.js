function NAMESPACE_OPTION_BATTLE(){
	this.unit = new Array(100); // 유닛의 정보를 저장하는 배열 생성
	this.item = new Array(100); // 아이템의 정보를 저장하는 배열 생성
	this.combination = new Array(100); // 아이템의 조합 정보를 저장하는 배열 생성
	this.dungeon = new Array(100); // 던전의 정보를 저장하는 배열 생성
	this.enemy = new Array(100); // 적의 정보를 저장하는 배열 생성
	this.story = new Array(100);
	this.game = {};
	this.sound = {};
	this.music = {};
	this.background = {};
	this.user = {};
}

// 네임스페이스 사용하기
var optionbattle = new NAMESPACE_OPTION_BATTLE();// namespace 선언
var canvas = document.getElementById("canvas");
/*canvas.addEventListener("click",function () {
canvas.style.width = ""+window.innerWidth+"px";
//canvas.style.height= ;
if  ( canvas . requestFullscreen )  { 
  canvas . requestFullscreen ( ) ; 
}  else  if  ( canvas . msRequestFullscreen )  { 
  canvas . msRequestFullscreen ( ) ; 
}  else  if  ( canvas . mozRequestFullScreen )  { 
  canvas . mozRequestFullScreen ( ) ; 
}  else  if  ( canvas . webkitRequestFullscreen )  { 
  canvas . webkitRequestFullscreen ( ) ; 
}  }, false);*/

var ctx = canvas.getContext('2d'); // canvas 기능 사용
delete NAMESPACE_OPTION_BATTLE;

var imageBoxEnemy = new Array();
(function(){
    imageBoxEnemy[0] = new Image();  imageBoxEnemy[0].src = "image/system/unused.png";
    for(var a = 1; a <= 55; a++){
        imageBoxEnemy[a] = new Image();
        imageBoxEnemy[a].src = "image/enemy/enemy"+a+".png";
    }
})();
var imageBoxRoundList = [10, 11, 12, 13, 14, 15, 16, 17, 18, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 40, 41, 42, 43, 44, 45, 46];
var imageBoxRound = new Array();
(function(){
	for(var a = 0; a < imageBoxRoundList.length; a++){
		imageBoxRound[a] = new Image();
		imageBoxRound[a].number = a;  // 이미지 번호
		imageBoxRound[a].code = imageBoxRoundList[a]; // 이미지박스 리스트
		imageBoxRound[a].src = "image/round/round"+imageBoxRoundList[a]+".png"; // 라운드
	}
})();
function get_imageBoxRound(listNumber){
	for(var a = 0; a < imageBoxRoundList.length; a++){
		if(listNumber == imageBoxRoundList[a]){
			return imageBoxRound[a];
		}
	}
}
