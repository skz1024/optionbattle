// 사운드 파일 이름을 그대로 쓰시고 번호는 중복되지만 않게 하면 됩니다.
const soundName = { none:0, select_move:1, select_enter:2, select_back:3, select_menu:4,
	 system_buzzer:5, system_score:6, system_upgrade:7, system_notice:8, type_hyper:9, type_heal:10,
	 arrowshot:11, bubble:12, dongrami_fail:13, highattack:14, splashdamage:15, swordattack:16,
	 전자기장:17, multishot:18, laserA:19, whiteflash:20,  bombmissile:21, bomb:22, light_break:23,
	 system_pause:24, bombattack:25, meteorite_break:26, levelup:27, wall_break:28, warning_strong_missile_detected:29,
	 strong_missile_detected:30, strong_missile_bomb:31, blackhole:32, linelaser:33, damage:34,
	 hitshot:35, sawtooth_attack:36, sawtooth_launch:37, parapo:38, fire:39, palsern_wait:40, palsern_hit:41, palsern_miss:42,
	 machinegun:43, beam1:44, beam2:45, beam3:46, burstshot:47, burstshot_hit:48, burstshot_saw:49, enemyshot:50,
	 tamsaseonwarning:51, tamsaseon_recoverytime:52
	 
	};

function Sound(){
//사운드는 이 객체에서 처리합니다.
var sound = new Array(100); // 사운드 파일 저장
var createCount = -1;
function create(constSound, src){
	sound[constSound] = new Audio();
	sound[constSound].src = src;
	createCount++;
	sound[constSound].preload = true;
}

this.play = function(constSound){
	if(optionbattle.game.getsoundOn() == false)  return;
	
	if(sound[constSound].paused == true){
		sound[constSound].play(); // 사운드 출력
	} else {
		sound[constSound].pause();
		sound[constSound].currentTime = 0;
		sound[constSound].play();
	}
};
this.test = function(constSound){
	if(optionbattle.game.getsoundOn() == false)  return;

	if(sound[constSound].paused == true){
		sound[constSound].play(); // 사운드 출력
	} else {
		sound[constSound].pause();
		sound[constSound].currentTime = 0;
		sound[constSound].play();
	}
};
this.getCount = function(){
    return createCount;
};

// 사운드 만들기
create(soundName.none, "sound/none.wav");
create(soundName.select_move, "sound/select_move.wav");
create(soundName.select_enter, "sound/select_enter.wav");
create(soundName.select_back, "sound/select_back.wav");
create(soundName.select_menu, "sound/select_menu.wav");
create(soundName.system_buzzer, "sound/system_buzzer.wav");
create(soundName.system_notice, "sound/system_notice.wav");
create(soundName.system_score, "sound/system_score.wav");
create(soundName.system_upgrade, "sound/system_upgrade.wav");
create(soundName.type_heal, "sound/type_heal.wav");
create(soundName.type_hyper, "sound/type_hyper.wav");
create(soundName.arrowshot, "sound/arrowshot.wav");
create(soundName.bubble, "sound/bubble.wav");
create(soundName.dongrami_fail, "sound/dongrami_fail.wav");
create(soundName.highattack, "sound/highattack.wav");
create(soundName.splashdamage, "sound/splashdamage.wav");
create(soundName.swordattack, "sound/swordattack.wav");
create(soundName.전자기장, "sound/전자기장.wav");
create(soundName.bombmissile, "sound/bombmissile.wav");
create(soundName.whiteflash, "sound/whiteflash.wav");
create(soundName.multishot, "sound/multishot.wav");
create(soundName.laserA, "sound/laserA.wav");
create(soundName.bomb, "sound/bomb.wav");
create(soundName.light_break, "sound/light_break.wav");
create(soundName.system_pause, "sound/system_pause.wav");
create(soundName.bombattack, "sound/bombattack.wav");
create(soundName.meteorite_break, "sound/meteorite_break.wav");
create(soundName.levelup, "sound/levelup.wav");
create(soundName.wall_break, "sound/wall_break.wav");
create(soundName.warning_strong_missile_detected, "sound/warning_strong_missile_detected.wav");
create(soundName.strong_missile_detected, "sound/strong_missile_detected.wav");
create(soundName.strong_missile_bomb, "sound/strong_missile_bomb.wav");
create(soundName.blackhole, "sound/blackhole.wav");
create(soundName.linelaser, "sound/linelaser.wav");
create(soundName.damage, "sound/damage.wav");
create(soundName.hitshot, "sound/hitshot.wav");
create(soundName.sawtooth_attack, "sound/sawtooth_attack.wav");
create(soundName.sawtooth_launch, "sound/sawtooth_launch.wav");
create(soundName.parapo, "sound/parapo.wav");
create(soundName.fire, "sound/fire.wav");
create(soundName.palsern_wait, "sound/palsern_wait.wav");
create(soundName.palsern_hit, "sound/palsern_hit.wav");
create(soundName.palsern_miss, "sound/palsern_miss.wav");
create(soundName.machinegun, "sound/machinegun2.wav");
create(soundName.beam1, "sound/beam1.wav");
create(soundName.beam2, "sound/beam2.wav");
create(soundName.beam3, "sound/beam3.wav");
create(soundName.burstshot, "sound/burstshot.wav");
create(soundName.burstshot_hit, "sound/burstshot_hit.wav");
create(soundName.burstshot_saw, "sound/burstshot_saw.wav");
create(soundName.enemyshot, "sound/enemyshot.wav");
create(soundName.tamsaseonwarning, "sound/tamsaseonwarning.wav");
create(soundName.tamsaseon_recoverytime, "sound/tamsaseon_recoverytime.wav");
//var soundPlayCount = new Array(100*5);
//for(var a=0, length = soundPlayCount.length; a < length; a++) soundPlayCount[a] = 0;
} // 객체 종료






//---------------------------//
//이 파일은 배경음악과 관련 있는 파일입니다.
var musicName = { none:0, title:1, roundclear:2, roundfail:3, 
        music01_space_tour:11, music02_paran_planet:12, music03_donggrami_maeul:13,
		music04_donggrami_maeul_part2:14, music05_down_tower:15, music06_down_tower_passage:16,
		music07_down_tower_boss:17, music08_space_music:18, music09_battle_music:19
		};
function Music(){
//--------------------//
var music = new Array(100);
for(var a = 0; a < music.length; a++)  music[a] = new Audio();
var currentmusicCode = 0;
var playmusicCode = 0;
var lastmusicCode = 0;
var musicEndCheck = false;
var musicStopCheck = false;
var musicCount = -1;
var isPlay = false;
var delay = 0;
var count = 0;
var fade = {  nextMusic:0, time:0, volume:0, out:false, in:false, count:200, maxvolume:100};

function create(constMusic, src, loopOption){
	musicCount++;
	music[constMusic] = new Audio();
	music[constMusic].src = src; // 경로 지정
	music[constMusic].preload = true;
	if(loopOption != false){
		music[constMusic].loop = true; // music은 루프를 활성화.
	}
	
	if(lastmusicCode <= constMusic)  lastmusicCode = constMusic;
}

this.play = function(constMusic){
	isPlay = true;
	fade.nextMusic = 0;
	fade.time = 0;
	musicStopCheck = false;
	music[playmusicCode].pause(); // 현재 음악 정지
	music[playmusicCode].currentTime = 0; // 재생 시간을 0초로 변경
	
	playmusicCode = constMusic; // 재생중인 musicCode를 저장
	if(optionbattle.game.getmusicOn() == false)  return; // 음악이 on되어있지 않은경우 함수 종료.
	
	music[constMusic].play(); // 배경음악 재생
	music[constMusic].currentTime = 0;
	fade.volume = fade.maxvolume; // 볼륨 최대치로 저장
};
this.change = function(constMusic){ // play랑 비슷하지만, change를 하게되면 페이드아웃과 페이드인을 자동으로 하게된다.
	if(isPlay){ // 플레이 중인경우
		fade.time = fade.count;
		fade.volume = fade.maxvolume;
		fade.out = true;
		fade.nextMusic = constMusic;
	} else { // 플레이중이 아닌경우
		fade.time = fade.count / 2; // 2로 나누는건 페이드인만 처리하기 위해서
		playmusicCode = constMusic;
		fade.nextMusic = playmusicCode;
		fade.out = true;
		fade.volume = 0;
	}
};
this.test = function(constMusic){
	musicStopCheck = false;
	music[playmusicCode].pause(); // 현재 음악 정지
	music[playmusicCode].currentTime = 0; // 재생 시간을 0초로 변경
	
	music[constMusic].play(); // 배경음악 재생
	playmusicCode = constMusic; // 재생중인 musicCode를 저장
};
this.reset = function(){
	music[playmusicCode].pause(); // 현재 음악 정지
	music[playmusicCode].currentTime = 0; // 재생 시간을 0초로 변경
	music[playmusicCode].play(); // 배경음악 재생
};
this.check = function(){
	if(playmusicCode == 0){ // 코드가 0일경우 아무것도 처리하지 않음.
		isPlay = false; // 음악재생중이 아니므로 play부분을 false로 변경
	} else if(optionbattle.game.getmusicOn() == false || musicStopCheck == true){ // 음악설정이 OFF로 되어있을경우 또는 음악을 정지하였을경우
		music[playmusicCode].pause(); // 현재 음악 정지
	} else { // 음악이 재생중인경우.
		isPlay = true;
		// 페이드 인 또는 페이드 아웃의 상황의 경우
		if(fade.time > fade.count / 2 && fade.time <= 500){  fade.volume -= fade.maxvolume / fade.count * 2;  }
		else if(fade.time > 0 && fade.time <= 500){  fade.volume += fade.maxvolume / fade.count * 2; }
		
		if(fade.time <= 0)  fade.volume = 100;
		else if(fade.time == fade.count / 2 && fade.out){
			 music[playmusicCode].pause(); // 현재 재생중인 음악 정지
			 fade.volume = 0;  playmusicCode = fade.nextMusic;  fade.out = false; // 그리고 다음 음악을 재생함.
		}
		fade.time--;
		
		if(fade.volume > 100)  fade.volume = 100;
		if(fade.volume < 0)  fade.volume = 0;
		
		//볼륨을 설정할 때 1에서 0 사이로 설정할것, 1은 최대치를 의미함.
		music[playmusicCode].volume = fade.volume / 100;
		
		// 음악이 일시정지되었고 음악의 루프가 true인경우, 이경우 음악을 다시 재생한다.
		if(music[playmusicCode].paused == true && music[playmusicCode].loop == true){
			music[playmusicCode].play();
		}
	}
};
this.stop = function(){ musicStopCheck = true; };
this.previousmusic = function(){
    for(var a = currentmusicCode; a > 0; ){
        a--; // 다음 뮤직으로 코드를 변경
        currentmusicCode = a;
        if(music[a].src != "")  return a; 
    }
    return 0;
};
this.nextmusic = function(){
    if(currentmusicCode == lastmusicCode)  return lastmusicCode; // 마지막 음악일경우 생략
    for(var a = currentmusicCode; a < music.length; ){
        a++; // 다음 뮤직으로 코드를 변경
        currentmusicCode = a;
        if(music[a].src != "")  return a;
    }
    currentmusicCode = lastmusicCode; // 다음 음악이 마지막일경우의 처리
    return lastmusicCode;
};
this.continue = function(){ musicStopCheck = false; }; // deplecated.
this.continueMusic = function(){ musicStopCheck = false; };
this.time = function(){ return music[playmusicCode].currentTime.toFixed(2); };
this.getmusicCount = function(){  return musicCount; };
this.duration = function(){ 
	var argumentsData = arguments[0] || currentmusicCode;
	var durationData = music[argumentsData].duration;
    return durationData.toFixed(2);
};
this.plus5 = function(){
    if(music[playmusicCode].currentTime + 5 < music[playmusicCode].duration){
        music[playmusicCode].currentTime += 5;
    } else {
        music[playmusicCode].currentTime = music[playmusicCode].duration;
    }
};
this.minus5 = function(){
    if(music[playmusicCode].currentTime - 5 > 0){
        music[playmusicCode].currentTime -= 5;
    } else {
        music[playmusicCode].currentTime = 0;
    }
};
/*this.setFadeCancle = function(){
	//페이드를 취소함.
	isFadeout = false;
	isFadein = false;
	fadeVolume = 100;
};
this.setFadeout = function(isBoolean){
	//페이드아웃을 설정하면 그 시점부터 페이드아웃됨. 해제 전까지
	isFadeout = isBoolean;
	fadeVolume = 100;
};
this.setFadein = function(isBoolean){
	//페이드인을 설정하면 그 시점부터 페이드인됨. 해제 전까지
	isFadein = isBoolean;
	fadeVolume = 0;
};*/

this.getmusicStopCheck = function(){ return music[playmusicCode].paused; };

create(musicName.none, "sound/none.wav", false);
create(musicName.title, "music/title.ogg", false);
create(musicName.roundclear, "music/roundclear.ogg", false);
create(musicName.roundfail,  "music/roundfail.ogg", false);
create(musicName.music01_space_tour, "music/music01_space_tour.ogg");
create(musicName.music02_paran_planet, "music/music02_paran_planet.ogg");
create(musicName.music03_donggrami_maeul, "music/music03_donggrami_maeul.ogg");
create(musicName.music04_donggrami_maeul_part2, "music/music04_donggrami_maeul_part2.ogg");
create(musicName.music05_down_tower, "music/music05_down_tower.ogg");
create(musicName.music06_down_tower_passage, "music/music06_down_tower_passage.ogg");
create(musicName.music07_down_tower_boss, "music/music07_down_tower_boss.ogg");
create(musicName.music08_space_music, "music/music08_space_music.ogg");
create(musicName.music09_battle_music, "music/music09_battle_music.ogg");
}//function end


//객체 생성
optionbattle.sound = new Sound();
optionbattle.music = new Music();


