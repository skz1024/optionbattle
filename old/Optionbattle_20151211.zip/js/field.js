function Field(){
// function start //

// 구조는 의미 없는거 같음. 무시해도 됨.
// 뒷자리가 Unit일경우 클래스(클래스는 암묵적으로 맨 앞글자가 대문자이다.)
// 뒷자리가 unit일경우 객체 배열로 간주한다.
// 뒷자리가 data일경우 단일 변수 객체로 간주한다.
// 뒷자리가 없을경우, 그와 관련한 데이터를 처리하는것으로 간주한다.
// unit객체는 필요시 상속한다.
// 그 외의 변수들은 따로 객체 내에 내장해서 사용
// unit객체는 전역 객체로 간주하고 변수는 어디든 집적 수정할 수 있다. 사용하면서 주의할것.
var NOTHING = -1;
	
function collision(obj1, obj2, y, width, height){ // object1, object2 // or // object1, x(obj2 << change), y, w(width), h(height)
  if(typeof obj1 == "object" && typeof obj2 == "object" && typeof obj1 !== null && typeof obj2 !== null){
      // left = x, right = x + imagesizeX, top = y, bottom = imagesizeY;
      if(obj1.x <= obj2.x + obj2.width && obj1.y <= obj2.y + obj2.height &&
         obj1.x + obj1.width >= obj2.x && obj1.y + obj1.height >= obj2.y ){
             return true;
      } else {
          return false;
      }
  } else if(typeof obj1 == "object" && typeof obj2 == "number" && typeof y == "number" && typeof width == "number" && typeof height == "number"){
      var obj3 = { x:obj2, y:y, width:width, height:height };
      if(obj1.x <= obj3.x + obj3.width && obj1.y <= obj3.y + obj3.height &&
         obj1.x + obj1.width >= obj3.x && obj1.y + obj1.height >= obj3.y){
             return true;
      } else {
          return false;
      }
  }
}	


function ObjectUnit(){
    // 이 이외의 변수들은 필요시 객체를 확장하여 적용.
    this.x = 0; // x좌표
    this.y = 0; // y좌표
    this.width = 0; // 가로크기
    this.height = 0; // 세로크기
    this.isusing = false; // 사용중인지 판단하는 변수
    this.type = 0; // 타입 번호
    this.code = 0; // 코드(용도에 따라서 다르게 쓰일 수 있음.)
    this.mode = 0; // 모드
    this.attack = 0; // 공격력
    this.defense = 0; // 방어력
    this.miss = 0; // 미스확률
    this.hp = 0; // 체력
    this.maxhp = 0; // 최대체력
    this.shield = 0;  // 쉴드
    this.armor = 0; // 갑옷
    this.count = 0; // 카운트
    this.delay = 0; // 딜레이(지연시간 / 프레임단위)
    this.color = "#000000"; // 색깔: html코드 또는 스트링?으로 결정
    this.speedx = 0; // x좌표 속도 기준점
    this.speedy = 0; // y좌표 속도 기준점
    this.movex = 0; // 이동되는 양
    this.movey = 0; // 이동되는 양
    this.combo = 0; // 콤보 또는 타격 수
    this.width = 0; // 가로크기
    this.height = 0; // 세로크기
    this.image = new Image(); // 이미지 복사 파일
    this.image.src = "image/system/unused.png";
    this.wait = 0;
    this.iswait = false;
    this.x2 = 0; // 제 2좌표
    this.y2 = 0; // 제 2좌표
}


// 아군세력 유닛 관련 정보
function ForceUnit(){
	this.attack = 0;   this.attackTechnical = 0;   this.attackSkill = 0; // 공격력 관련 수치
	this.delay = 0;    this.delayTechnical = 0;    this.delaySkill = 0; // 딜레이 관련 수치
	this.count = 0;    this.countTechnical = 0;    this.countSkill = 0; // 카운트 관련 수치
	this.shotCount = 0;  this.techCount = 0;

	this.isstackshot = false,  this.stackshot = 0,  this.stackshotCount = 0, this.stackshotDelay = 0;
} ForceUnit.prototype = new ObjectUnit();

// 아군세력 유닛 관련 함수
var force = {};
force.stat = new Image();  force.stat.src = "image/system/forcestat.png";
force.data = new Array(  optionbattle.user.getTeamunit().length  );
for(var a = 0; a < force.data.length; a++)  force.data[a] = new ForceUnit();

force.setForce = function(){
    var teamunit = optionbattle.user.getTeamunit();
	for(var a = 0; a < force.data.length; a++){
	    if(teamunit[a] == -1){  
	        force.data[a] = new ForceUnit(); // 세력의 데이터 초기화
	        continue; // 건너뜀
	    }
		var I = optionbattle.user.getInventoryData(teamunit[a]);
		var U = optionbattle.unit.getUnit(I.code);
		var T = optionbattle.type.getType(U.type);
		var outputBasex = 0;
		var outputBasey = 340;
		
		force.data[a].isusing         = true;
		force.data[a].attack          = U.attack * (I.lv * 0.02 + 1)|0;
		force.data[a].attackTechnical = U.attackTechnical * (I.lv * 0.02 + 1)|0;
		force.data[a].attackSkill     = 0;
		force.data[a].delay           = U.delay;
		force.data[a].delayTechnical  = U.delayTechnical;
		force.data[a].delaySkill      = 0;
		force.data[a].techshot        = 0;
		force.data[a].delayTechshot   = 0;
		force.data[a].techshotLeft    = 0;
		force.data[a].countTechshot   = 0;
		force.data[a].count           = a * 2 + 1;
		force.data[a].countTechnical  = a * 2 + 2;
		force.data[a].countSkill      = 0;
		force.data[a].hp              = U.hp * (I.lv * 0.02 + 1)|0;
		force.data[a].type            = U.type;
		force.data[a].x               = outputBasex + (128 * (a%5))|0;
		force.data[a].y               = outputBasey + (20 * Math.floor(a/5))|0;
		force.data[a].code            = I.code;
		force.data[a].shotCount       = T.shotCount;
		force.data[a].techCount       = T.techCount;
		force.data[a].image           = U.image;
		force.data[a].stackshot       = 0;
		
		if(T.iswait == true){
			force.data[a].isstackshot = true;
			force.data[a].stackshotDelay = T.delay;
		}
		
		// 탐사선 체력 추가
		tamsaseon.hp += force.data[a].hp;
		tamsaseon.maxhp += force.data[a].hp;
	}
};
force.countUp = function(){  // 해당 유저의 유닛의 카운트 증가, 단 딜레이가 카운트보다 작을경우 카운트는 증가하지 않음.
  // 참고: 딜레이가 0일경우, 카운트는 0에서부터 시작하므로 조건에 맞지 않아서 카운트가 증가하지 않음.
  for(var a = 0; a < force.data.length; a++){
  	if(enemy.getCurrentCount() == 0)  continue;
  	
	if(force.data[a].count          < force.data[a].delay)         {  force.data[a].count += 1; }
	if(force.data[a].countTechnical < force.data[a].delayTechnical){  force.data[a].countTechnical += 1; }
	if(force.data[a].stackshotCount  < force.data[a].stackshotDelay) {  force.data[a].stackshotCount++; }
	
	if(force.data[a].delay == 0)  force.data[a].count = 0;
	if(force.data[a].delayTechnical == 0)  force.data[a].countTechnical = 0;
  }
};
force.attackCheck = function(){	
  for(var a = 0; a < force.data.length; a++){
    if(force.data[a].isusing == false)  continue;
    
	// 일반 공격 처리, 지연시간이 0인경우, 공격을 할 수 없음.
	var U = optionbattle.unit.getUnit(force.data[a].code);
	
	if(force.data[a].count >= force.data[a].delay && force.data[a].delay != 0){
		force.data[a].count -= force.data[a].delay;
		if(force.data[a].isstackshot == true){
			force.data[a].stackshot += force.data[a].shotCount;
		} else {
			for(var i = 0; i < force.data[a].shotCount; i++){
			    attack.create(force.data[a], "normal", i);
			}
			optionbattle.sound.play(U.attackSound);
		}
	}
	
	
	
	// 테크니컬 공격 처리
	if(force.data[a].countTechnical >= force.data[a].delayTechnical && force.data[a].delayTechnical != 0){  
		force.data[a].countTechnical -= force.data[a].delayTechnical;
		if(force.data[a].type == typeName.HEAL){
		    tamsaseon.hp += force.data[a].attackTechnical;
		    if(tamsaseon.hp >= tamsaseon.maxhp)  tamsaseon.hp = tamsaseon.maxhp;
		} else{
		    for(var i = 0; i < force.data[a].techCount; i++){
		        attack.create(force.data[a], "technical", i);
		    }
		}
		optionbattle.sound.play(U.attackTechnicalSound);
	}
	
	// 스택형태의 샷 처리용
	if(force.data[a].stackshot >= 1 && force.data[a].stackshotCount >= force.data[a].stackshotDelay){
		force.data[a].stackshotCount = 0;
		force.data[a].stackshot--;
		attack.create(force.data[a], "normal", 0);
		optionbattle.sound.play(U.attackSound);
	}
  }// for end
};

force.init = function(){  force.setForce();  }; // 초기화 함수
force.process = function(){
	force.attackCheck();
	if(tamsaseon.recovery == false)  force.countUp();
}; // 진행, 처리 함수
force.display = function(){ // 출력함수
    if(system.pause == false)  return;  // 일시정지상태가 아니면 출력 안함.
    
    ctx.drawImage(force.stat, 0, 340);
	for(var a = 0; a < force.data.length; a++){
	    if(force.data[a].isusing == false)  continue;
		ctx.drawImage(force.data[a].image, force.data[a].x, force.data[a].y, 16, 16);
		var percentNormal = 0, percentTechnical = 0;
		
		if(force.data[a].delay != 0) percentNormal = force.data[a].count / force.data[a].delay;
		if(force.data[a].delayTechnical != 0) percentTechnical = force.data[a].countTechnical / force.data[a].delayTechnical;
		
		ctx.strokeStyle = "black";
		ctx.fillStyle = "orange";
		ctx.strokeRect(force.data[a].x+20, force.data[a].y+3, 90, 5);  ctx.fillRect(force.data[a].x+20, force.data[a].y+3, 90*percentNormal, 5);
		ctx.fillStyle = "skyblue";
		ctx.strokeRect(force.data[a].x+20, force.data[a].y+8, 90, 5);  ctx.fillRect(force.data[a].x+20, force.data[a].y+8, 90*percentTechnical, 5);
	}
};	


//---------------------------------//


function AttackUnit(){
	this.target = 0; // 적을 타겟할 대상의 번호(적의 코드가 아님)
	this.istarget = true; // 타겟을 추적하는 방식. 이게 false일경우 적을 추적하지 않음.
	this.isfollow = true; // 적을 쫓아가는 방식
	this.mode = ""; // 공격을 한 유닛의 공격 정의 패턴(normal, technical, skill, enemy)
	this.combo = 0;
	this.ismoveon = true;
	this.waittime = 0; // 무기가 표시되기까지 대기시간
	this.compulsion = 0;  // 해당 지연시간동안 히트에 실패하면 적을 무조건 강제로 타격, 단 타겟이 true인경우만 적용
}  AttackUnit.prototype = new ObjectUnit(); // 서브 클래스 상속
// class Attack
var attack = {};
attack.data = new Array(200);
attack.usingCount = 0;
for(var a = 0; a < attack.data.length; a++)  attack.data[a] = new AttackUnit();
attack.create = function (U, mode, option) {
    if (mode == null) mode = "normal";
    var number = 0;
    for (var a = 0; a < attack.data.length; a++) {
        if (attack.data[a].isusing == false) { number = a; break; }
    }
    var attackUnitData = attack.data[number]; // 간편하게 작성하기 위해 attackUnitData로 취급을 해버림.
    attackUnitData.x = tamsaseon.x + 24; attackUnitData.y = tamsaseon.y + 24;

    var I = optionbattle.unit.getUnit(U.code);
    var T = optionbattle.type.getType(U.type);
    if (mode == "normal") {
        attackUnitData.image = I.attackImage;
        attackUnitDatawidth = attackUnitData.image.width; attackUnitData.height = attackUnitData.image.height;
        attackUnitData.attack = U.attack;
    } else if (mode == "technical") {
        attackUnitData.image = I.attackTechnicalImage;
        attackUnitData.width = attackUnitData.image.width; attackUnitData.height = attackUnitData.image.height;
        attackUnitData.attack = U.attackTechnical;
    }

    attackUnitData.type = U.type;
    attackUnitData.code = U.code;
    attackUnitData.mode = mode;
    attackUnitData.isusing = true;
    attackUnitData.istarget = T.istarget;
    attackUnitData.isfollow = T.isfollow;
    attackUnitData.delay = T.delay;
    attackUnitData.combo = T.combo;
    attackUnitData.count = 0;
    attackUnitData.speedx = 10;
    attackUnitData.waittime = 0;
    attackUnitData.compulsion = 0;

    switch (U.type) {
        case typeName.WHITEFLASH: attackUnitData.speedx = 15; break;
        case typeName.LASER:
            if (mode == "technical") {
                attackUnitData.x = -640;
                attackUnitData.speedx = 10; attackUnitData.speedy = 0;
                attackUnitData.width = 600; attackUnitData.height = 10;
            } else {
                attackUnitData.istarget = true;
                attackUnitData.delay = 0;
            } break;
        case typeName.WAYSHOT3:
            switch (option) {
                case 0: attackUnitData.speedy = -2; break;
                case 1: attackUnitData.speedy = 0; break;
                case 2: attackUnitData.speedy = 2; break;
            } break;
        case typeName.DOUBLESHOT:
            switch (option) {
                case 0: attackUnitData.y = attackUnitData.y - 10; break;
                case 1: attackUnitData.y = attackUnitData.y + 10; break;
            } break;
        case typeName.FIRE:
            attackUnitData.x = tamsaseon.x + 48; attackUnitData.y = tamsaseon.y;
            effect.create(effectName.FIRE, attackUnitData.x, attackUnitData.y);
            attackUnitData.delay = 1; attackUnitData.combo = 10;
            switch (option) {
                case 0: attackUnitData.speedy = -8; attackUnitData.speedx = 20; break;
                case 1: attackUnitData.speedy = -4; attackUnitData.speedx = 20; break;
                case 2: attackUnitData.speedy = 0; attackUnitData.speedx = 20; break;
                case 3: attackUnitData.speedy = 4; attackUnitData.speedx = 20; break;
                case 4: attackUnitData.speedy = 8; attackUnitData.speedx = 20; break;
            } break;
        case typeName.PALSERN:
            optionbattle.sound.play(soundName.palsern_wait); // 사운드가 여기서 재생되는 이유는 공격시에 재생하면 8번재생하기 때문
            attackUnitData.delay = 40; attackUnitData.combo = 2;
            attackUnitData.speedx = 0; attackUnitData.speedy = 0;
            attackUnitData.y = tamsaseon.y + 24 + (option * 20) - 80; break;
        case typeName.ROCKET: attackUnitData.combo = 1; attackUnitData.speedx = -4; attackUnitData.speedy = Math.random() * 8 - 4 | 0; break;
        case typeName.MACHINEGUN: attackUnitData.speedx = 0; attackUnitData.speedy = 0; break;
        case typeName.BEAM:
            attackUnitData.x = 0; attackUnitData.speedx = 0; attackUnitData.speedy = 0;
            attackUnitData.width = 640; attackUnitData.height = 40; break;
        case typeName.BEAMLOGIC:
            if (mode == "normal") {
                if (option == 0) {
                    attackUnitData.x = 0; attackUnitData.y = 0;
                    attackUnitData.speedx = 0; attackUnitData.speedy = 10;
                    attackUnitData.width = 640; attackUnitData.height = 40;
                } else if (option == 1) {
                    attackUnitData.x = 0; attackUnitData.y = 0;
                    attackUnitData.speedx = 10; attackUnitData.speedy = 0;
                    attackUnitData.width = 40; attackUnitData.height = 480;
                }
            } else if (mode == "technical") {
                if (option == 0) {
                    attackUnitData.x = 0; attackUnitData.y = tamsaseon.y + 24;
                    attackUnitData.speedx = 0; attackUnitData.speedy = 0;
                    attackUnitData.width = 640; attackUnitData.height = 40;
                } else if (option == 1) {
                    attackUnitData.x = tamsaseon.x + 24; attackUnitData.y = 0;
                    attackUnitData.speedx = 0; attackUnitData.speedy = 0;
                    attackUnitData.width = 40; attackUnitData.height = 480;
                }
            } break;
        case typeName.BEAMSIX:
            attackUnitData.x = 0; attackUnitData.speedx = 0; attackUnitData.speedy = 0;
            attackUnitData.width = 640; attackUnitData.height = 20; break;
    } // switch end

    if (attackUnitData.istarget == true) {
        attackUnitData.target = attack.setTarget();
    }

    if (attackUnitData.isfollow == false && attackUnitData.istarget == true) {
        attackUnitData.speedx = (enemy.data[attackUnitData.target].x - attackUnitData.x + (enemy.data[attackUnitData.target].width / 2)) / 10 | 0;
        attackUnitData.speedy = (enemy.data[attackUnitData.target].y - attackUnitData.y + (enemy.data[attackUnitData.target].height / 2)) / 10 | 0;
    }
};
attack.setTarget = function(){
	return enemy.livelist[Math.random() * enemy.livelistCount|0];
};
attack.target = function (attackData) {
    // 타겟을 결정할 필요가 없는 타입들은 타겟을 정하지 않음.
    if (attackData.isusing == false && attackData.istarget == false)  return;

    if (enemy.data[attackData.target].isusing == false || enemy.data[attackData.target].died == true) {  // 적이 죽었을 경우 타겟 재설정
        if (enemy.livelistCount == NOTHING) {  // 적이 아무도 없을경우 타겟설정을 취소함.
            attackData.istarget = false;
            attackData.isfollow = false;
            attackData.speedy = 0;
            attackData.speedx = 10;
        } else if (attackData.type == typeName.HITSHOT && attackData.combo < 4) {
            attack.deleteData(attackData);
        } else if (attackData.type == typeName.SAWTOOTH && attackData.combo < 6) {
            attackData.istarget = false;
        } else {
            attackData.target = attack.setTarget();
        }
    }
};
attack.damageCheck = function(A, E){ // A: Attack, E: Enemy
    // 이 함수는 적에게 데미지를 주는 함수입니다. 이걸 한번쓸때마다 적의 체력이 감소하니 참고바람.
    // 그리고 데미지도 표시합니다.
    var enemyDefnsedown = E.defensedown > 100 ? 100 : E.defensedown; // 삼항연산자 사용, 방어력감소의 최대치는 100%
    var enemyWeakness = E.weakness > 100 ? 100 : E.weakness; // 약점의 최대치는 100%
    // 적용되는 데미지값 = 공격력 - 적의 방어력 - ( 적의 방어력 * 적의 방어감소율 / 100);
    var enemyDefense = E.defense - (E.defense * E.defensedown / 100);
    var percent = (Math.random() * 100) |0;
    if(enemyDefense <= 0)  enemyDefense = 0;
    var damageValue = A.attack - enemyDefense;
    switch(A.type){
        case typeName.DIRECT: damageValue = A.attack;  break; // 다이렉트는 자기 공격력의 데미지가 그대로 들어감
        case typeName.HITSHOT:  E.weakness += 2;  break;  // 히트샷은 약점 2개를 추가함
        case typeName.SAWTOOTH:  if(A.combo > 8)  E.defensedown += 8;
        						 else  E.defensedown += 4;  break;  // 톱니는 방어력감소 8개를 추가함.
        case typeName.FIRE:  E.fire += 1;  E.firedamage = ( E.firedamage + A.attack ) / 2 |0; break; // 파이어는 파이어디버프를 2개 추가함 그리고 파이어 데미지 결정
        case typeName.PARAPO: damageValue = A.attack + E.defense;  break;  // 파라포 = 자기공격력 + 적의 방어력 합산 데미지
        case typeName.BURSTSHOT:  if(percent <= 35){  effect.create(effectName.BURSTSHOT, A.x, A.y);  E.defensedown += 17;   optionbattle.sound.play(soundName.burstshot_saw); }  break;
        						  // 버스트는 35%확률로 방어력17% 감소
    }
    
    if(damageValue < 1)  damageValue = 1; // 데미지값이 1 미만인경우, 1로 적용
    // 최종데미지 = 적용되는 데미지값 + (적용되는 데미지값 * 약점수 / 100);
    var totalDamage = damageValue + (damageValue * enemyWeakness / 100) |0; // 최종데미지는 정수로 처리
    E.hp -= totalDamage;
    
    damage.create(totalDamage, A.type, E.x, E.y - (E.damagecount*10));
    E.damagecount++;
};
attack.countCheck = function(A){ // A: Attack. 이 함수는 카운트와 딜레이를 체크하는 함수, 귀찮아서 countCheck 라고 씀.
    A.count++;
    if(A.count >= A.delay){
        A.count -= A.delay;
        return true;
    }
};

attack.move_notarget = function(attackData){
    attackData.compulsion++;
    attackData.x += attackData.speedx;
    attackData.y += attackData.speedy;
    if(attackData.x >= 900 || attackData.compulsion >= 250)  attack.deleteData(attackData);
};

attack.move_istarget = function(attackData){
    attackData.compulsion++;
    attackData.x += attackData.speedx;
    attackData.y += attackData.speedy;
    if(attackData.compulsion >= 10){
        attackData.x = enemy.data[attackData.target].x;
        attackData.y = enemy.data[attackData.target].y;
    }
    
    if(attackData.x >= 900 || attackData.compulsion >= 250)  attack.deleteData(attackData);
};

attack.move_followtarget = function(attackData){
    attackData.compulsion++;
    var movesizeX = (enemy.data[attackData.target].x - attackData.x) / 10;
    var movesizeY = (enemy.data[attackData.target].y - attackData.y) / 5;
    
    if(movesizeX < 10 && movesizeX >= 1)  movesizeX = 10;
    else if(movesizeX <= 1 && movesizeX >= -1)  movesizeX = 0;
    else if(movesizeX <= -1 && movesizeX >= -10)  movesizeX = -10;
    if(movesizeY < 10 && movesizeY >= 1)  movesizeY = 10;
    else if(movesizeY <= 1 && movesizeY >= -1)  movesizeY = 0;
    else if(movesizeY <= -1 && movesizeY >= -10)  movesizeY = -10;
    
    if(attackData.type == typeName.WHITEFLASH)  movesizeX = attackData.speedx;

    attackData.x += movesizeX;
    attackData.y += movesizeY;
    if(movesizeX == 0 && movesizeY == 0){
        attackData.x = enemy.data[attackData.target].x;
        attackData.y = enemy.data[attackData.target].y;
    }
    
    switch(attackData.type){
    case typeName.DIRECT:  attackData.x = enemy.data[attackData.target].x;  attackData.y = enemy.data[attackData.target].y;  break;
    case typeName.HITSHOT:
        if(attackData.combo < 4)  attackData.x = enemy.data[attackData.target].x;  attackData.y = enemy.data[attackData.target].y;  break;
    case typeName.SAWTOOTH:
        if(attackData.combo > 8)  attackData.x = enemy.data[attackData.target].x;  attackData.y = enemy.data[attackData.target].y;  break;
    case typeName.BEAMSIX:
        attackData.x = 0;  attackData.y = enemy.data[attackData.target].y;  break;
    default: break;
    }
    
    if(attackData.compulsion >= 240){
        attackData.x = enemy.data[attackData.target].x;  attackData.y = enemy.data[attackData.target].y;
    }
    if(attackData.x >= 900 || attackData.compulsion >= 250)  attack.deleteData(attackData);
};

attack.move = function(attackData){
    if(attackData.istarget == false){
        attack.move_notarget(attackData);
    } else if(attackData.istarget == true && attackData.isfollow == false){ // 타겟이 있지만 추적방식이 아닌 조준방식일경
    	attack.move_istarget(attackData);
    } else if(attackData.istarget == true && attackData.isfollow == true) { // 타겟이 있을경우에만 이 구문 실행
        attack.move_followtarget(attackData);
    }
};

//attack.logic_typeName
//공격 타입에 대한 여러 요소들을 처리하는 함수.
//default의 경우도 있다.
attack.logic_whiteflash = function (attackData) {
    if (attack.countCheck(attackData)) {
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(attackData, enemy.data[i])) attack.damageCheck(attackData, enemy.data[i]);
        }
    }
};
attack.logic_laser = function (attackData) {
    if (attackData.mode == "normal") {
        if (collision(attackData, enemy.data[attackData.target])) {
            attack.damageCheck(attackData, enemy.data[attackData.target]);
            attack.deleteData(attackData);
        }
    } else {  // 일반공격모드가 아닐경우 테크니컬로 간주함.
        if (attack.countCheck(attackData)) {
            for (var i = 0; i < enemy.data.length; i++) {
                if (enemy.data[i].isusing == false) continue;
                if (collision(attackData, enemy.data[i])) {
                    attack.damageCheck(attackData, enemy.data[i]);
                } 
            }
        }

        if (attack.data[a].x >= 1280) attack.deleteData(attackData);
    }
};
attack.logic_missile = function (attackData) {
    if (attackData.combo == 5 && collision(attackData, enemy.data[attackData.target])) {
        attackData.combo = 4;
        attackData.moveon = false;
        attack.damageCheck(attackData, enemy.data[attackData.target]);
        optionbattle.sound.play(soundName.bombattack);
    } else if (attack.countCheck(attackData) && attackData.combo <= 4) {
        effect.create(effectName.MISSILE, attackData.x - 90, attackData.y - 90);
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(enemy.data[i], attackData.x - 90, attackData.y - 90, 180, 180)) attack.damageCheck(attackData, enemy.data[i]);
        }
        optionbattle.sound.play(soundName.bomb);
        attackData.combo--;
        if (attackData.combo <= 0) attack.deleteData(attackData);
    }
};
attack.logic_splash = function (attackData) {
    if (collision(attackData, enemy.data[attackData.target])) {
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(enemy.data[i], attackData.x - 200, attackData.y - 200, 400, 400)) attack.damageCheck(attackData, enemy.data[i]);
        }
        optionbattle.sound.play(soundName.splashdamage);
        effect.create(effectName.SPLASH, attackData.x - 200, attackData.y - 200);
        attack.deleteData(attackData);
    }
};
attack.logic_rocket = function (attackData) {
    if (attackData.combo == 1) {
        if (attackData.x >= 1) attackData.speedx--;
        else {
            attackData.combo = 0;  attackData.speedx = 4;
            attackData.delay = 8;  attackData.count = 0;
        }
    } else if (attackData.combo == 0 && attack.countCheck(attackData)) {
        for (var i = 0 ; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(enemy.data[i], attackData.x - 90, attackData.y - 90, 180, 180)) attack.damageCheck(attackData, enemy.data[i]);
        }

        effect.create(effectName.MISSILE, attackData.x - 90, attackData.y - 90);
        optionbattle.sound.play(soundName.bomb);
        attackData.speedx += 2;
        attackData.delay--;
        if (attackData.delay <= 4) attackData.delay = 4;
        if (attackData.x >= 720) attack.deleteData(attackData);
    }
};
attack.logic_hitshot = function (attackData) {
    if (attack.countCheck(attackData) && collision(attackData, enemy.data[attackData.target])) {
        if (attackData.combo == 4) optionbattle.sound.play(soundName.hitshot);
        attack.damageCheck(attackData, enemy.data[attackData.target]);
        attackData.combo--;
    } else if(attackData.combo <= 3){
        attack.damageCheck(attackData, enemy.data[attackData.target]);
        attackData.combo--;
        
        if(attackData.combo <= 0)  attack.deleteData(attackData);
    }
};
attack.logic_sawtooth = function (attackData) {
    if (attack.countCheck(attackData) && attackData.combo > 8 && collision(attackData, enemy.data[attackData.target])) {
        attack.damageCheck(attackData, enemy.data[attackData.target]);
        attackData.combo--;
        optionbattle.sound.play(soundName.sawtooth_attack);
        if (attackData.combo <= 8) {
            attackData.istarget = false;
            attackData.speedx = 12;
            attackData.delay = 6;
            attackData.count = -12;
            attackData.attack = attackData.attack * 0.5 | 0;
        }
    } else if (attackData.istarget == false && attack.countCheck(attackData)) {
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(attackData, enemy.data[i])) {
                attack.damageCheck(attackData, enemy.data[i]);
                optionbattle.sound.play(soundName.sawtooth_attack);
                attackData.combo--;
                break;
            }
        }
        if (attackData.combo <= 0) attack.deleteData(attackData);
    }
};
attack.logic_fire = function (attackData) {
    attackData.combo--;
    effect.create(effectName.FIRE, attackData.x, attackData.y);
    if (attack.countCheck(attackData)) {
        for (var i = 0; i < enemy.data.length; i++) {
            if (collision(attackData, enemy.data[i])) {
                attack.damageCheck(attackData, enemy.data[i]);
            }
        }
    }
    if (attackData.combo <= 0) attack.deleteData(attackData);
};
attack.logic_palsern = function (attackData) {
    if (attackData.combo == 2 && attack.countCheck(attackData)) {
        attackData.combo = 1;
        attackData.target = attack.setTarget();
        attackData.delay = 11;
        attackData.count = 0;
        attackData.speedx = (enemy.data[attackData.target].x - attackData.x) / 10;
        attackData.speedy = (enemy.data[attackData.target].y - attackData.y) / 10;
    } else if (attackData.combo == 1 && attack.countCheck(attackData)) {
        var typeX1 = Math.abs(enemy.data[attackData.target].x + enemy.data[attackData.target].width - attackData.x);
        var typeX2 = Math.abs(enemy.data[attackData.target].x - attackData.x);
        var typeY1 = Math.abs(enemy.data[attackData.target].y + enemy.data[attackData.target].height - attackData.y);
        var typeY2 = Math.abs(enemy.data[attackData.target].y - attackData.y);
        var distance_x = Math.min(typeX1, typeX2);
        var distance_y = Math.min(typeY1, typeY2);
        var distance = distance_x + distance_y / 2 | 0;  /// 거리에 따라 미스확률 결정, distance = miss_percent
        if ((Math.random() * 100 | 0) >= distance) {  // 적을 히트한 경우
            attack.damageCheck(attackData, enemy.data[attackData.target]);
            optionbattle.sound.play(soundName.palsern_hit);
        } else {
            attackData.attack = 1;
            attackData.type = typeName.UNUSED; // 색깔 변경용
            attack.damageCheck(attackData, enemy.data[attackData.target]);
            optionbattle.sound.play(soundName.palsern_miss);
        }

        attack.deleteData(attackData);
    }
};
attack.logic_machinegun = function (attackData) {
    if (!attack.countCheck(attackData))  return;

    for (var i = 0; i < enemy.data.length; i++) {
        if (enemy.data[i].isusing == false) continue;
        if (collision(enemy.data[i], tamsaseon.x, tamsaseon.y - 70, 350, 140)) {
            if ((Math.random() * 100 | 0) <= 35) {  // 1발 발사당 35%확률로 히트
                attack.damageCheck(attackData, enemy.data[i]);
                break;
            }
        }
    }

    if (/*attackData.combo % 0 == 0*/true) {
        var randomSelect = (Math.random() * 3) | 0;
        var random_x = (Math.random() * 50) | 0;
        var random_y = (Math.random() * 60) | 0;
        switch (randomSelect) {
            case 0: effect.create(effectName.MACHINEGUN_CENTER, tamsaseon.x + random_x, tamsaseon.y + random_y);
            case 1: effect.create(effectName.MACHINEGUN_UP, tamsaseon.x + random_x, tamsaseon.y + random_y + 0);
            case 2: effect.create(effectName.MACHINEGUN_DOWN, tamsaseon.x + random_x, tamsaseon.y + random_y - 30);
        }
        optionbattle.sound.play(soundName.machinegun);
    }

    attackData.combo--;
    if (attackData.combo <= 0) attack.deleteData(attackData);
};
attack.logic_beam = function (attackData) {
    attackData.y = tamsaseon.y;
    if (attack.countCheck(attackData)) {
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false)  continue;
            if (collision(attackData, enemy.data[i])) {
                attack.damageCheck(attackData, enemy.data[i]);
            }
        }

        attackData.combo--;
        if (attackData.combo <= 0) attack.deleteData(attackData);
    }
};
attack.logic_beamlogic = function (attackData) {
    if (attackData.mode == "technical") {
        if (attackData.x == 0) {
            attackData.y = tamsaseon.y;
        } else {
            attackData.x = tamsaseon.x;
        }
    }

    if (attack.countCheck(attackData)) {
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(attackData, enemy.data[i])) {
                attack.damageCheck(attackData, enemy.data[i]);
        }   }

        attackData.combo--;
        if (attackData.combo <= 0) attack.deleteData(attackData);
    }             
};
attack.logic_beamsix = function(attackData){
    if (attack.countCheck(attackData)) {
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(attackData, enemy.data[i])) {
                attack.damageCheck(attackData, enemy.data[i]);
            }
        }

        if (attackData.type == typeName.BEAMSIX) {
            attackData.x = 0;
            attackData.y = enemy.data[attackTarget].y;
        }

        attackData.combo--;
        if (attackData.combo <= 0) attack.deleteData(attackData);
    }
};
attack.logic_default = function(attackData){
    if (attackData.istarget == false) {  // 타겟이 정해지지 않은경우의 충돌처리
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(attackData, enemy.data[i])) {
                attack.damageCheck(attackData, enemy.data[i]);
                attack.deleteData(attackData);
            }
        }
    } else {  // 타겟이 정해진 경우의 충돌처리
        if (collision(attackData, enemy.data[attackData.target])) {
            attack.damageCheck(attackData, enemy.data[attackData.target]);
            if (attackData.type == typeName.PARAPO) optionbattle.sound.play(soundName.parapo);

            attack.deleteData(attackData);
        }
    }
};
attack.processLogic = function (attackData) {
    switch (attackData.type) {
        case typeName.WHITEFLASH: attack.logic_whiteflash(attackData); break;
        case typeName.LASER: attack.logic_laser(attackData); break;
        case typeName.MISSILE: attack.logic_missile(attackData); break;
        case typeName.SPLASH: attack.logic_splash(attackData); break;
        case typeName.ROCKET: attack.logic_rocket(attackData); break;
        case typeName.HITSHOT: attack.logic_sawtooth(attackData); break;
        case typeName.SAWTOOTH: attack.logic_sawtooth(attackData); break;
        case typeName.FIRE: attack.logic_fire(attackData); break;
        case typeName.PALSERN: attack.logic_palsern(attackData); break;
        case typeName.MACHINEGUN: attack.logic_machinegun(attackData); break;
        case typeName.BEAM: attack.logic_beam(attackData); break;
        case typeName.BEAMLOGIC: attack.logic_beamlogic(attackData); break;
        case typeName.BEAMSIX: attack.logic_beamsix(attackData); break;
        default:  attack.logic_default(attackData); break;
    } // switch end
};
attack.process = function(){
    for(var i = 0; i < attack.data.length; i++){
        if(attack.data[i].isusing == true){
            attack.target(attack.data[i]);
            attack.processLogic(attack.data[i]);
            attack.move(attack.data[i]);
        }
    }
};
attack.display = function(){
    for(var a = 0; a < attack.data.length; a++){
        if(attack.data[a].isusing == false)  continue;
        var A = attack.data[a];
        
        switch(attack.data[a].type){
        	case typeName.LASER:
        		if(attack.data[a].mode == "technical")  ctx.drawImage(A.image, 0, 0, A.image.width, A.image.height, A.x, A.y, A.width, A.height );
        		else  ctx.drawImage(attack.data[a].image, attack.data[a].x, attack.data[a].y);  break;
        	case typeName.BEAM:
        	case typeName.BEAMLOGIC:
        	case typeName.BEAMSIX:
        		ctx.drawImage(A.image, 0, 0, A.image.width, A.image.height, A.x, A.y, A.width, A.height );  break;
        	default:  ctx.drawImage(attack.data[a].image, attack.data[a].x, attack.data[a].y);  break;
        }
        
    }
};

// 객체의 데이터를 삭제한것처럼(실제 삭제가 아님) 처리한다.
// 인덱스 번호를 넣으면 해당 배열번호에 있는 데이터가 사라지고, 객체를 넣으면 해당 객체의 데이터가 사라진다.
attack.deleteData = function (index) {
    if(typeof index == "number"){
        attack.data[index].isusing = false;
    } else {
        index.isusing = false;
    }
};
attack.init = function(){
    for(var a = 0; a < attack.data.length; a++){
        attack.deleteData(a);
    }
};

//--------------------------------//
var damage = {};
damage.data = new Array(100);
for(var a = 0; a < damage.data.length; a++)  damage.data[a] = new ObjectUnit();
damage.create = function(attack, attackType, x, y){ // U: 데미지를 받는 대상, attackType: 공격의 타입, value:데미지 값
    var number = 0;
    for(var a = 0; a < damage.data.length; a++){
        if(damage.data[a].isusing == false){
            number = a;  break;
    }   }
    
    damage.data[number].isusing = true;
    damage.data[number].count = 50;
    damage.data[number].attack = attack;
    damage.data[number].color = optionbattle.type.getColor(attackType);
    damage.data[number].x = x;
    damage.data[number].y = y;
};
damage.display = function(){
    ctx.font = "20px arial";
    for(var a = 0; a < damage.data.length; a++){
        if(damage.data[a].isusing == false)  continue;
        var D = damage.data[a];
        ctx.fillStyle = D.color;
        ctx.fillText(D.attack, D.x, D.y);
    }
};
damage.process = function(){
    for(var a = 0; a < damage.data.length; a++){
        if(damage.data[a].isusing == false)  continue;
        
        damage.data[a].count--;
        damage.data[a].y--;
        if(damage.data[a].count <= 0)  damage.data[a].isusing = false;
    }
};
damage.init = function(){
    for(var a = 0; a < damage.data.length; a++){
        damage.data[a].isusing = false;
    }
};

//--------------------------------//
function EnemyUnit(){
    this.tamsaseoncount = 0;
	this.score = 0;
	this.speedType = "";
	this.diecount = 0;
	this.diemotion = "";
	this.diemotiontime = 0;
	this.diesound = 0;
	this.died = false;
	this.imagenumber = 0;
	this.group = 0;
	this.damagecount = 0; // 데미지 처리용 카운트, 여러줄 표시용
	this.damagecountdelay = 0; // 일정시간후 초기화용
	this.shot = false; // 적이 총으로 공격하는지 여부
	this.shotcount = 0;
	
	// 버프 관련 요소
	this.weakness = 0; // 약점, 퍼센트로 증가
	this.weaknesstime = 250; // 약점시간, 5초당 처리
	this.defensedown = 0; // 방어력감소, 퍼센트로 증가
	this.defensedowntime = 250; // 방어력감소시간, 5초당 처리
	this.fire = 0; // 파이어 중첩 계수, 퍼센트로 증가
	this.firetime = 250; // 파이어시간, 5초당 처리
	this.firedamage = 0; // 파이어데미지, 당한 파이어의 평균데미지로 결정
}  EnemyUnit.prototype = new ObjectUnit();
function EnemyAttack(){
	this.target = false;
}  EnemyAttack.prototype = new ObjectUnit();


var enemy = {};
enemy.statusImage = new Image();  enemy.statusImage.src = "image/system/enemystatus.png";
enemy.data = new Array(150);
enemy.attack = new Array(150);
for(var a = 0; a < enemy.data.length; a++){  enemy.data[a] = new EnemyUnit();  enemy.attack[a] = new EnemyAttack(); }
enemy.createCount = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
enemy.currentCount = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
enemy.livelist = [0, ];
enemy.livelistCount = NOTHING;
enemy.bullet = new Image();  enemy.bullet.src = "image/enemy.attack.png";


enemy.createAttack = function(E){  // 생성하는 적공격
	var number = 0;
	for(var a = 0; a < enemy.attack.length; a++){
		if(enemy.attack[a].isusing == false){
			number = a;  break;
		}
	}
	
	enemy.attack[number].isusing = true;
	enemy.attack[number].x = E.x + (E.width / 2) |0;
	enemy.attack[number].y = E.y + (E.height / 2) |0;
	enemy.attack[number].attack = E.attack / 2 |0;
	enemy.attack[number].speedx = (tamsaseon.x - enemy.attack[number].x) / 40;
	enemy.attack[number].speedy = (tamsaseon.y - enemy.attack[number].y) / 40;
};
enemy.processAttack = function(){
	for(var a = 0; a < enemy.attack.length; a++){
		if(enemy.attack[a].isusing == false)  continue;
		
		enemy.attack[a].x += enemy.attack[a].speedx;
		enemy.attack[a].y += enemy.attack[a].speedy;
		
		if(collision(tamsaseon, enemy.attack[a])){
			tamsaseon.hp -= enemy.attack[a].attack;
			enemy.deleteAttack(a);
			optionbattle.sound.play(soundName.damage);
		}
	}
};
enemy.displayAttack = function(){
	for(var a = 0; a < enemy.attack.length; a++){
		if(enemy.attack[a].isusing == false)  continue;
		ctx.drawImage(enemy.bullet, enemy.attack[a].x, enemy.attack[a].y);
	}
};

enemy.init = function(){
    for(var a = 0; a < enemy.data.length; a++){
        enemy.deleteData(a);
    }
    
    enemy.createCount = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    enemy.currentCount = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    for(var a = 0; a < system.group.length; a++){
        enemy.createCount[a] = system.group[a].enemycount;
        enemy.currentCount[a] = 0;
    }
};
enemy.create = function(E, G){
	if(E == -1)  return; // 적을 잘못생성하는 코드번호를 작성하는경우 강제로 함수 종료.
	
    var number = 0;
    for(var a = 0; a < enemy.data.length; a++){
        if(enemy.data[a].isusing == false){
            number = a;  break;
        }
    }
    
    enemy.data[number].group = G;
    enemy.data[number].isusing = true;
    enemy.data[number].hp = E.hp;
    enemy.data[number].imagenumber = E.imagenumber;
    enemy.data[number].image = imageBoxEnemy[enemy.data[a].imagenumber];
    enemy.data[number].attack = E.attack;
    enemy.data[number].defense = E.defense;
    enemy.data[number].speedx = -E.speedx;
    enemy.data[number].speedy = -E.speedy;
    enemy.data[number].speedType = E.speedType;
    enemy.data[number].diesound = E.diesound;
    enemy.data[number].width = enemy.data[number].image.width;
    enemy.data[number].height = enemy.data[number].image.height;
    enemy.data[number].x = 640 + enemy.data[number].width;
    enemy.data[number].y = Math.random() * 480|0;
    enemy.data[number].died = false;
    enemy.data[number].diecount = 50;
    enemy.data[number].score = E.score;
    enemy.data[number].shot = E.shot;
    enemy.currentCount[G]++;
    enemy.createCount[G]--;
};
enemy.process = function(){
    enemy.move();
    enemy.livelistCheck();
    enemy.damageupCheck();
    enemy.dieCheck();
    enemy.dieEnimation();
    enemy.buffCheck();
    var E = optionbattle.dungeon.getEnemy(system.dungeon);
    for(var a = 0; a < system.group.length; a++){
        if(enemy.createCount[a] >= 1 && enemy.currentCount[a] < system.group[a].enemymax){
            var R = Math.random() * system.group[a].enemylist.length|0;
            enemy.create(E[ system.group[a].enemylist[R] ], a);
        }    
    }
    
    enemy.processAttack();
};
enemy.damageupCheck = function(){
    for(var a = 0; a < enemy.data.length; a++){
        enemy.data[a].tamsaseoncount--;
        if(enemy.data[a].damageup > 0)  enemy.data[a].damageup--;
        if(enemy.data[a].damageup < 0)  enemy.data[a].damageup++;
        if(enemy.data[a].damageup == 0)  enemy.data[a].damageup = 0;
    }
};
enemy.livelistCheck = function(){
    enemy.livelistCount = NOTHING;
    for(var a = 0; a < enemy.data.length; a++){
        if(enemy.data[a].isusing == true && enemy.data[a].died == false){
            enemy.livelistCount++;
            enemy.livelist[enemy.livelistCount] = a;
        }
    }
};
enemy.move = function(){
    for(var a = 0; a < enemy.data.length; a++){
        if(enemy.data[a].isusing == false || enemy.data[a].died == true)  continue;
        
        enemy.data[a].x += enemy.data[a].speedx;
        enemy.data[a].y += enemy.data[a].speedy;
        
        if(enemy.data[a].x <= -10-enemy.data[a].width)  enemy.data[a].x = 649;
        if(enemy.data[a].y <= -10)  enemy.data[a].speedy = -enemy.data[a].speedy;
        if(enemy.data[a].x >= 650+enemy.data[a].width)  enemy.data[a].speedx = -enemy.data[a].speedx;
        if(enemy.data[a].y >= 490)  enemy.data[a].speedy = -enemy.data[a].speedy;
        
        if(enemy.data[a].speedType == "noexit"){
            if(enemy.data[a].x <= 0){  enemy.data[a].speedx = -enemy.data[a].speedx;  enemy.data[a].x = 0; }
            if(enemy.data[a].x >= 640 - enemy.data[a].width){  enemy.data[a].speedx = -enemy.data[a].speedx;  enemy.data[a].x = 640 - enemy.data[a].width; };
            if(enemy.data[a].y <= 0){  enemy.data[a].speedy = -enemy.data[a].speedy;  enemy.data[a].y = 0; }
            if(enemy.data[a].y >= 480 - enemy.data[a].height){  enemy.data[a].speedy = -enemy.data[a].speedy;  enemy.data[a].y = 480 - enemy.data[a].height; };
        }
        
        enemy.data[a].shotcount++;
        if(enemy.data[a].shotcount >= 40 && enemy.data[a].shot == true){
        	enemy.data[a].shotcount = 0;
        	enemy.createAttack(enemy.data[a]);
        	optionbattle.sound.play(soundName.enemyshot);
        }
    }
};
enemy.dieCheck = function(){
    for(var a = 0; a < enemy.data.length; a++){
        if(enemy.data[a].isusing == false || enemy.data[a].died == true)  continue;
        if(enemy.data[a].hp <= 0){
        	tamsaseon.killcount++;
            system.scoreBonus += enemy.data[a].score;
            enemy.currentCount[enemy.data[a].group]--;
            enemy.data[a].died = true;
            enemy.data[a].fire = 0;
            enemy.data[a].defensedown = 0;
            enemy.data[a].weakness = 0;
            optionbattle.sound.play(enemy.data[a].diesound);
        }
    }
};
enemy.dieEnimation = function(){
    for(var a = 0; a < enemy.data.length; a++){
        if(enemy.data[a].isusing == true && enemy.data[a].died == true){
            enemy.data[a].y += 10;
            enemy.data[a].diecount--;
            
            if(enemy.data[a].diecount <= 0){
                enemy.deleteData(a);
            }  
        }
    }
};
enemy.buffCheck = function(){
    for(var a = 0; a < enemy.data.length; a++){
        if(enemy.data[a].isusing == false)  continue;
        
        // 버프 최대치 재설정
        if(enemy.data[a].weakness > 100)  enemy.data[a].weakness = 100;
        if(enemy.data[a].defensedown > 100)  enemy.data[a].defensedown = 100;
        if(enemy.data[a].fire > 200)  enemy.data[a].fire = 200;
        
        // 파이어 버프 처리
        if(enemy.data[a].fire != 0 && enemy.data[a].firetime%100 == 0){
            var firepoint = enemy.data[a].fire; // 파이어의 적용값을 처리
            if(firepoint >= 200)  firepoint = 200;
            var damageValue = (firepoint * enemy.data[a].firedamage * 20) / 100 |0;
            enemy.data[a].hp -= damageValue;
            damage.create(damageValue, typeName.FIRE, enemy.data[a].x, enemy.data[a].y);
        }
        
        // 버프가 적용되었을경우, 버프체크시간을 감소시킴. 버프가 없을경우 버프체크시간을 최대로 유지.
        if(enemy.data[a].weakness != 0)  enemy.data[a].weaknesstime--;
        else  enemy.data[a].weaknesstime = 250;
        if(enemy.data[a].defensedown != 0)  enemy.data[a].defensedowntime--;
        else  enemy.data[a].defensedowntime = 250;
        if(enemy.data[a].fire != 0)  enemy.data[a].firetime--;
        else  enemy.data[a].firetime = 300;
        
        // 시간이 0이될경우, 버프에 적용되었던 값 감소
        if(enemy.data[a].weaknesstime <= 0){
            enemy.data[a].weaknesstime = 350; // 시간 초기화 
            if(enemy.data[a].weakness <= 10)  enemy.data[a].weakness -= 4;
            else if(enemy.data[a].weakness >= 11 && enemy.data[a].weakness <= 20)  enemy.data[a].weakness -= 8;
            else if(enemy.data[a].weakness >= 21 && enemy.data[a].weakness <= 35)  enemy.data[a].weakness -= 13;
            else if(enemy.data[a].weakness >= 36 && enemy.data[a].weakness <= 50)  enemy.data[a].weakness -= 21;
            else if(enemy.data[a].weakness >= 51 && enemy.data[a].weakness <= 70)  enemy.data[a].weakness -= 30;
            else if(enemy.data[a].weakness >= 71 && enemy.data[a].weakness <= 90)  enemy.data[a].weakness -= 42;
            else if(enemy.data[a].weakness >= 91 && enemy.data[a].weakness <= 100)  enemy.data[a].weakness -= 55;
        }
        if(enemy.data[a].defensedowntime <= 0){
            enemy.data[a].defensedowntime = 200;
            if(enemy.data[a].defensedown <= 10)  enemy.data[a].defensedown -= 8;
            else if(enemy.data[a].defensedown >= 11 && enemy.data[a].defensedown <= 20)  enemy.data[a].defensedown -= 16;
            else if(enemy.data[a].defensedown >= 21 && enemy.data[a].defensedown <= 35)  enemy.data[a].defensedown -= 24;
            else if(enemy.data[a].defensedown >= 36 && enemy.data[a].defensedown <= 50)  enemy.data[a].defensedown -= 36;
            else if(enemy.data[a].defensedown >= 51 && enemy.data[a].defensedown <= 70)  enemy.data[a].defensedown -= 55;
            else if(enemy.data[a].defensedown >= 71 && enemy.data[a].defensedown <= 90)  enemy.data[a].defensedown -= 70;
            else if(enemy.data[a].defensedown >= 91 && enemy.data[a].defensedown <= 100)  enemy.data[a].defensedown -= 80;
        }   
        if(enemy.data[a].firetime <= 0){  
        	enemy.data[a].firetime = 300;  enemy.data[a].fire -= 12;
        }
        
        // 음수값이 있을경우 0으로 변경
        if(enemy.data[a].weakness <= 0)  enemy.data[a].weakness = 0;
        if(enemy.data[a].defensedown <= 0)  enemy.data[a].defensedown = 0;
        if(enemy.data[a].fire <= 0)  enemy.data[a].fire = 0;
        
        
        // 데미지 출력 표시 관련 수정
        enemy.data[a].damagecountdelay++;
        if(enemy.data[a].damagecountdelay > 2){
        	enemy.data[a].damagecountdelay = 0;
        	enemy.data[a].damagecount = 0;
        }
    }
};
enemy.display = function(){
    ctx.drawImage(enemy.statusImage, 640 - enemy.statusImage.width, 0);
    var enemyCurrent = 0,  enemyCreate = 0;
    for(var a = 0; a < enemy.currentCount.length; a++){
        enemyCurrent += enemy.currentCount[a];
    }
    for(var a = 0; a < enemy.createCount.length; a++){
        enemyCreate += enemy.createCount[a];
    }
    
    numberDisplay(enemyCurrent, 640 - enemy.statusImage.width + 80, 5);
    numberDisplay(enemyCreate, 640 - enemy.statusImage.width + 230, 5);
    for(var a = 0; a < enemy.data.length; a++){
        if(enemy.data[a].isusing == false)  continue;
        ctx.drawImage(enemy.data[a].image, enemy.data[a].x, enemy.data[a].y);
        
        ctx.font = "12px consolas";  ctx.fillStyle = "orange";
        if(enemy.data[a].weakness >= 1)  ctx.fillText(enemy.data[a].weakness, enemy.data[a].x+5, enemy.data[a].y+20);
        ctx.fillStyle = "cyan";
        if(enemy.data[a].defensedown >= 1)  ctx.fillText(enemy.data[a].defensedown, enemy.data[a].x+5, enemy.data[a].y+30);
        ctx.fillStyle = "salmon";
        if(enemy.data[a].fire >= 1)  ctx.fillText(enemy.data[a].fire, enemy.data[a].x+5, enemy.data[a].y+40);
    }
    
    enemy.displayAttack();
};
enemy.deleteData = function(index){
    enemy.data[index] = new EnemyUnit();
};
enemy.deleteAttack = function(index){
	enemy.attack[index] = new EnemyAttack();
};

enemy.clearCheck = function(){
    var notEnemy = enemy.isNotEnemy();
    if(notEnemy == true){ // 적이 모두 죽은상태의 경우
    	for(var a = 0; a < enemy.data.length; a++){  
    		if(enemy.data[a].isusing == true){
    			return false; // 적 객체 데이터를 사용중인경우 클리어처리를 미룸.
    		}
    	}
    }
    
    return true;
};

enemy.isNotEnemy = function(){
	var createCount = 0,  currentCount = 0;
    for(var a = 0; a < enemy.createCount.length; a++){
        createCount += enemy.createCount[a];
    }
    for(var a = 0; a < enemy.currentCount.length; a++){
        currentCount += enemy.currentCount[a];
    }
    
    if(currentCount <= 0 && createCount <= 0)  return true;
    else  return false;
};

enemy.getCurrentCount = function(){
	var currentCount = 0;
	for(var a = 0; a < enemy.currentCount.length; a++){
        currentCount += enemy.currentCount[a];
    }
    
    return currentCount;
};
enemy.getCreateCount = function(){
	var createCount = 0;
	for(var a = 0; a < enemy.createCount.length; a++){
        createCount += enemy.createCount[a];
    }
    
    return createCount;
};

//--------------------------------
var tamsaseon = new ObjectUnit();
tamsaseon.image = new Image();  tamsaseon.image.src = "image/system/tamsaseon.png";
tamsaseon.hpImage = new Image();  tamsaseon.hpImage.src = "image/system/tamsaseonhp.png";
tamsaseon.hpMeter = new Image();  tamsaseon.hpMeter.src = "image/system/tamsaseonhpmeter.png";
tamsaseon.hpWarning = new Image();  tamsaseon.hpWarning.src = "image/system/tamsaseonhpwarning.png";
tamsaseon.warning50 = false;
tamsaseon.warning25 = false;
tamsaseon.warningTime = 0;
tamsaseon.warningDelay = 0;
tamsaseon.recovery = false;
tamsaseon.recoveryTime = 0;
tamsaseon.recoveryCount = 0;
tamsaseon.recoveryDelay = 0;
tamsaseon.viewright = true;
tamsaseon.shield = new Array(4);
for(var i = 0; i < tamsaseon.shield.length; i++){
	tamsaseon.shield[i] = new ObjectUnit();
	tamsaseon.width = 80;
	tamsaseon.height = 80;
}
tamsaseon.shieldImage = new Image();  tamsaseon.shieldImage.src = "image/system/shield.png";
tamsaseon.shieldHp = 0;

tamsaseon.shieldMovePoint = 0;
tamsaseon.shieldEnergy = 2000;
tamsaseon.shieldType = "front";
tamsaseon.shieldEquip = false;
tamsaseon.hp = 0;  tamsaseon.maxhp = 0;
tamsaseon.width = 48;  tamsaseon.height = 48;
tamsaseon.x = 0;
tamsaseon.y = 0;
tamsaseon.killcount = 0; // 탐사선이 적을 죽인 개수

tamsaseon.process = function(){
    if(inputpush[keyboard.up] == true && tamsaseon.y > 0)  tamsaseon.y -= 8;
    if(inputpush[keyboard.down] == true && tamsaseon.y < 480 - 48)  tamsaseon.y += 8;
    if(inputpush[keyboard.left] == true && tamsaseon.x > 0){  tamsaseon.x -= 8; } //tamsaseon.viewright = false; }
    if(inputpush[keyboard.right] == true && tamsaseon.x < 640 - 48) {  tamsaseon.x += 8;  tamsaseon.viewright = true; }
    if(inputkey == keyboard.enter && tamsaseon.shieldEnergy >= 1000 && tamsaseon.shieldHp <= 0){  
    	if(tamsaseon.shieldType == "front"){
    		tamsaseon.shieldImage.src = "image/system/shield.png";
    		tamsaseon.shieldEnergy -= 1000;  tamsaseon.shieldHp = tamsaseon.maxhp * 0.4|0;
    	} else if(tamsaseon.shieldType == "roll"){
    		tamsaseon.shieldImage.src = "image/system/shield2.png";
    		tamsaseon.shieldEnergy -= 1000;  tamsaseon.shieldHp = tamsaseon.maxhp * 0.5|0;
    		for(var i = 0; i < tamsaseon.shield.length; i++){
    			tamsaseon.shield[i].count = 0;
    			tamsaseon.shield[i].width = 40;
    			tamsaseon.shield[i].height = 40;
    			switch(i){
    			case 0:
    				tamsaseon.shield[i].speedx = -3;
    				tamsaseon.shield[i].speedy = 3;
    				tamsaseon.shield[i].x2 = 0;
    				tamsaseon.shield[i].y2 = - 60;  break;
    			case 1:
    				tamsaseon.shield[i].speedx = 3;
    				tamsaseon.shield[i].speedy = 3;
    				tamsaseon.shield[i].x2 = - 60;
    				tamsaseon.shield[i].y2 = 0;   break;
    			case 2:
    				tamsaseon.shield[i].speedx = 3;
    				tamsaseon.shield[i].speedy = -3;
    				tamsaseon.shield[i].x2 = 0;
    				tamsaseon.shield[i].y2 = 60;  break;
    			case 3:
    				tamsaseon.shield[i].speedx = -3;
    				tamsaseon.shield[i].speedy = -3;
    				tamsaseon.shield[i].x2 = 60;
    				tamsaseon.shield[i].y2 = 0;  break;
    			}
    		}
    	}
    }
    if(inputkey == keyboard.esc && tamsaseon.shieldHp <= 0){
    	if(tamsaseon.shieldType == "front"){
    		tamsaseon.shieldType = "roll";
    	} else if(tamsaseon.shieldType == "roll"){
    		tamsaseon.shieldType = "front";
    	}
    }
    if(tamsaseon.shieldEnergy <= 5000)  tamsaseon.shieldEnergy++;
    tamsaseon.shieldMovePoint++;
    
    if(tamsaseon.shieldHp >= 1){
    	for(var i = 0; i < tamsaseon.shield.length; i++){
    		if(tamsaseon.shieldType == "front"){
    			tamsaseon.shield[i].x = tamsaseon.x + 48;
    			tamsaseon.shield[i].y = tamsaseon.y - 16;
    		} else if(tamsaseon.shieldType == "roll" ){
    			tamsaseon.shield[i].x = tamsaseon.x + tamsaseon.shield[i].x2;
    			tamsaseon.shield[i].y = tamsaseon.y + tamsaseon.shield[i].y2;
    			tamsaseon.shield[i].x2 += tamsaseon.shield[i].speedx;
    			tamsaseon.shield[i].y2 += tamsaseon.shield[i].speedy;
    			
    			tamsaseon.shield[i].count++;
    			if(tamsaseon.shield[i].count >= 20){
    				tamsaseon.shield[i].count = 0;
    				if(tamsaseon.shield[i].speedx == -3 && tamsaseon.shield[i].speedy == 3){
    					tamsaseon.shield[i].speedx = 3;  tamsaseon.shield[i].speedy = 3;
    				} else if(tamsaseon.shield[i].speedx == 3 && tamsaseon.shield[i].speedy == 3){
    					tamsaseon.shield[i].speedx = 3;  tamsaseon.shield[i].speedy = -3;
    				} else if(tamsaseon.shield[i].speedx == 3 &&  tamsaseon.shield[i].speedy == -3){
    					tamsaseon.shield[i].speedx = -3;  tamsaseon.shield[i].speedy = -3;
    				} else if(tamsaseon.shield[i].speedx == -3 &&  tamsaseon.shield[i].speedy == -3){
    					tamsaseon.shield[i].speedx = -3;  tamsaseon.shield[i].speedy = 3;
    				}
    			}
    		}
    	}
    }
    
    for(var a = 0; a < enemy.data.length; a++){
        if(tamsaseon.shieldHp >= 1 && enemy.data[a].tamsaseoncount <= 0 &&
        	(  collision(tamsaseon.shield[0], enemy.data[a]) || collision(tamsaseon.shield[1], enemy.data[a])
        	|| collision(tamsaseon.shield[2], enemy.data[a]) || collision(tamsaseon.shield[3], enemy.data[a])  ) 
        	){
    			tamsaseon.shieldHp -= enemy.data[a].attack;
	            enemy.data[a].tamsaseoncount = 50;
	            enemy.data[a].speedx = -enemy.data[a].speedx;
	            enemy.data[a].speedy = -enemy.data[a].speedy;
	            enemy.data[a].hp -= force.data[21].attack;
	            damage.create(force.data[21].attack, typeName.SHIELD, enemy.data[a].x, enemy.data[a].y);
	            break;
        } else if(tamsaseon.recovery == false && enemy.data[a].tamsaseoncount <= 0 && collision(enemy.data[a], tamsaseon.x, tamsaseon.y, tamsaseon.width, tamsaseon.height) ){
            tamsaseon.hp -= enemy.data[a].attack;
            enemy.data[a].tamsaseoncount = 50;
            enemy.data[a].speedx = -enemy.data[a].speedx;
            enemy.data[a].speedy = -enemy.data[a].speedy;
            if(enemy.data[a].attack >= tamsaseon.hp/100|0 )  optionbattle.sound.play(soundName.damage);
        }
    }
    
    
    
    if(tamsaseon.hp <= tamsaseon.maxhp * 0.5 && tamsaseon.warning50 == false){
    	tamsaseon.warningTime = 80;
    	tamsaseon.warningDelay = 0;
    	tamsaseon.warning50 = true;
    	optionbattle.sound.play(soundName.tamsaseonwarning);
    }
    
    if(tamsaseon.hp <= tamsaseon.maxhp * 0.25 && tamsaseon.warning25 == false){
    	tamsaseon.warningTime = 80;
    	tamsaseon.warningDelay = 0;
    	tamsaseon.warning25 = true;
    	optionbattle.sound.play(soundName.tamsaseonwarning);
    }
    
    if(tamsaseon.hp >= tamsaseon.maxhp * 0.51){
    	tamsaseon.warningDelay++;
    	if(tamsaseon.warningDelay >= 500){
    		tamsaseon.warning25 = false;
    		tamsaseon.warning50 = false;
    	}
    }
    
    if(tamsaseon.hp <= 0 && tamsaseon.recovery == false){
    	tamsaseon.recovery = true;
    	optionbattle.sound.play(soundName.wall_break);
    	tamsaseon.recoveryTime = 30;
    	tamsaseon.recoveryDelay = 2;
    	tamsaseon.recoveryCount = -100;
    }
    
    if(tamsaseon.recovery == true){
    	tamsaseon.recoveryCount++;
    	if(tamsaseon.recoveryCount >= tamsaseon.recoveryDelay){
    		tamsaseon.recoveryCount = 0;
    		tamsaseon.recoveryTime--;
    		system.time--;
    		optionbattle.sound.play(soundName.tamsaseon_recoverytime);
    	}
    	
    	if(tamsaseon.recoveryTime <= 0){
    		tamsaseon.recovery = false;
    		tamsaseon.hp = tamsaseon.maxhp;
    		tamsaseon.warning50 = false;
    		tamsaseon.warning25 = false;
    	}
    }
};
tamsaseon.display = function(){
    // 탐사선의 체력 및 수치 정보는  force.display 에서 처리
    
    if(tamsaseon.viewright == true && tamsaseon.recovery == false){
        ctx.drawImage(tamsaseon.image, 0, 0, 48, 48, tamsaseon.x, tamsaseon.y, 48, 48);
    } else if(tamsaseon.recovery == false) {
        ctx.drawImage(tamsaseon.image, 48, 0, 48, 48, tamsaseon.x, tamsaseon.y, 48, 48);
    }
    
    if(tamsaseon.shieldHp >= 1){
    	for(var i = 0; i < 4; i++){
    		ctx.drawImage(tamsaseon.shieldImage, tamsaseon.shield[i].x, tamsaseon.shield[i].y);
    	}
    }
    
    
    if(tamsaseon.hp >= 1){
    	var percent = tamsaseon.hp / tamsaseon.maxhp;
    	ctx.drawImage(tamsaseon.hpMeter, 0, 0, percent * 640, 20, 0, 460, percent * 640, 20);
    }
    
    tamsaseon.warningTime--;
    if(tamsaseon.warningTime >= 1 && tamsaseon.warningTime % 2 == 0){
    	ctx.drawImage(tamsaseon.hpWarning, 0, 0, percent * 640, 20, 0, 460, percent * 640, 20);
    }
    
    ctx.drawImage(tamsaseon.hpImage, 0, 440);
    numberDisplay(tamsaseon.hp, 110, 440, null, true);
    numberDisplay(tamsaseon.maxhp, 140, 440);
    numberDisplay((tamsaseon.shieldEnergy/1000|0), 623, 440);
    if(tamsaseon.shieldHp >= 1)  numberDisplay(tamsaseon.shieldHp, 600 ,440, null, true);
};
tamsaseon.init = function(){
    tamsaseon.hp = 30000 + ( 100 * optionbattle.user.getlv() );
    tamsaseon.maxhp = tamsaseon.hp;
    tamsaseon.x = 100;  tamsaseon.y = 240;
    tamsaseon.warning50 = false;
    tamsaseon.warning25 = false;
    tamsaseon.warningDelay = 0;
    tamsaseon.warningTime = 0;
    tamsaseon.killcount = 0;
    tamsaseon.recovery = false;
	tamsaseon.recoveryTime = 0;
	tamsaseon.recoveryDelay = 0;
};

// class System
var system = {};
system.pauseImage = new Image();  system.pauseImage.src = "image/system/pause.png";
system.arrow = new Image();  system.arrow.src = "image/system/arrow2.png";
system.on = new Image();  system.on.src = "image/system/on.png";
system.off = new Image();  system.off.src = "image/system/off.png";
system.timeImage = new Image();  system.timeImage.src = "image/system/fieldtime.png";
system.resultImage = new Image();  system.resultImage.src = "image/system/result.png";
system.gameoverImage = new Image();  system.gameoverImage.src = "image/system/gameover.png";
system.scoreImage = new Image();  system.scoreImage.src = "image/system/score.png";
system.boss = NOTHING;
system.bosskill = false;
system.goldBonus = 0;
system.select = 0;
system.gameover = false;
system.giveup = false;
system.time = 0;
system.timedown = false;
system.pause = false;
system.clearImpossible = false;
system.clear = false;
system.clearinit = false;
system.clearDelay = 0;
system.processPoint = 0;
system.processMax = 0;
system.waitTime = 0;
system.dungeon = 0;
system.round = 0;
system.mapscore = 0;
system.mapgold = 0;
system.group = new Array();
system.clearBonus = 0,  system.timeBonus = 0,  system.scoreBonus = 0,  system.totalBonus = 0,  system.scoreEnimation = 0;
system.scoreEnimationCount = 0;

system.init = function(){
    system.dungeon = optionbattle.game.getDungeonSelect();
    system.round = optionbattle.game.getRoundSelect();
    var D = optionbattle.dungeon.getRound(system.dungeon, system.round);
    var E = optionbattle.dungeon.getEnemy(system.dungeon);
    
    background.imageNumber = D.map[0].imageNumber;
    background.setImage();
    background.x = 0;  background.y = 0;
    background.isScrollLoopX = D.map[0].loopx;
    background.isScrollLoopY = D.map[0].loopy;
    background.scrollX = D.map[0].speedx;
    background.scrollY = D.map[0].speedy;
    
    system.mapscore = D.mapscore;
    system.clearBonus = D.mapscore * D.time;
    system.time = D.time;
    system.timedown = true;
    system.pause = false;
    system.gameover = false;
    system.giveup = false;
    system.clear = false;
    system.clearinit = false;
    system.clearDelay = 0;
    system.processPoint = 0;
    system.processMax = 0;
    system.scoreBonus = 0;
    system.mapgold = D.mapgold;
    if(D.boss == NOTHING)  system.boss = NOTHING;
    else  system.boss = E[D.boss];
    
    system.group = null;
    system.group = D.group;
    for(var a = 0; a < D.group.length; a++){
        system.processMax += D.group[a].enemyCount;
    }
    
    system.waitTime = 0;
    optionbattle.music.play(D.musicNumber);
    
    event.script = D.script; // 스크립트 얻기
};

system.process = function(){
    if(inputkey == keyboard.p && system.clear == false && system.gameover == false){
        optionbattle.sound.play(soundName.system_pause);
        if(system.pause)  system.pause = false;
        else  system.pause = true;
    }
    if(enemy.getCurrentCount() == 0 && system.clearImpossible == false){  system.clearDelay++; }
    else  {  system.clearDelay = 0; }
    
    if(tamsaseon.recovery == true || enemy.getCurrentCount() == 0){  system.timedown = false; }
    else  { system.timedown = true; }
    
    
    if(system.pause == true){
        optionbattle.music.stop();
        if(inputkey == keyboard.up && system.select > 0){
            system.select--;  optionbattle.sound.play(soundName.select_move);
        } else if(inputkey == keyboard.down && system.select < 3){
            system.select++;  optionbattle.sound.play(soundName.select_move);
        } else if(inputkey == keyboard.enter){
            switch(system.select){
                case 0: system.pause = false;  optionbattle.sound.play(soundName.system_pause); break;
                case 1: optionbattle.game.musicStatusChange(); break;
                case 2: optionbattle.game.soundStatusChange(); break;
                case 3: system.pause = false;  system.giveup = true; break;
            }
        }
    } else if(system.pause == false && system.clear == false && system.gameover == false && system.giveup == false) {
        optionbattle.music.continueMusic();
        if(system.timedown == true)  system.time -= 0.02;
        system.time = Number(system.time.toFixed(2));
        
        //클리어 조건 체크 후, 클리어 처리
        if(system.clearImpossible == false && enemy.clearCheck() && system.boss == NOTHING && system.clearDelay >= 10){
            system.clear = true;
        } else if(enemy.clearCheck() && system.bosskill == false && system.boss != NOTHING){
            enemy.create(system.boss, 0);
            system.bosskill = true;
            system.boss = NOTHING;
        }
        
        // 실패
        if(system.time <= 0){
        	system.gameover = true;
        }
    } else if(system.pause == false && system.clear == true) {
    	if(system.clearinit == false){ // 클리어를 할경우 클리어점수와 배경음악 재생등의 조치를 취함.
    		optionbattle.music.play(musicName.roundclear);
            system.clearBonus = system.clearBonus;
            if(system.mapscore/100|0 < 1)  system.timeBonus = system.time * 100 |0;
            else  system.timeBonus = system.time * (system.mapscore/100|0) * 100 |0;
            system.totalBonus = system.clearBonus + system.timeBonus + system.scoreBonus;
            system.scoreEnimation = system.totalBonus;
            system.clearinit = true; // 이 값을 변경하여 시슽
            system.goldBonus = system.scoreBonus * 0.1 |0;
            optionbattle.user.plusgold(system.goldBonus + system.mapgold);
    	}
    	
        system.scoreEnimationCount++;
        if(system.scoreEnimationCount%4 == 0&& system.scoreEnimation > 0){
            var getPoint = system.totalBonus * 0.04 |0;
            if(getPoint <= 0)  getPoint = 1;
            if(system.scoreEnimation > getPoint){
                system.scoreEnimation -= getPoint;
                optionbattle.user.plusexp(getPoint);
            } else if(system.scoreEnimation <= getPoint){
                optionbattle.user.plusexp(system.scoreEnimation);
                system.scoreEnimation = 0;
            }
            optionbattle.sound.play(soundName.system_score);
        }
        
        if(system.scoreEnimation <= 0){
            system.waitTime++;
        }
        if(system.waitTime >= 150)  optionbattle.game.modeChangeMenu();
    } else if(system.pause == false && system.gameover == true){
    	if(system.clearinit == false){ // 클리어를 할경우 클리어점수와 배경음악 재생등의 조치를 취함.
    		optionbattle.music.play(musicName.roundfail);
            system.clearBonus = 0;
            system.timeBonus = 0;
            system.totalBonus = system.clearBonus + system.timeBonus + system.scoreBonus;
            system.scoreEnimation = system.totalBonus;
            system.clearinit = true; // 이 값을 변경하여 시슽
            system.goldBonus = system.scoreBonus * 0.1 |0;
            optionbattle.user.plusgold(system.goldBonus);
    	}
    	
    	system.scoreEnimationCount++;
        if(system.scoreEnimationCount%4 == 0&& system.scoreEnimation > 0){
            var getPoint = system.totalBonus * 0.04 |0;
            if(getPoint <= 0)  getPoint = 1;
            if(system.scoreEnimation > getPoint){
                system.scoreEnimation -= getPoint;
                optionbattle.user.plusexp(getPoint);
            } else if(system.scoreEnimation <= getPoint){
                optionbattle.user.plusexp(system.scoreEnimation);
                system.scoreEnimation = 0;
            }
            optionbattle.sound.play(soundName.system_score);
        }
        
        if(system.scoreEnimation <= 0){
            system.waitTime++;
        }
        if(system.waitTime >= 150)  optionbattle.game.modeChangeMenu();
    } else if(system.pause == false && system.giveup == true){
    	if(system.clearinit == false){ // 클리어를 할경우 클리어점수와 배경음악 재생등의 조치를 취함.
            system.clearBonus = 0;
            system.timeBonus = 0;
            system.totalBonus = system.clearBonus + system.timeBonus + system.scoreBonus;
            system.scoreEnimation = system.totalBonus;
            system.clearinit = true; // 이 값을 변경하여 시슽
            system.goldBonus = system.scoreBonus * 0.1 |0;
            optionbattle.user.plusgold(system.goldBonus);
    	}
    	
    	system.scoreEnimationCount++;
        if(system.scoreEnimationCount%4 == 0&& system.scoreEnimation > 0){
            var getPoint = system.totalBonus * 0.10 |0;
            if(getPoint <= 0)  getPoint = 1;
            if(system.scoreEnimation > getPoint){
                system.scoreEnimation -= getPoint;
                optionbattle.user.plusexp(getPoint);
            } else if(system.scoreEnimation <= getPoint){
                optionbattle.user.plusexp(system.scoreEnimation);
                system.scoreEnimation = 0;
            }
            optionbattle.sound.play(soundName.system_score);
        }
    	
    	if(system.scoreEnimation <= 0){
            system.waitTime++;
        }
        if(system.waitTime >= 50)  optionbattle.game.modeChangeMenu();
    }
};
system.display = function(){
    ctx.drawImage(system.timeImage, 0, 0);
    numberDisplay(system.time, 60, 5);
    if(system.pause){
        ctx.drawImage(system.pauseImage, 230, 30);
        ctx.drawImage(system.arrow, 220, 60+(30*system.select));
        if(optionbattle.game.getmusicOn() == true)  ctx.drawImage(system.on, 410, 90);
        else  ctx.drawImage(system.off, 410, 90);
        if(optionbattle.game.getsoundOn() == true)  ctx.drawImage(system.on, 410, 120);
        else  ctx.drawImage(system.off, 410, 120);
        
        ctx.drawImage(system.scoreImage, 0, 30);
        numberDisplay(system.scoreBonus, 150, 35, null, true);
    } else if(system.clear || system.gameover || system.giveup){
        var alignY = 185,  alignX = 500;
        if(system.clear == true)  ctx.drawImage(system.resultImage, 0, 0);
        else  ctx.drawImage(system.gameoverImage, 0, 0);
        
        numberDisplay(system.clearBonus, alignX, alignY, null, true);
        numberDisplay(system.timeBonus, alignX, alignY+30, null, true);
        numberDisplay(system.scoreBonus, alignX, alignY+60, null, true);
        numberDisplay(system.totalBonus, alignX, alignY+90, null, true);
        numberDisplay(optionbattle.user.getlv(), 180, alignY+120, null, true);
        numberDisplay(optionbattle.user.getexp(), 360, alignY+120, null, true);
        numberDisplay(system.goldBonus, alignX, alignY+150, null, true);
        var expTable = optionbattle.user.getexpTable();
        var needexp = expTable[optionbattle.user.getlv()];
        numberDisplay(needexp, 400, alignY+120);
        ctx.fillStyle = "blue";
        var expPercent = optionbattle.user.getexp() / needexp;
        ctx.fillRect(120, 360, expPercent*410, 10);
    }
};


var background = {};
background.imageBlack = new Image();  background.imageBlack.src = "image/background/black.png";
background.imageNumber = 0;
background.imageChangeNumber = 0;
background.image = new Image();
background.imageChange = new Image();
background.isChange = false;
background.changeCount = 0;
background.changeDelay = 150;
background.x = 0;
background.speedx = 0;
background.speedy = 0;
background.isScrollLoopX = false;
background.isScrollLoopY = false;
background.scrollX = 0;
background.scrollY = 0;
background.y = 0;
background.setImage = function(){
	background.image = get_imageBoxRound(background.imageNumber);
};
background.changeImage = function(changeNumber){
	background.changeCount = background.changeDelay;
	background.isChange = true;
	background.imageChangeNumber = changeNumber;
	background.imageChange = get_imageBoxRound(changeNumber);
};
background.display = function(){
    var sizex = background.image.width;
    var sizey = background.image.height;
    var x = background.x;
    var y = background.y;
    var wx = sizex - x;
    var hy = sizey - y;
    var nonex = 0;
    var noney = 0;
    //if(wx >= 640)  wx = 640;
    //if(hy >= 480)  hy = 480;
    //if(x >= 640) px = x - 640;
    //if(y >= 480) py = y - 480;
    
    
    /* ctx.drawImage(image, x, y, sizex - x, sizey - y, 0, 0, sizex - x, sizey - y);
    ctx.drawImage(image, 0, 0, x, sizey, sizex - x, y, x, sizey);
    ctx.drawImage(image, 0, 0, sizex, y, x, sizey - y, sizex, y); */
    
    //고작 이미지 스크롤 처리하는데 4번씩이나 그려야 한다니 헐... 빌어먹을 파이어폭스, IE
    //하지만 어느게 표준인거지? 도무지 알수없군...
    //crop 크기가 0, 0 이면 에러가 나서 일일히 이래야 한다니 멘붕
    
    // ie, firefox, chrome, opera // y is 0 or x is 0
    // ie and firefox have zero size error.

    if(x == 0 && y == 0){
        ctx.drawImage(background.image, 0, 0); // 이미지 출력, x좌표 and y좌표가 0일경우
    } else if(x == 0 && y != 0) { // x좌표가 0일경우(y좌표 스크롤)
        if(y != 0)  ctx.drawImage(background.image, 0, 0, sizex, y, nonex, hy, sizex, y);
        if(hy != 0)  ctx.drawImage(background.image, nonex, y, sizex, hy, 0, 0, sizex, hy);
    } else if(x != 0 && y == 0) { // y좌표가 0일경우(x좌표 스크롤)
        if(wx != 0)  ctx.drawImage(background.image, x, noney, wx, sizey, 0, 0, wx, sizey);
        if(x != 0)  ctx.drawImage(background.image, 0, 0, x, sizey, wx, noney, x, sizey);
    } else if(x != 0 && y != 0) { // x와 y좌표가 0이 아닐경우(x, y 다 스크롤)
        if(wx != 0  && hy != 0) ctx.drawImage(background.image, x, y, wx, hy, 0, 0, wx, hy); // 그림 1
        if(x != 0  && hy != 0)  ctx.drawImage(background.image, 0, y, x, hy, wx, 0, x, hy); // x축 그림 2
        if(wx != 0  && y != 0)  ctx.drawImage(background.image, x, 0, wx, y, 0, hy, wx, y); // y축 그림 3
        if(wx != 0 && hy != 0)  ctx.drawImage(background.image, 0, 0, x, y, wx, hy, x, y); // x, y축 그림 4
    }
    
    if(background.isChange == true){
    	if(background.changeCount >= background.changeDelay / 2){
    		ctx.globalAlpha = 1 - (background.changeCount - (background.changeDelay / 2) ) / (background.changeDelay / 2);
    		ctx.drawImage(background.imageBlack, 0, 0);
    	} else {
    		ctx.globalAlpha = (background.changeCount) / (background.changeDelay / 2);
    		ctx.drawImage(background.imageBlack, 0, 0);
    	}
    }
    // 투명값 원래대로
    ctx.globalAlpha = 1;
    
};
background.process = function(){
    background.x += background.scrollX;
    background.y += background.scrollY;
    background.changeCount--;
    if(background.changeCount <= 0 && background.isChange == true){
    	background.isChange = false;
    } else if(background.changeCount == background.changeDelay / 2|0 ){
    	background.image = get_imageBoxRound(background.imageChangeNumber);
    }
    
    if(background.x >= background.image.width && background.isScrollLoopX == true)  background.x = 0;
    else if(background.x >= background.image.width - 640 && background.isScrollLoopX == false)  background.x -= background.scrollX;
    else if(background.x <= -1 && background.isScrollLoopX == true)  background.x = background.image.width;
    else if(background.x <= -1 && background.isScrollLoopX == false) background.x = 0;
    if(background.y >= background.image.height && background.isScrollLoopY == true)  background.y = 0;
    else if(background.y >= background.image.height - 480 && background.isScrollLoopY == false)  background.y -= background.scrollY;
    else if(background.y <= -1 && background.isScrollLoopY == true)  background.y = background.image.height;
    else if(background.y <= -1 && background.isScrollLoopY == false)  background.y = 0;
};

//-----------------------------//
function EffectUnit(){
    this.countNumber = 0;
    this.imageCount = 0;
    this.effectNumber = 0;
    this.width = 0;
    this.height = 0;
    this.outputWidth = 0;
    this.outputHeight = 0;
} EffectUnit.prototype = new ObjectUnit();
var effect = {};
effect.picture = new Array(10);
for(var a = 0; a < effect.picture.length; a++)  effect.picture[a] = new EffectUnit();
effect.data = new Array(150);
for(var a = 0; a < effect.data.length; a++)  effect.data[a] = new EffectUnit();
var effectName = {SPLASH:0, MISSILE:1, HITSHOT:2, FIRE:3, MACHINEGUN_UP:4, MACHINEGUN_DOWN:5, MACHINEGUN_CENTER:6,
			BURSTSHOT:7 };
effect.setEffect = function(number, filename, imageCount, delay, width, height, outputWidth, outputHeight){
    effect.picture[number].imageCount = imageCount;
    effect.picture[number].image = new Image();
    effect.picture[number].image.src = "image/effect/"+filename+".png";
    effect.picture[number].delay = delay;
    effect.picture[number].width = width;
    effect.picture[number].height = height;
    effect.picture[number].outputWidth = outputWidth;
    effect.picture[number].outputHeight = outputHeight;
};
effect.setEffect(effectName.SPLASH, "splash", 10, 1, 40, 40, 400, 400);
effect.setEffect(effectName.MISSILE, "missile", 10, 1, 40, 40, 180, 180);
effect.setEffect(effectName.HITSHOT, "hitshot", 10, 1, 40, 40, 40, 40);
effect.setEffect(effectName.FIRE, "fire", 10, 0, 60, 60, 60, 60);
effect.setEffect(effectName.MACHINEGUN_DOWN, "machinegun_down", 10, 0, 40, 40, 20, 400);
effect.setEffect(effectName.MACHINEGUN_UP, "machinegun_up", 10, 0, 40, 40, 20, 400);
effect.setEffect(effectName.MACHINEGUN_CENTER, "machinegun_center", 10, 0, 40, 40, 20, 400);
effect.setEffect(effectName.BURSTSHOT, "burstshot", 10, 1, 40, 40, 40, 40);

effect.create = function(effectNumber, x, y){
    var number = 0;
    for(var a = 0; a < effect.data.length; a++){
        if(effect.data[a].isusing == false){
            number = a;  break;
        }
    }
    
    effect.data[number].countNumber = 0;
    effect.data[number].x = x;
    effect.data[number].y = y;
    effect.data[number].isusing = true;
    effect.data[number].effectNumber = effectNumber;
    effect.data[number].delay = effect.picture[effectNumber].delay;
    effect.data[number].imageCount = effect.picture[effectNumber].imageCount;
    effect.data[number].width = effect.picture[effectNumber].width;
    effect.data[number].height = effect.picture[effectNumber].height;
    effect.data[number].outputWidth = effect.picture[effectNumber].outputWidth;
    effect.data[number].outputHeight = effect.picture[effectNumber].outputHeight;
};
effect.deleteData = function(index){
    effect.data[index] = new EffectUnit();
};
effect.display = function(index){
    for(var a = 0; a < effect.data.length; a++){
        if(effect.data[a].isusing == false)  continue;
        
        var EF = effect.data[a].effectNumber;
        var CN = effect.data[a].countNumber;
        var E = effect.data[a];
        
        var basex = 0;
        var basey = 0;
        for(var i = 0; i < effect.data[a].countNumber; i++){
        	basex += E.width;
        	if(basex >= effect.picture[EF].image.width){
        		basey += E.height;
        		basex = 0;
        	}
        }
        
        if(CN < effect.data[a].imageCount){
        	ctx.drawImage(effect.picture[EF].image, basex, basey, E.width, E.height, E.x, E.y, E.outputWidth, E.outputHeight);
        }  
    }
};
effect.process = function(){
    for(var a = 0; a < effect.data.length; a++){
        if(effect.data[a].isusing == false)  continue;
        
        if(effect.data[a].count >= effect.data[a].delay){
            effect.data[a].count = 0;
            if(effect.data[a].countNumber < effect.data[a].imageCount){
                effect.data[a].countNumber++;
            } else {
                effect.deleteData(a);
            }
        }
        effect.data[a].count++;
    }
};
effect.init = function(){
	for(var a = 0; a < effect.data.length; a++){
		effect.data[a].isusing = false;
	}
};
//-----------------------------//
// 스크립트와 같은 특수한 이벤트 처리를 위해 만든 객체
/*function Script(){
	this.condition = new Array(10);
	this.action = new Array(10);
	for(var a = 0; a < this.action.length; a++){
		this.condition[a] = "";
		this.action[a] = "";
	}
}*/

var event = {};
event.script = new Array(101);
event.variable = new Array(101);
event.switch_ = new Array(101);
event.used = new Array(101);
for(var a = 0; a < event.script.length; a++){
	event.variable[a] = 0;
	event.switch_[a] = false;
	event.used[a] = false;
}

event.process = function(){
  for(var a = 0; a < event.script.length; a++){ // 모든 스크립트를 매 프레임마다 조사
  	if(event.used[a] == true)  continue; // 스크립트를 사용했다면 건너 뜀
  	var scriptTrue = [false, false, false, false, false, false, false, false, false, false];
  	
  	// 스크립트의 조건 체크
  	for(var b = 0; b < event.script[a].condition.length; b++){
  		var scriptCondition = event.script[a].condition[b].split(" ");
  		var con_who = scriptCondition[0];
  		var con_type = scriptCondition[1];
	  	var con_opt1 = scriptCondition[2];
	  	var con_opt2 = scriptCondition[3];
	  	var con_opt3 = scriptCondition[4];
	  	if(con_who == "tamsaseon"){ // 탐사선
	  		if(con_type == "killcount"){ // 킬 카운트가
	  			if(con_opt1 == "="){  // 해당 개수일때
	  				con_opt2 = Number(con_opt2); // 문자를 숫자로 변환
	  				if(con_opt2 == tamsaseon.killcount){
	  					scriptTrue[b] = true;
	  				}
	  			}

	  		}
	  	} else if(con_who == "variable"){
	  		con_type = Number(con_type);
	  		con_opt2 = Number(con_opt2);
	  		if(con_opt1 == "="){
	  			if(event.variable[con_type] == con_opt2)  scriptTrue[b] = true;
	  		} else if(con_opt1 == ">="){
	  			if(event.variable[con_type] >= con_opt2)  scriptTrue[b] = true;
	  		} else if(con_opt1 == "<"){
	  			if(event.variable[con_type] <  con_opt2)  scriptTrue[b] = true;
	  		}
	  		
	  	} else if(con_who == "enemy"){
	  		if(con_type == "currentcount"){
	  			con_opt2 = Number(con_opt2);
	  			var currentCount = enemy.getCurrentCount();
	  			switch(con_opt1){
	  				case '=':  if(currentCount == con_opt2)  scriptTrue[b] = true;  break;
	  				case '<':  if(currentCount <  con_opt2)  scriptTrue[b] = true;  break;
	  			}
	  		} else if(con_type == "createcount"){
	  			con_opt2 = Number(con_opt2);
	  			var createCount = enemy.getCreateCount();
	  			switch(con_opt1){
	  				case '=':  if(createCount == con_opt2)  scriptTrue[b] = true;  break;
	  				case '<':  if(createCount <  con_opt2)  scriptTrue[b] = true;  break;
	  			}
	  		}
	  	} else {
	  		break;  // 조건이 안맞는경우 강제로 포문을 종료.
	  	}
  	}
  	
  	var realTrue = false; // 모든 조건이 맞는지 체크하는 변수
  	for(var c = 0; c < event.script[a].condition.length; c++){
  		if(scriptTrue[c] == true){ // 조건이 맞는경우
  			realTrue = true;
  			continue;
  		} else {  // 조건이 안맞는경우
  			realTrue = false;
  			break;
  		}
  		
  	}
  	
  	// 조건이 맞지 않는경우 해당 포문을 건너뛰고 다음 스크립트로 넘어감.
  	if(realTrue == false)  continue;
  	else  event.used[a] = true; // 조건이 맞는경우 해당 스크립트를 사용한다.
  	
  	// 스크립트의 조건이 맞으므로  액션 체크
  	for(b = 0; b < event.script[a].action.length; b++){
  		var scriptAction = event.script[a].action[b].split(" ");
  		var act_who = scriptAction[0];
	  	var act_type = scriptAction[1];
	  	var act_opt1 = scriptAction[2];
	  	var act_opt2 = scriptAction[3];
	  	var act_opt3 = scriptAction[4];
		if(act_who == "tamsaseon"){
			if(act_type == "killcount"){
				act_opt2 = Number(act_opt2);
				switch(act_opt1){
					case '=':  tamsaseon.killcount = act_opt2;  break;
					case '+':  tamsaseon.killcount += act_opt2;  break;
					case '-':  tamsaseon.killcount -= act_opt2;  break;
				}
			}
		} else if(act_who == "music"){
			act_opt1 = Number(act_opt1); // 숫자로 변환
			if(act_type == "play"){
				optionbattle.music.play(act_opt1);
			} else if(act_type == "change"){
				optionbattle.music.change(act_opt1);
			}
		} else if(act_who == "system"){
			if(act_type == "round"){ 
				if(act_opt1 == "clear"){
					if(act_opt2 == "true"){
						system.clear = true;
						system.clearImpossible = false;
					} else if(act_opt2 == "impossible"){
						system.clearImpossible = true;
					} else if(act_opt2 == "possible"){
						system.clearImpossible = false;
					}
				}
			}
		} else if(act_who == "group"){ // 해당 그룹
			act_type = Number(act_type); // 그룹 번호
			if(act_opt1 == "createcount"){ // 크리에잇카운트
				act_opt3 = Number(act_opt3); // 값 적용
				switch(act_opt2){ // 어떻게
					case '=':  enemy.createCount[act_type] = act_opt3;  break;
					case '+':  enemy.createCount[act_type] += act_opt3;  break;
				}
			} else if(act_opt1 == "create"){
				act_opt2 = Number(act_opt2); // 값 적용
				for(var a = 1; a <= act_opt2; a++){
					var E = optionbattle.dungeon.getEnemy(system.dungeon);
					var R = Math.random() * system.group[a].enemylist.length|0;
					enemy.create(E[system.group[act_type].enemylist[0] ], act_type);
				}
			}
		} else if(act_who == "variable"){ // 변수
			act_type = Number(act_type); // 변수 번호
			act_opt2 = Number(act_opt2);
			switch(act_opt1){
				case '=':  event.variable[act_type] = act_opt2;  break;
				case '+':  event.variable[act_type] += act_opt2;  break;
			}
		} else if(act_who == "map"){ // 맵
			if(act_type == "change"){
				background.changeImage(Number(act_opt1));
			} else if(act_type == "speedx"){
				switch(act_opt1){
					case '=':  event.variable[act_type] = act_opt2;  break;
					case '+':  event.variable[act_type] += act_opt2;  break;
				}
			} else if(act_type == "loopx"){
				if(act_opt1 == "true"){
					background.isScrollLoopX = true;
				} else if(act_opt1 == "false") {
					background.isScrollLoopX = false;
				}
			}
		} else if(act_who == "infinity"){ // 무한모드
			event.used[a] = false; // 스크립트를 무한으로 쓸 때 사용
		}
  	}

  }
};
event.init = function(){
	for(var a = 0; a < event.variable.length; a++){
		// 스크립트값을 얻는것은 시스템에서 처리
		// event.script[a] = optionbattle.dungeon.getScript();
		event.variable[a] = 0;
		event.switch_[a] = false;
		event.used[a] = false;
	}
};

//-----------------------------//
var unusedImage = new Image();  unusedImage.src = "image/system/unused.png";
// function process
this.init = function(){
    tamsaseon.init();
    force.setForce();
    system.init();
    enemy.init();
    attack.init();
    damage.init();
    effect.init();
    event.init();
};

this.process = function(){
    if(system.pause == true){
	    system.process();
	} else if(system.clear == false && system.gameover == false && system.giveup == false) {
	    system.process();
	    tamsaseon.process();
	    enemy.process();
	    attack.process();
	    force.process();
	    damage.process();
	    effect.process();
	    background.process();
	    event.process();
	} else if(system.clear == true || system.gameover == true || system.giveup == true) {
	    system.process();
	}
};
this.display = function(){
    background.display();
    attack.display();
    enemy.display();
    tamsaseon.display();
    effect.display();
    damage.display();
    force.display();
    system.display();
};


var numberPng = new Image();
numberPng.src = "image/system/numberPng.png";
this.numberDisplay = function(number, x, y, strColor, isAlignRight){
    numberDisplay(number, x, y, strColor, isAlignRight);
};

function numberDisplay(number, x, y, strColor, isAlignRight){
    // 여기에 있는 const 변수는 이미지 출력 좌표를 간단히 하기 위해 만든 변수임
    // 위 함수와 다른점은 이 함수는 해당 객체 내부에서 사용할 수 있게 한 함수임.
    cw = 12, ch = 20, sw = 12, sh = 20; // c = crop, s = imagesize, w = width, h = height
    var p = 0; // p = color;
    if(strColor == "green")  p = 1;
    else if(strColor == "skyblue")  p = 2;
    else if(strColor == "yellow")  p = 3;
    
    var strnumber = number.toString();
    
    if(isAlignRight == true){ // 오른쪽 정렬일때, length에서 1을 빼주는것은 스트링 배열은 0번부터 시작하기때문
        for(var a = strnumber.length-1 , b = 0 ; a >= 0; a--, b++){
            var outputnumber = strnumber.charAt(a);
            switch(outputnumber){
                case '0': ctx.drawImage(numberPng, cw*0, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '1': ctx.drawImage(numberPng, cw*1, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '2': ctx.drawImage(numberPng, cw*2, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '3': ctx.drawImage(numberPng, cw*3, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '4': ctx.drawImage(numberPng, cw*4, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '5': ctx.drawImage(numberPng, cw*5, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '6': ctx.drawImage(numberPng, cw*6, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '7': ctx.drawImage(numberPng, cw*7, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '8': ctx.drawImage(numberPng, cw*8, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '9': ctx.drawImage(numberPng, cw*9, ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '.': ctx.drawImage(numberPng, cw*10,ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '-': ctx.drawImage(numberPng, cw*11,ch*p, sw, sh, x-(b*sw), y, sw, sh);  break;
            }
        }
    } else {
        for(var a = 0; a < strnumber.length; a++){
            var outputnumber = strnumber.charAt(a);
            switch(outputnumber){
                case '0': ctx.drawImage(numberPng, cw*0, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '1': ctx.drawImage(numberPng, cw*1, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '2': ctx.drawImage(numberPng, cw*2, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '3': ctx.drawImage(numberPng, cw*3, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '4': ctx.drawImage(numberPng, cw*4, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '5': ctx.drawImage(numberPng, cw*5, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '6': ctx.drawImage(numberPng, cw*6, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '7': ctx.drawImage(numberPng, cw*7, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '8': ctx.drawImage(numberPng, cw*8, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '9': ctx.drawImage(numberPng, cw*9, ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '.': ctx.drawImage(numberPng, cw*10,ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '-': ctx.drawImage(numberPng, cw*11,ch*p, sw, sh, x+(a*sw), y, sw, sh);  break;
            }
        }
    }
    
}
//-----------------------//
}// function end
//-----------------------//
optionbattle.field = new Field();