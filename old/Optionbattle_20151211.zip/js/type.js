// 타입의 이름
// 번호는 단순히 구분을 위해서 넣은것, 타입 배열의 순서는 알아서 지정되므로 타입 배열 순서를 임의로 지정하지 마세요.
// 한줄에 몰아서 써져있는 것들은(10000번대 제외) 같은 계열을 의미합니다.
const typeName = {
    UNUSED:0,
    HYPER:1000, PALSERN:1100, // 하이퍼 계열
    MULTISHOT:2000, WAYSHOT3:2103, WAYSHOT8:2108, DOUBLESHOT:2202,  // 멀티샷 계열
    SPLASH:3000, MISSILE:3100, ROCKET:3101, // 스플래시 계열
    LASER:4000, WHITEFLASH:4100, // 레이져/관통 계열
    BEAM:4500, BEAMLOGIC:4501, BEAMSIX:4502,  // 빔/관통 계열
    MACHINEGUN:5000,  // 머신건/난사 계열
    
    HITSHOT:9000, // 위크니스/약점 계열
    SAWTOOTH:9300, BURSTSHOT:9321, // 디펜스다운/방어력감소 계열
    FIRE:9600, // 파이어/지속데미지 계열
    
    DIRECT:10000, HEAL:10001, METAL:10002, PARAPO:10003, SHIELD:10004,
};
// 타입의 클래스
const typeClass = {
    UNUSED:0, HYPER:1, MULTISHOT:2, SPLASH:3, DIRECT:4, HEAL:5, METAL:6, LASER:7,
    //사용안함:0, 하이퍼:!, 멀티샷:2, 스플래시:3, 다이렉트:4, 힐:5, 메탈:6, 레이져/관통:7
    
    PARAPO:8, WEAKNESS:9, DEFENSEDOWN:10, MACHINEGUN:11, FIRE:12, CHAINCOMBO:13
    //파라포:8, 위크너스/약점:9, 디펜스다운/방어력감소:10, 머신건/난사:11, 파이어/지속데미지:12, 연쇄콤보:13
    
    
};

function Type(){
var typeDpf = {};
typeDpf.data = [1000, ];
typeDpf.arealevel = [1000, ];
typeDpf.base = 1000;
typeDpf.minus = 3.5;
typeDpf.variance = 500;

for(var a = 1; a <= 240; a++){  typeDpf.arealevel[a] = typeDpf.arealevel[a-1] + (typeDpf.base - (a * typeDpf.minus) );  }
for(var a = 1; a <= 240; a++){
    typeDpf.data[a] = (typeDpf.base - typeDpf.variance) + ( (typeDpf.arealevel[240] - typeDpf.arealevel[a]) / typeDpf.arealevel[240] * typeDpf.variance) | 0;
}

var data = new Array();
var createCount = -1;
var typeNumber = [];
function create(classType, className, name, color, section, normalPercent, shotCount, techCount){
    createCount++;
    data[createCount] = new create_type(classType, className, name, color, section, normalPercent, shotCount, techCount);
    data[createCount].number = className;
    typeNumber[createCount] = data[createCount].number;
    //요소 설명
    //주의: 클래스 타입과 클래스 이름은 위에 있는 상수 변수를 사용해야한다. name만 문자열을 사용한다.
    //classType: 클래스 타입,  className(TypeName): 클래스 이름(타입 이름),  name: 이름
    //section: 공격력 범위 구간,  technicalPercent: 테크니컬 공격 할당량 %(0 ~ 100)
    //shotCount: 한번 발사시 발사하는 총알 개수,  techCount: 한번 테크니컬 공격시 발사하는 총알 개수
}


function create_type(classType, className, name, color, section, normalPercent, shotCount, techCount){
    this.className = className;  // 클래스번호
    this.name = name; // 타입 이름
    this.number = null; // 번호?
    this.color = color; // 색깔
    this.section = section; // 섹션, 이것에 따라 기본 dpf가 결정됨
    this.normalPercent = normalPercent;  // 노멀공격형태의 비중%
    if(normalPercent == null)  this.normalPercent = 0; // 아무값도 없을경우 0%로 간주
    this.technicalPercent = 100 - this.normalPercent; // 테크니컬퍼센트값 결정
    this.classType = classType; // 클래스타입 저장
    this.special = false; // 스페셜 여부 판정
    this.delay = 0; // 딜레이
    this.combo = 0; // 콤보(연속타격과 유사한 형태로 활용)
    this.iswait = false; // 여러발을 발사했을 때, 지연시간의 참 거짓 여부, 지연시간은 delay의 값을 사용
    this.istarget = true; // 타겟 추적의 여부를 판정, 기본값은 true
    this.isfollow = true; // 이값이 true일경우 적을 쫓아가는방식, false일경우 적의 좌표값의 의존해 x,y의 속도값이 결정되는 방식
    if(section <= 60)  section = 60;
    if(section >= 300)  section = 300;
    
    this.dpf = typeDpf.data[section - 60]; // section의 최소 수치는 60정도. 따라서 section - 60을 해야 정확한 dpf를 알 수 있음.
    this.shotCount = shotCount;
    this.techCount = techCount;
    if(shotCount == null){  this.shotCount = 1; }
    if(techCount == null){  this.techCount = 1; }
    if(shotCount <= 0){ this.shotCount = 1; }
    if(techCount <= 0){ this.techCount = 1; }
    
    var normalValue = 1;
    var technicalValue = 1;
    switch(className){
	//hyper, 테크니컬, 노말의 효율이 1.1배 증가
    case typeName.HYPER:  normalValue = 1.1;  technicalValue = 1.1;  break;
    //palsern, 미스확률의 특성상 한발당 60%의 효율을 가짐(총합 60*8 = 480%), (x+y/2) 차이 만큼 미스확률 증가. x+y = 200이상, 미스확률 100%
    //타입 구조 내에서 정확한 판별 불가능, 필드의 공격객체 내에 있는 로직을 참고바람.
    case typeName.PALSERN:  normalValue = 4.8;  this.istarget = false;  break;
    
    //multishot, 멀티샷 계열은 테크니컬과 노말의 밸류가 동일, 적을 쫓아가지는 않지만 타겟을 추적하는 형태
    case typeName.MULTISHOT:  this.isfollow = false;  break;
    
    //wayshot3, wayshot8, doubleshot 은 적을 추적하지 않음.
    case typeName.WAYSHOT3:  
    case typeName.WAYSHOT8:
    case typeName.DOUBLESHOT:
    		this.istarget = false;
    break;
    
    //splash, 스플래시는 15%의 효율을 가짐. 스플래시 범위 xy축 +-200(400)
    case typeName.SPLASH:  normalValue = 0.15;  break;
    //missile, 미사일은 1회 타격 후, 4회 폭발함. 하이퍼:20%, 스플래시:25% * 80% 효율로 취급, 스플래시 범위 xy축 +-80(160)
    //combo 5인경우 일반타격, 4이하인경우 스플래시 발동
    case typeName.MISSILE:  normalValue = (0.2 + 0.25 * 0.8) / 5;  this.combo = 5;  this.delay = 12;  break;
    //rocket, 로켓은 앞으로 날라가면서 스플래시 공격 스플래시:40% 효율로 취급, 스플래시 범위 xy축 +-80(160)
    //로켓의 기본 딜레이는 12, 그러나 1회 폭발마다 1씩 감소, 최소는 4, 최대폭발수: 16
    case typeName.ROCKET:  normalValue = 0.4 / 6;  this.delay = 12;  this.istarget = false;  break;
    
    //direct, 다이렉트는 70%의 효율, 특성상 방어무시, 감쇄무시, 무효화무시등 여러 요소들을 무시하기 때문.
    case typeName.DIRECT:  normalValue = 0.7;  break;
    
    //heal(필수/기본), 힐은 회복효율 20%
    case typeName.HEAL:  normalValue = 1;  technicalValue = 0.2;  break;
    
    //metal(필수/기본), 메탈은 공격효율 20%, 대신 다른 타입보다 10배의 체력을 가짐
    case typeName.METAL:  normalValue = 0.2;  break;
    
    //laser, 레이져는 관통공격에 한해 10%효율, 레이져 이동속도: 10, 딜레이:5
    case typeName.LASER:  normalValue = 1;  technicalValue = 0.1;  this.istarget = false;  this.delay = 5;  break;
    //whiteflash, 효율은 35%, 이동속도: 20, 딜레이:5
    case typeName.WHITEFLASH:  normalValue = 0.27;  this.delay = 8;  break;
    //beam, 빔은 관통공격을 사용, 1타당 효율 55% 빔타격 최대횟수:8, 딜레이:10, 범위: x축전체 y축+-20(40)
    case typeName.BEAM:  normalValue = 0.55 / 10;  this.delay = 10;  this.combo = 8;  this.istarget = false;  break;
    //beamlogic, 빔로직, 일반공격: 1타당 효율 47% 빔타격 최대횟수:8, 딜레이 10, 범위: x축전체 y축+-20(40) AND x축+-20(40) y축전체
    //beamlogic, 테크니컬 공격: 1타당 효율 71% 빔타격 최대횟수:8, 딜레이:10, 이동속도:10, 범위: x축전체 y축+-20(40) AND x축+-20(40) y축전체
    case typeName.BEAMLOGIC:  normalValue = 0.47 / 8;  technicalValue = 0.71 / 8;
    			this.delay = 10;  this.combo = 8;  this.istarget = false;  break;
    //beamsix, 추적관통형 빔을 6개 발사, 1타당 효율 41%, 빔타격 최대횟수:8, 딜레이:10, 범위: x축전체 y축+-10(20)
    case typeName.BEAMSIX:  normalValue = 0.81 / 6;  this.delay = 10;  this.combo = 8;  break;
    
    //parapo, 적의 방어력을 역으로 합산 공격, 방어력만 무시, 적의 방어력이 높다면 매우 좋음. 방어력감소에 영향을 받지 않음.
    case typeName.PARAPO:  normalValue = 0.82;  break;
    
    //hitshot, 1회타격당 약점 2개, 1발당 최대 4회 타격, 딜레이:10
    //약점은 적이 받는 데미지를 증가시킨다. 약점 1개당 1%씩 증가한다. 적의 약점개수에 따라서 약점감소량이 다르다.
    //기준은 7초, 10이하:4, 20이하:8, 35이하:13, 50이하:21, 70이하:30, 90이하:42, 100이상:55
    case typeName.HITSHOT:  normalValue = 0.45 / 4;  this.combo = 4;  this.delay = 10;  break;
    
    //sawtooth, 1회타격당 방어력감소 8개, 1발당 4회 확정타격, 그 후 추가타 최대 12회, 딜레이:10, 방어력감소 1타당 8개
    //방어력감소는 적의 방어력을 감소시킨다. 방어력감소 1개당 1%감소된다. 적의 방어력감소개수에 따라서 방어력감소감소량이 다르다.
    //약점과는 다르게 빠르게 감소하고 빠르게 증가한다.
    //기준은 4초, 10이하:8, 20이하:16, 35이하:24, 50이하:36, 70이하:55, 90이하:70, 100이상:80
    case typeName.SAWTOOTH:  normalValue = (0.25 * 4)/48 + (0.42 * 12)/48;  this.combo = 12;  this.delay = 11;  break; 
    //burstshot, 1회타격당 35%확률로 방어력감소 17개, 멀티샷과 비슷한놈이라 발사수가 많아서 톱니보다 더 효율이 좋을수도 있음.
    case typeName.BURSTSHOT:  normalValue = 0.25;  this.isfollow = false;  this.iswait = true;  this.delay = 6;  break;
    
    //fire, 1회타격당 파이어 1개씩 중첩, 1발당 10차례에 걸쳐서 파이어 발사, 이동속도:30
    //파이어는 적에게 도트데미지를 준다. 파이어 1개당 파이어버프의 평균데미지의 10%씩 증가한다.
    //파이어로 적을 공격할때는 방어력의 영향을 받지만, 파이어버프의 데미지는 방어력의 영향을 받지 않는다.(감쇄는 영향을 받음.)
    case typeName.FIRE:  normalValue = 0.75 / 10;  this.istarget = false;  break;
    
    //machinegun, 총알연속횟수:100, (발사수는 객체 저장공간의 문제로 1개로 함), 범위는 x축400 y축100
    //1회 타격당 적에게 히트할 확률은 35%, 미스날경우 무효처리, 따라서 기본효율: (1 / 0.35) * (1.35 / 100);
    case typeName.MACHINEGUN: normalValue = (1 / 0.35) * (1.35 / 100);  this.istarget = false;  this.combo = 100;  break;
    }
    
    if(classType == typeName.HEAL || classType == typeName.METAL){
        this.special = true;
    }
    
    var shotValue = 1;
    var techCountValue = 1;
    if(shotCount >= 2)  shotValue *= 1.1;
    if(techCount >= 2)  techCountValue *= 1.1;
    if(this.istarget == false){  shotValue *= 1.1;  techCountValue *= 1.1; }
    
    
    this.normal = Math.round((this.normalPercent / 100) * (this.dpf * shotValue * normalValue) / this.shotCount) |0;
    this.technical = Math.round((this.technicalPercent / 100) * (this.dpf * techCountValue * technicalValue) / this.techCount) |0;
    this.standard = this.normal + this.technical;
    
    // 타겟이 정해지지 않은경우 적을 쫓아가는 방식도 쓰지 않는다.
    if(this.istarget == false)  this.isfollow = false;
}


// 여기서는 가장 기본적인 값들만 설정, 추가값들은 위쪽에 있는 className을 추가로 수정하는부분에서 수정한다.
// create(타입클래스, 타입이름, 이름, 색깔, 섹션, )
create(typeClass.UNUSED, typeName.UNUSED, "unused", "black", 100, 100);
create(typeClass.HYPER, typeName.HYPER, "hyper", "green", 300, 18);
create(typeClass.HYPER, typeName.PALSERN, "palsern", "greenyellow", 300, 100, 8);
create(typeClass.MULTISHOT, typeName.MULTISHOT, "multishot", "maroon", 60, 50);
create(typeClass.MULTISHOT, typeName.WAYSHOT3, "wayshot3", "brown", 70, 50, 3, 3);
create(typeClass.MULTISHOT, typeName.WAYSHOT8, "wayshot8", "brown", 70, 50, 8, 8);
create(typeClass.MULTISHOT, typeName.DOUBLESHOT, "doubleshot", "brown", 80, 50, 2, 2);
create(typeClass.SPLASH, typeName.SPLASH, "splash", "red", 180, 100);
create(typeClass.SPLASH, typeName.MISSILE, "missile", "#3E5E7E", 210, 100);
create(typeClass.SPLASH, typeName.ROCKET,  "rocket",  "#3E5E7E", 210, 100);
create(typeClass.DIRECT, typeName.DIRECT, "direct", "darkblue", 150, 70);
create(typeClass.HEAL, typeName.HEAL, "heal", "pink", 300, 50);
create(typeClass.METAL, typeName.METAL, "metal", "silver", 300, 100);
create(typeClass.LASER, typeName.LASER, "laser", "yellow", 200, 70, 5);
create(typeClass.LASER, typeName.WHITEFLASH, "whiteflash", "lavender", 90, 100, 8);
create(typeClass.LASER, typeName.BEAM, "beam", "#FFEE88", 230, 100);
create(typeClass.LASER, typeName.BEAMLOGIC, "beamlogic", "#FFEE88", 230, 65, 2, 2);
create(typeClass.LASER, typeName.BEAMSIX, "beamsix", "#FFEE88", 230, 100, 6);
create(typeClass.PARAPO, typeName.PARAPO, "parapo", "#B08040", 300, 100);
create(typeClass.WEAKNESS, typeName.HITSHOT, "hitshot", "orange", 220, 100);
create(typeClass.DEFENSEDOWN, typeName.SAWTOOTH, "sawtooth", "cyan", 220, 100);
create(typeClass.DEFENSEDOWN, typeName.BURSTSHOT, "burstshot", "cyan", 110, 100, 3);
create(typeClass.FIRE, typeName.FIRE, "fire", "salmon", 60, 100, 5);
create(typeClass.MACHINEGUN, typeName.MACHINEGUN, "machinegun", "darkkhaki", 110, 100);
create(typeClass.UNUSED, typeName.SHIELD, "shield", "skyblue", 100, 100);



function typeNumberReturn(typeConst){
    for(var a = 0; a < typeNumber.length; a++){
        if(typeNumber[a] == typeConst)  return a;
    }
}
this.getCount = function(){
    return createCount;
};
this.getType = function(typeConst, isOption){
    if(isOption == true){
        return data[typeConst];
    } else {
        var number = typeNumberReturn(typeConst);
        return data[number];
    }
};
this.getColor = function(typeConst){
    var number = typeNumberReturn(typeConst);
    return data[number].color;
};

//--------------------------------//
}  optionbattle.type = new Type(); // 객체 생성