function Story(_name){
	var name = _name;
	var text = new Array(300);
	var textlength = 0;
	function TextLine(StringCharacter, StringTextLine1, StringTextLine2, StringTextLine3, imagenumber){
		this.character = StringCharacter;
		this.textline1 = StringTextLine1;
		this.textline2 = StringTextLine2;
		this.textline3 = StringTextLine3;
		this.imagenumber = imagenumber;
	};
	
	this.textadd = function(StringCharacter, StringTextLine1, StringTextLine2, StringTextLine3, imagenumber){
		text[textlength] = new TextLine(StringCharacter, StringTextLine1, StringTextLine2, StringTextLine3, imagenumber);
		textlength++; // 텍스트의 개수 1 추가
	};
	
	this.get_name = function(){  return name; };
	this.get_text_length = function(number){  return textlength; };
	this.get_text_character = function(number){  return text[number].character; };
	this.get_text_line1 = function(number){  return text[number].textline1; };
	this.get_text_line2 = function(number){  return text[number].textline2; };
	this.get_text_line3 = function(number){  return text[number].textline3; };
	this.get_text_imagenumber = function(number){  return text[number].imagenumber; };
}

option_battle.story[0] = new Story("...");
option_battle.story[1] = new Story("파란블루의 부탁");
option_battle.story[1].textadd("", "2110년 8월 5일", "나에게 어떤 이메일이 도착하였다.", "", 0);
option_battle.story[1].textadd("", "", "", "", 1);
option_battle.story[1].textadd("", "", "", "", 2);
option_battle.story[1].textadd("", "", "", "", 3);
option_battle.story[1].textadd("", "", "", "", 4);
option_battle.story[1].textadd("", "이메일을 본 나는, 푸른 경계면을 조사하기 위해 파란 행성으로 출발하였다.", "오랜만에 즐거운 모험이 될 것 같다. 아니면 말고.(...)", "", 4);
option_battle.story[2] = new Story("파란 행성에 도착하다.");
option_battle.story[2].textadd("", "\"여기가 파란 행성인가 보군. 왠지 썰렁하네.\"", "썰렁한 기분을 느낀 채로 파란 행성에 도착한 나는 이 행성의 지도를", "살펴보았다.", 5);
option_battle.story[2].textadd("", "", "", "", 6);
option_battle.story[2].textadd("", "\"일단 내가 가야할곳은 마을 회관이다.", "마을 회관으로 가려면 250km까지 내려간 후에, 동그라미 마을로 가야한다.\"", "", 6);
option_battle.story[2].textadd("", "\"여기는 가장 윗부분이라서 그런지 아무것도 없는것처럼 느껴진다.", "그래도 상관없다. 일단은 내려가자.\"", "", 5);
option_battle.story[2].textadd("", "그렇게 나는, 동그라미 마을이 있는 곳으로 이동했다.", "", "", 5);
option_battle.story[3] = new Story("활발한 마을 주민들(?)");
option_battle.story[3].textadd("", "동그라미들은 왜 이 탐사선이랑 계속 부딪히는거야!", "", "", 7);
option_battle.story[3].textadd("", "", "", "", 8);
option_battle.story[3].textadd("", "동그라미들은 뭐가 그렇게 즐거운지 이리 저리 뛰어놀고 있었다.", "물론 나는 계속해서 동그라미들과 충돌하고 있기 때문에, 짜증날 뿐이였다.", "", 8);
option_battle.story[3].textadd("", "\"동그라미들을 계속 밀어내고 있는데도 끝도없네.", "이러다가 여기서 한평생의 시간을 보내개 생겼군.\"", "", 8);
option_battle.story[3].textadd("동그라미들", "얏호!", "신난다!", "와!", 8);
option_battle.story[3].textadd("", "즐겁게 뛰어노는 동그라미들을 무시한 채로 나는 마을 입구 앞까지 도착하였", "다. 물론 마을이라서 그런지 이제는 색깔이 다양한 동그라미들도 나온다.", "", 9);
option_battle.story[3].textadd("", "\"과연 나는 마을 회관까지 무사히 도착할 수 있을까?\"", "", "", 9);
option_battle.story[4] = new Story("마을 회관에서의 대화");
option_battle.story[4].textadd("", "어찌저찌해서 난 겨우 마을회관에 도착할 수 있었다.", "", "", 10);
option_battle.story[4].textadd("", "", "", "", 10);
option_battle.story[4].textadd("", "마을 회관은 동그라미 마을과 다르게 조용한 곳이였다.", "동그라미들은 이 근처에서 살아가는것 같지 않았다.", "", 10);
option_battle.story[4].textadd("파란블루", "오셨는지요?", "", "", 11);
option_battle.story[4].textadd("", "그때 파란블루가 등장하였다.", "그리고 나는, 그가 보낸 이메일과 지금까지의 일에 대해 말하였다.", "", 11);
option_battle.story[4].textadd("파란블루", "그렇군요. 고생이 많으셨겠습니다.", "저희 동그라미들은 워낙 활발해서 말이죠.", "", 11);
option_battle.story[4].textadd("", "그렇게 그는 웃으면서 동그라미들에 대해 설명하였다.", "", "", 11);
option_battle.story[4].textadd("파란블루", "동그라미들은 제가 50년전 본 특이한 생명체입니다.", "이 행성에서 마을을 건설하고 살고 있는 주민들이죠.", "", 0);
option_battle.story[4].textadd("파란블루", "동그라미들의 성격은 하나같이 순수하고 착해요. 그리고 내성도 높아서", "헥미사일급의 공격을 당해도 아무런 문제가 없답니다.", "저는 어차피 갈곳이 없어서 그냥 여기서 사는거고요.", 0);
option_battle.story[4].textadd("파란블루", "그리고 저는 동그라들에게 매력을 느껴 여기서 살게 되었고,", "동그라미들을 위해 마을 회관, 아파트, 스카이랜드를 만들었죠.", "밑쪽에는 중간도시라는 마을이 있으니 한번 둘러다보세요.", 0);
option_battle.story[4].textadd("플레이어", "잠깐만요. 그렇다면 저한테 왜 이메일을 보내신 겁니까?", "푸른 경계면이 어쩌고저쩌고 하던거 같은데요?", "", 0);
option_battle.story[4].textadd("파란블루", "푸른 경계면... 그렇군요. 제가 며칠 전에 이메일을 보냈었었는데,", "그걸 당신이 받은거로군요.", "", 0);


option_battle.story[5] = new Story("타워의 여행");

