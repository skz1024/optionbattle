//배경화면, 여기에 있는 모든 객체는 이미지만 저장된다.
function Background(){ // function Background Start.
var title = {}; // 타이틀 이미지 객체 생성
title.image = new Image();  title.image.src = "image/background/title.png";
title.arrow = new Image();  title.arrow.src = "image/system/arrow.png";
title.title = new Image();  title.title.src = "image/system/title.png";
title.developer = new Image();  title.developer.src = "image/system/developer.png";
title.createdby = new Image();  title.createdby.src = "image/system/createdby.png";
title.tamsaseon = new Image();  title.tamsaseon.src = "image/system/tamsaseon.png";
title.display = function(){ //타이틀을 출력하는 함수
    ctx.drawImage(title.image, 0, 0); // 이미지 표시
    ctx.drawImage(title.title, 100, 40); // 타이틀 표시
    ctx.drawImage(title.developer, 290, 120); // 개발자 표시
    ctx.drawImage(title.arrow,350,250+(game.get_menu()*40)); // 화살표 표시
    
    ctx.fillStyle = "#004C63";  ctx.font = "20px arial";
    
    ctx.fillText("START",460,280);
    ctx.fillText("OPTION",460,320);
    ctx.fillText("TITLE THEMA",460,360);
    ctx.fillText("skz1024 blog",460,400);
    
    ctx.fillStyle = "black";
    ctx.fillText("ENTER or Z key to SELECT(선택)",50,350);
    ctx.fillText("X or ESC key to CANCEL(취소)",50,375);
    ctx.fillText("Arrow key to MOVE cursor(커서 이동)",50,400);
    
    ctx.fillStyle = "gold";
    ctx.fillText("created by skz1024",10,440);
    ctx.fillText("Ver 0.075, 2014/07/13(day)",10,465);
};

var titlethema = {}; // 타이틀 테마 객체 생성
titlethema.block = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
for(var a = 0; a < titlethema.block.length; a++)  titlethema.block[a] = [0, 0, 0];
titlethema.count = 0;

titlethema.display = function(){
	var currentTime = game.get_currenttime();
	if(currentTime == 0.00){
		titlethema.count = 0;
		titlethema.block_init();
	}
	
	if(currentTime >= 1.00 && currentTime <= 6.00){
		titlethema.block_add();
		titlethema.block_delete();
		for(var a = 0; a < 20; a++){
			var color = titlethema.block[a][2];
			if(color == 0)  continue;
			
			switch(color){
				case 1: ctx.fillStyle = "black";  break;
				case 2: ctx.fillStyle = "yellow"; break;
				case 3: ctx.fillStyle = "skyblue"; break;
				case 4: ctx.fillStyle = "green"; break;
				case 5: ctx.fillStyle = "blue"; break;
				case 6: ctx.fillStyle = "brown"; break;
				case 7: ctx.fillStyle = "orange"; break;
				case 8: ctx.fillStyle = "pink"; break;
				case 9:	ctx.fillStyle = "grey"; break;
			}
			
			var x = titlethema.block[a][0];
			var y = titlethema.block[a][1];
			ctx.fillRect(x, y, 10, 10);
			
			titlethema.block[a][0] -= titlethema.block[a][2] * 5;
			
			titlethema.count++;
			var timecount = (titlethema.count/100) | 0;
			if(timecount > 35)  timecount = 35;
			if(timecount > 25)  ctx.drawImage(title.createdby, 0, 0, (timecount-25)*20, 70, 300, 200, (timecount-25)*20, 70 );
		}
	} else if(currentTime >= 6.00 && currentTime <= 15.00){
		ctx.drawImage(title.image, 0, 0);
		if(currentTime == 6.02){
			titlethema.count = 0;
		}
		
		titlethema.count++;
		ctx.drawImage(title.tamsaseon, titlethema.count*4, 240);
		
		if(currentTime == 10.00){
			titlethema.count = 0;
		}
		if(currentTime >= 10.00 && currentTime <= 13.70){
			ctx.drawImage(title.title, 100, titlethema.count-150);
		} else if(currentTime >= 13.70){
			ctx.drawImage(title.title, 100, 40);
		}
	}
};
titlethema.block_add = function(){
	for(var a = 0; a < 20; a++){
		if(titlethema.block[a][2] != 0)  continue; // 블럭의 2번 정보가 0인경우 패스
		
		titlethema.block[a][0] = 640;
		titlethema.block[a][1] = Math.random() * 480 | 0;
		titlethema.block[a][2] = Math.random() * 10 | 0;
	}
};
titlethema.block_delete = function(){
	for(var a = 0; a < 20; a++){
		if(titlethema.block[a][0] <= 0){
			titlethema.block[a][2] = 0;
		}
	}
};
titlethema.block_init = function(){
	for(var a = 0; a < 20; a++){
		titlethema.block[a][0] = 0;
		titlethema.block[a][1] = 0;
		titlethema.block[a][2] = 0;
	}
};


var option = {};
option.display = function(){ // 옵션화면을 출력하는 함수
    ctx.drawImage(title.image, 0,0); // 이미지 표시(title과 같음)
    ctx.drawImage(title.title, 100,40); // 타이틀 표시(title과 같음)
    ctx.drawImage(title.arrow, 150, 190+(game.get_select()*40) ); // 화살표 표시(title과 같음)
    
    ctx.fillStyle = "#004C63";  ctx.font = "20px arial";
    ctx.fillText("SOUND : "+game.get_soundOn(),250,220);
    ctx.fillText("MUSIC : "+game.get_musicOn(),250,260);
    ctx.fillText("SOUND TEST : "+game.get_soundNumber(),250,300);
    ctx.fillText("SOUND EFFECT : ...",250,340);
    ctx.fillText("MUSIC TEST : "+game.get_musicNumber(),250,380);
    ctx.fillText("EXIT",250,420);
};

var main = {}; // 메인 이미지 객체 생성
main.image = new Image();  main.image.src = "image/background/main.png";
main.exp_meter = new Image();  main.exp_meter.src = "image/system/user_exp.png";
main.fuel_meter = new Image();  main.fuel_meter.src = "image/system/user_fuel.png";
main.arrow = new Image();  main.arrow.src = "image/system/arrow2.png";
main.user_status = new Image();  main.user_status.src = "image/system/user_status.png";
main.menu = new Image();  main.menu.src = "image/system/menu.png";
main.keyhelp = new Image();  main.keyhelp.src = "image/system/keyhelp.png";
main.display = function(){
    var exp_percent = (user.get_exp() / user.get_exptable(user.get_lv()) );
    var fuel_percent = (user.get_fuel() / user.get_fuelmax() );
    
    ctx.drawImage(main.image,0,0); // 메인 이미지 출력
    ctx.drawImage(main.user_status,0,0); // 유저 스테더스 출력
    if(exp_percent > 0)  ctx.drawImage(main.exp_meter, 0, 0, (exp_percent*300), 25, 6, 61, (exp_percent*300), 25); // 경험치 미터 출력 
    if(fuel_percent > 0)  ctx.drawImage(main.fuel_meter, 0, 0, (fuel_percent*300), 25, 328, 61, (fuel_percent*300), 25); // 연료 미터 출력
    ctx.drawImage(main.keyhelp,400, 90); // 키 도움말 출력
    ctx.drawImage(main.menu, 0, 90); // 메뉴 출력
    ctx.drawImage(main.arrow, 140, 150+(game.get_menu()*30) ); // 화살표 출력
    
    ctx.font = "24px arial";
    ctx.fillStyle = "black";  ctx.fillText(user.get_lv(),75,25); // 레벨 출력
    ctx.fillStyle = "black";  ctx.fillText(user.get_exp()+" / "+user.get_exptable(user.get_lv()),75,55); // 경험치 표시
    ctx.fillStyle = "gold";  ctx.fillText(user.get_gold(),420,25); // 골드 표시
    ctx.fillStyle = "#48D1CC";  ctx.fillText(user.get_fuel()+" / "+user.get_fuelmax(),420,55); // 연료 표시
    ctx.fillStyle = "pink";  ctx.fillText(user.get_crystal(),587,25); // 크리스탈 표시
    
    ctx.fillStyle = "black";  ctx.font = "18px arial";
    ctx.fillText("메뉴 선택(menu select)", 10, 120);
    ctx.fillText("---------------------", 10, 150);
    ctx.fillText("던전(dungeon)",10,180);
    ctx.fillText("파티(party)",10,210);
    ctx.fillText("스토리(story)", 10, 240);
    ctx.fillText("조합(combination)",10,270);
    ctx.fillText("인벤토리(inventory)",10,300);
    ctx.fillText("상점(shop)",10,330);
    ctx.fillText("종료(exit)",10,360);
    
    ctx.fillText("인벤토리에서 판매 또는",5,410);
    ctx.fillText("유닛 강화가 가능합니다",5,440);
};

var party = {}; // 파티 이미지 표시하는 객체 생성
party.image = new Image();  party.image.src = "image/background/main.png";
party.party = new Image();  party.party.src = "image/background/party.png";
party.select = new Image();  party.select.src = "image/system/select.png";
party.display = function(){
    ctx.drawImage(party.image,0,0); // 파티 이미지 출력
    ctx.drawImage(party.party,0,0); // 파티 파티 출력(정확하게는 파티.파티 이미지)
    var select = game.get_select_teamunit(); // 팀유닛 선택
    var unithp = 0, userhp = user.get_hp(user.get_lv()), totalhp = 0;
    
    for(var a = 0; a < 12; a++){
        var team = user.teamunit_data(a),  data = user.inventory_data(team);
        var code = data[invenconst.code],  lv = data[invenconst.lv];
        
        unithp += option_battle.unit[code].get_hp(lv);
        option_battle.unit[code].display((64*[a%3])+80,(64*[Math.floor(a/3)])+120);
    }
    ctx.drawImage(party.select, (64*(select%3))+75, (64*Math.floor(select/3))+115);
    ctx.font = "24px arial";  ctx.fillStyle = "black";  totalhp = unithp + userhp;
    ctx.fillText("TOTAL HP : " + unithp + " + " + userhp + " = " + totalhp, 50, 420);
};

var shop = {}; // 상점(현질용) 이미지 표시하는 객체 생성
shop.image = new Image();  shop.image.src = "image/background/shop.png";
shop.display = function(){  ctx.drawImage(shop.image,0,0); };

var inventory = {}; // 인벤토리 이미지 객체 생성
inventory.image = new Image();  inventory.image.src = "image/background/main.png";
inventory.select = new Image();  inventory.select.src = "image/system/select.png";
inventory.inventory = new Image();  inventory.inventory.src = "image/system/inventory.png";
inventory.display = function(){
    ctx.drawImage(inventory.image,0,0); // 이미지 출력
    ctx.drawImage(inventory.inventory,0,0); // 인벤토리 이미지 출력
    ctx.fillStyle = "black";  ctx.font = "18px arial";
    ctx.fillText(game.get_select(), 260, 45); // 현재 선택한 번호를 출력
    
    var cursor = game.get_select() % 50;
    var start = Math.floor(game.get_select()/50) * 50;
    var page = (start / 50) + 1;
    ctx.fillText(page + " / " + user.get_inventory_maxcount() / 50, 150, 70); // 페이지 출력
    ctx.fillText(user.get_inventory_maxcount(), 260, 95);
    for(var a = start, b = 0; b < 50; a++, b++){
        var data = user.inventory_data(a),  code = data[invenconst.code];
        if(data[invenconst.type] == itemType.unit){
            option_battle.unit[code].display(10+((b%10)*60), 150+( Math.floor(b/10)*60) );
        }
        else if(data[invenconst.type] == itemType.item){
            option_battle.item[code].display(10+((b%10)*60), 150+( Math.floor(b/10)*60) );
        }
    }
    ctx.drawImage(inventory.select, 4+((cursor%10)*60), 145+(Math.floor(cursor/10)*60));
};

var unitview = {}; // 유닛뷰 객체 생성
unitview.image = new Image();  unitview.image.src = "image/background/main.png";
unitview.unitview = new Image();  unitview.unitview.src = "image/system/unitview.png";
unitview.upgrade = new Image();  unitview.upgrade.src = "image/system/upgrade.png";
unitview.back = new Image();  unitview.back.src = "image/system/back.png";
unitview.sell = new Image();  unitview.sell.src = "image/system/sell.png";
unitview.button = new Image();  unitview.button.src = "image/system/button.png";
unitview.display = function(){
    ctx.drawImage(unitview.image,0,0);
    ctx.drawImage(unitview.unitview,0,0);
    ctx.drawImage(unitview.back,10,390);
    ctx.drawImage(unitview.upgrade,130,390);
    ctx.drawImage(unitview.sell,250,390);
    ctx.drawImage(unitview.button,10+(game.get_menu()*120),390);
    
    ctx.font = "18px arial";
    var data = user.inventory_data(game.get_select()),  code = data[invenconst.code];
    var rank = data[invenconst.rank],  lv = data[invenconst.lv];
    if(data[invenconst.type] == itemType.unit){
        ctx.fillStyle = "#0C0200";  ctx.fillRect(240,100,380,280);
        option_battle.unit[code].display(20,100,192,192);
        
        ctx.fillStyle = "orange";  ctx.fillText("NAME : "+option_battle.unit[code].get_name(), 250, 130);
        ctx.fillStyle = "skyblue";  ctx.fillText("TYPE : "+option_battle.unit[code].get_type_name(),250,160);
        ctx.fillStyle = "pink";  ctx.fillText("HP : "+option_battle.unit[code].get_hp(lv), 450, 160);
        ctx.fillStyle = "#6B9900";  ctx.fillText("LV : "+lv+" / "+option_battle.unit[code].get_maxlv(), 250, 190);
        ctx.fillText("RANK : "+option_battle.unit[code].get_rank(),450,190);

        ctx.fillStyle = "#A84E19";  ctx.fillText("ATTACK : "+option_battle.unit[code].get_attack(lv),250,220);
        ctx.fillStyle = "#FFBA85";  ctx.fillText("DELAY : "+option_battle.unit[code].get_delay(), 450, 220);
        
        ctx.fillStyle = "#E0B94F";  
        ctx.fillText("ATTACK2 : "+option_battle.unit[code].get_attack(lv, 1), 250, 250);
        ctx.fillText("DELAY : "+option_battle.unit[code].get_delay(1), 450, 250);
        ctx.fillText("ATTACK3 : "+option_battle.unit[code].get_attack(lv, 2), 250, 280);
        ctx.fillText("DELAY : "+option_battle.unit[code].get_delay(2), 450, 280);
        
        ctx.fillStyle = "#C0E783";
        ctx.fillText("TECHNICAL : "+option_battle.unit[code].get_technical(), 250, 310);
        ctx.fillText("SKILL : "+option_battle.unit[code].get_skill(), 250, 340);
        
        ctx.fillStyle = "white";
        ctx.fillText("UPGRADE COST(강화 비용) : ", 250, 370);
        ctx.fillText(game.get_unit_upgrade_gold(lv), 500, 370);
    }
    else if(data[invenconst.type] == itemType.item){
        var name = option_battle.item[code].stat_name();
        option_battle.item[code].display(20,100,192,192);
        ctx.fillStyle = "darkgreen";  ctx.fillText(name,10,320);
    }
    else if(data[invenconst.type] == itemType.upgrade){
        //var name = option_battle.upgrade[code].stat_name();
        //option_battle.item[code].display(20,100,192,192);
        //ctx.fillStyle = "darkgreen";
        //ctx.fillText(name,10,320);
    }
};

var dungeon = {};
dungeon.image = new Image();  dungeon.image.src = "image/background/main.png";
dungeon.select = new Image();  dungeon.select.src = "image/system/arrow2.png";
dungeon.menu = new Image();  dungeon.menu.src = "image/system/menu.png";
dungeon.clear = new Image();  dungeon.clear.src = "image/system/clear.png";
dungeon.new = new Image();  dungeon.new.src = "image/system/new.png";
dungeon.display = function(){
    main.display();
    ctx.clearRect(0, 120, 196, 360);
    ctx.drawImage(dungeon.menu, 0, 90);
    ctx.drawImage(dungeon.select, 150, 150+(30*game.get_menu()) );
    ctx.fillText("던전 선택(dungeon select)", 10, 120);
    ctx.fillText("---------------", 10, 150);
    ctx.fillText("뒤로가기(back)", 10, 180);
    for(var a = 1; a < 2; a++){
        ctx.fillText(option_battle.dungeon[1].get_name(), 10, 180+(30*a));
    }
};

var round = {};
round.display = function(){
    main.display();
    ctx.clearRect(0, 120, 196, 360);
    ctx.drawImage(dungeon.menu, 0, 90);
    if(game.get_select() <= 9){  ctx.fillText("뒤로가기(back)", 10, 120);  }
    else  ctx.fillText("△△△△△△△△", 10, 120);
    
    ctx.drawImage(dungeon.select, 150, 120+(30*(game.get_select()%10) ) );
    var start = (game.get_select()/10 | 0) * 10;
    var end = option_battle.dungeon[game.get_menu()].get_roundcount();
    for(var a = start, b = 0; b < 10 && a <= end; a++, b++){
        ctx.fillText(a+ " : "+option_battle.dungeon[game.get_menu()].get_round_name(a), 10, 150+(30*b));
        var clear = user.get_round_clear(game.get_menu(), a);
        var open = user.get_round_open(game.get_menu(), a);
        
        if(clear == true){ ctx.drawImage(dungeon.clear, 180, 140+(30*b) ); }
        if(clear == false && open == true){  ctx.drawImage(dungeon.new, 180, 140+(30*b) );}
        if(open == false){ ctx.strokeRect(10, 145+(30*b), 200, 1); }
    }
    if(end >= a+10){
        ctx.fillText("▽▽▽▽▽▽▽▽", 10, 450);
    }
};

var loading = {};
loading.image = new Image();  loading.image.src = "image/background/loading.png";
loading.display = function(){ ctx.drawImage(this.image,0,0); };

var round_1 = {};
round_1.image1_1 = new Image();  round_1.image1_1.src = "image/background/round1_image1.png";
round_1.image1_2 = new Image();  round_1.image1_2.src = "image/background/round1_image2.png";
round_1.image1_3 = new Image();  round_1.image1_3.src = "image/background/round1_image3.png";
round_1.image1_4 = new Image();  round_1.image1_4.src = "image/background/round1_image4.png";
round_1.image1_5 = new Image();  round_1.image1_5.src = "image/background/round1_image5.png";
round_1.image1_6 = new Image();  round_1.image1_6.src = "image/background/round1_image6.png";
round_1.image1_7 = new Image();  round_1.image1_7.src = "image/background/round1_image7.png";
round_1.image1_8 = new Image();  round_1.image1_8.src = "image/background/round1_image8.png";
round_1.display = function(roundNumber, stringInputOption){
    var imageX = 0;
    var imageY = 0;
    switch(roundNumber){
        case 0: case 1: case 2: case 3: case 4: case 5: ctx.drawImage(round_1.image1_1,imageX,imageY,640,480,0,0,640,480); break;
        case 6: case 7: ctx.drawImage(round_1.image1_2,imageX,imageY,640,480,0,0,640,480); break;
        case 8: case 9: ctx.drawImage(round_1.image1_3,imageX,imageY,640,480,0,0,640,480); break;
        case 10: case 11: case 12: ctx.drawImage(round_1.image1_4,imageX,imageY,640,480,0,0,640,480); break;
        case 13: case 14: case 15: case 16: ctx.drawImage(round_1.image1_5,imageX,imageY,640,480,0,0,640,480); break;
    	case 17: case 18: ctx.drawImage(round_1.image1_6,imageX,imageY,640,480,0,0,640,480); break;
    }
};

var story = {};
story.new = new Image();  story.new.src = "image/system/new.png";
story.display = function(){
	main.display();
    ctx.clearRect(0, 120, 196, 360);
    ctx.drawImage(dungeon.menu, 0, 90);
    ctx.drawImage(dungeon.select, 150, 150+(30*game.get_menu()) );
    ctx.fillText("스토리 선택(story select)", 10, 120);
    ctx.fillText("---------------", 10, 150);
    ctx.fillText("뒤로가기(back)", 10, 180);
    for(var a = 1; a < 5; a++){
        ctx.fillText(option_battle.story[a].get_name(), 10, 180+(30*a));
        var isNew = user.get_storyread(a);
        if(isNew == true)  ctx.drawImage(story.new, 180, 170+(30*a));
    }
};

var storyview = {};
storyview.image = new Array(12);
for(var a = 0; a < storyview.image.length; a++){
	storyview.image[a] = new Image();
	storyview.image[a].src = "image/story/image[" + a + "].png";
}
storyview.display = function(){
	var menu = game.get_menu();
	var page = game.get_page();
	
	var character = option_battle.story[menu].get_text_character(page);
	var textline1 = option_battle.story[menu].get_text_line1(page);
	var textline2 = option_battle.story[menu].get_text_line2(page);
	var textline3 = option_battle.story[menu].get_text_line3(page);
	var imagenumber = option_battle.story[menu].get_text_imagenumber(page);

	ctx.drawImage(storyview.image[imagenumber], 0, 0);
	if(character != ""){
		ctx.fillStyle = "darkblue";
		ctx.fillRect(0, 340, 320, 30);
		ctx.fillStyle = "yellow";
		ctx.fillText(character, 30, 360);
	}
	
	if(textline1 == "" && textline2 == "" && textline3 == ""){
		//이미지만 출력...
	} else {
		ctx.fillStyle = "#D8D8D8";
		ctx.fillRect(0, 370, 640, 90);
		ctx.fillStyle = "black";
		ctx.font = "18px arial";
		ctx.fillText(textline1, 30, 400);
		ctx.fillText(textline2, 30, 425);
		ctx.fillText(textline3, 30, 450);
	}
};

//배경화면을 지우는 함수, 1frame당 전부 지우고 계속해서 다시 그린다.
function display_clear(){ ctx.clearRect(0, 0, 640, 480); }
this.display_clear = function(){ ctx.clearRect(0, 0, 640, 480); };

this.display = function(constNumber_modeName){
    switch(constNumber_modeName){
        case modeName.main: main.display(); break;
        case modeName.option: option.display(); break;
        case modeName.dungeon: dungeon.display(); break;
        case modeName.title: title.display(); break;
        case modeName.shop: shop.display(); break;
        case modeName.inventory: inventory.display(); break;
        case modeName.round: round.display(); break;
        case modeName.loading: loading.display(); break;
        case modeName.unitview: unitview.display(); break;
        case modeName.party: party.display(); break;
        case modeName.round_1: round_1.display(field.get_round_number()); break;
        case modeName.story: story.display(); break;
        case modeName.storyview: storyview.display(); break;
        case modeName.titlethema: titlethema.display(); break;
    }
};

//-------------------------//
}// function Background end;

var background = new Background();