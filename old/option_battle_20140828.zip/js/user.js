//객체 상수 정의
var invenconst = { type:0, code:1, lv:2, rank:3, teamunit:4 };

// MENU유저관련처리
function User(stringName)
{
    const NO_TEAMDATA = -1; // 팀유닛 관련 데이터가 없다는 의미. 상수로 사용한다.
    var name = stringName; // 유저의 이름, 생성될 때 선언
    var lv = 1, maxlv = 10, exp = 0; // 레벨, 최대레벨, 경험치
    var fuel = 1000, fuelmax = 1000; // 연료, 연료최대치
    var gold = 100000, crystal = 10; // 골드(게임머니), 크리스탈(현질...)
    var exptable = [0, 181100, 181200, 181300, 181400, 181500, 181600, 181700, 181800, 181900, 182000,
    /*경험치 테이블▲*/	255500, 256000, 256500, 257000, 257500, 258000, 258500, 259000, 259500, 260000,
                    361200, 362400, 363600, 364800, 366000, 367200, 368400, 369600, 370800, 372000];
    var hptable = [0, 30000, 30500, 31000, 31500, 32000, 32550, 33100, 33650, 34200, 34750, 
    /*체력 테이블▲*/	35400, 36000, 36600, 37200, 37800, 38400, 39000, 39600, 40200, 41000,
                    41700, 42800, 43500, 44200, 44900, 45600, 46300, 47000, 47700, 48400];
    var teamunit = new Array(12); // 팀유닛 배열 생성, 사용하지 않는 팀유닛은 -1로 처리한다. 이 배열에 저장되는 정보는 인벤토리 번호뿐이다.
    for(var a = 0, L = teamunit.length; a < L; a++)  teamunit[a] = NO_TEAMDATA; // 팀유닛을 -1로 초기화
    var inventory = new Array(1000); // 인벤토리 배열 생성
    var inventoryMax = inventory.length;
    for(var a = 0, L = inventory.length; a < L; a++)  inventory[a] = [itemType.nodata,0,0,0,NO_TEAMDATA]; // 2차원 배열로 처리
    var inventoryUseCount = 0; // 인벤토리를 사용하는 카운트
    
    var CLEAR = 0,  OPEN = 1,  NEW = 2;
    var round = new Array(10); // 클리어에 관한 변수 생성
	round[0] = false; // ...(던전 0번에 대한 정보는 없으므로 의미 없음.)
	round[1] = new Array(144); // 던전 1번에 대한 클리어 관련 정보
	for(var a = 0, L = round[1].length; a < L; a++){  
		round[1][a] = [false, false, false];
	}
	round[1][0][OPEN] = true; // 첫번째 라운드 오픈 허용
	
	var storyread = new Array(100); // 스토리를 읽었는지 판단하는 변수
	for(var a = 0, L = storyread.length; a < L; a++){
		storyread[a] = true;
	}
	
	this.round_open = function(dungeonNumber, roundNumber){  round[dungeonNumber][roundNumber][OPEN] = true; };
	this.round_clear = function(dungeonNumber, roundNumber){  round[dungeonNumber][roundNumber][CLEAR] = true; };
    this.round_lock = function(dungeonNumber, roundNumber){  round[dungeonNumber][roundNumber][OPEN] = false; };
    this.story_read = function(storyNumber){  storyread[storyNumber] = false; };
    
    //각 스탯들을 리턴하는 함수는 get 메서드에 정의한다.
    this.get_name = function(){  return name; };
    this.get_lv = function(){  return lv; };
    this.get_maxlv = function(){  return maxlv; };
    this.get_exp = function(){  return exp; };
    this.get_fuel = function(){  return fuel; };
    this.get_fuelmax = function(){  return fuelmax; };
    this.get_crystal = function(){  return crystal; };
    this.get_gold = function(){  return gold; };
    this.get_exptable = function(lv){  return exptable[lv]; };
    this.get_hp = function(lv){  return hptable[lv]; };
    this.get_round_clear = function(dungeonNumber, roundNumber){  return round[dungeonNumber][roundNumber][CLEAR]; };
    this.get_round_open = function(dungeonNumber, roundNumber){  return round[dungeonNumber][roundNumber][OPEN]; };
    this.get_storyread = function(storyNumber){  return storyread[storyNumber]; };
    this.get_inventory_maxcount = function(){  return inventoryMax; };
	
	//각 스탯들의 능력치를 추가하거나 감소하거나 변경하는 함수들
	//plus : 더하기(증가), minus : 빼기(감소), change : 변경
    this.plus_gold = function(value){  gold += value; };
    this.minus_gold = function(value){  gold -= value; };
    this.change_gold = function(value){  gold = value; };
    this.plus_fuel = function(value){  fuel += value;  if(fuel >= fuelmax) fuel = fuelmax; };
    this.minus_fuel = function(value){  fuel -= value;  if(fuel <= 0)  fuel = 0;  };
    this.plus_crystal = function(value){  crystal += value; };
    this.minus_crystal = function(value){  crystal -= value; };
    this.plus_exp = function(value){ // 경험치 추가 함수(감소함수는 없음)
    	exp += value;
    	if(exp >= exptable[lv]){ // 경험치 초과되는지 체크
    		for(;;){ // 초과가 될경우
    			if( lv >= maxlv && exp >= exptable[lv]){ lv = maxlv;  exp = exptable[lv];  break; }
    			else if( exp <= exptable[lv] )  break;
    			else{  exp -= exptable[lv];  lv++;  }
    		}
    	}
    };
    
    //팀유닛 설정 함수
    this.teamunit_setting = function(lineNumber, inventoryNumber){
		var L = lineNumber;
		var N = inventoryNumber;
		var Is = false; // 유닛이 이미 편성되어 있는가를 표시하는 표시하는 변수
		for(var a = 0, length = teamunit.length; a < length; a++){
			if(teamunit[a] == inventoryNumber)  Is = true; // 유닛이 편성되어있을경우 true로 한다.
		}
		
		// 유닛이 편성되어있지 않을경우 그리고 인벤토리 번호의 타입이 unit일경우 유닛 편성
		if(inventory[N][invenconst.type] == itemType.unit && Is == false){
			var invenLv = inventory[N][invenconst.lv];
			var invenCode = inventory[N][invenconst.code];
			
			teamunit[L] = inventoryNumber;
			inventory[N][invenconst.teamunit] = lineNumber;
			return true; // 유닛이 제대로 편성됨, 이 값은 특수한 경우에 사용
		} else if(Is == true) {
			sound_play(soundName.system_notice);
			alert("해당 유닛은 이미 편성되어 있습니다.");
			return false; // 유닛이 편성되지 않음, 이 값은 특수한 경우에 사용
		}
	};
	//팀 유닛 삭제 함수
	this.teamunit_delete = function(lineNumber){
		var N = teamunit[lineNumber]; // 인벤토리랑 연결되어있는 팀 유닛 번호 획득
		if(N == NO_TEAMDATA)  return;  // 팀유닛의 정보가 -1일경우 함수 종료.
		inventory[N][invenconst.teamunit] = NO_TEAMDATA; // 인벤토리에 있는 팀유닛 정보 삭제
		teamunit[lineNumber] = NO_TEAMDATA; // 팀유닛 정보 삭제
	};
	//팀 유닛 데이터를 얻는 함수
	this.teamunit_data = function(lineNumber){ 
		return teamunit[lineNumber];
	};
	
	//인벤토리 추가 함수
	this.inventory_add = function(constNumber_itemType, code, lv, rank){
		var U = inventoryUseCount;
		if(U == inventory.length){ // 인벤토리 최대한도(배열 길이)가 넘어갈경우 알림과 함께 false을 리턴
			sound_play(soundName.system_notice);
			alert("배열의 한도(1000)가 초과하여  더이상 인벤토리에 아이템을 추가할 수 없습니다.");
			return false; // 아이템 추가 실패
		}
		
		inventory[U][invenconst.type] = constNumber_itemType;
		inventory[U][invenconst.code] = code;
		inventory[U][invenconst.lv] = lv;
		inventory[U][invenconst.rank] = rank;
		inventory[U][invenconst.teamunit] = NO_TEAMDATA;
		inventoryUseCount++;
	};
	this.inventory_delete = function(inventoryNumber){
		var N = inventoryNumber;
		//팀유닛이 있을경우 인벤토리에 해당하는 부분을 삭제할 수 없음.
		if(inventory[N][invenconst.teamunit] != NO_TEAMDATA){
			sound_play(soundName.system_notice);
			alert("삭제하려는 유닛이 팀에 있습니다. 팀에서 유닛을 해제하신 후 삭제하시기 바랍니다.");
			return false; // 유닛 삭제 실패
		} else {
			// 인벤토리 데이터를 0으로 해서 초기화
			for(var a = 0, length = inventory[N].length; a < length; a++){ inventory[N][a] = 0; }
			inventory[N][invenconst.teamunit] = NO_TEAMDATA; // 팀유닛의 데이터도 초기화
			return true; // 유닛 삭제 성공
		}
	};
	this.inventory_clean = function(){
		// 아이템을 정렬 시작
		var progress = 0; // 몇번까지 처리 완료되었는지 표시하는 변수
		for(var a = 0, L = inventory.length; a < L; a++){ // 배열 최대길이까지 조사
			if(inventory[a][invenconst.type] != itemType.nodata && progress == a){
				progress++; // progress 증가
				continue;  // 인벤토리 타입이 데이터가 있을경우 그리고 progress와 a가 같은경우 처리를 건너 뜀.
			} else if(inventory[a][invenconst.type] != itemType.nodata) {  // 아이템의 데이터가 있을 때
				for(var b = 0; b < 3; b++){
					inventory[progress][b] = inventory[a][b]; // 데이터 이동 : a -> progress
				}
				
				var teamNumber = inventory[a][invenconst.teamunit]; // 팀유닛의 정보를 가져옴.
				if(teamNumber != 0){ // 팀유닛의 정보가 있을경우
					this.teamunit_delete(teamNumber); // 팀유닛 삭제
					this.teamunit_setting(teamNumber, progress); // 팀유닛 다시 재설정(데이터 복사...)
				}
				// 팀유닛 정보 데이터 이동;
				inventory[progress][invenconst.teamunit] = inventory[a][invenconst.teamunit];
				
				progress++; // 아이템이 있는 개수를 1개 증가
			}
		}
		
		// 나머지 부분 내용 삭제
		for(var a = progress, length = inventory.length; a < length; a++)  this.inventory_delete(a);
		inventoryUseCount = progress; // 인벤토리 사용 카운트 저장
	};
	this.inventory_data = function(inventoryNumber){ // 인벤토리 번호에 해당하는 데이터를 얻음
		if(inventoryNumber == -1)  return [0,0,0,0,NO_TEAMDATA]; // 잘못된 값이 올경우 아무것도 없는 값을 리턴
		else  return inventory[inventoryNumber]; // 인벤토리 데이터를 배열로 리턴
	};
	this.inventory_data_lv = function(inventoryNumber){ // 인벤토리 번호에 해당하는 데이터의 레벨을 얻음
		if(inventoryNumber == -1)  return 0;
		else  return inventory[inventoryNumber][invenconst.lv];
	};
	this.inventory_unitlvup = function(inventoryNumber){
	    if(inventory[inventoryNumber][invenconst.type] == itemType.unit){
		    var code = inventory[inventoryNumber][invenconst.code]; // 유닛의 코드값을 얻음.
		    var unit_maxlv = option_battle.unit[code].get_maxlv(); // 해당 유닛의 최대레벨값을 얻음
		    var unit_lv = inventory[inventoryNumber][invenconst.lv]; // 인벤토리의 유닛 레벨값을 얻음
		    
		    if(unit_lv < unit_maxlv){ //유닛 레벨이 최대레벨보다 낮을경우
		        inventory[inventoryNumber][invenconst.lv]++; // 레벨 증가
		    } else {
		        sound_play(soundName.system_notice);
		        alert("해당 유닛의 레벨이 최대치이기 때문에 더이상 강화를 할 수 없습니다.");
		    }
		}
	};
    
    this.autorun = function(){
        // 여기에 추가 자동실행? 작업을 진행합니다.(?)
        this.inventory_clean();
        for(var a = 0; a < 12; a++){
        	this.inventory_add(itemType.unit, a+1, 0, 1);
        	this.teamunit_setting(a, a);
        }//*/
        /*this.inventory_add(itemType.unit, 11, 0, 1);
        this.teamunit_setting(0, 0);//*/
    };  this.autorun(); // 자동실행 함수 실행
}

var user = new User("user"); // 유저란 이름을 사용하는 유저 객체 생성