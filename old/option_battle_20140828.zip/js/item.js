itemJS = {}; // itemJS객체 생성
itemJS.Item = function(number_, stringName, constNumber_itemType, lv_, rank_, imagesrc){
    var number = number_;
    var type = constNumber_itemType;
    var lv = lv_;
    var rank = rank_;
    if( constNumber_itemType == itemType.unit ){  
    	alert("해당하는것은 유닛입니다. 유닛 파일에서 만들어주십시요."); 
    	return 0; 
    }
    if(lv == null)  lv_ = 0;
    if(rank == null)  rank_ = 0;
    
    this.image = new Image();
    this.image.src = imagesrc;
    
    this.stat_number = function(){  return number; };
    this.stat_type = function(){  return type; };
    this.stat_lv = function(){  return lv; };
    this.stat_rank = function(){  return rank; };
};
itemJS.Combination = function(stringName, round_, usegold_){
    var name = stringName;
    var round = round_;
    var material = [];
    //material = ArraySize10_material;
    var usegold = usegold_;
    
    this.stat_name = function(){  return name; };
    this.stat_round = function(){  return round; };
    this.stat_material = function(index){
        if(index == null)  return material;
        else if(index < 10)  return material[index];
        else return 0;
    };
    this.stat_usegold = function(){  return usegold; };
};
itemJS.Item.prototype.display = function(x, y, size_x, size_y){
	if( size_x == null || size_y == null )
        ctx.drawImage(this.image,x,y);
    else
        ctx.drawImage(this.image,x,y,size_x,size_y);
};

var itemType = { nodata:0, item:1, unit:2, upgrade:3 };
option_battle.item[0] = new itemJS.Item(0, "unused", itemType.item, 1, 1, "image/system/unused.png");
option_battle.item[1] = new itemJS.Item(1, "운석 파편", itemType.item, 1, 1, "image/item/item[1].png");
option_battle.item[2] = new itemJS.Item(2, "동그라미 파편", itemType.item, 1, 1, "image/item/item[2].png");
option_battle.item[3] = new itemJS.Item(3, "아이템3", itemType.item, 1, 1, "image/item/item[3].png");
option_battle.item[4] = new itemJS.Item(4, "아이템4", itemType.item, 1, 1, "image/item/item[4].png");

delete itemJS; //itemJS객체 삭제
