function Enemy(stringName, _number, _hp, _attack, _defense, _score, stringTechnical, stringSkill, constNumber_soundName_dieSound, stringDieMotion)//적만들기
{
	var name = stringName;
	var number = _number;
	var attack = _attack;
	var hp = _hp;
	var defense = _defense;
	var technical = stringTechnical;
	var skill = stringSkill;
	var score = _score;
	var isFirstExtendSetting = false;
	var speed_x = 10;
	var speed_y = 10;
	var speedType = "";
	var dieSound = constNumber_soundName_dieSound;
	if(dieSound == null)  dieSound = soundName.none;
	var diemotion = stringDieMotion;
	var movetype = "";
	
	this.image = new Image();
	this.image.src = "";
	
	this.get_name = function(){  return name; };
	this.get_number = function(){  return number; };
	this.get_attack = function(){  return attack; };
	this.get_hp = function(){  return hp; };
	this.get_technical = function(){  return technical; };
	this.get_skill = function(){  return skill; };
	this.get_score = function(){  return score; };
	this.get_defense = function(){  return defense; };
	this.get_speed_x = function(){  return speed_x; };
	this.get_speed_y = function(){  return speed_y; };
	this.get_speed_type = function(){  return speedType; };
	this.get_diesound = function(){  return dieSound; };
	this.get_diemotion = function(){  return diemotion; };
	
	this.speed_setting = function(_speed_x, _speed_y, _speedType){
	    speed_x = _speed_x;
	    speed_y = _speed_y;
	    speedType = _speedType;
	};
}
Enemy.prototype.display = function(x, y, width, height)
{
	if( width == null || height == null )
        ctx.drawImage(this.image, x, y);
    else
        ctx.drawImage(this.image, x, y, width, height);
};

option_battle.enemy[0] = new Enemy("unused", 0, 0, 0, 0, 0, "", "", soundName.select_none, "");
option_battle.enemy[0].image.src = "image/system/unused.png";
//-------------------------------------//
option_battle.enemy[1] = new Enemy("약한 빨간색 빛", 1, 15000, 2, 0, 100, "", "", soundName.light_break, "out");
option_battle.enemy[1].image.src = "image/enemy/enemy[1].png";
option_battle.enemy[2] = new Enemy("약한 주황색 빛", 2, 15000, 2, 0, 100, "", "", soundName.light_break, "out");
option_battle.enemy[2].image.src = "image/enemy/enemy[2].png";
option_battle.enemy[3] = new Enemy("약한 초록색 빛", 3, 15000, 2, 0, 100, "", "", soundName.light_break, "out");
option_battle.enemy[3].image.src = "image/enemy/enemy[3].png";
option_battle.enemy[4] = new Enemy("약한 파란색 빛", 4, 15000, 2, 11, 100, "", "", soundName.light_break, "out");
option_battle.enemy[4].image.src = "image/enemy/enemy[4].png";
option_battle.enemy[5] = new Enemy("약한 노란색 빛", 5, 15000, 2, 15, 100, "", "", soundName.light_break, "out");
option_battle.enemy[5].image.src = "image/enemy/enemy[5].png";
for(var a = 1; a <= 5; a++)  option_battle.enemy[a].speed_setting(11, 11, "random");
//-------------------------------------//
option_battle.enemy[6] = new Enemy("하얀색 운석", 6, 19000, 20, 20, 110, "", "", soundName.meteorite_break, "out");
option_battle.enemy[6].image.src = "image/enemy/enemy[6].png";
option_battle.enemy[7] = new Enemy("회색 운석", 7, 19000, 20, 20, 110, "", "", soundName.meteorite_break, "out");
option_battle.enemy[7].image.src = "image/enemy/enemy[7].png";
option_battle.enemy[8] = new Enemy("갈색 운석", 8, 21000, 20, 20, 117, "", "", soundName.meteorite_break, "out");
option_battle.enemy[8].image.src = "image/enemy/enemy[8].png";
option_battle.enemy[9] = new Enemy("분홍색 운석", 9, 18000, 20,35, 111, "", "", soundName.meteorite_break, "out");
option_battle.enemy[9].image.src = "image/enemy/enemy[9].png";
option_battle.enemy[10] = new Enemy("하늘색 운석", 10, 20000, 20, 35, 114, "", "", soundName.meteorite_break, "out");
option_battle.enemy[10].image.src = "image/enemy/enemy[10].png";
option_battle.enemy[11] = new Enemy("대형 운석", 11, 370000, 410, 90, 1000, "", "", soundName.meteorite_break, "out");
option_battle.enemy[11].image.src = "image/enemy/enemy[11].png";
for(var a = 6; a <= 11; a++)  option_battle.enemy[a].speed_setting(4, 4, "normal");
//-------------------------------------//
option_battle.enemy[12] = new Enemy("파란색 동그라미", 12, 28000, 50, 40, 130, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[12].image.src = "image/enemy/enemy[12].png";
option_battle.enemy[13] = new Enemy("어두운 파란색 동그라미", 13, 30892, 50, 40, 135, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[13].image.src = "image/enemy/enemy[13].png";
option_battle.enemy[14] = new Enemy("밝은 파란색 동그라미", 14, 25722, 56, 70, 133, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[14].image.src = "image/enemy/enemy[14].png";
option_battle.enemy[15] = new Enemy("하늘색 동그라미", 15, 31000, 53, 49, 135, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[15].image.src = "image/enemy/enemy[15].png";
option_battle.enemy[16] = new Enemy("어두운 하늘색 동그라미", 16, 33453, 53, 49, 139, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[16].image.src = "image/enemy/enemy[16].png";
option_battle.enemy[17] = new Enemy("밝은 하늘색 동그라미", 17, 28644, 62, 71, 137, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[17].image.src = "image/enemy/enemy[17].png";
for(var a = 12; a <= 17; a++)  option_battle.enemy[a].speed_setting(8, 8, "free");
//-------------------------------------//
option_battle.enemy[18] = new Enemy("초록색 동그라미", 18, 33000, 65, 60, 140, "", "", soundName.dongrami_fail, "fall" );
option_battle.enemy[18].image.src = "image/enemy/enemy[18].png";
option_battle.enemy[19] = new Enemy("어두운 초록색 동그라미", 19, 35660, 65, 60, 145, "", "", soundName.dongrami_fail, "fall" );
option_battle.enemy[19].image.src = "image/enemy/enemy[19].png";
option_battle.enemy[20] = new Enemy("밝은 초록색 동그라미", 20, 31171, 82, 93, 142, "", "", soundName.dongrami_fail, "fall" );
option_battle.enemy[20].image.src = "image/enemy/enemy[20].png";
option_battle.enemy[21] = new Enemy("청록색 동그라미", 21, 35000, 72, 70, 150, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[21].image.src = "image/enemy/enemy[21].png";
option_battle.enemy[22] = new Enemy("어두운 청록색 동그라미", 22, 37934, 72, 70, 158, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[22].image.src = "image/enemy/enemy[22].png";
option_battle.enemy[23] = new Enemy("밝은 청록색 동그라미", 23, 32727, 89, 94, 152, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[23].image.src = "image/enemy/enemy[23].png";
for(var a = 18; a <= 23; a++)  option_battle.enemy[a].speed_setting(6, 7, "free");
//-------------------------------------//
option_battle.enemy[24] = new Enemy("노란색 동그라미", 24, 37000, 80, 80, 160, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[24].image.src = "image/enemy/enemy[24].png";
option_battle.enemy[25] = new Enemy("어두운 노란색 동그라미", 25, 39137, 80, 80, 165, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[25].image.src = "image/enemy/enemy[25].png";
option_battle.enemy[26] = new Enemy("밝은 노란색 동그라미", 26, 34636, 103, 112, 167, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[26].image.src = "image/enemy/enemy[26].png";
option_battle.enemy[27] = new Enemy("주황색 동그라미", 27, 39000, 90, 92, 170, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[27].image.src = "image/enemy/enemy[27].png";
option_battle.enemy[28] = new Enemy("어두운 주황색 동그라미", 28, 41664, 90, 92, 177, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[28].image.src = "image/enemy/enemy[27].png";
option_battle.enemy[29] = new Enemy("밝은 주황색 동그라미", 29, 36577, 113, 114, 173, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[29].image.src = "image/enemy/enemy[27].png";
for(var a = 24; a <= 29; a++)  option_battle.enemy[a].speed_setting(5, 5, "free");
//-------------------------------------//
option_battle.enemy[30] = new Enemy("빨간색 동그라미", 30, 41000, 100, 100, 180, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[30].image.src = "image/enemy/enemy[30].png";
option_battle.enemy[31] = new Enemy("어두운 빨간색 동그라미", 31, 43693, 100, 100, 186, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[31].image.src = "image/enemy/enemy[31].png";
option_battle.enemy[32] = new Enemy("밝은 빨간색 동그라미", 32, 38729, 121, 123, 188, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[32].image.src = "image/enemy/enemy[32].png";
option_battle.enemy[33] = new Enemy("분홍색 동그라미", 33, 43000, 107, 107, 190, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[33].image.src = "image/enemy/enemy[33].png";
option_battle.enemy[34] = new Enemy("분홍색 동그라미", 34, 45585, 107, 107, 195, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[34].image.src = "image/enemy/enemy[34].png";
option_battle.enemy[35] = new Enemy("분홍색 동그라미", 35, 40278, 129, 129, 195, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[35].image.src = "image/enemy/enemy[35].png";
for(var a = 30; a <= 35; a++)  option_battle.enemy[a].speed_setting(4, 4, "free");
//-------------------------------------//
option_battle.enemy[36] = new Enemy("하얀색 동그라미", 36, 45000, 120, 120, 200, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[36].image.src = "image/enemy/enemy[36].png";
option_battle.enemy[37] = new Enemy("회색 동그라미", 37, 46824, 124, 124, 204, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[37].image.src = "image/enemy/enemy[37].png";
option_battle.enemy[38] = new Enemy("검정색 동그라미", 38, 48173, 126, 129, 211, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[38].image.src = "image/enemy/enemy[38].png";
option_battle.enemy[39] = new Enemy("파분색 동그라미", 39, 50166, 132, 137, 224, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[39].image.src = "image/enemy/enemy[39].png";
option_battle.enemy[40] = new Enemy("보초색 동그라미", 40, 51392, 141, 141, 230, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[40].image.src = "image/enemy/enemy[40].png";
option_battle.enemy[41] = new Enemy("갈노색 동그라미", 41, 52284, 155, 121, 231, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[41].image.src = "image/enemy/enemy[41].png";
for(var a = 36; a <= 41; a++)  option_battle.enemy[a].speed_setting(3, 3, "free");
//-------------------------------------//
option_battle.enemy[42] = new Enemy("대형 동그라미", 42, 477100, 592, 100, 2600, "", "", soundName.dongrami_fail, "fall");
option_battle.enemy[42].image.src = "image/enemy/enemy[42].png";
option_battle.enemy[42].speed_setting(8, 8, "normal");
option_battle.enemy[43] = new Enemy("성벽", 43, 1950000, 0, 100, 5600, "", "", soundName.wall_break, "fall");
option_battle.enemy[43].image.src = "image/enemy/enemy[43].png";
option_battle.enemy[43].speed_setting(0, 0, "stop");
option_battle.enemy[44] = new Enemy("훗(돌로만든 그림)", 44, 132100, 0, 170, 1400, "", "", soundName.wall_break, "out");
option_battle.enemy[44].image.src = "image/enemy/enemy[44].png";
option_battle.enemy[44].speed_setting(0, 0, "stop");
option_battle.enemy[45] = new Enemy("벙커", 45, 653330, 111, 50, 3300, "gunshot_attack", "", soundName.wall_break, "out");
option_battle.enemy[45].image.src = "image/enemy/enemy[45].png";
option_battle.enemy[45].speed_setting(0, 0, "stop");


option_battle.enemy[99] = new Enemy("TEST", 11, 15, 1200000, 200, 119, "", "");
option_battle.enemy[99].image.src = "image/enemy/enemy[11].png";









