var dungeonType = { story:1, sub:2, resource:3, item:4 };
function Dungeon(_number, stringName, constNumber_dungeonType, stringColor, createRoundCount){
var number = _number;
var name = stringName;
var type = constNumber_dungeonType;
var color = stringColor;
var round = new Array(createRoundCount);
var roundcount = -1;

this.get_number = function(){  return number; };
this.get_name = function(){  return name; };
this.get_type = function(){  return type; };
this.get_color = function(){  return color; };
this.get_round = function(roundNumber){  
	if(roundNumber != null)  return round[roundNumber];
	else  alert("잘못된 인수를 입력하셨습니다.");
};
this.get_roundcount = function(){  return roundcount; };

function Round(number, stringName, constNumber_musicName, nextround, time, createcount, enemymax, clearbonus){
    this.number = number;
    this.name = stringName;
    this.nextround = nextround;
    this.time = time;
    this.createcount = createcount;
    this.clearbonus = clearbonus;
    this.enemylist = [0,0,0,0,0,0,0,0,0,0];
    this.getitem = [0,0,0,0,0,0,0,0,0,0];
    this.getunit = 0;
    this.extendenemylist = [0];
    this.boss = 0;
    this.Pcount = 0;
    this.musicnumber = constNumber_musicName;
    if(enemymax >= 50){  this.enemymax = 50; }
    else  this.enemymax = enemymax;
}
this.round_create = function(number, stringName, constNumber_musicName, nextround, time, createcount, enemymax, clearbonus){
    round[number] = new Round(number, stringName, constNumber_musicName, nextround, time, createcount, enemymax, clearbonus);
    roundcount++;
};
this.round_setting = function(number, arraymax10_enemylist, arraymax10_getitem, getunit){
    round[number].enemylist = arraymax10_enemylist;
    round[number].getitem = arraymax10_getitem;
    round[number].getunit = getunit;
};
this.round_extend_enemy_setting = function(number, numberEnemycode_extendenemy, leftEnemyCount_남은_적의_수){
	var Pcount = round[number].Pcount;
	round[number].extendenemylist[Pcount] = [0,0];
	round[number].extendenemylist[Pcount][0] = numberEnemycode_extendenemy;
	round[number].extendenemylist[Pcount][1] = leftEnemyCount_남은_적의_수;
	round[number].Pcount++;
};
this.round_boss_setting = function(number, numberEnemycode_boss_보스는_1명만_가능){
	round[number].boss = numberEnemycode_boss_보스는_1명만_가능;
};
this.get_round_name = function(roundNumber){  return round[roundNumber].name; };
this.get_round_nextround = function(roundNumber){  return round[roundNumber].nextround; };
this.get_round_time = function(roundNumber){  return round[roundNumber].time; };
this.get_round_createcount = function(roundNumber){  return round[roundNumber].createcount; };
this.get_round_clearbonus = function(roundNumber){  return round[roundNumber].clearbonus; };
this.get_round_enemylist = function(roundNumber){  return round[roundNumber].enemylist; };
this.get_round_getitem = function(roundNumber){  return round[roundNumber].getitem; };
this.get_round_getunit = function(roundNumber){  return round[roundNumber].getunit; };
this.get_round_boss = function(roundNumber){  return round[roundNumber].boss; };
this.get_round_enemymax = function(roundNumber){  return round[roundNumber].enemymax; };
this.get_round_musicnumber = function(roundNumber){  return round[roundNumber].musicnumber; };
	
//------------------//
};//function Dungeon end


//던전 생성
option_battle.dungeon[0] = new Dungeon(0, "", dungeonType.sub, "black");
option_battle.dungeon[1] = new Dungeon(1, "파란 행성 PART 1", dungeonType.story, "darkblue", 100);
option_battle.dungeon[1].round_create(0, "우주 이동 경로 1", musicName.music01, 1, 120, 150, 30, 12000);
option_battle.dungeon[1].round_setting(0, [1,2,3,4,5], [1], 0);
option_battle.dungeon[1].round_create(1, "우주 이동 경로 2", musicName.music01, 2, 120, 150, 30, 12100);
option_battle.dungeon[1].round_setting(1, [1,2,3,4,5], [1], 0);
option_battle.dungeon[1].round_create(2, "우주 이동 경로 3", musicName.music01, 3, 120, 150, 30, 12200);
option_battle.dungeon[1].round_setting(2, [1,2,3,4,5], [1], 0);
option_battle.dungeon[1].round_create(3, "우주 이동 경로 4", musicName.music01, 4, 140, 120, 30, 13170);
option_battle.dungeon[1].round_setting(3, [1,2,3,4,5,6,7,8], [1], 0);
option_battle.dungeon[1].round_boss_setting(3, 11); // 보스 설정;
option_battle.dungeon[1].round_create(4, "우주 이동 경로 5", musicName.music01, 5, 140, 150, 30, 13330);
option_battle.dungeon[1].round_setting(4, [1,2,3,4,5,7,8,9], [1], 0);
option_battle.dungeon[1].round_create(5, "우주 이동 경로 6", musicName.music01, 6, 140, 150, 30, 13650);
option_battle.dungeon[1].round_setting(5, [4,5,6,7,8,9,10], [1], 0);
option_battle.dungeon[1].round_create(6, "파란행성 진입구간 1", musicName.music02, 7, 127, 112, 30, 10100);
option_battle.dungeon[1].round_setting(6, [6,7,8,9,10], [1], 0);
option_battle.dungeon[1].round_boss_setting(6, 11); // 보스 설정;
option_battle.dungeon[1].round_create(7, "파란행성 진입구간 2", musicName.music02, 8, 127, 142, 30, 10230);
option_battle.dungeon[1].round_setting(7, [6,7,8,9,10], [1], 0);
option_battle.dungeon[1].round_create(8, "상공 300km", musicName.music03, 9, 110, 70, 13, 14000);
option_battle.dungeon[1].round_setting(8, [12,13,14], [1], 0);
option_battle.dungeon[1].round_create(9, "상공 280km", musicName.music03, 10, 125, 87, 17, 14200);
option_battle.dungeon[1].round_setting(9, [12,13,14], [1], 0);
option_battle.dungeon[1].round_create(10, "상공 270km", musicName.music03, 11, 170, 155, 22, 18900);
option_battle.dungeon[1].round_setting(10, [12,13,14,15,16,17], [1], 0);
option_battle.dungeon[1].round_create(11, "상공 260km", musicName.music03, 12, 190, 170, 28, 19326);
option_battle.dungeon[1].round_setting(11, [12,13,14,15,16,17], [1], 0);
option_battle.dungeon[1].round_create(12, "상공 250km", musicName.music03, 13, 150, 135, 35, 16565);
option_battle.dungeon[1].round_setting(12, [12,13,14,15,16,17], [1], 0);
option_battle.dungeon[1].round_create(13, "동그라미 마을 입구", musicName.none, 14, 180, 220, 40, 20300);
option_battle.dungeon[1].round_setting(13, [12,13,14,15,16,17,18,19,20,21,22,23,24], [1], 0);
option_battle.dungeon[1].round_create(14, "동그라미 광장", musicName.none, 15, 240, 200, 40, 22500);
option_battle.dungeon[1].round_setting(14, [12,13,15,17,19,20,21,22,23,24,26,28,31], [1], 0);
option_battle.dungeon[1].round_create(15, "동그라미 아파트 1단지", musicName.none, 16, 110, 100, 20, 17000);
option_battle.dungeon[1].round_setting(15, [12,14,17,18,20,23,24,28], [1], 0);
option_battle.dungeon[1].round_create(16, "동그라미 아파트 2단지", musicName.none, 17, 110, 100, 20, 17000);
option_battle.dungeon[1].round_setting(16, [13,15,19,21,22,25,28,33], [1], 0);
option_battle.dungeon[1].round_create(17, "마을 회관", musicName.none, 18, 50, 1, 1, 6000);
option_battle.dungeon[1].round_setting(17, [42], [1], 0);
option_battle.dungeon[1].round_create(18, "엄청난 수의 동그라미", musicName.none, 19, 180, 120, 40, 19600);
option_battle.dungeon[1].round_setting(18, [12,14,16,18,20,22,24,26,28,30,32,34,36,38,40]);
option_battle.dungeon[1].round_boss_setting(18, 42);


