// 모든 유닛(unit)은 이 함수를 이용하여 만든다.
function Unit(stringName, _number, constNumber_typeName, _rank, _maxlv, _attack, _hp, stringTechnical, stringSkill)
{
    // 여기에 있는 모든 변수들은(일부 예외 빼고) Private로 정의한다.
    var name = stringName; // 유닛의 이름
    var number = _number; // 유닛의 번호
    var type = constNumber_typeName; // 유닛의 타입(또는 속성)
    var technical = stringTechnical; // 유닛의 테크니컬 공격(아무것도 안쓰면 타입공격)
    var techshot = 0;
    var skill = stringSkill; // 유닛의 스킬
    var rank = _rank; // 유닛의 랭크
    var maxlv = _maxlv; // 유닛의 최대레벨
    var hp = _hp; // 유닛의 체력
    var mp = 0; // 유닛의 마력(정의 안하면 0)
    var attack = { normal:_attack, technical:0, skill:0 }; // 공격력
    var delay = { normal:0, technical:0, skill:0 }; // 한번 공격하는데 걸리는 시간(1 frame 단위)
    var defense = 0; // 방어력?
    
    // 이미지와 관련되어있는 변수는 Public
    this.image = new Image(); // 유닛의 이미지
    this.image.src = ""; // 유닛의 이미지 경로
    this.attackImage = { }; // 공격 이미지 객체 생성
    this.attackImage.normal = new Image();  this.attackImage.normal.src = "";
    this.attackImage.technical = new Image();  this.attackImage.technical.src = "";
    this.attackImage.skill = new Image();  this.attackImage.skill.src = "";
    
    // 스탯을 리턴하는 함수는 Public으로 정의한다.
    this.get_name = function(){  return name; };
    this.get_number = function(){  return number; };
    this.get_type_name = function(){  return option_battle.type[type].get_name(); };
    this.get_type = function(){  return type; };
    this.get_normal = function(){  return normal; };
    this.get_technical = function(){  return technical; };
    this.get_skill = function(){  return skill; };
    this.get_maxlv = function(){  return maxlv; };
    this.get_rank = function(){  return rank; };
    this.get_hp = function(lv){  
    	if(lv == null)  return hp; 
    	else  return  ( hp * 0.02 * lv + hp ) | 0; // 정수값으로 리턴;
    };
    this.get_mp = function(){  return mp; };
    this.get_attack = function(lv, stringType){
    	if(lv == "normal" || lv == "technical" || lv == "skill"){
    		stringType = lv;   lv = 0;
    	}  else if (lv == null)  lv = 0;
    	
        if(stringType == 0 || stringType == null || stringType == "normal")  returndata = attack.normal;
        else if(stringType == 1 || stringType == "technical")  returndata = attack.technical;
        else if(stringType == 2 || stringType == "skill")  returndata = attack.skill;
        return (returndata * 0.02 * lv + returndata) | 0;  // 정수값으로 리턴
    };
    this.get_delay = function(stringType){
        if(stringType == 0 || stringType == null || stringType == "normal")  return delay.normal;
        else if(stringType == 1 || stringType == "technical")  return delay.technical;
        else if(stringType == 2 || stringType == "skill")  return delay.skill;
    };
    this.get_defense = function(){  return defense; };
    this.get_color = function(){  return option_battle.type[type].get_color(); };
    this.get_techshot = function(){  return techshot; };
   
    //유닛의 스탯을 설정하는 함수(자동 실행됩니다.) 그리고 이 밑의 함수들은 Private 입니다.
    function autorun(){ // 자동실행되는 함수...
        // rankAttack : 랭크의 기준 공격력, rankStandard : 랭크의 기준 효율 : (attack / rankstandard) = delay
        var rankAttack = 0, rankStandard = 0, rankHp = 0; // 랭크와 관련된 정보 변수 생성
        switch(rank){ // 랭크에 따라서 관련 정보를 처리
        	case 0: rank = 1; // 랭크 1로 처리
        	case 1: rankAttack = 1200, rankStandard = 40, rankHp = 1000; break;
        }
        
        // 체력이 타입 기준에 맞는지 조사
        var typehp = rankHp * option_battle.type[type].get_hp(); // 체력범위의 %값을 받아옴
        if(hp >= typehp*1.2)  hp = typehp*1.2 | 0;
        else if(hp <= typehp*0.9)  hp = typehp*0.9 | 0;
        
        // 해당 타입의 맞게 유닛을 설정
        var rangemin = rankAttack * option_battle.type[type].get_rangemin(); //공격력 범위 최소치
        var rangemax = rankAttack * option_battle.type[type].get_rangemax(); //공격력 범위 최대치
        //var standard = rankStandard * option_battle.type[type].get_standard(); //공격력 효율 표준값
        var percentNormal = rankStandard * option_battle.type[type].get_normal(); //일반 공격력 효율
        var percentTechnical = rankStandard * option_battle.type[type].get_technical(); //테크니컬 공격력 효율
        var percentSkill = rankStandard * option_battle.type[type].get_skill(); //스킬 공격력 효율
        if(attack.normal >= rangemax)  attack.normal = rangemax;
        else if(attack.normal <= rangemin)  attack.normal = rangemin;
        
        delay.normal = attack.normal / percentNormal | 0; //일반공격 딜레이 설정 -> 정수로 처리
        
        // 테크니컬 관련 설정
        if(technical == ""){  // 테크니컬이 공백(없음)일 경우
        	switch(type){
        		// 테크니컬 공격력을 다음과 같이 설정.
        		case typeName.hyper: attack.technical = attack.normal * 7; break;
        		case typeName.multishot:  attack.technical = attack.normal * 1; break;
        		case typeName.direct: attack.technical = attack.normal * 2; break;
        		case typeName.heal: attack.technical = attack.normal * 1; break;
        		case typeName.metal: attack.technical = attack.normal * 1; break;
        		case typeName.laser: attack.technical = attack.normal * 0.4; break;
        		case typeName.chaincombo: attack.technical = attack.normal * 2; break;
        		case typeName.knight: attack.technical = attack.normal * 2; break;
        		case typeName.magician: attack.technical = attack.normal * 2; break;
        	}
        } else { // 테크니컬의 스킬이 존재
        	//여러발 형태로 쏘는 테크니컬일경우 techshot을 설정해야 함.
        	if(technical == "swordattack")  attack.technical = attack.normal * 4;
        	else if(technical == "전자기장")  attack.technical = attack.normal * 3;
        	else if(technical == "arrowshot_20"){  attack.technical = attack.normal * 1.5 | 0;  techshot = 20; }
        }
        if(techshot != 0)  delay.technical = (attack.technical / percentTechnical) * techshot | 0; // 여러 발 쏘는 딜레이 계산
        else if(percentTechnical != 0)  delay.technical = attack.technical / percentTechnical | 0; // 딜레이 설정
        else  delay.technical = 0;
        
        //스킬 설정
        if(skill == ""){ // 스킬이 비어있을 경우
        	switch(type){ // 해당 타입의 기본값으로 스킬 공격력 설정
        		case typeName.laser: attack.skill = attack.normal * 1.2 | 0;
        		case typeName.knight: attack.skill = attack.normal * 1.2 | 0;
        		case typeName.magician: attack.skill = attack.normal * 1.2 | 0;
        	}
        } else { // 스킬이 있을경우
        	
        }
        if(percentSkill != 0)  delay.skill = attack.skill / percentSkill | 0; // 딜레이 설정
        else  delay.skill = 0;
        
        // 공격력과 딜레이는 소수점 이하를 무조건 버림한다.
    }  autorun(); // 함수 자동실행
    //----------------------------------//
};// option_battle.unitJs.new Unit();
Unit.prototype.display = function(x, y, width, height){
    //유닛의 그림을 그립니다.
    if( width == null || height == null )  ctx.drawImage(this.image, x, y);
    else  ctx.drawImage(this.image, x, y, width, height);
};
Unit.prototype.attackdisplay = function(x, y, stringType){
	if(stringType == 0 || stringType == null || stringType == "normal"){
		ctx.drawImage(this.attackImage.normal, x, y);
	}
	else if(stringType == 1 || stringType == "technical"){
		ctx.drawImage(this.attackImage.technical, x, y);
	}
	else if(stringType == 2 || stringType == "skill"){
		ctx.drawImage(this.attackImage.skill, x, y);
	}
};


// 유닛 생성
option_battle.unit[0] = new Unit("", 0, typeName.unused, 0, 0, 0, 0, "", "");
option_battle.unit[0].image.src = "image/system/unused.png";
option_battle.unit[1] = new Unit("대포", 1, typeName.hyper, 1, 40, 2800, 1000, "", "");
option_battle.unit[1].image.src = "image/unit/unit[1].png";
option_battle.unit[1].attackImage.normal.src = "image/attack/unit[1].attack.png";
option_battle.unit[1].attackImage.technical.src = "image/attack/unit[1].technical.png";
option_battle.unit[2] = new Unit("캐논", 2, typeName.hyper, 1, 40, 3200, 1000, "", "");
option_battle.unit[2].image.src = "image/unit/unit[2].png";
option_battle.unit[2].attackImage.normal.src = "image/attack/unit[2].attack.png";
option_battle.unit[2].attackImage.technical.src = "image/attack/unit[2].technical.png";
option_battle.unit[3] = new Unit("멀티샷 장치", 3, typeName.multishot, 1, 40, 500, 1000, "", "");
option_battle.unit[3].image.src = "image/unit/unit[3].png";
option_battle.unit[3].attackImage.normal.src = "image/attack/unit[3].attack.png";
option_battle.unit[3].attackImage.technical.src = "image/attack/unit[3].technical.png";
option_battle.unit[4] = new Unit("나무 활", 4, typeName.multishot, 1, 40, 770, 1000, "arrowshot_20", "");
option_battle.unit[4].image.src = "image/unit/unit[4].png";
option_battle.unit[4].attackImage.normal.src = "image/attack/unit[4].attack.png";
option_battle.unit[4].attackImage.technical.src = "image/attack/unit[4].technical.png";
option_battle.unit[5] = new Unit("약한 검", 5, typeName.direct, 1, 40, 1700, 1000, "swordattack", "");
option_battle.unit[5].image.src = "image/unit/unit[5].png";
option_battle.unit[5].attackImage.normal.src = "image/attack/unit[5].attack.png";
option_battle.unit[5].attackImage.technical.src = "image/attack/unit[5].technical.png";
option_battle.unit[6] = new Unit("전자기장 직접장치", 6, typeName.direct, 1, 40, 1900, 1100, "전자기장", "");
option_battle.unit[6].image.src = "image/unit/unit[6].png";
option_battle.unit[6].attackImage.normal.src = "image/attack/unit[6].attack.png";
option_battle.unit[7] = new Unit("폭발물 연구원", 7, typeName.splash, 1, 40, 1768, 200, "", "");
option_battle.unit[7].image.src = "image/unit/unit[7].png";
option_battle.unit[7].attackImage.normal.src = "image/attack/unit[7].attack.png";
option_battle.unit[8] = new Unit("공구상자", 8, typeName.heal, 1, 40, 1832, 2400, "", "");
option_battle.unit[8].image.src = "image/unit/unit[8].png";
option_battle.unit[8].attackImage.normal.src = "image/attack/unit[8].attack.png";
option_battle.unit[8].attackImage.technical.src = "image/attack/unit[8].technical.png";
option_battle.unit[9] = new Unit("수레차", 9, typeName.laser, 1, 40, 3036, 700, "", "");
option_battle.unit[9].image.src = "image/unit/unit[9].png";
option_battle.unit[9].attackImage.normal.src = "image/attack/unit[9].attack.png";
option_battle.unit[9].attackImage.technical.src = "image/attack/unit[9].technical.png";
option_battle.unit[9].attackImage.skill.src = "image/attack/unit[9].skill.png";
option_battle.unit[10] = new Unit("강철-공격장치", 10, typeName.metal, 1, 40, 1098, 5000, "", "");
option_battle.unit[10].image.src = "image/unit/unit[10].png";
option_battle.unit[10].attackImage.normal.src = "image/attack/unit[10].attack.png";
option_battle.unit[10].attackImage.technical.src = "image/attack/unit[10].attack.png";
option_battle.unit[11] = new Unit("화이트플래시 장치", 11, typeName.whiteflash, 1, 40, 900, 200, "", "");
option_battle.unit[11].image.src = "image/unit/unit[11].png";
option_battle.unit[11].attackImage.normal.src = "image/attack/unit[11].attack.png";
option_battle.unit[12] = new Unit("미사일 연구원", 12, typeName.bombmissile, 1, 40, 1879, 1, "", "");
option_battle.unit[12].image.src = "image/unit/unit[12].png";
option_battle.unit[12].attackImage.normal.src = "image/attack/unit[12].attack.png";
//option_battle.unit[12].attackImage.technical.src = "image/attack/unit[12].technical.png";

