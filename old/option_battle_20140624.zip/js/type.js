var typeName = { hyper:0, multishot:1, direct:2, splash:3, heal:4, metal:5, laser:6, 
    whiteflash:7, missilebomb:8, knight:9, magician:10, chaincombo:11 };
function Type() // 해당 타입의 기준을 정의하는 함수? -> 객체로 활용(자바스크립트의 힘)
{
    var typeName = ""; // 타입 이름
    var typeHp = 0; // 타입의 기준 체력
    var typeColor = ""; // 타입의 컬러(문자열로 표기)
    var _attackRangeMin = 0; // 타입의 공격력 범위 최소치
    var _attackRangeMax = 0; // 타입의 공격력 범위 최대치
    var _attackStandard = 0; // 공격력 기준 설정값
    var _attackPercentNormal = 0; // 일반 공격력
    var _attackPercentTechnical= 0; // 테크니컬 공격력
    var _attackPercentSkill = 0; // 스킬 공격력
    
    this.attack_setting = function(attackRangeMin,attackRangeMax,attackStandard,percentNormal,percentTechnical,percentSkill)
    {
        _attackRangeMin = attackRangeMin;
        _attackRangeMax = attackRangeMax;
        _attackStandard = attackStandard;
        _attackPercentNormal = percentNormal;
        _attackPercentTechnical = percentTechnical;
        _attackPercentSkill = percentSkill;
    };
}
Type.prototype.type_setting = function(typeName,typeHp,typeColor)
{
    this.typeName = typeName;
    this.typeHp = typeHp;
    this.typeColor = typeColor;
};
Type.prototype.attack_impormation = function()
{
    console.log(this.attackStandard);
};

function TypeEx()
{
    
}
TypeEx.prototype = new Type();

var P = new TypeEx();
