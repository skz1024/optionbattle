//적만들기
var enemyCreateCount=3;
var enemyMax = 20;
var enemyCurrent=0;
function enemy_standard_total_progress()
{
    var enemyListNumber = Math.floor(Math.random() * 5);
    var roundCode = background_dungeon.roundCode;
    
    enemy_create(dungeon[roundCode].enemylist[enemyListNumber]);
    //enemy_move();
    enemy_die();
    enemy_delete();
}
function enemy_create(code)
{
    for(number=0;number<enemyMax;number++){
        if(enemyunit[number][enemyoption.on]==false && enemyunit[number][enemyoption.die]<=0 && enemyCurrent<=enemyMax && enemyCreateCount>=1 ){
            enemyunit[number][enemyoption.on] = true;
            enemyunit[number][enemyoption.x] = Math.floor(Math.random()*100)  + 500;
            enemyunit[number][enemyoption.y] = Math.floor(Math.random()*400)  + 70;
            enemyunit[number][enemyoption.code] = code;
            enemyunit[number][enemyoption.hp] = enemy[code].hp;
            enemyunit[number][enemyoption.hp_max] = enemy[code].hp;
            enemyunit[number][enemyoption.attack] = enemy[code].attack;
            enemyunit[number][enemyoption.defense] = enemy[code].defense;
            enemyunit[number][enemyoption.move_x] = 4;
            enemyunit[number][enemyoption.move_y] = 4;
            enemyCurrent++;
            enemyCreateCount--;
            break;
        }
        else{
            continue;
        }
    }
}
function boss_create(code)
{
    for(number=0;number<20;number++){
        //if(enemyunit[0][enemyoption.on]==false && enemyunit[0][enemyoption.die]<=0 )
        {
        	enemyunit[0][enemyoption.on] = 1;
            enemyunit[0][enemyoption.x] = 400;//Math.floor(Math.random()*100)  + 500;
            enemyunit[0][enemyoption.y] = 100;//Math.floor(Math.random()*400)  + 70;
            enemyunit[0][enemyoption.code] = code;
            enemyunit[0][enemyoption.hp] = enemy[code].hp;
            enemyunit[0][enemyoption.die] = 0;
            enemyunit[0][enemyoption.hp_max] = enemy[code].hp;
            enemyunit[0][enemyoption.attack] = enemy[code].attack;
            enemyunit[0][enemyoption.defense] = enemy[code].defense;
            enemyunit[0][enemyoption.move_x] = enemy[code].arrow;
            enemyunit[0][enemyoption.move_y] = enemy[code].arrow;
            enemyCurrent++;
            //enemyCreateCount--;
            break;
        }
        //else{
        //    continue;
        //}
    }
}
function enemy_move()
{
    for(number=0;number<enemyMax;number++){
      if(enemyunit[number][enemyoption.on]==true)
      {
        enemyunit[number][enemyoption.x] += enemyunit[number][enemyoption.move_x];
        enemyunit[number][enemyoption.y] += enemyunit[number][enemyoption.move_y];
        if(enemyunit[number][enemyoption.y] <= filed.size_y[0]){
        	if(enemyunit[number][enemyoption.move_y]<0){//이동 속도가 음수일경우, x좌표기준
                enemyunit[number][enemyoption.move_y] += (enemyunit[number][enemyoption.move_y]*-2);
            }
        }
        else if(enemyunit[number][enemyoption.y] >= 360){
            if(enemyunit[number][enemyoption.move_y]>0){//이동 속도가 음수일경우, x좌표기준
                enemyunit[number][enemyoption.move_y] += (enemyunit[number][enemyoption.move_y]*-2);
            }
        }
        
        
        if(enemyunit[number][enemyoption.x] <= filed.size_x[3] ) // 유저에게 적이 닿았을 때
        {
            enemyunit[number][enemyoption.move_x] -= (enemyunit[number][enemyoption.move_x]*2);
            user.hp -= enemyunit[number][enemyoption.attack];
        }
        else if(enemyunit[number][enemyoption.x] >= 600) // 일정 범위 이상
        {
            enemyunit[number][enemyoption.move_x] += (enemyunit[number][enemyoption.move_x]*-2);
        }
      }
    }
}
function enemy_delete()
{
    for(number=0;number<enemyMax;number++){
        if(enemyunit[number][enemyoption.hp] <= 0 && enemyunit[number][enemyoption.on]==true ){
            enemyunit[number][enemyoption.die] = 600;
            enemyunit[number][enemyoption.on] = false;
            
            sound_output("kill");
            enemyCurrent--;
            if(round_code==1) user.exp+=434;
            else if(round_code==2) user.exp+=678;
        }
    }
}
function enemy_die()
{
	for(number=0;number<enemyMax;number++){
		if(enemyunit[number][enemyoption.die] > 0){
			enemyunit[number][enemyoption.die]-=5;
		    enemyunit[number][enemyoption.y]+=5;
		}
	}
}