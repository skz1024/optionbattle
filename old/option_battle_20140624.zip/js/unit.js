var unit = new Array(100);
var enemy = new Array(100);
var boss = new Array(10);
var enemyunit = new Array(50);
for(a=0;a<50;a++){
    enemyunit[a] = new Array(20); // enemyunit 2차원 배열 사용
    enemyunit[a] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]; // 초기값 설정(안하면 문제가 있음.)
}
var enemyoption = { line:0, number:1, code:2, hp:3, hp_max:4, x:5, y:6, count:7, 
    delay:8, on:9, attack:10, defense:11, move_x:12, die:13, move_y:14 };
var upgradeGold = new Array(70);
upgradeGold = [0,800,810,820,830,840,850,860,870,880,890, // 레벨 0은 0의 골드가 소모됨.
        1030,1060,1090,1120,1150,1180,1210,1240,1270,1300, // 레벨 20까지
        1450,1500,1550,1600,1750,1800,1850,1900,1950,2000, // 레벨 30까지
        2070,2140,2210,2280,2350,2420,2490,2560,2630,2700]; // 레벨 40까지

//-----------------------------//
function Unit() // 유닛들은 이 클래스를 사용한다.
{
    this.name = "unknown"; // 유닛의 이름
    this.number = 0; // 유닛의 번호
    this.type = "unknown"; // 유닛의 타입(또는 속성)
    this.skill = ["","",""]; // 유닛의 스킬(직업공격보다 우선선택됨)
    this.maxlv = 1; // 유닛의 최대레벨
    this.rank = 1; // 유닛의 랭크
    this.maxrank = 1; // 유닛의 최대랭크
    this.hp = 0; // 유닛의 체력(정의 안하면 0)
    this.mp = 0; // 유닛의 마력(정의 안하면 0)
    this.delay = [0,0,0]; //각 공격에 대한 지연카운트 총 3개
    this.attack = [0,0,0]; // 유닛의 공격력(정의 안하면 0) 총 3개
    this.image = new Image(); // 유닛의 이미지
    this.image.src = ""; // 유닛의 이미지 경로
    this.attackimage = new Array(3);
    this.attackimage[0] = new Image(); // 유닛의 공격 이미지(이건 없을수도 있음)
    this.attackimage[0].src = ""; // 유닛의 공격 이미지 경로(이건 없을수도 있음)
    this.attackimage[1] = new Image(); // 유닛의 공격 2번째 이미지(이건 없을수도 있음)
    this.attackimage[1].src = ""; // 유닛의 공격 2번째 이미지 경로(이건 없을수도 있음)
    this.attackimage[2] = new Image(); // 유닛의 공격 3번째 이미지(이건 없을수도 있음)
    this.attackimage[2].src = ""; // 유닛의 공격 3번째 이미지 경로(이건 없을수도 있음)
    this.defense = 0;
    this.score = 0;
}
Unit.prototype.meter = function(x,y,width,height){
    //유닛의 체력과 마력 게이지바를 나타내나(현실은 체력만 나타냄)
    /*var hp_percent = this.hp / this.hp_max;
    var mp_percent = this.mp / this.mp_max;
	
    ctx.strokeStyle = "black";
    ctx.fillStyle = "darkgrey";
    ctx.font = "8px arial";
    ctx.fillRect(x,y,(hp_percent*width),height);
    ctx.strokeRect(x,y,width,height);
    ctx.fillStyle = "darkblue";
    ctx.fillText("HP : "+this.hp+"/"+this.hp_max, x, (y+15));
    */
};
Unit.prototype.display = function(x,y,size_x,size_y){
    //유닛의 그림을 그립니다.
    if( size_x == null || size_y == null )
        ctx.drawImage(this.image,x,y);
    else
        ctx.drawImage(this.image,x,y,size_x,size_y);
};
//-----------------------------//
enemy[0] = new Unit();
enemy[0].name = "unused";
enemy[1] = new Unit();
enemy[1].image.src = "image/enemy/enemy[1].png";
enemy_setting(1,"","",10000,0,100,0,100);
enemy[2] = new Unit();
enemy[2].image.src = "image/enemy/enemy[2].png";
enemy_setting(2,"","",11250,0,100,0,102);
enemy[3] = new Unit();
enemy[3].image.src = "image/enemy/enemy[3].png";
enemy_setting(3,"","",13200,0,100,0,106);
enemy[4] = new Unit();
enemy[4].image.src = "image/enemy/enemy[4].png";
enemy_setting(4,"","",10920,0,110,15,112);
enemy[5] = new Unit();
enemy[5].image.src = "image/enemy/enemy[4].png";
enemy_setting(5,"","",12860,0,107,70,115);

//-----------------------------//
function enemy_setting(number, name, type, hp, mp, attack, defense, score)
{
    enemy[number].name = name;
    enemy[number].type = type;
    enemy[number].hp = hp;
    enemy[number].mp = mp;
    enemy[number].attack[0] = attack;
    enemy[number].defense = defense;
    enemy[number].score = score;
}

//-----------------------------//
//참고사항
//랭크당 공격력 증가하는양은 기본값에 20%씩 증가합니다.
//랭크당 체력 증가하는양은 임의의 상수를 집어넣습니다.(내 맘대로 넣을거임!?)
//for(a=0; a<21; a++)  unit[a] = new Unit(); 임시로 만든 유닛 생성문.
unit[0] = new Unit();
unit[0].image.src = "image/system/unused.png";
unit[0].name = "unused";
unit[1] = new Unit();
unit[1].image.src = "image/unit/unit[1].png";
unit[1].attackimage[0].src = "image/attack/unit[1].attack.png";
unit[1].attackimage[1].src = "image/attack/unit[1].hyper.png";
unit_stat_setting(1,"대포","hyper","",1,4,10,1000,300,2000);
unit[2] = new Unit();
unit[2].image.src = "image/unit/unit[2].png";
unit[2].attackimage[0].src = "image/attack/unit[2].attack.png";
unit[2].attackimage[1].src = "image/attack/unit[2].hyper.png";
unit_stat_setting(2,"캐논","hyper","",1,4,10,1000,300,2800);
unit[3] = new Unit();
unit[3].image.src = "image/unit/unit[3].png";
unit[3].attackimage[0].src = "image/attack/unit[3].attack.png";
unit[3].attackimage[1].src = "image/attack/unit[3].multishot.png";
unit_stat_setting(3,"멀티샷","multishot","",1,4,10,1000,300,450);
unit[4] = new Unit();
unit[4].image.src = "image/unit/unit[4].png";
unit[4].attackimage[0].src = "image/attack/unit[4].attack.png";
unit[4].attackimage[1].src = "image/attack/unit[4].headshot.png";
unit_stat_setting(4,"총","multishot","headshot",1,4,10,1000,300,550);
unit[5] = new Unit();
unit[5].image.src = "image/unit/unit[5].png";
unit[5].attackimage[0].src = "image/attack/unit[5].attack.png";
unit_stat_setting(5,"힘력","etc","buff_powerup",1,4,10,1000,300,18179);
unit[6] = new Unit();
unit[6].image.src = "image/unit/unit[6].png";
unit[6].attackimage[0].src = "image/attack/unit[6].attack.png";
unit[6].attackimage[1].src = "image/attack/unit[6].laserA.png";
unit[6].attackimage[2].src = "image/attack/unit[6].laserB.png";
unit_stat_setting(6,"수레차","special","laserABC",1,4,20,4128,892,3298);
unit[7] = new Unit();
unit[7].image.src = "image/unit/unit[7].png";
unit[7].attackimage[0].src = "image/attack/unit[7].attack.png";
unit[7].attackimage[1].src = "image/attack/unit[7].highattack.png";
unit_stat_setting(7,"스워드검","direct","highattack",1,4,10,1000,300,2100);
unit[8] = new Unit();
unit[8].image.src = "image/unit/unit[8].png";
unit[8].attackimage[0].src = "image/attack/unit[8].attack.png";
unit[8].attackimage[1].src = "image/attack/unit[8].multishot.png";
unit_stat_setting(8,"보우활","multishot","multishot_arrow",1,4,10,1000,300,480);
unit[9] = new Unit();
unit[9].image.src = "image/unit/unit[9].png";
unit[9].attackimage[0].src = "image/attack/unit[9].attack.png";
unit[9].attackimage[1].src = "image/attack/unit[9].attack2.png";
unit_stat_setting(9,"공구상자","heal","",1,4,10,1600,500,800);
unit[10] = new Unit();
unit[10].image.src = "image/unit/unit[10].png";
unit[10].attackimage[0].src = "image/attack/unit[10].attack.png";
unit_stat_setting(10,"구급상자","heal","",1,4,10,1600,500,800);
unit[11] = new Unit();
unit[11].image.src = "image/unit/unit[11].png";
unit[11].attackimage[0].src = "image/attack/unit[11].attack.png";
unit_stat_setting(11,"연구원","splash","",1,4,15,600,120,1814);
unit[12] = new Unit();
unit[12].image.src = "image/unit/unit[12].png";
unit[12].attackimage[0].src = "image/attack/unit[12].attack.png";
unit_stat_setting(12,"조종자","splash","",1,4,15,600,120,2078);
unit[13] = new Unit();
unit[13].image.src = "image/unit/unit[13].png";
unit[13].attackimage[0].src = "image/attack/unit[13].attack.png";
unit_stat_setting(13,"빨간색_동그라미","splash","",1,4,15,600,120,1966);
unit[14] = new Unit();
unit[14].image.src = "image/unit/unit[14].png";
unit[14].attackimage[0].src = "image/attack/unit[14].attack.png";
unit[14].attackimage[1].src = "image/attack/unit[14].hyper.png";
unit_stat_setting(14,"갈색_동그라미","hyper","",1,4,10,1000,300,2800);
unit[15] = new Unit();
unit[15].image.src = "image/unit/unit[15].png";
unit[15].attackimage[0].src = "image/attack/unit[15].attack.png";
unit[15].attackimage[1].src = "image/attack/unit[15].multishot.png";
unit_stat_setting(15,"회색_동그라미","multishot","",1,4,10,1000,300,420);
unit[16] = new Unit();
unit[16].image.src = "image/unit/unit[16].png";
unit[16].attackimage[0].src = "image/attack/unit[16].attack.png";
unit[16].attackimage[1].src = "image/attack/unit[16].highattack.png";
unit_stat_setting(16,"파란색_동그라미","direct","highattack",1,4,10,1000,300,1700);
unit[17] = new Unit();
unit[17].image.src = "image/unit/unit[17].png";
unit[17].attackimage[0].src = "image/attack/unit[17].attack.png";
unit_stat_setting(17,"연두색_동그라미","heal","",1,4,10,1600,500,800);
unit[18] = new Unit();
unit[18].image.src = "image/unit/unit[18].png";
unit[18].attackimage[0].src = "image/attack/unit[18].attack.png";
unit[18].attackimage[1].src = "image/attack/unit[18].multishot.png";
unit_stat_setting(18,"하얀색_구름","multishot","bubble",1,4,10,1900,582,696);
unit[19] = new Unit();
unit[19].image.src = "image/unit/unit[19].png";
unit[19].attackimage[0].src = "image/attack/unit[19].attack.png";
unit[19].attackimage[1].src = "image/attack/unit[19].thunder_combo.png";
unit_stat_setting(19,"검은색_구름","etc","thunder",1,4,10,1900,582,2377);
unit[20] = new Unit();
unit[20].image.src = "image/unit/unit[20].png";
unit[20].attackimage[0].src = "image/attack/unit[20].attack.png";
unit[20].attackimage[1].src = "image/attack/unit[20].rainbow.png";
unit[20].attackimage[2].src = "image/attack/unit[20].mixcolor.png";
unit_stat_setting(20,"무지개색_동그라미","special","rainbow_color",1,4,10,4400,765,2884);

//-------------------------------
function unit_stat_setting(number,name,type,skill,rank,maxrank,maxlv,hp,hp_plus,attack)
{
	unit[number].number = number; // 숫자, 번호를 의미
	unit[number].name = name; // 문자, 이름
	unit[number].type = type; // 문자, 특성
	unit[number].skill = skill; // 문자, 스킬(특성보다 우선적용)
	unit[number].rank = rank; // 시작랭크
	unit[number].maxrank = maxrank; // 최대랭크
	unit[number].maxlv = maxlv; // (랭크당)최대레벨(주의 : 레벨*랭크가 최대로 올릴 수 있는 레벨임)
	unit[number].hp = hp; // HP
	unit[number].hp_plus = hp_plus; // HP 증가치(랭크당)
	unit[number].attack[0] = attack; // 공격력
	
	unit_type_setting(number); // 유닛의 타입을 설정(공격력과 딜레이와 관련한것들)
	unit_skill_setting(number); // 유닛의 스킬을 설정(타입과 비슷한 방식)
	for(a=0;a<3;a++){ //소수점 버리기
		unit[number].delay[a] = Math.floor(unit[number].delay[a]);
		unit[number].attack[a] = Math.floor(unit[number].attack[a]);
	}
}
function unit_skill_setting(number, skill0, skill1, skill2)
{
    unit[number].skill[0] = skill0;
    unit[number].skill[1] = skill1;
    unit[number].skill[2] = skill2;
}
function unit_type_setting(number)
{
	var data = unit[number].type;
	
	//통상 기능
	if(data == "hyper" ){ // hyper 계열
		unit[number].attack[1] = unit[number].attack[0] * 2.8; // 2.8배수 특수공격
		unit[number].delay[0] = unit[number].attack[0] / 6; // 일반공격 효율 수치
		unit[number].delay[1] = unit[number].attack[1] / 24; // 특수공격 효율 수치
	}
	else if(data == "multishot" ){ // multishot
		unit[number].attack[1] = unit[number].attack[0] * 0.91; // 0.91배수 특수공격
		unit[number].delay[0] = unit[number].attack[0] / 15; // 일반공격 효율 수치
		unit[number].delay[1] = unit[number].attack[1] / 15; // 특수공격 효율 수치
	}
	else if(data == "direct" ){ // direct 계열
		unit[number].attack[1] = unit[number].attack[0] * 4; // 4배수 특수공격
		unit[number].delay[0] = unit[number].attack[0] / 18; // 일반공격 효율 수치
		unit[number].delay[1] = unit[number].attack[1] / 12; // 특수공격 효율 수치
	}
	else if(data == "heal" ){ // heal 계열
		unit[number].attack[1] = unit[number].attack[0] * 0.5; // 0.5배수 힐
		unit[number].delay[0] = unit[number].attack[0] / 5000; // 일반공격 효율 수치
		unit[number].delay[1] = unit[number].attack[1] / 5000; // 특수공격 효율 수치
	}
	else if(data == "splash" ){ // splash_damage 계열
		unit[number].delay[0] = unit[number].attack[0] / 6; // 일반공격 효율 수치
		//단, 이 유닛들은 특수공격이 없는 대신에 일반공격이 스플래시로 처리됨.
	}
	else if(data == "high" || data == "etc" ){ // 기타 계열
		unit[number].delay[0] = unit[number].attack[0] / 15; // 일반공격 효율 수치
		//단, 이 유닛들은 특수공격이 없는 대신에 스킬 공격이 존재한다.
	}
	else if(data == "special" ){ // 스페셜 계열
		unit[number].delay[0] = unit[number].attack[0] / 10; // 일반공격 효율 수치
		unit[number].delay[1] = unit[number].attack[1] / 10; // 일반공격 효율 수치
		//단, 이 유닛들은 모든 공격이 특수공격으로 처리되기 때문에 스킬설정에서
		//일일히 설정해야 한다. 여기서 써져있는 값은 기본값이다.
	}
}
function unit_skill_setting(number)
{
	var skilldata = unit[number].skill;
	
	if( skilldata == "headshot" ){
		unit[number].attack[1] = unit[number].attack[0] * 17; // 17배수 스킬공격(특수공격 없음)
		unit[number].delay[1] = unit[number].attack[1] / 15; // 스킬공격 효율 수치
	}
	else if ( skilldata == "bubble" ){
		unit[number].delay[1] = unit[number].delay[1] * 3;
	}
	else if ( skilldata == "multishot_arrow" ){
		unit[number].delay[1] = unit[number].delay[1] * 19;
	}
	else if ( skilldata == "laserABC" ){
	    unit[number].attack[1] = unit[number].attack[0] * 1.17;
	    unit[number].attack[2] = unit[number].attack[0] * 1.17;
	    unit[number].delay[0] = unit[number].attack[0] / 10;
	    unit[number].delay[1] = unit[number].attack[1] / 11;
	    unit[number].delay[2] = unit[number].attack[2] / 9;
	}
	/*else if ( skilldata == "thunder" ){
		unit[number].delay[1] = unit[number].attack[0] / 13;
		unit[number].attack[1] = unit[number].attack[0];
		unit[number].delay[0] = 0;
	}*/
	
	for(a=0;a<3;a++){  //소수점 버리기
		unit[number].delay[a] = Math.floor(unit[number].delay[a]);
		unit[number].attack[a] = Math.floor(unit[number].attack[a]);
	}
}
function unit_stat_check(string_loadType,code,lv)
{
	var value;
	
    if(string_loadType == "attack"){
    	value = unit[code].attack[0] + ( (unit[code].attack[0]*0.3) / unit[code].maxlv ) * (lv-1);
    }
	else if(string_loadType == "attack2"){
    	value = unit[code].attack[1] + ( (unit[code].attack[0]*0.3) / unit[code].maxlv ) * (lv-1);
    }
	else if(string_loadType == "attack3"){
    	value = unit[code].attack[2] + ( (unit[code].attack[0]*0.3) / unit[code].maxlv ) * (lv-1);
    }
    else if(string_loadType == "hp"){
    	value = unit[code].hp + ( (unit[code].hp_plus) / unit[code].maxlv ) * lv;
    }
    
    value = Math.floor(value);
    return value;
}