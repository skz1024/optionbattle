function Dungeon()
{
	this.round = 1;
	this.subround = 1;
	this.name = "";
	this.type = "";
	this.time = 100;
	this.enemycreate = 100;
	this.enemylist = new Array(10);
	this.boss = 0;
}
function dungeon_input(number,round,subround,name,type,time,enemycreate,boss)
{
	dungeon[number].round = round;
	dungeon[number].subround = subround;
	dungeon[number].name = name;
	dungeon[number].type = type;
	dungeon[number].time = time;
	dungeon[number].boss = boss;
	dungeon[number].enemycreate = enemycreate;
}
var dungeonoption = { enemyhp:1, enemyattack:2, enemyspeed:3 };
var dungeon = new Array(100);

dungeon[0] = new Dungeon();
///////
dungeon[1] = new Dungeon();
dungeon[1].enemylist = [1,2,3,4,5];
dungeon_input(1,1,1,"파란 행성 하늘구간1","normal",180,110,0);
dungeon[2] = new Dungeon();
dungeon[2].enemylist = [1,2,3,4,5];
dungeon_input(2,1,2,"파란 행성 하늘구간2","normal",180,110,0);
dungeon[3] = new Dungeon();
dungeon[3].enemylist = [1,2,3,4,5];
dungeon_input(3,1,3,"파란 행성 상층구간1","normal",211,141,0);
dungeon[4] = new Dungeon();
dungeon[4].enemylist = [1,2,3,4,5];
dungeon_input(4,1,4,"파란 행성 상층구간2","normal",252,11,21);
dungeon[5] = new Dungeon();
dungeon[5].enemylist = [3,4,5,6,7];
dungeon_input(5,1,5,"파란 행성 마을1","normal",160,109,0);
dungeon[6] = new Dungeon();
dungeon[6].enemylist = [3,4,5,6,7];
dungeon_input(6,1,6,"파란 행성 마을2","",193,109,0);
dungeon[7] = new Dungeon();
dungeon[7].enemylist = [3,4,5,6,7];
dungeon_input(7,1,7,"파란 행성 스카이랜드1","",192,235,0);
dungeon[8] = new Dungeon();
dungeon[8].enemylist = [3,4,5,6,7];
dungeon_input(8,1,8,"파란 행성 스카이랜드2","",192,235,0);
dungeon[9] = new Dungeon();
dungeon[9].enemylist = [6,7,8,9,10];
dungeon_input(9,1,9,"파란 행성 중층구간1","",192,235,0);
dungeon[10] = new Dungeon();
dungeon[10].enemylist = [6,7,8,9,10];
dungeon_input(10,1,10,"파란 행성 중층구간2","",192,235,0);
dungeon[11] = new Dungeon();
dungeon[11].enemylist = [6,7,8,9,10];
dungeon_input(11,1,11,"파란 행성 중간도시1","",192,235,0);
dungeon[12] = new Dungeon();
dungeon[12].enemylist = [6,7,8,9,10];
dungeon_input(12,1,12,"파란 행성 중간도시2","",192,235,0);
dungeon[13] = new Dungeon();
dungeon[13].enemylist = [6,7,8,9,10];
dungeon_input(13,1,13,"파란 행성 보라하늘1","",192,235,0);
dungeon[14] = new Dungeon();
dungeon[14].enemylist = [6,7,8,9,10];
dungeon_input(14,1,14,"파란 행성 보라하늘2","",192,235,0);
dungeon[15] = new Dungeon();
dungeon[15].enemylist = [6,7,8,9,10];
dungeon_input(15,1,15,"파란 행성 푸른경계면1","",192,235,0);
dungeon[16] = new Dungeon();
dungeon[16].enemylist = [6,7,8,9,10];
dungeon_input(16,1,16,"파란 행성 푸른경계면2","",192,235,0);
