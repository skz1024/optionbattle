function party_standard_total_progress()
{
	party_countup();
	party_attack_check();
}
function party_setting(line,code,lv,inventory)
{
    user.teamunit[line][teamoption.code] = code;
    user.teamunit[line][teamoption.lv] = lv;
    user.teamunit[line][teamoption.inventory] = inventory;
    
    user.teamunit[line][teamoption.job] = unit[code].job;
    user.teamunit[line][teamoption.hp] = unit[code].hp;
    user.teamunit[line][teamoption.mp_max] = unit[code].mp;
    user.teamunit[line][teamoption.delay1] = unit[code].delay[0];
    user.teamunit[line][teamoption.delay2] = unit[code].delay[1];
    user.teamunit[line][teamoption.delay3] = unit[code].delay[2];
    user.teamunit[line][teamoption.attack] = unit[code].attack[0];
    user.teamunit[line][teamoption.attack2] = unit[code].attack[1];
    user.teamunit[line][teamoption.attack3] = unit[code].attack[2];
    user.teamunit[line][teamoption.count1] = line*5+5;
    user.teamunit[line][teamoption.count2] = line*5+25;
    user.teamunit[line][teamoption.count3] = line*5+45; 
}
for(a=0; a<12; a++){
    party_setting(a,18,1,a);
}
//party_setting(0,6,1,0);
//party_setting(1,6,1,1);
/*party_setting(2,Math.floor(Math.random()*19)+1,1,2);
party_setting(3,Math.floor(Math.random()*19)+1,1,3);
party_setting(4,Math.floor(Math.random()*19)+1,1,4);
party_setting(5,Math.floor(Math.random()*19)+1,1,5);
party_setting(6,Math.floor(Math.random()*19)+1,1,6);
party_setting(7,Math.floor(Math.random()*19)+1,1,7);
party_setting(8,Math.floor(Math.random()*19)+1,1,8);
party_setting(9,Math.floor(Math.random()*19)+1,1,9);
party_setting(10,Math.floor(Math.random()*19)+1,1,10);
party_setting(11,Math.floor(Math.random()*19)+1,1,11);
/*party_setting(0,11,152,0);
party_setting(1,11,142,1);
party_setting(2,11,414,1);
party_setting(3,11,199,2);
party_setting(4,11,199,2);
party_setting(5,11,199,2);
party_setting(6,11,199,2);
party_setting(7,11,199,2);
party_setting(8,11,199,2);
party_setting(9,11,199,2);
party_setting(10,3,199,2);
party_setting(11,3,199,2);*/

function party_countup(){
    for(number=0;number<user.teamunit.length;number++){
        user.teamunit[number][teamoption.count1]++;
        user.teamunit[number][teamoption.count2]++;
        user.teamunit[number][teamoption.count3]++;
		user.teamunit[number][teamoption.countwait4]++;
		user.teamunit[number][teamoption.countwait5]++;
		
        if(user.teamunit[number][teamoption.mp] <= user.teamunit[number][teamoption.mp_max]){
            user.teamunit[number][teamoption.mp]++;
        }
        
        user.teamunit[number][teamoption.bufftime]--;
        if(user.teamunit[number][teamoption.bufftime]<0){
        	user.teamunit[number][teamoption.buff]=0;
        }
    }
}
function party_attack_check()
{
    if(attackCount >= attack.length){ attackCount=0; }
    for(number=0;number<user.teamunit.length;number++){
    	var code = user.teamunit[number][teamoption.code]; // 공격한 유닛의 코드를 조사
		
		//첫번째 공격카운트 조사
        if(user.teamunit[number][teamoption.delay1]!=0 && user.teamunit[number][teamoption.count1] >= user.teamunit[number][teamoption.delay1]){
            user.teamunit[number][teamoption.count1]=0;
			party_attackmake(number); // 공격 처리
			
			var sound_code = unit[code].type; // 사운드 재생
			if((unit[code].type == "special" || unit[code].type == "etc") && unit[code].skill!="")    sound_code = unit[code].skill;
			sound_shot(sound_code);
        }
		//두번째 공격카운트 조사
        else if(user.teamunit[number][teamoption.delay2]!=0 && user.teamunit[number][teamoption.count2] >= user.teamunit[number][teamoption.delay2]){
            var code = user.teamunit[number][teamoption.code];
            user.teamunit[number][teamoption.count2]=0;
			var attackcode = 2;
			
			var sound_code;
            if(unit[code].skill != "") sound_code = unit[code].skill;
            else    sound_code = unit[code].type;
            sound_shot(sound_code);
			
			//공격 처리
			if(unit[code].skill == "" || unit[code].skill == null)    party_attackmake(number,attackcode);
			else if(unit[code].skill == "bubble")		for(d=0; d<3; d++){ party_attackmake(number,attackcode); }
			else if(unit[code].skill == "laserABC" || unit[code].skill == "highattack")    party_attackmake(number,attackcode);
			else if(unit[code].skill == "multishot_arrow"){
				user.teamunit[number][teamoption.count4] += 20;
			}
        }
		else if(user.teamunit[number][teamoption.delay3]!=0 && user.teamunit[number][teamoption.count3] >= user.teamunit[number][teamoption.delay3]){
            var code = user.teamunit[number][teamoption.code];
            user.teamunit[number][teamoption.count3]=0;
			var attackcode = 3;
			
            var sound_code;
            if(unit[code].skill != "") sound_code = unit[code].skill;
			else    sound_code = unit[code].type;
            sound_shot(sound_code);
			
			//공격 처리
			if(unit[code].skill == "" || unit[code].skill == null)    party_attackmake(number,attackcode);
			else if(unit[code].skill == "laserABC")    party_attackmake(number,attackcode);
        }
		else if(user.teamunit[number][teamoption.count4] >=1){
			var code = user.teamunit[number][teamoption.code];
			var attackcode = 2;
			var delay4 = user.teamunit[number][teamoption.countwait4];
			// count 2 계열의 공격 패턴을 새로 씁니다. 무슨말이나면, 특수한 공격을 처리할때는 여기에 있는 기능들을 쓴다는겁니다.
			
			if(unit[code].skill == "multishot_arrow" && delay4 >= 10 ){
				party_attackmake(number,attackcode);
				sound_shot("multishot_arrow");
				user.teamunit[number][teamoption.count4]--;
				user.teamunit[number][teamoption.countwait4] = 0;
			}
			
		}
    }//for1
}
function party_attackmake(number,attackcode)
{   
    attackCount_check();
    
    var code = user.teamunit[number][teamoption.code];
	attack[attackCount][damageoption.code] = code;
	var lv = user.teamunit[number][teamoption.lv];
	//참고 : 공격력은 무조건 정수로 들어감.(소수 이하는 버림)
	attack[attackCount][damageoption.x] = filed.size_x[number%3]; // 공격 발사 위치
	attack[attackCount][damageoption.y] = filed.size_y[Math.floor(number/3)]; // 공격 발사 위치
	
	if(attackcode == null) attackcode=1;
	attack[attackCount][damageoption.mode] = attackcode;
	
	if(attackcode == 1){
		attack[attackCount][damageoption.attack] = unit_stat_check("attack",code,lv);
		if(unit[code].type == "etc" || unit[code].type == "special") attack[attackCount][damageoption.skill] = unit[code].skill; // 직업이 없는경우
		attack[attackCount][damageoption.type] = unit[code].type; // 직업이 있는경우
	}
	else if(attackcode == 2){
		attack[attackCount][damageoption.attack] = unit_stat_check("attack2",code,lv);
		if(unit[code].skill != "") attack[attackCount][damageoption.skill] = unit[code].skill; // 스킬이 있는경우
		attack[attackCount][damageoption.type] = unit[code].type; // 스킬이 없는경우
	}
	else if(attackcode == 3){
        attack[attackCount][damageoption.attack] = unit_stat_check("attack3",code,lv);
        if(unit[code].skill != "") attack[attackCount][damageoption.skill] = unit[code].skill; // 스킬이 있는경우
        attack[attackCount][damageoption.type] = unit[code].type; // 스킬이 없는경우
    }
	//직업 구분에 따른 공격패턴 정하기
	
	
        
	//공격 대상 지정
	for(a=1;a<10;a++){
		attack[attackCount][damageoption.target] = Math.floor(Math.random() * enemyMax);
		if(attack[attackCount][damageoption.target]!=(enemyunit[a][enemyoption.hp]<0)){
			if(attack[attackCount][damageoption.type]=="direct"){
				attack[attackCount][damageoption.x] = enemyunit[attack[attackCount][damageoption.target]][enemyoption.x];
				attack[attackCount][damageoption.y] = enemyunit[attack[attackCount][damageoption.target]][enemyoption.y];
            }
            break;
		}
        else continue;
	}
}
function attackCount_check()
{
    attackCount++;

    for(b=0; b<attack.length; attackCount++,b++){
        if(attackCount >= attack.length) attackCount=0; // 배열 초과 계산 금지
        if(attack[attackCount][damageoption.attack]==0){
            break;
        }
    }
    
    if(attackCount >= attack.length) attackCount=0;
}
