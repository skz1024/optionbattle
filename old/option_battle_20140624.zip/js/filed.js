function Filed()
{
    this.ally = new Array(12);
    this.enemy = new Array(10);
    this.size_x = new Array(4);
    this.size_y = new Array(5);
    this.size_x[0]=30; this.size_x[1]=100; this.size_x[2]=170; this.size_x[3]=240;
    this.size_y[0]=100; this.size_y[1]=170; this.size_y[2]=240; this.size_y[3]=310; this.size_y[4]=380;
}
Filed.prototype.display = function()
{
    var input = 0;
    for(number=0;number<12;number++)//아군 표시
    {
        input = user.teamunit[number][teamoption.code];
        unit[input].display(this.size_x[number%3],this.size_y[parseInt(number/3)]);
        
        var percent1 = user.teamunit[number][teamoption.count1] / user.teamunit[number][teamoption.delay1];
        var percent2 = user.teamunit[number][teamoption.count2] / user.teamunit[number][teamoption.delay2];
        var percent3 = user.teamunit[number][teamoption.count3] / user.teamunit[number][teamoption.delay3];
        //....
            ctx.strokeStyle="black";
            ctx.fillStyle = "#DFDFDF";
            ctx.strokeRect(this.size_x[number%3],this.size_y[parseInt(number/3)]+50,70,5);
            ctx.fillRect(this.size_x[number%3],this.size_y[parseInt(number/3)]+50,percent1*70,5);
                
            ctx.fillStyle = "#BCCCFC";
            ctx.strokeRect(this.size_x[number%3],this.size_y[parseInt(number/3)]+55,70,5);
            ctx.fillRect(this.size_x[number%3],this.size_y[parseInt(number/3)]+55,percent2*70,5);
                
            ctx.fillStyle = "#BCFCBD";
            ctx.strokeRect(this.size_x[number%3],this.size_y[parseInt(number/3)]+60,70,5);
            ctx.fillRect(this.size_x[number%3],this.size_y[parseInt(number/3)]+60,percent3*70,5);
        
        /*if(user.teamunit[number][teamoption.mp] != 0 ){
            var percent4 = user.teamunit[number][teamoption.mp] / user.teamunit[number][teamoption.mp_max];
            ctx.fillStyle = "#BCFCBD";
            ctx.strokeRect(this.size_x[number%3]+60,this.size_y[parseInt(number/3)],10,50);
            ctx.fillRect(this.size_x[number%3]+60,this.size_y[parseInt(number/3)]+50,10,(percent4*50)*-1);
        }*/
    }
    user.hp_meter(this.size_x[0],this.size_y[4],180,30);//아군 체력 표시
    //ctx.fillText("남은 적 수 : "+enemy_create_count,this.size_x[0],this.size_y[4]+70);
    for(number=0; number < enemyMax ; number++)//적군 표시
    {
        if(enemyunit[number][enemyoption.on]==true||(enemyunit[number][enemyoption.on]==false&&enemyunit[number][enemyoption.die]>=1))
        {
            input = enemyunit[number][enemyoption.code];
            enemy[input].display(enemyunit[number][enemyoption.x],enemyunit[number][enemyoption.y]);
        }
    }
    
};
filed = new Filed();
{
    
}