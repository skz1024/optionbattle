function spritE()
{
    this.image = new Image();
    this.image.src = "";
    this.x=0; // x 좌표
    this.y=1; // y 좌표
    this.count;
}
spritE.prototype.filedmake = function(count) // 2차원 배열 만들기
{
    this.filed = new Array(count);
    for(i=0;i<count;i++){
        this.filed[i] = new Array(3);
    }
};
spritE.prototype.display = function(size_x,size_y) // 출력
{
    if(size_x==null&&size_y==null){
        for(i=0;i<this.count;i++){
            ctx.drawImage(this.image,this.filed[i][this.x],this.filed[i][this.y]);
        }
    }
    else{
        for(i=0;i<this.count;i++){
            ctx.drawImage(this.image,this.filed[i][this.x],this.filed[i][this.y],size_x,size_y);
        }
    }
};
spritE.prototype.random = function(count,option) // 좌표 랜덤 설정
//참고로 옵션은 null이 아닐경우 모든 좌표를 건들지 않는다.
{
    if(option!=null)
    {
        this.filed[count][this.x] = Math.floor(Math.random() * 1080) - 240;
        this.filed[count][this.y] = Math.floor(Math.random() * (480-30)) + 30;
    }
    else
        for(i=0;i<count;i++){
            this.filed[i][this.x] = Math.floor(Math.random() * 1080) - 240;
            this.filed[i][this.y] = Math.floor(Math.random() * (480-30)) + 30;
        }
};
spritE.prototype.moveX = function(speed,number)
{
    if(number==null){
        for(i=0;i<this.count;i++){
            this.filed[i][this.x]+=speed;
        }
    }
    else
        this.filed[number][this.x]+=speed;
    
    for(i=0;i<this.count;i++){
        if(this.filed[i][this.x] > 640 + 320){
            this.filed[i][this.x] = -290 + Math.floor(Math.random() * 250);
            this.filed[i][this.y] = Math.floor(Math.random() * 320);
        }
    }
};

sprite_green_cloud = new spritE;
{
    sprite_green_cloud.image.src = "image/sprite/green_cloud.png";
    sprite_green_cloud.count = 4;
}
sprite_green_cloud.filedmake(sprite_green_cloud.count);
sprite_green_cloud.random(sprite_green_cloud.count);

sprite_white_cloud = new spritE;
{
    sprite_white_cloud.image.src = "image/sprite/white_cloud.png";
    sprite_white_cloud.count = 3;
}
sprite_white_cloud.filedmake(sprite_white_cloud.count);
sprite_white_cloud.random(sprite_white_cloud.count);