var damage = new Array(100); // 데미지를 표시하는 숫자는 최대 100개까지 저장된다.
var attack = new Array(100); // 공격 이미지를 표시하는 이미지는 최대 100개까지 처리된다.
for(a=0 ; a< damage.length ;a++){  damage[a] = new Array(10); attack[a] = new Array(10); }
for(a=0 ; a< damage.length ;a++){
    for(b=0; b<20 ;b++){
        damage[a][b]=0; attack[a][b]=0;
    }
}
var damage_count=0;
var attack_count=0;
var damageoption = {x:0, y:1, attack:2, color:3, style:4, code:5, target:6,
	count:7, type:8, mode:9, skill:10 };
var color = { hyper:"darkgreen", multishot:"saddlebrown", direct:"darkblue" ,splash:"red", heal:"pink",
    metal:"slategray"};
function attack_standard_total_progress()
{
    attack_move();
    attack_progress();
    damage_display();
    attack_display();
}
function damage_display()//데미지를 표시하는 함수
{
    for(a=0; a<damage.length; a++)
    {
    	//데미지가 0 이하이거나 출력표시 카운트가 0이하일경우 출력을 생략함.
		if(damage[a][damageoption.attack] <= 0 || damage[a][damageoption.count] <= 0 ) continue;
        else{
        	ctx.fillStyle = damage[a][damageoption.color];
        	ctx.font = "26px arial";
			ctx.fillText(damage[a][damageoption.attack] , damage[a][damageoption.x], damage[a][damageoption.y]);
			damage[a][damageoption.y]--;
			damage[a][damageoption.count]--;
		}
	    // 텍스트 출력: 수치, x좌표, y좌표
    }
}
function damage_input(attack,x,y,color)//데미지를 입력하는 함수
{
    if(damage_count>=damage.length) damage_count=0; // 배열 초과계산 금지
    damage[damage_count][damageoption.attack] = attack;
    damage[damage_count][damageoption.x] = x;
    damage[damage_count][damageoption.y] = y;
    damage[damage_count][damageoption.count] = 50;
    if(color==null){ damage[damage_count][damageoption.color] = "black"; }
    else{ damage[damage_count][damageoption.color] = color; }
    
    damage_count++;
}
function attack_display()//공격이미지를 표시하는 함수
{
    for(a=0; a<attack.length ;a++)
    {
        if(attack[a][damageoption.attack]!=0)
        {
            var code = attack[a][damageoption.code];
            var mode = attack[a][damageoption.mode];
            attack_image(a,code,mode);
        }
        else continue;
    }
}
function attack_image(line,number,mode)//공격 이미지 출력
{
    if(mode==1){
	    ctx.drawImage(unit[number].attackimage[0],attack[line][damageoption.x],attack[line][damageoption.y]);
    }
    else if(mode==2){
    	ctx.drawImage(unit[number].attackimage[1],attack[line][damageoption.x],attack[line][damageoption.y]);
    }
    else if(mode==3){
        ctx.drawImage(unit[number].attackimage[2],attack[line][damageoption.x],attack[line][damageoption.y]);
    }
}
function attack_target(a,target)//공격 타겟 재설정
{
    for(b=0;b<20;b++){
        target = Math.floor(Math.random() * enemy_max);//랜덤으로 타겟 재설정
            
        if(enemyunit[target][enemyoption.on]==true){
	        attack[a][damageoption.target] = target;
            if(attack[a][damageoption.type]=="direct"){
				attack[a][damageoption.x] = enemyunit[target][enemyoption.x];
				attack[a][damageoption.y] = enemyunit[target][enemyoption.y];
            }
            break;//설정 완료되면 break;
		}//조건문 종료
    }
}
function attack_move()//공격장치 이동(?)
{
    for(a=0;a<attack.length;a++)
    {
    	var target = attack[a][damageoption.target]; // 타겟 대입;
    	if(enemyunit[target][enemyoption.on]==false){ // 타겟이 잘못 설정된 경우
            attack_target(a,target);
        }
        if(enemy_current==0) attack[a][damageoption.attack]=0; // 적의 수가 0일경우
        
        var movesize_x = (enemyunit[target][enemyoption.x] - attack[a][damageoption.x])/20;
        var movesize_y = (enemyunit[target][enemyoption.y] - attack[a][damageoption.y])/10;
        
        if(movesize_x<10 && movesize_x>0) movesize_x=10; // x좌표 이동
        else if(movesize_x < 0) movesize_x=-10; // x좌표 역으로 이동
        
        if(movesize_y<=10 && movesize_y>0) movesize_y=5; // y좌표 이동
        else if(movesize_y <= 0 && movesize_y >= -1) movesize_y=0;
        else if(movesize_y < -1) movesize_y= -5; // y좌표 역으로 이동
        
        if(movesize_x==8 &&( enemyunit[target][enemyoption.x] - 
            attack[a][damageoption.x] <= 10 )&&(enemyunit[target][enemyoption.x] - attack[a][damageoption.x] >= -10 ))
        {
            attack[a][damageoption.x] = enemyunit[target][enemyoption.x];
            attack[a][damageoption.y] = enemyunit[target][enemyoption.y];
        }
        
        attack[a][damageoption.x] += movesize_x;
        attack[a][damageoption.y] += movesize_y;
        
        //if(movesize_y<1 && movesize_y>0) movesize_y=-1;
        //else if(movesize_y < 1) movesize_y=1;
    }//for
}
var majondasu=0;
var splashmajondasu=0;
function attack_progress()
{
    for(a=0;a<100;a++)
    {
        var target = attack[a][damageoption.target];
        if( attack[a][damageoption.attack]!=0 && enemyunit[target][enemyoption.hp]>0 
            && ( enemyunit[target][enemyoption.x] >= attack[a][damageoption.x]-10 && enemyunit[target][enemyoption.x] <= attack[a][damageoption.x]+10 )
            && ( enemyunit[target][enemyoption.y] >= attack[a][damageoption.y]-10 && enemyunit[target][enemyoption.y] <= attack[a][damageoption.y]+10 )
          ) // 여기까지 if 조건
        {
        majondasu++;
			// 여기서부터 조건 체크
            if(attack[a][damageoption.type]=="splash"){    //스플래시로 타겟을 맞출 경우
        	
        	for(var i=0; i<10; i++){ if(a==splasharray[i]){ splasharray[i]=0; }}
        	
        	for(number=0 ; number < enemy_max ; number++){
        	    var atkx = attack[a][damageoption.x];
        	    var atky = attack[a][damageoption.y];
        	    var enemyx = enemyunit[number][enemyoption.x];
        	    var enemyy = enemyunit[number][enemyoption.y];
                    
        	    if((enemyx <= atkx+100 && enemyx >= atkx-100)&&(enemyy <= atky+100 && enemyy >= atky-100)){
        	    	var damage_attack = (attack[a][damageoption.attack] - enemyunit[number][enemyoption.defense]);
                        
        	        if(damage_attack <= 0) damage_attack=1; // 1이하의 데미지가 들어가면 1로 처리
        	    	enemyunit[number][enemyoption.hp] -= damage_attack;
                    damage_input(damage_attack,enemyunit[number][enemyoption.x],enemyunit[number][enemyoption.y],"red");
                    //ctx.fillStyle ="red"; 
                    //ctx.fillRect(atkx-100,atky-100,200,200);
        	    }
        	}
        	splashmajondasu++;
            sound_output("bomb");
            }//여기까지 스플래시 공격
			else if(attack[a][damageoption.skill]=="thunder"){ // 번개 공격
			    var damage_attack = (attack[a][damageoption.attack] - enemyunit[target][enemyoption.defense]);
				enemyunit[target][enemyoption.hp] -= damage_attack;
				damage_input(Math.floor(damage_attack),enemyunit[target][enemyoption.x],enemyunit[target][enemyoption.y],"yellow");
				sound_output("thunderdamage");
			}
			else if(attack[a][damageoption.skill]=="highattack"){ // 하이어택 공격
			    var damage_attack = (attack[a][damageoption.attack] - enemyunit[target][enemyoption.defense]);
				enemyunit[target][enemyoption.hp] -= damage_attack;
				damage_input(Math.floor(damage_attack),enemyunit[target][enemyoption.x],enemyunit[target][enemyoption.y],"darkblue");
				sound_output("highattackdamage");
			}
			else{  //일반 공격
			    var damage_attack = (attack[a][damageoption.attack] - enemyunit[target][enemyoption.defense]);
        	    enemyunit[target][enemyoption.hp] -= damage_attack;
        	    //if(attack[a][damageoption.type]=="direct"){ sound_output("highattackdamage") }
        	    
        	    var color;
        	    if(attack[a][damageoption.type]=="direct") color="darkblue";
        	    else if(attack[a][damageoption.skill]=="laserABC") color="gold";
                else if(attack[a][damageoption.skill]=="bubble") color="slateblue";
                else if(attack[a][damageoption.skill]=="multishot_arrow") color="slateblue";
        	    else if(attack[a][damageoption.type]=="hyper") color="darkgreen";
        	    else if(attack[a][damageoption.type]=="multishot") color="saddlebrown";
        	    else if(attack[a][damageoption.type]=="heal") color="pink";
        	    
                damage_input(Math.floor(damage_attack),enemyunit[target][enemyoption.x],enemyunit[target][enemyoption.y],color);
            }
			
			attack[a][damageoption.attack]=0; // 공격을 처리 후, 공격력을 0으로 함.
			attack[a][damageoption.type]=""; // job에 대한 정보를 지움.
        }
        else if(attack[a][damageoption.x]>=1000) // 미사일이 바깥으로 나갈경우
        {
            attack[a][damageoption.attack] = 0; // 공격력을 0으로 해서 제거
        }
    }
}