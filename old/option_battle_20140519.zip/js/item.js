var inventoryoption = { number:0, code:1, type:2, lv:3, rank:4 };
var inventory_type = { unit:0, item:1, upgrade:2 };
function inventory_input(number,code,type,lv,rank)
{
	if(lv==null) lv=0;
	if(rank==null) rank=0;
	
	user.inventory[number][inventoryoption.code] = code;
	user.inventory[number][inventoryoption.type] = type;
	user.inventory[number][inventoryoption.lv] = lv;
	user.inventory[number][inventoryoption.rank] = rank;
}
for(a=0;a<=11;a++) inventory_input(a+1,a+1,0,1,1);
function inventory_check()
{
	inventory_sort();
	for(a=0;a<=user.inventory_max;a++)
	{
		if(user.inventory[a][inventoryoption.code]==0 && user.inventory[a][inventoryoption.type]==0 ){
			user.inventory_use = a;
			break;
		}
		
		if(a<=user.inventory_max) user.inventory_use = user.inventory_max;
	}
}
function inventory_sort()
{
	for(a=0;a<=user.inventory_max && inventory_status==1;a++)
	{
		if(a!=0&&user.inventory[a-1][inventoryoption.code]==0 && user.inventory[a-1][inventoryoption.type]==0){
			for(b=0;b<12;b++){
			    if(user.teamunit[b][teamoption.inventory]==a) user.teamunit[b][teamoption.inventory]--;
			}
			user.inventory[a-1][inventoryoption.code] = user.inventory[a][inventoryoption.code];
			user.inventory[a-1][inventoryoption.type] = user.inventory[a][inventoryoption.type];
			user.inventory[a-1][inventoryoption.rank] = user.inventory[a][inventoryoption.rank];
			user.inventory[a-1][inventoryoption.lv] = user.inventory[a][inventoryoption.lv];
			user.inventory[a][inventoryoption.code] = 0;
			user.inventory[a][inventoryoption.type] = 0;
			user.inventory[a][inventoryoption.rank] = 0;
			user.inventory[a][inventoryoption.lv] = 0;
		}
	}
}
var inventory_status = true;

//------------------------//
// 조합관련처리
var combination = new Array(100);
function combinatioN()
{
	this.number = 0;
	this.name = "";
	this.round = ""; // 해당되는 라운드(구분용)
	this.material = new Array(6); // 재료
	this.result = new Array(2); // 결과(종류,번호)
	this.gold = 0; // 사용되는 골드
}
combination[0] = new combinatioN;
{
	combination[0].round = 0;
	combination[0].material = [0,0,0,0,0,0];
	
}
combination[1] = new combinatioN;
{
	combination[1].round = 1;
	combination[1].material = [1,1,1,0,0,0];
	combination[1].result = [inventory_type.unit,13];
	combination[1].gold = 2000;
}
combination[2] = new combinatioN;
{
	combination[2].round = 1;
	combination[2].material = [2,2,2,0,0,0];
	combination[2].result = [inventory_type.unit,14];
	combination[2].gold = 2000;
}
combination[3] = new combinatioN;
{
	combination[3].round = 1;
	combination[3].material = [3,3,3,0,0,0];
	combination[3].result = [inventory_type.unit,15];
	combination[3].gold = 2000;
}
combination[4] = new combinatioN;
{
	combination[4].round = 1;
	combination[4].material = [4,4,4,0,0,0];
	combination[4].result = [inventory_type.unit,16];
	combination[4].gold = 2000;
}
combination[5] = new combinatioN;
{
	combination[5].round = 1;
	combination[5].material = [5,5,5,0,0,0];
	combination[5].result = [inventory_type.unit,17];
	combination[5].gold = 2000;
}
combination[6] = new combinatioN; // 무지개동그라미파편
{
	combination[6].round = 1;
	combination[6].material = [1,2,3,4,5,0];
	combination[6].result = [inventory_type.item,6];
	combination[6].gold = 8000;
}
combination[7] = new combinatioN; // 무지개동그라미
{
	combination[7].round = 1;
	combination[7].material = [6,6,6,6,0,0];
	combination[7].result = [inventory_type.unit,20];
	combination[7].gold = 50000;
}
combination[8] = new combinatioN; // 구름
{
	combination[8].round = 1;
	combination[8].material = [7,7,7,7,8,0];
	combination[8].result = [inventory_type.unit,18];
	combination[8].gold = 17000;
}
combination[9] = new combinatioN; // 구름
{
	combination[9].round = 1;
	combination[9].material = [8,8,8,8,7,0];
	combination[9].result = [inventory_type.unit,19];
	combination[9].gold = 17000;
}

//------------------------//
// 아이템관련처리
function iteM()
{
	this.number = 0;
	this.name = "";
	this.text = "";
	this.getarea = "";
	this.image = new Image();
	this.image.src = "";
}
iteM.prototype.display = function(x,y,size_x,size_y)
{
	if(size_x==null||size_y==null) ctx.drawImage(this.image,x,y);
	else ctx.drawImage(this.image,x,y,size_x,size_y);
};
var item = new Array(100);
var upgrade = new Array(100);
item[0] = new iteM;
{
	this.name = "null";
	this.text = "unused";
	this.getarea = "???";
}
item[1] = new iteM;
{
    item[1].name = "빨간색 동그라미 파편";
	item[1].text = "빨간색 동그라미를 만들때 사용하는 재료이다.";
	item[1].image.src = "image/item/item[1].png";
}
item[2] = new iteM;
{
	item[2].name = "갈색 동그라미 파편";
	item[2].text = "갈색 동그라미를 만들때 사용하는 재료이다.";
	item[2].image.src = "image/item/item[2].png";
}
item[3] = new iteM;
{
	item[3].name = "회색 동그라미 파편";
	item[3].text = "회색 동그라미를 만들때 사용하는 재료이다.";
	item[3].image.src = "image/item/item[3].png";
}
item[4] = new iteM;
{
	item[4].name = "파란색 동그라미 파편";
	item[4].text = "파란색 동그라미를 만들때 사용하는 재료이다.";
	item[4].image.src = "image/item/item[4].png";
}
item[5] = new iteM;
{
	item[5].name = "연두색 동그라미 파편";
	item[5].text = "연두색 동그라미를 만들때 사용하는 재료이다.";
	item[5].image.src = "image/item/item[5].png";
}
item[6] = new iteM;
{
	item[6].name = "무지개색 동그라미 파편";
	item[6].text = "무지개색 동그라미를 만들때 사용하는 재료이다.";
	item[6].image.src = "image/item/item[6].png";
}
item[7] = new iteM;
{
	item[7].name = "하얀색 구름 파편";
	item[7].text = "하얀색 구름을 만들때 사용하는 재료이다.";
	item[7].image.src = "image/item/item[7].png";
}
item[8] = new iteM;
{
	item[8].name = "검은색 구름 파편";
	item[8].text = "검은색 구름을 만들때 사용하는 재료이다.";
	item[8].image.src = "image/item/item[8].png";
}

upgrade[0] = new iteM;
{
	
}
upgrade[1] = new iteM;
{
	upgrade[1].name = "hyper unit upgrade";
	upgrade[1].text = "hyper type의 유닛들을 업그레이드 하는데 사용합니다.";
	upgrade[1].image.src = "image/upgrade/upgrade[1].png";
}
upgrade[2] = new iteM;
{
	upgrade[2].name = "multishot unit upgrade";
	upgrade[2].text = "multishot type의 유닛들을 업그레이드 하는데 사용합니다.";
	upgrade[2].image.src = "image/upgrade/upgrade[2].png";
}
upgrade[3] = new iteM;
{
	upgrade[3].name = "direct unit upgrade";
	upgrade[3].text = "direct type의 유닛들을 업그레이드 하는데 사용합니다.";
	upgrade[3].image.src = "image/upgrade/upgrade[3].png";
}
upgrade[4] = new iteM;
{
	upgrade[4].name = "splash unit upgrade";
	upgrade[4].text = "splash type의 유닛들을 업그레이드 하는데 사용합니다.";
	upgrade[4].image.src = "image/upgrade/upgrade[4].png";
}
upgrade[5] = new iteM;
{
	upgrade[5].name = "heal unit upgrade";
	upgrade[5].text = "heal type의 유닛들을 업그레이드 하는데 사용합니다.";
	upgrade[5].image.src = "image/upgrade/upgrade[5].png";
}
upgrade[6] = new iteM;
{
	upgrade[6].name = "metal unit upgrade";
	upgrade[6].text = "metal type의 유닛들을 업그레이드 하는데 사용합니다.";
	upgrade[6].image.src = "image/upgrade/upgrade[6].png";
}
upgrade[7] = new iteM;
{
	upgrade[7].name = "high unit upgrade";
	upgrade[7].text = "기타(etc...)에 해당하는 유닛들을 업그레이드 하는데 사용합니다.";
	upgrade[7].image.src = "image/upgrade/upgrade[7].png";
}
upgrade[8] = new iteM;
{
	upgrade[8].name = "special unit upgrade";
	upgrade[8].text = "특수(special)에 해당하는 유닛들을 업그레이드 하는데 사용합니다.";
	upgrade[8].image.src = "image/upgrade/upgrade[8].png";
}