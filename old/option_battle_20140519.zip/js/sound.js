function change_sound_status(option)
{
	if(option=="bgm"){
		if(music_status=="on") music_status="off";
		else music_status ="on";
	}
	else if(option=="sound"){
		if(sound_status=="on") sound_status="off";
		else sound_status ="on";
	}
	//사운드 on/off버튼 체크
	if(sound_status == "off")
		document.getElementById("sound_button").value = " SOUND ON  ";
	else
		document.getElementById("sound_button").value = " SOUND OFF ";
	//---------------------------//
	if(music_status == "off")
		document.getElementById("bgm_button").value = " MUSIC ON  ";
	else
		document.getElementById("bgm_button").value = " MUSIC OFF ";
}
//배경음악공간
var music_status = "on";
var music = new Array(1);
music[0] = document.getElementById("bgm_main");


//소리의 중첩재생?을 위한 도구, sound_counter는 배열의 4번을 의미;
//반드시 사운드 배열은 5개로 만드시오!
//사용공식 : if(sound_???[sound_counter] > sound_max ) sound_???[sound_counter] = 0;
var sound_status = "on";
var sound = new Array(400);
var sound_counter = 5;
sound[0] = document.getElementById("headshot1");
sound[1] = document.getElementById("headshot1");
sound[2] = document.getElementById("headshot2");
sound[3] = document.getElementById("headshot3");
sound[4] = document.getElementById("headshot4");
sound[5] = 0; // counter;
sound[6] = document.getElementById("heal1");
sound[7] = document.getElementById("heal2");
sound[8] = document.getElementById("heal3");
sound[9] = document.getElementById("heal4");
sound[10] = 0; // counter;
sound[11] = document.getElementById("hyper1");
sound[12] = document.getElementById("hyper2");
sound[13] = document.getElementById("hyper3");
sound[14] = document.getElementById("hyper4");
sound[15] = 0; // counter;
sound[16] = document.getElementById("kill1");
sound[17] = document.getElementById("kill2");
sound[18] = document.getElementById("kill3");
sound[19] = document.getElementById("kill4");
sound[20] = 0;
sound[21] = document.getElementById("laser1");
sound[22] = document.getElementById("laser2");
sound[23] = document.getElementById("laser3");
sound[24] = document.getElementById("laser4");
sound[25] = 0;
sound[26] = document.getElementById("rocket1");
sound[27] = document.getElementById("rocket2");
sound[28] = document.getElementById("rocket3");
sound[29] = document.getElementById("rocket4");
sound[30] = 0;
sound[31] = document.getElementById("bomb1");
sound[32] = document.getElementById("bomb2");
sound[33] = document.getElementById("bomb3");
sound[34] = document.getElementById("bomb4");
sound[35] = 0;
sound[36] = document.getElementById("highattack1");
sound[37] = document.getElementById("highattack2");
sound[38] = document.getElementById("highattack3");
sound[39] = document.getElementById("highattack4");
sound[40] = 0;
sound[41] = document.getElementById("shot1");
sound[42] = document.getElementById("shot2");
sound[43] = document.getElementById("shot3");
sound[44] = document.getElementById("shot4");
sound[45] = 0;
sound[46] = document.getElementById("highattackdamage1");
sound[47] = document.getElementById("highattackdamage2");
sound[48] = document.getElementById("highattackdamage3");
sound[49] = document.getElementById("highattackdamage4");
sound[50] = 0;
sound[51] = document.getElementById("multishot_arrow1");
sound[52] = document.getElementById("multishot_arrow2");
sound[53] = document.getElementById("multishot_arrow3");
sound[54] = document.getElementById("multishot_arrow4");
sound[55] = 0;
sound[56] = document.getElementById("select_move1");
sound[57] = document.getElementById("select_move2");
sound[58] = document.getElementById("select_move3");
sound[59] = document.getElementById("select_move4");
sound[60] = 0;
sound[61] = document.getElementById("select_back1");
sound[62] = document.getElementById("select_back2");
sound[63] = document.getElementById("select_back3");
sound[64] = document.getElementById("select_back4");
sound[65] = 0;
sound[66] = document.getElementById("select_menu1");
sound[67] = document.getElementById("select_menu2");
sound[68] = document.getElementById("select_menu3");
sound[69] = document.getElementById("select_menu4");
sound[70] = 0;
sound[71] = document.getElementById("upgrade1");
sound[72] = document.getElementById("upgrade2");
sound[73] = document.getElementById("upgrade3");
sound[74] = document.getElementById("upgrade4");
sound[75] = 0;
sound[76] = document.getElementById("score1");
sound[77] = document.getElementById("score2");
sound[78] = document.getElementById("score3");
sound[79] = document.getElementById("score4");
sound[80] = 0;
sound[81] = document.getElementById("buzzer1");
sound[82] = document.getElementById("buzzer2");
sound[83] = document.getElementById("buzzer3");
sound[84] = document.getElementById("buzzer4");
sound[85] = 0;
sound[86] = document.getElementById("bubble1");
sound[87] = document.getElementById("bubble2");
sound[88] = document.getElementById("bubble3");
sound[89] = document.getElementById("bubble4");
sound[90] = 0;
sound[91] = document.getElementById("thunder1");
sound[92] = document.getElementById("thunder2");
sound[93] = document.getElementById("thunder3");
sound[94] = document.getElementById("thunder4");
sound[95] = 0;
sound[96] = document.getElementById("thunderdamage1");
sound[97] = document.getElementById("thunderdamage2");
sound[98] = document.getElementById("thunderdamage3");
sound[99] = document.getElementById("thunderdamage4");
sound[100] = 0;

var sound_effect = new Array(10); // 단일 효과음을 의미
sound_effect[0] = document.getElementById("select_enter");
sound_effect[1] = document.getElementById("select_enter");
sound_effect[2] = document.getElementById("boss_kill");
sound_effect[3] = document.getElementById("skz1024_opening");
sound_effect[4] = document.getElementById("combination");
sound_effect[5] = document.getElementById("score1");

function sound_output(code)
{
  if(sound_status=="on"){
	var line=0;
	if(code==0) line=1;
	else if(code=="headshot") line=1;
	else if(code=="heal") line=2;
	else if(code=="hyper") line=3;
	else if(code=="kill") line=4;
	else if(code=="laser") line=5;
	else if(code=="rocket") line=6;
	else if(code=="bomb") line=7;
	else if(code=="highattack") line=8;
	else if(code=="shot") line=9;
	else if(code=="highattackdamage") line=10;
	else if(code=="multishot_arrow") line=11;
	else if(code=="select_move") line=12;
	else if(code=="select_back") line=13;
	else if(code=="select_menu") line=14;
	else if(code=="upgrade") line=15;
	else if(code=="score") line=16;
	else if(code=="buzzer") line=17;
	else if(code=="bubble") line=18;
	else if(code=="thunder") line=19;
	else if(code=="thunderdamage") line=20;
	else line=code;
	
	var output=0;
	if(sound[line*5]==0||sound[line*5]>=5){ sound[line*5]=1; }
	output = sound[line*5];
	sound[ (output%5) + ((line*5) - 5) ].play();
	sound[line*5]++;
  }
}
function sound_shot(code)
{
	if(code=="hyper") sound_output("hyper");
	else if(code=="direct") sound_output("highattack");
	//else if(code=="heal") sound_output("heal");
	else if(code=="laserABC") sound_output("laser");
	else if(code=="splash") sound_output("rocket");
	else if(code=="bubble") sound_output("bubble");
	else if(code=="thunder") sound_output("thunder");
	else if(code=="multishot_arrow") sound_output("multishot_arrow");
}
function sound_effect_output(code)
{
  if(sound_status=="on"){
	var line=0;
	if(code=="select_enter") line=1;
	else if(code=="boss_kill") line=2;
	else if(code=="skz1024_opening") line=3;
	else if(code=="combination") line=4;
	else if(code=="score") line=5;
	else line=code;
	
	sound_effect[line].play();
  }
}