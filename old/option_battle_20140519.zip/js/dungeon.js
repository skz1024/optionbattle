function dungeoN()
{
	this.round = 1;
	this.subround = 1;
	this.name = "";
	this.type = "";
	this.time = 100;
	this.enemy_create = 100;
	this.enemy = new Array(10);
}
function dungeon_input(number,round,subround,name,type,time,enemy_create)
{
	dungeon[number].round = round;
	dungeon[number].subround = subround;
	dungeon[number].name = name;
	dungeon[number].type = type;
	dungeon[number].time = time;
	dungeon[number].enemy_create = enemy_create;
	for(a=0;a<10;a++){
		dungeon[number].enemy[a] = new Array(10);
	}
}
var dungeonoption = { enemyhp:1, enemyattack:2, enemyspeed:3 };
var dungeon = new Array(100);

dungeon[0] = new dungeoN;
dungeon[1] = new dungeoN;
{
	
}
dungeon_input(1,1,1,"파란 행성 초반부1","normal",11,3);
dungeon[2] = new dungeoN;
{
	
}
dungeon_input(2,1,2,"파란 행성 초반부2","normal",208,140);
dungeon[3] = new dungeoN;
{
	
}
dungeon_input(3,1,3,"파란 행성 하늘구역1","normal",177,121);
dungeon[4] = new dungeoN;
{
	
}
dungeon_input(4,1,4,"파란 행성 하늘구역2","normal",170,119);