//-----------------
//배경화면
function display_top()
{
    //----------------------//
    ctx.beginPath();
    ctx.moveTo(0,30);
    ctx.lineTo(600,30);
    ctx.strokeStyle="#000000";
    ctx.stroke();
    ctx.closePath();
	
    //-------시간표시-------//
    var time_percent;
    ctx.fillStyle="#000000";
    ctx.font = "18px arial";
    ctx.fillText("TIME : "+time_sec,5,20);
    //----------------------//
    time_percent = (time_sec/time_max)*100;
    if(time_percent>25)     ctx.fillStyle="black";
    else if(time_percent>10&&time_percent<=25)  ctx.fillStyle="orange";
    else                    ctx.fillStyle="red";
    ctx.fillRect(120,5,((time_percent*(600-120)/100)),20);
}
function display_bottom()
{
    ctx.beginPath();
    ctx.moveTo(0,450);
    ctx.lineTo(600,450);
    ctx.strokeStyle="black";
    ctx.stroke();
    ctx.closePath();
}
function display_clear()
{
    ctx.clearRect(0,0,640,480);
}
function backgrounD()
{
    this.image = new Image();
    this.image.src = "";
    this.x=0;
    this.y=0;
    this.x_size;
    this.y_size;
    this.scrool;
    this.effect;
}
background_title = new backgrounD;
{
    background_title.image.src = "image/background/title.png";
    background_title.notice_counter=0;
    background_title.select=0;
    background_title.x=0;
    background_title.arrow = new Image();
    background_title.arrow.src = "image/system/arrow.png";
    background_title.title = new Image();
    background_title.title.src = "image/system/title.png";
    background_title.my = new Image();
    background_title.my.src = "image/system/my.png";
}
background_title.display = function()
{
    ctx.drawImage(this.image, this.x, this.y);
    ctx.drawImage(background_title.title, 100,40);
    ctx.drawImage(background_title.my, 290,120);
    //--------------------------
    ctx.fillStyle = "#004C63";
    ctx.font = "20px arial";
    ctx.fillText("START",460,280);
    ctx.fillText("OPTION",460,320);
    ctx.fillText("HELP",460,360);
    ctx.fillText("skz1024 blog",460,400);
    ctx.drawImage(background_title.arrow,350,250+(background_title.select*40));
    //--------------------------
    ctx.fillStyle = "black";
    ctx.fillText("ENTER or Z key to SELECT(선택)",50,350);
    ctx.fillText("X or ESC key to CANCEL(취소)",50,375);
    ctx.fillText("Arrow key to MOVE cursor(커서 이동)",50,400);
    
    ctx.fillStyle = "gold";
    ctx.fillText("created by skz1024",10,440);
    ctx.fillText("Ver 0.050, 2014/05/19(day)",10,465);
};
background_option = new backgrounD;
{
	background_option.image.src ="image/background/title.png";
	background_option.select = 0;
	background_option.sound_test = 0;
	background_option.sound_effect = 0;
	background_option.music_test = 0;
	background_option.arrow = new Image();
	background_option.arrow.src = "image/system/arrow.png";
	background_option.title = new Image();
	background_option.title.src = "image/system/title.png";
}
background_option.display = function()
{
	ctx.drawImage(background_option.image, 0,0);
	ctx.drawImage(background_option.title, 100,40);
    ctx.fillStyle = "#004C63";
    ctx.font = "20px arial";
    ctx.fillText("SOUND : "+sound_status,250,220);
    ctx.fillText("MUSIC : "+music_status,250,260);
    ctx.fillText("SOUND TEST : "+background_option.sound_test,250,300);
    ctx.fillText("SOUND EFFECT : "+background_option.sound_effect,250,340);
    ctx.fillText("MUSIC TEST : "+background_option.music_test,250,380);
    ctx.fillText("EXIT",250,440);
    if(background_option.select<5){
    ctx.drawImage(background_option.arrow,150,190+(background_option.select*40));
    }
    else{
    ctx.drawImage(background_option.arrow,150,210+(background_option.select*40));	
    }
};
background_main = new backgrounD;
{
	background_main.image.src ="image/background/main.png";
	background_main.exp_meter = new Image();
	background_main.exp_meter.src ="image/system/user_exp.png";
	background_main.fuel_meter = new Image();
	background_main.fuel_meter.src ="image/system/user_fuel.png";
	background_main.arrow = new Image();
	background_main.arrow.src = "image/system/arrow2.png";
	background_main.user_status = new Image();
	background_main.user_status.src ="image/system/user_status.png";
	background_main.menu = new Image();
	background_main.menu.src = "image/system/menu.png";
	background_main.keyhelp = new Image();
	background_main.keyhelp.src = "image/system/keyhelp.png";
	background_main.select = 0;
	background_main.delay = 100;
	background_main.x = 0;
}
background_main.display = function()
{
	ctx.drawImage(background_main.image,0,0);
	ctx.drawImage(background_main.user_status,0-this.x,0);
	var exp_percent = (user.exp/exptable[user.lv]);
	ctx.drawImage(this.exp_meter,3-this.x,86,(exp_percent*241),27);
	var fuel_percent = (user.fuel/user.fuel_max);
	ctx.drawImage(this.fuel_meter,335-this.x,79,(fuel_percent*298),34);
	ctx.drawImage(this.keyhelp,380-this.x,132);
	
	ctx.fillStyle = "#778899"; // 레벨 표시
	ctx.font = "44px arial";
	ctx.fillText(user.lv,89-this.x,44);
	
	ctx.fillStyle = "#32CD42"; // 경험치 표시
	ctx.font = "24px arial";
	ctx.fillText(user.exp+"/"+exptable[user.lv],90-this.x,73);
	
	ctx.fillStyle = "gold"; // 골드 표시
	ctx.font = "24px arial";
	ctx.fillText(user.gold,418-this.x,32);
	
	ctx.fillStyle = "#48D1CC"; // 연료 표시
	ctx.font = "24px arial";
	ctx.fillText(user.fuel+"/"+user.fuel_max,418-this.x,65);
	
	ctx.fillStyle = "#FEBFFF"; // 크리스탈 표시
	ctx.font = "36px arial";
	ctx.fillText(user.crystal,590-this.x,63);
	
	ctx.drawImage(this.menu,0-this.x,120);
	ctx.drawImage(this.arrow,140-this.x,170+(this.select*30));
	ctx.fillStyle = "black";
	ctx.font = "18px arial";
	ctx.fillText("던전(dungeon)",10-this.x,200);
	ctx.fillText("파티(party)",10-this.x,230);
	ctx.fillText("조합(combination)",10-this.x,260);
	ctx.fillText("인벤토리(inventory)",10-this.x,290);
	ctx.fillText("상점(shop)",10-this.x,320);
	ctx.fillText("종료(exit)",10-this.x,350);
	
	ctx.fillText("인벤토리에서 판매 또는",5-this.x,410);
	ctx.fillText("유닛 강화가 가능합니다",5-this.x,440);
};
background_party = new backgrounD;
{
	background_party.image.src = "image/background/main.png";
	background_party.party = new Image();
	background_party.party.src = "image/background/party.png";
	background_party.select = 0;
	background_party.selectimage = new Image();
	background_party.selectimage.src = "image/system/select.png";
}
background_party.display = function()
{
	ctx.drawImage(background_party.image,0,0);
	ctx.drawImage(background_party.party,0,0);
	var partyhp=0;
	for(number=0;number<12;number++){
        var input = user.teamunit[number][teamoption.code];
        unit[input].display((64*[number%3])+80,(64*[parseInt(number/3)])+120);
        partyhp+=unit_stat_check("hp",input,user.teamunit[number][teamoption.lv]);
	}
	ctx.drawImage(this.selectimage,(64*[this.select%3])+75,(64*[parseInt(this.select/3)])+115);
	
	var totalhp = partyhp + user.hp_max;
	ctx.font = "24px arial";
	ctx.fillStyle = "black";
	ctx.fillText("Party total HP : "+partyhp+" + "+user.hp_max+" = "+totalhp,50,430);
};
background_shop = new backgrounD;
{
	background_shop.image.src = "image/background/shop.png";
}
background_shop.display = function()
{
	ctx.drawImage(background_shop.image,0,0);
};
background_inventory = new backgrounD;
{
	background_inventory.image.src = "image/background/main.png";
	background_inventory.selectimage = new Image();
	background_inventory.selectimage.src = "image/system/select.png";
	background_inventory.inventory = new Image();
	background_inventory.inventory.src = "image/system/inventory.png";
	background_inventory.page = 0;
	background_inventory.page_max = Math.floor(user.inventory_max/50);
	background_inventory.select = 0;
	background_inventory.keyhelp = new Image();
	background_inventory.keyhelp.src = "image/system/keyhelp.png";
}
background_inventory.display = function()
{
	ctx.drawImage(background_inventory.image,0,0);
	ctx.drawImage(background_inventory.inventory,0,0);
	ctx.drawImage(background_inventory.keyhelp,368,11);
	if(background_inventory.page <= 0) background_inventory.page=1;
	if(background_inventory.select <= 0) background_inventory.select=0;
	background_inventory.page_max = Math.floor(user.inventory_max/50);
	ctx.fillStyle = "black";
	ctx.font = "24px arial";
	ctx.fillText(user.inventory_use+"/"+user.inventory_max,89,87);
	ctx.fillText(this.page+"/"+this.page_max,89,117);
	
	inventory_check();
	var start = 0 + (background_inventory.page-1)*50;
	var end = 0 + (background_inventory.page)*50;
	for( a=start,b=0 ; a<end ;a++,b++){
		var code = user.inventory[a][inventoryoption.code];
		var type = user.inventory[a][inventoryoption.type];
		if(type==inventory_type.unit){
			unit[code].display( 10+((b%10)*63) , 150+(Math.floor(b/10)*63) );
		}
		else if(type==inventory_type.item){
			item[code].display( 10+((b%10)*63) , 150+(Math.floor(b/10)*63) );
		}
		else if(type==inventory_type.upgrade){
			upgrade[code].display( 10+((b%10)*63) , 150+(Math.floor(b/10)*63) );
		}
		
	}
	var cursor = background_inventory.select - ((this.page-1)*50);
	ctx.drawImage(background_inventory.selectimage,4+((cursor%10)*63),145+(Math.floor(cursor/10)*63));
};
background_unitview = new backgrounD;
{
	background_unitview.image.src = "image/background/main.png";
	background_unitview.code = 0;
	background_unitview.unitview = new Image();
	background_unitview.unitview.src = "image/system/unitview.png";
	background_unitview.upgrade = new Image();
	background_unitview.upgrade.src = "image/system/upgrade.png";
	background_unitview.back = new Image();
	background_unitview.back.src = "image/system/back.png";
	background_unitview.sell = new Image();
	background_unitview.sell.src = "image/system/sell.png";
	background_unitview.button = new Image();
	background_unitview.button.src = "image/system/button.png";
	background_unitview.select = 0;
}
background_unitview.display = function()
{
	ctx.drawImage(this.image,0,0);
	ctx.drawImage(this.unitview,0,0);
	ctx.drawImage(this.back,10,390);
	ctx.drawImage(this.upgrade,130,390);
	ctx.drawImage(this.sell,250,390);
	ctx.drawImage(this.button,10+(this.select*120),390);
	
	ctx.font = "24px arial";
	if(user.inventory[this.code][inventoryoption.type]==inventory_type.unit){
		var code = user.inventory[this.code][inventoryoption.code];
		var rank = user.inventory[this.code][inventoryoption.rank];
		var lv = user.inventory[this.code][inventoryoption.lv];
		var attack = unit_stat_check("attack",code,lv);
		var hp = unit_stat_check("hp",code,lv);
		var delay = unit[code].delay;
		
		ctx.fillStyle = "#0C0200";
		ctx.fillRect(240,100,380,250);
		
		unit[code].display(20,100,192,192);
		ctx.fillStyle = "orange";
		ctx.fillText("NAME : "+unit[code].name,250,130);
		ctx.fillStyle = "pink";
		ctx.fillText("HP : "+hp,450,130);
		ctx.fillStyle = "#6B9900";
		ctx.fillText("LV : "+lv+" / "+unit[code].maxlv*rank,250,160);
		ctx.fillText("RANK : "+rank+" / "+unit[code].maxrank,450,160);

		ctx.fillStyle = "#A84E19";
		ctx.fillText("ATK : "+attack,250,190);
		ctx.fillStyle = "#FFBA85";
		ctx.fillText("DELAY : "+delay[0],450,190);
		
		ctx.fillStyle = "skyblue";
		ctx.fillText("TYPE : "+unit[code].type,250,220);
		ctx.fillStyle = "#E0B94F";
		ctx.fillText("ATTACK2 : "+unit[code].skill,250,250);
		ctx.fillText("DELAY : "+delay[1],250,280);
		ctx.fillText("ATTACK3 : "+unit[code].skill,250,310);
		ctx.fillText("DELAY : "+delay[2],250,340);
	}
	else if(user.inventory[this.code][inventoryoption.type]==inventory_type.item){
		var code = user.inventory[this.code][inventoryoption.code];
		var name = item[code].name;
		var text = item[code].text;
		
		item[code].display(20,100,192,192);
		ctx.fillStyle = "darkgreen";
		ctx.fillText(name,10,320);
		ctx.fillStyle = "darkblue";
		ctx.fillText(text,10,350);
	}
	else if(user.inventory[this.code][inventoryoption.type]==inventory_type.upgrade){
		var code = user.inventory[this.code][inventoryoption.code];
		var name = upgrade[code].name;
		var text = upgrade[code].text;
		
        upgrade[code].display(20,100,192,192);
		ctx.fillStyle = "darkgreen";
		ctx.fillText(name,10,320);
		ctx.fillStyle = "darkblue";
		ctx.fillText(text,10,350);
	}
};
background_combination = new backgrounD;
{
	background_combination.image.src = "image/background/main.png";
	background_combination.making = new Image();
	background_combination.making.src = "image/background/making.png";
	background_combination.mode = 1;
	background_combination.round = 1;
	background_combination.select = 0;
	background_combination.cursor = new Image();
	background_combination.cursor.src = "image/system/select.png";
	background_combination.arrow = new Image();
	background_combination.arrow.src = "image/system/arrow2.png";
}
background_combination.display = function()
{
	ctx.drawImage(background_combination.image,0,0);
	ctx.drawImage(background_combination.making,0,0);
	ctx.drawImage(background_combination.arrow,80,12+(this.round*45));
	if(background_combination.mode == 1)
	{
	    for(a=0;a<9;a++){
	    	var type = combination[a].result[0];
	    	var code = combination[a].result[1];
	    	if(type == inventory_type.unit){
	    		unit[code].display(180+((a%7)*64),180+(Math.floor(a/7)*64));
	    	}
	    	else if(type == inventory_type.item){
	    		item[code].display(180+((a%7)*64),180+(Math.floor(a/7)*64));
	    	}
	    }
	    ctx.drawImage(this.cursor,175+((this.select%7)*64),175+(Math.floor(this.select/7)*64));
	    
	    for(a=0;a<6;a++){
	    	var code = combination[this.select].material[a];
	    	if(code==0) continue;
	    	
	    	item[code].display(244+((a%6)*64),336);
	    }
	    
	    ctx.font = "24px arial";
	    ctx.fillText("재료->",180,359);
	    ctx.fillText("필요한 골드 : "+combination[this.select].gold,180,430);
	    ctx.fillText("현재 골드 : "+user.gold,180,460);
	}
	
};
background_dungeon_select = new backgrounD;
{
	background_dungeon_select.image.src = "image/background/main.png";
	background_dungeon_select.arrow = new Image();
	background_dungeon_select.arrow.src = "image/system/arrow2.png";
	background_dungeon_select.menu = new Image();
	background_dungeon_select.menu.src = "image/system/list.png";
	background_dungeon_select.select = 0;
	background_dungeon_select.roundcode = 0;
	background_dungeon_select.mode = 0;
	background_dungeon_select.list = new Array();
	background_dungeon_select.list[0] = "1. 파란 행성";
	background_dungeon_select.list[1] = "!!자원 행성 - 은";
	background_dungeon_select.list[2] = "!!재료 행성 - 강화용";
	background_dungeon_select.list[3] = "2. 기계철강 공장";
	background_dungeon_select.list[4] = "3. 아즈테크 연구실";
	background_dungeon_select.list[5] = "!!자원 행성 - 금";
	background_dungeon_select.list[6] = "!!재료 행성 - 특수용";
	background_dungeon_select.list[7] = "4. 선택의 신전";
	background_dungeon_select.list[8] = "!!특수 던전 - 한계의 끝";
	background_dungeon_select.list[9] = "5. 악마의 마을";
}
background_dungeon_select.display = function()
{
	background_main.display();
	ctx.clearRect(0,120,196,360);
	ctx.drawImage(this.menu,0,120);
	
	if(background_dungeon_select.mode==0)
	{
	    ctx.font = "18px arial";
	    ctx.fillStyle = "#7D78FF";
	    ctx.fillText("back(뒤로가기)",10,200);
	    ctx.fillStyle = "black";
	    ctx.fillText(background_dungeon_select.list[0],10,230);
	    ctx.fillStyle = "darkblue";
	    ctx.fillText(background_dungeon_select.list[1],10,260);
	    ctx.fillText(background_dungeon_select.list[2],10,290);
	    ctx.fillStyle = "black";
	    ctx.fillText(background_dungeon_select.list[3],10,320);
	    ctx.fillText(background_dungeon_select.list[4],10,350);
	    ctx.fillStyle = "#CCA63D";
	    ctx.fillText(background_dungeon_select.list[5],10,380);
	    ctx.fillText(background_dungeon_select.list[6],10,410);
	    ctx.fillStyle = "black";
	    ctx.fillText(background_dungeon_select.list[7],10,440);
	    ctx.fillStyle = "#993800";
	    ctx.fillText("↓↓↓↓↓↓↓↓↓↓↓↓",10,470);
	    ctx.drawImage(background_dungeon_select.arrow,140,(this.roundcode*30)+170);
	}
	else if(background_dungeon_select.mode==1&&background_dungeon_select.roundcode==1)
	{
		ctx.font = "18px arial";
	    ctx.fillStyle = "black";
	    ctx.fillText("뒤로가기",10,200);
	    ctx.fillText(dungeon[1].name,10,230);
	    ctx.fillText(dungeon[2].name,10,260);
	    ctx.fillText(dungeon[3].name,10,290);
	    ctx.fillText(dungeon[4].name,10,320);
	    ctx.drawImage(background_dungeon_select.arrow,140,(this.select*30)+170);
	}
};
background_loading = new backgrounD;
{
	background_loading.image.src = "image/background/loading.png";
	background_loading.percent = 0;
	background_loading.status = 0;
	background_loading.count = 25;
}
background_loading.display = function()
{
	ctx.drawImage(this.image,0,0);
};

background_round01 = new backgrounD;
{
    background_round01.image.src = "image/background/stage01.png";
    background_round01.x=0;
    background_round01.y=0;
    background_round01.x_size=1280;
    background_round01.scrool=1;
}
background_round01.display = function()
{
	ctx.drawImage(this.image,0,0);
};
background_round02 = new backgrounD;
{
    background_round02.image.src = "image/background/stage02.png";
    background_round02.x=0;
    background_round02.y=0;
    background_round02.x_size=1280;
    background_round02.scrool=1;
}
background_round02.display = function()
{
	ctx.drawImage(this.image,0,0);
};

