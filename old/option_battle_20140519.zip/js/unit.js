unit = new Array(100);
enemy = new Array(100);
boss = new Array(10);
enemyunit = new Array(40);
for(a=0;a<20;a++){
    enemyunit[a] = new Array(20);
    for(b=0;b<20;b++) enemyunit[a][b]=0;
}
enemyoption = { line:0, number:1, code:2, hp:3, hp_max:4, x:5, y:6, count:7, delay:8, on:9, attack:10, defense:11, move_x:12, die:13, move_y:14 };
enemycount = 0;
//-----------------------------//
function uniT() // 유닛들은 이 클래스를 사용한다.
{
    this.name = "unknown"; // 유닛의 이름
    this.number = 0; // 유닛의 번호
    this.type = "unknown"; // 유닛의 타입(또는 속성)
    this.skill =""; // 유닛의 스킬(직업공격보다 우선선택됨)
    this.maxlv = 1; // 유닛의 최대레벨
    this.rank = 1; // 유닛의 랭크
    this.maxrank = 1; // 유닛의 최대랭크
    this.hp = 0; // 유닛의 체력(정의 안하면 0)
    this.hp_plus = 0; // 유닛의 체력 레벨당 증가량
    this.mp = 0; // 유닛의 마력(정의 안하면 0)
    this.mp_maxlv = 0; // 유닛의 마력 레벨당 증가량
    this.delay = [0,0,0]; //각 공격에 대한 지연카운트 총 3개
    this.attack = [0,0,0]; // 유닛의 공격력(정의 안하면 0) 총 3개
    this.image = new Image(); // 유닛의 이미지
    this.image.src = ""; // 유닛의 이미지 경로
    this.attackimage = new Array(3);
    this.attackimage[0] = new Image(); // 유닛의 공격 이미지(이건 없을수도 있음)
    this.attackimage[0].src = ""; // 유닛의 공격 이미지 경로(이건 없을수도 있음)
    this.attackimage[1] = new Image(); // 유닛의 공격 2번째 이미지(이건 없을수도 있음)
    this.attackimage[1].src = ""; // 유닛의 공격 2번째 이미지 경로(이건 없을수도 있음)
    this.attackimage[2] = new Image(); // 유닛의 공격 3번째 이미지(이건 없을수도 있음)
    this.attackimage[2].src = ""; // 유닛의 공격 3번째 이미지 경로(이건 없을수도 있음)
    this.defense=0;
}
uniT.prototype.meter = function(x,y,width,height){
    //유닛의 체력과 마력 게이지바를 나타내나(현실은 체력만 나타냄)
    /*var hp_percent = this.hp / this.hp_max;
    var mp_percent = this.mp / this.mp_max;
	
    ctx.strokeStyle = "black";
    ctx.fillStyle = "darkgrey";
    ctx.font = "8px arial";
    ctx.fillRect(x,y,(hp_percent*width),height);
    ctx.strokeRect(x,y,width,height);
    ctx.fillStyle = "darkblue";
    ctx.fillText("HP : "+this.hp+"/"+this.hp_max, x, (y+15));
    */
};
uniT.prototype.display = function(x,y,size_x,size_y){
    //유닛의 그림을 그립니다.
    if( size_x == null || size_y == null )
        ctx.drawImage(this.image,x,y);
    else
        ctx.drawImage(this.image,x,y,size_x,size_y);
};
//-----------------------------//
enemy[0] = new uniT();
{
    enemy[0].name = "unused";
}
enemy[1] = new uniT();{
    enemy[1].hp = 4444;
    enemy[1].number = 1;
    enemy[1].image.src = "image/enemy/enemy[1].png";
    enemy[1].defense = 192;
}
enemy[2] = new uniT();{
    enemy[2].hp = 5894;
    enemy[2].number = 2;
    enemy[2].image.src = "image/enemy/enemy[2].png";
    enemy[2].defense = 70;
}
enemy[3] = new uniT();{
    enemy[3].hp = 2087;
    enemy[3].number = 3;
    enemy[3].image.src = "image/enemy/enemy[3].png";
    enemy[3].defense = 186;
}
enemy[4] = new uniT();{
    enemy[4].hp = 4612;
    enemy[4].number = 4;
    enemy[4].image.src = "image/enemy/enemy[4].png";
    enemy[4].defense = 45;
}
enemy[5] = new uniT();{
    enemy[5].hp = 3298;
    enemy[5].number = 5;
    enemy[5].image.src = "image/enemy/enemy[5].png";
    enemy[5].defense = 322;
}
enemy[6] = new uniT();{
    enemy[1].hp = 5444;
    enemy[6].number = 6;
    enemy[6].image.src = "image/enemy/enemy[6].png";
    enemy[6].defense = 90;
}
enemy[7] = new uniT();{
    enemy[7].hp = 6017;
    enemy[7].number = 7;
    enemy[7].image.src = "image/enemy/enemy[7].png";
    enemy[7].defense = 34;
}
enemy[8] = new uniT();{
    enemy[8].hp = 7121;
    enemy[8].number = 8;
    enemy[8].image.src = "image/enemy/enemy[8].png";
    enemy[8].defense = 113;
}
enemy[9] = new uniT();{
    enemy[9].hp = 5644;
    enemy[9].number = 9;
    enemy[9].image.src = "image/enemy/enemy[9].png";
    enemy[9].defense = 211;
}
enemy[10] = new uniT();{
    enemy[10].hp = 7144;
    enemy[10].number = 10;
    enemy[10].image.src = "image/enemy/enemy[10].png";
    enemy[10].defense = 445;
}
enemy[11] = new uniT();{
    enemy[11].hp = 300000;
    enemy[11].number = 11;
    enemy[11].image.src = "image/enemy/enemy[11].png";
    enemy[11].defense = 0;
}
//-----------------------------//
//참고사항
//랭크당 공격력 증가하는양은 기본값에 20%씩 증가합니다.
//랭크당 체력 증가하는양은 임의의 상수를 집어넣습니다.(내 맘대로 넣을거임!?)
unit[0] = new uniT();
{
	unit[0].image.src = "image/system/unused.png";
	unit[0].name = "unused";
}
unit[1] = new uniT();
{
	unit[1].image.src = "image/unit/unit[1].png";
	unit[1].attackimage[0].src = "image/attack/unit[1].attack.png";
	unit[1].attackimage[1].src = "image/attack/unit[1].hyper.png";
}
unit_stat_setting(1,"대포","hyper","",1,4,10,1000,300,2000);
unit[2] = new uniT();
{
	unit[2].image.src = "image/unit/unit[2].png";
	unit[2].attackimage[0].src = "image/attack/unit[2].attack.png";
	unit[2].attackimage[1].src = "image/attack/unit[2].hyper.png";
}
unit_stat_setting(2,"캐논","hyper","",1,4,10,1000,300,2800);
unit[3] = new uniT();
{
	unit[3].image.src = "image/unit/unit[3].png";
	unit[3].attackimage[0].src = "image/attack/unit[3].attack.png";
	unit[3].attackimage[1].src = "image/attack/unit[3].multishot.png";
}
unit_stat_setting(3,"멀티샷","multishot","",1,4,10,1000,300,450);
unit[4] = new uniT();
{
	unit[4].image.src = "image/unit/unit[4].png";
	unit[4].attackimage[0].src = "image/attack/unit[4].attack.png";
	unit[4].attackimage[1].src = "image/attack/unit[4].headshot.png";
}
unit_stat_setting(4,"총","multishot","headshot",1,4,10,1000,300,550);
unit[5] = new uniT();
{
	unit[5].image.src = "image/unit/unit[5].png";
	unit[5].attackimage[0].src = "image/attack/unit[5].attack.png";
}
unit_stat_setting(5,"힘력","etc","buff_powerup",1,4,10,1000,300,18179);
unit[6] = new uniT();
{
	unit[6].image.src = "image/unit/unit[6].png";
	unit[6].attackimage[0].src = "image/attack/unit[6].attack.png";
	unit[6].attackimage[1].src = "image/attack/unit[6].laserA.png";
	unit[6].attackimage[2].src = "image/attack/unit[6].laserB.png";
}
unit_stat_setting(6,"수레차","special","laserABC",1,4,20,4128,892,3298);
unit[7] = new uniT();
{
	unit[7].image.src = "image/unit/unit[7].png";
	unit[7].attackimage[0].src = "image/attack/unit[7].attack.png";
	unit[7].attackimage[1].src = "image/attack/unit[7].highattack.png";
}
unit_stat_setting(7,"스워드검","direct","highattack",1,4,10,1000,300,2100);
unit[8] = new uniT();
{
	unit[8].image.src = "image/unit/unit[8].png";
	unit[8].attackimage[0].src = "image/attack/unit[8].attack.png";
	unit[8].attackimage[1].src = "image/attack/unit[8].multishot.png";
}
unit_stat_setting(8,"보우활","multishot","multishot_arrow",1,4,10,1000,300,480);
unit[9] = new uniT();
{
	unit[9].image.src = "image/unit/unit[9].png";
	unit[9].attackimage[0].src = "image/attack/unit[9].attack.png";
	unit[9].attackimage[1].src = "image/attack/unit[9].attack2.png";
}
unit_stat_setting(9,"공구상자","heal","",1,4,10,1600,500,800);
unit[10] = new uniT();
{
	unit[10].image.src = "image/unit/unit[10].png";
	unit[10].attackimage[0].src = "image/attack/unit[10].attack.png";
}
unit_stat_setting(10,"구급상자","heal","",1,4,10,1600,500,800);
unit[11] = new uniT();
{
	unit[11].image.src = "image/unit/unit[11].png";
	unit[11].attackimage[0].src = "image/attack/unit[11].attack.png";
}
unit_stat_setting(11,"연구원","splash","",1,4,15,600,120,1814);
unit[12] = new uniT();
{
	unit[12].image.src = "image/unit/unit[12].png";
	unit[12].attackimage[0].src = "image/attack/unit[12].attack.png";
}
unit_stat_setting(12,"조종자","splash","",1,4,15,600,120,2078);
unit[13] = new uniT();
{
	unit[13].image.src = "image/unit/unit[13].png";
	unit[13].attackimage[0].src = "image/attack/unit[13].attack.png";
}
unit_stat_setting(13,"빨간색_동그라미","splash","",1,4,15,600,120,1966);
unit[14] = new uniT();
{
	unit[14].image.src = "image/unit/unit[14].png";
	unit[14].attackimage[0].src = "image/attack/unit[14].attack.png";
	unit[14].attackimage[1].src = "image/attack/unit[14].hyper.png";
}
unit_stat_setting(14,"갈색_동그라미","hyper","",1,4,10,1000,300,2800);
unit[15] = new uniT();
{
	unit[15].image.src = "image/unit/unit[15].png";
	unit[15].attackimage[0].src = "image/attack/unit[15].attack.png";
	unit[15].attackimage[1].src = "image/attack/unit[15].multishot.png";
}
unit_stat_setting(15,"회색_동그라미","multishot","",1,4,10,1000,300,420);
unit[16] = new uniT();
{
	unit[16].image.src = "image/unit/unit[16].png";
	unit[16].attackimage[0].src = "image/attack/unit[16].attack.png";
	unit[16].attackimage[1].src = "image/attack/unit[16].highattack.png";
}
unit_stat_setting(16,"파란색_동그라미","direct","highattack",1,4,10,1000,300,1700);
unit[17] = new uniT();
{
	unit[17].image.src = "image/unit/unit[17].png";
	unit[17].attackimage[0].src = "image/attack/unit[17].attack.png";
}
unit_stat_setting(17,"연두색_동그라미","heal","",1,4,10,1600,500,800);
unit[18] = new uniT();
{
	unit[18].image.src = "image/unit/unit[18].png";
	unit[18].attackimage[0].src = "image/attack/unit[18].attack.png";
	unit[18].attackimage[1].src = "image/attack/unit[18].multishot.png";
}
unit_stat_setting(18,"하얀색_구름","multishot","bubble",1,4,10,1900,582,696);
unit[19] = new uniT();
{
	unit[19].image.src = "image/unit/unit[19].png";
	unit[19].attackimage[0].src = "image/attack/unit[19].attack.png";
	unit[19].attackimage[1].src = "image/attack/unit[19].thunder_combo.png";
}
unit_stat_setting(19,"검은색_구름","etc","thunder",1,4,10,1900,582,2377);
unit[20] = new uniT();
{
	unit[20].image.src = "image/unit/unit[20].png";
	unit[20].attackimage[0].src = "image/attack/unit[20].attack.png";
	unit[20].attackimage[1].src = "image/attack/unit[20].rainbow.png";
	unit[20].attackimage[2].src = "image/attack/unit[20].mixcolor.png";
}
unit_stat_setting(20,"무지개색_동그라미","special","rainbow_color",1,4,10,4400,765,2884);

function unit_upgrade_gold(lv)
{
	var gold=0;
	switch(lv){
		case 0: gold=1500; break;
		case 1: gold=1500; break;
		case 2: gold=1500; break;
		case 3: gold=1500; break;
		case 4: gold=1500; break;
		case 5: gold=1500; break;
		case 6: gold=1800; break;
		case 7: gold=1800; break;
		case 8: gold=1800; break;
		case 9: gold=1800; break;
		case 10: gold=1800; break;
		case 11: gold=2200; break;
		case 12: gold=2300; break;
		case 13: gold=2400; break;
		case 14: gold=2500; break;
		case 15: gold=2600; break;
		case 16: gold=3000; break;
		case 17: gold=3000; break;
		case 18: gold=3200; break;
		case 19: gold=3400; break;
		case 20: gold=3600; break;
		case 21: gold=4400; break;
		case 22: gold=4400; break;
		case 23: gold=4700; break;
		case 24: gold=4700; break;
		case 25: gold=5000; break;
		case 26: gold=5600; break;
		case 27: gold=5600; break;
		case 28: gold=5600; break;
		case 29: gold=5600; break;
		case 30: gold=5600; break;
		case 31: gold=7200; break;
		case 32: gold=7200; break;
		case 33: gold=7200; break;
		case 34: gold=7200; break;
		case 35: gold=7200; break;
		case 36: gold=8100; break;
		case 37: gold=8700; break;
		case 38: gold=9300; break;
		case 39: gold=10200; break;
		case 40: gold=11500; break;
		case 41: gold=4800; break;
		case 42: gold=5500; break;
		case 43: gold=6300; break;
		case 44: gold=7000; break;
		case 45: gold=7700; break;
		case 46: gold=5300; break;
		case 47: gold=5300; break;
	}
	return gold;
}
//-------------------------------
function unit_stat_setting(number,name,type,skill,rank,maxrank,maxlv,hp,hp_plus,attack)
{
	unit[number].number = number; // 숫자, 번호를 의미
	unit[number].name = name; // 문자, 이름
	unit[number].type = type; // 문자, 특성
	unit[number].skill = skill; // 문자, 스킬(특성보다 우선적용)
	unit[number].rank = rank; // 시작랭크
	unit[number].maxrank = maxrank; // 최대랭크
	unit[number].maxlv = maxlv; // (랭크당)최대레벨(주의 : 레벨*랭크가 최대로 올릴 수 있는 레벨임)
	unit[number].hp = hp; // HP
	unit[number].hp_plus = hp_plus; // HP 증가치(랭크당)
	unit[number].attack[0] = attack; // 공격력
	
	unit_type_setting(number);
	unit_skill_setting(number);
	
	for(a=0;a<3;a++){
		//소수점 버리기
		unit[number].delay[a] = Math.floor(unit[number].delay[a]);
		unit[number].attack[a] = Math.floor(unit[number].attack[a]);
	}
}
function unit_type_setting(number)
{
	var data = unit[number].type;
	
	//통상 기능
	if(data == "hyper" ){ // hyper 계열
		unit[number].attack[1] = unit[number].attack[0] * 2.8; // 2.8배수 특수공격
		unit[number].delay[0] = unit[number].attack[0] / 6; // 일반공격 효율 수치
		unit[number].delay[1] = unit[number].attack[1] / 24; // 특수공격 효율 수치
	}
	else if(data == "multishot" ){ // multishot
		unit[number].attack[1] = unit[number].attack[0] * 0.91; // 0.91배수 특수공격
		unit[number].delay[0] = unit[number].attack[0] / 15; // 일반공격 효율 수치
		unit[number].delay[1] = unit[number].attack[1] / 15; // 특수공격 효율 수치
	}
	else if(data == "direct" ){ // direct 계열
		unit[number].attack[1] = unit[number].attack[0] * 4; // 4배수 특수공격
		unit[number].delay[0] = unit[number].attack[0] / 18; // 일반공격 효율 수치
		unit[number].delay[1] = unit[number].attack[1] / 12; // 특수공격 효율 수치
	}
	else if(data == "heal" ){ // heal 계열
		unit[number].attack[1] = unit[number].attack[0] * 0.5; // 0.5배수 힐
		unit[number].delay[0] = unit[number].attack[0] / 5000; // 일반공격 효율 수치
		unit[number].delay[1] = unit[number].attack[1] / 5000; // 특수공격 효율 수치
	}
	else if(data == "splash" ){ // splash_damage 계열
		unit[number].delay[0] = unit[number].attack[0] / 6; // 일반공격 효율 수치
		//단, 이 유닛들은 특수공격이 없는 대신에 일반공격이 스플래시로 처리됨.
	}
	else if(data == "high" || data == "etc" ){ // 기타 계열
		unit[number].delay[0] = unit[number].attack[0] / 15; // 일반공격 효율 수치
		//단, 이 유닛들은 특수공격이 없는 대신에 스킬 공격이 존재한다.
	}
	else if(data == "special" ){ // 스페셜 계열
		unit[number].delay[0] = unit[number].attack[0] / 10; // 일반공격 효율 수치
		unit[number].delay[1] = unit[number].attack[1] / 10; // 일반공격 효율 수치
		//단, 이 유닛들은 모든 공격이 특수공격으로 처리되기 때문에 스킬설정에서
		//일일히 설정해야 한다. 여기서 써져있는 값은 기본값이다.
	}
}
function unit_skill_setting(number)
{
	var skilldata = unit[number].skill;
	
	if( skilldata == "headshot" ){
		unit[number].attack[1] = unit[number].attack[0] * 17; // 17배수 스킬공격(특수공격 없음)
		unit[number].delay[1] = unit[number].attack[1] / 15; // 스킬공격 효율 수치
	}
	else if ( skilldata == "bubble" ){
		unit[number].delay[1] = unit[number].delay[1] * 3;
	}
	else if ( skilldata == "multishot_arrow" ){
		unit[number].delay[1] = unit[number].delay[1] * 19;
	}
	else if ( skilldata == "laserABC" ){
	    unit[number].attack[1] = unit[number].attack[0] * 1.17;
	    unit[number].attack[2] = unit[number].attack[0] * 1.17;
	    unit[number].delay[0] = unit[number].attack[0] / 10;
	    unit[number].delay[1] = unit[number].attack[1] / 11;
	    unit[number].delay[2] = unit[number].attack[2] / 9;
	}
	/*else if ( skilldata == "thunder" ){
		unit[number].delay[1] = unit[number].attack[0] / 13;
		unit[number].attack[1] = unit[number].attack[0];
		unit[number].delay[0] = 0;
	}*/
	
	for(a=0;a<3;a++){
		//소수점 버리기
		unit[number].delay[a] = Math.floor(unit[number].delay[a]);
		unit[number].attack[a] = Math.floor(unit[number].attack[a]);
	}
}
function unit_stat_check(mode,code,lv)
{
	var value;
	
    if(mode=="attack"){
    	value = unit[code].attack[0] + ( (unit[code].attack[0]*0.3) / unit[code].maxlv ) * (lv-1);
    }
	else if(mode=="attack2"){
    	value = unit[code].attack[1] + ( (unit[code].attack[0]*0.3) / unit[code].maxlv ) * (lv-1);
    }
	else if(mode=="attack3"){
    	value = unit[code].attack[2] + ( (unit[code].attack[0]*0.3) / unit[code].maxlv ) * (lv-1);
    }
    else if(mode=="hp"){
    	value = unit[code].hp + ( (unit[code].hp_plus) / unit[code].maxlv ) * lv;
    }
    
    value = Math.floor(value);
    return value;
}