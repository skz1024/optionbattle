onkeydown = keyboard;
var gamekey = 0;
var key = { enter:13, esc:27, z:90, x:88, up:38, down:40, left:37, right:39 };
function keyboard(code)
{
    gamekey = event.keyCode;
    //event.returnValue = false;
    if(gamekey != 116) event.preventDefault();
    
    if(gamekey == key.z) gamekey = key.enter; // ENTER key == Z
    else if(gamekey == key.x) gamekey = key.esc; // ESC key == X
}
