var gamemode = { title:0, option:1 , opening:2, main:3, dungeon:4, party:5, upgrade:6, combination:7, inventory:8,
	shop:9, unit_view:10, unit_select:11, dungeon_select:12, loading:13 };
var gamestatus = gamemode.title;
var system_select = 0;
var change_window = 640;
var user_score = 0;

//게임 전역 함수
function game_global()
{
    user.exp_check();
}
//게임 화면 타이틀
function game_title()
{
	background_title.display();
	if(gamekey == 13){ // ENTER key
		sound_effect_output("select_enter");
		if(background_title.select == 0){
			gamestatus = gamemode.main;
		}
		else if(background_title.select == 1){
			gamestatus = gamemode.option;
		}
		else if(background_title.select == 2){
			
		}
		else if(background_title.select == 3){
			
		}
	}
	else if(gamekey == 38 && background_title.select > 0 ){ // UP key
		sound_output("select_move");
		background_title.select--;
	}
	else if(gamekey == 40 && background_title.select < 3 ){ // DOWN key
		sound_output("select_move");
		background_title.select++;
	}
	gamekey=0;
}
//게임 옵션 화면
function game_option()
{
	background_option.display();
	var sound_max = 16;
	var sound_effect_max = 4;
	var bgm_max = 0;
	if(gamekey == 13){ // ENTER key
		if(background_option.select == 5){
			gamestatus = gamemode.title;
			background_option.select = 0;
		}
		else if(background_option.select == 2){
			sound_output(background_option.sound_test);
		}
		else if(background_option.select == 3){
			sound_effect[background_option.sound_effect].play();
		}
	}
	else if(gamekey == 38 && background_option.select > 0 ){ // UP key
		background_option.select--;
	}
	else if(gamekey == 40 && background_option.select < 5 ){ // DOWN key
		background_option.select++;
	}
	else if((gamekey == 39 || gamekey ==37) && background_option.select==0){
		change_sound_status("sound");
	}
	else if((gamekey == 39 || gamekey ==37) && background_option.select==1){
		change_sound_status("bgm");
	}
	else if(gamekey == 37 ){ // LEFT key
		if(background_option.select == 2){
			background_option.sound_test--;
			if(background_option.sound_test < 0 || background_option.sound_test > sound_max) background_option.sound_test=0;
		}
		else if(background_option.select == 3){
			background_option.sound_effect--;
			if(background_option.sound_effect < 0 || background_option.sound_effect > sound_effect_max) background_option.sound_effect=0;
		}
		else if(background_option.select == 4){
			background_option.bgm_test--;
			if(background_option.bgm_test < 0 || background_option.bgm_test > 1) background_option.bgm_test=0;
		}
	}
	else if(gamekey == 39 ){ // RIGHT key
		if(background_option.select == 2){
			background_option.sound_test++;
			if(background_option.sound_test < 0 || background_option.sound_test > sound_max) background_option.sound_test=0;
		}
		else if(background_option.select == 3){
			background_option.sound_effect++;
			if(background_option.sound_effect < 0 || background_option.sound_effect > sound_effect_max) background_option.sound_effect=0;
		}
		else if(background_option.select == 4){
			background_option.bgm_test++;
			if(background_option.bgm_test < 0 || background_option.bgm_test > 1) background_option.bgm_test=0;
		}
	}
}
// 게임 메인화면
function game_main()
{
	user.status();
	background_main.display();
	var exit=0;
	if(gamekey == 38 && background_main.select > 0 ){ // UP key
		background_main.select--;
		sound_output("select_move");
	}
	else if(gamekey == 40 && background_main.select < 5 ){ // DOWN key
		background_main.select++;
		sound_output("select_move");
	}
	else if(gamekey == 13){
		if(background_main.select == 0){
			sound_output("select_menu");
			gamestatus = gamemode.dungeon_select;
		}
		else if(background_main.select == 1){
			sound_output("select_menu");
			gamestatus = gamemode.party;
		}
		else if(background_main.select == 2){
			sound_output("select_menu");
			gamestatus = gamemode.combination;
		}
		else if(background_main.select == 3){
			sound_output("select_menu");
			gamestatus = gamemode.inventory;
		}
		else if(background_main.select == 4){
			sound_output("select_menu");
			gamestatus = gamemode.shop;
		}
		else if(background_main.select == 5){
			sound_output("select_back");
			exit=confirm("정말로 나가시겠습니까?");
		}
	}
	else if(gamekey == key.esc){
		exit=confirm("정말로 나가시겠습니까?");
	}
	
	
	if(exit==true) gamestatus = gamemode.title;
}
function game_party()
{
	background_party.display();
	if(gamekey == 37 && background_party.select > 0 ){ // UP key
		background_party.select--;
		sound_output("select_move");
	}
	else if(gamekey == 39 && background_party.select < 11 ){ // DOWN key
		background_party.select++;
		sound_output("select_move");
	}
	else if(gamekey == 38 && background_party.select-3 >= 0 ){ // left
		background_party.select-=3;
		sound_output("select_move");
	}
	else if(gamekey == 40 && background_party.select+3 <= 11 ){ // right
		background_party.select+=3;
		sound_output("select_move");
	}
	else if(gamekey == key.esc){ // X key
		sound_output("select_back");
		gamestatus = gamemode.main;
	}
	else if(gamekey == key.enter ){
		gamestatus = gamemode.unit_select;
	}
}

function unit_select()
{
	background_inventory.display();
	ctx.clearRect(0,0,640,120);
	ctx.font = "24px arial";
	ctx.fillText("파티에 편성할 유닛을 선택해 주세요.",20,30);
	var cursor = background_inventory.select - ((this.page-1)*50);
	
	if(gamekey == key.esc){ // X key
		sound_output("select_back");
		gamestatus = gamemode.party;
	}
	else if(gamekey == 13 && user.inventory[background_inventory.select][inventoryoption.type]==inventory_type.unit){ // ENTER key
		var check=0;
		for(a=0;a<12;a++){
			if(user.teamunit[a][teamoption.inventory] == background_inventory.select) check++;
		}
		
		if(check==0){
		    sound_output("select_menu");
		    gamestatus = gamemode.party;
		    var code = user.inventory[background_inventory.select][inventoryoption.code];
		    var line = background_party.select;
		    var lv = user.inventory[background_inventory.select][inventoryoption.lv];
		    var inventory = background_inventory.select;
		    party_setting(line,code,lv,inventory);
		}
		else{
			alert("해당 유닛은 이미 파티에 편성되어 있습니다.");
		}
	}
	else if(gamekey == 13 && user.inventory[background_inventory.select][inventoryoption.type]!=inventory_type.unit){ // ENTER key
		sound_output("buzzer");
		alert("아이템들은 파티에 편성할 수 없습니다.");
	}
	else if(gamekey == 37){ // LEFT key
		sound_output("select_move");
		background_inventory.select--;
		if(background_inventory.select%10==9){
			if(background_inventory.page > 1){
			background_inventory.page--;
			background_inventory.select-=40;
		    }
			else background_inventory.select+=10;
		}
	}
	else if(gamekey == 39){ // RIGHT key
		sound_output("select_move");
		background_inventory.select++;
		if(background_inventory.select%10==0){
			if(background_inventory.page < background_inventory.page_max){
			background_inventory.page++;
			background_inventory.select+=40;
		    }
			else background_inventory.select-=10;
		}
	}
	else if(gamekey == 38){ // UP key
		if(background_inventory.select-10 > 50*(background_inventory.page-1)){
		    background_inventory.select-=10;
		    sound_output("select_move");
		}
		else{
			//background_inventory.select = ( background_inventory.select%10 )+ 40;
		}
	}
	else if(gamekey == 40){ // DOWN key
		if(background_inventory.select+10 < 50*background_inventory.page){
		    background_inventory.select+=10;
		    sound_output("select_move");
		}
		else{
			//background_inventory.select = background_inventory.select%10;
		}
	}
}
function game_combination()
{
	background_combination.display();
	inventory_check();
	if(gamekey == key.esc){ // X key
		sound_output("select_back");
		if(background_combination.mode==1) background_combination.mode=0;
		else gamestatus = gamemode.main;
	}
	else if(gamekey == 38){ // UP
		sound_output("select_move");
		if(background_combination.mode==0&&background_combination.round>1) background_combination.round--;
	}
	else if(gamekey == 40){ // DOWN
		sound_output("select_move");
		if(background_combination.mode==0&&background_combination.round<7) background_combination.round++;
	}
	else if(gamekey == 37){ // LEFT
		sound_output("select_move");
		if(background_combination.mode==1&&background_combination.select>0) background_combination.select--;
	}
	else if(gamekey == 39){ // RIGHT
		sound_output("select_move");
		if(background_combination.mode==1&&background_combination.select<8) background_combination.select++;
	}
	else if(gamekey == 13){
		if(background_combination.mode==0){
			background_combination.mode=1;
		}
		else if(background_combination.mode==1){
			if(background_combination.select!=0&&confirm("정말로 조합하시겠습니까?")){
				if(user.gold < combination[background_combination.select].gold){
					alert("골드가 부족하여 조합할 수 없습니다.");
				}
				else{
				    combination_progress();
				}
			}
		}
	}
}
function combination_progress()
{
	var make=0;
	var material = new Array(6);
	var delete_item = new Array(6);
	var a=0;
	for(a=0;a<6;a++){
		material[a] = combination[background_combination.select].material[a];
		if(material[a]==0){ delete_item[a]=null; make++; continue; }
					    
		for(b=0;b<user.inventory_max;b++){
			var type = user.inventory[b][inventoryoption.type];
			if(type!=inventory_type.item) continue;
					    	
			if(material[a]==user.inventory[b][inventoryoption.code]){
			var ok=0;
			for(c=0;c<6;c++){
			    if(delete_item[c]==b) ok++;
			}
			        	    	
			if(ok>0) {}
			else { make++; delete_item[a]=b; break; }
			    }
			}
	}
			        
	if(make<=5){
		alert("재료가 부족하여 조합할 수 없습니다.");
	}
	else{
		alert("조합이 완료되었습니다.");
	var result_unit = combination[background_combination.select].result[1];
	var result_type = combination[background_combination.select].result[0];
	user.inventory[user.inventory_use+1][inventoryoption.type] = result_type;
	user.inventory[user.inventory_use+1][inventoryoption.code] = result_unit;
	user.gold -= combination[background_combination.select].gold;
			        	
	for(a=0;a<6;a++){
		if(delete_item[a]!=null){
			user.inventory[delete_item[a]][0] = 0;
			user.inventory[delete_item[a]][1] = 0;
			user.inventory[delete_item[a]][2] = 0;
			user.inventory[delete_item[a]][3] = 0;
			user.inventory[delete_item[a]][4] = 0;
		    }
	    }
    }
}
function game_upgrade(number)
{
	var lv = user.inventory[number][inventoryoption.lv];
	var code = user.inventory[number][inventoryoption.code];
	var rank = user.inventory[number][inventoryoption.rank];
	var gold = unit_upgrade_gold(lv) + unit_upgrade_gold(lv)*(rank*0.1);
	var maxlv = unit[code].maxlv * rank;
	var maxrank = unit[code].maxrank;
	if(user.inventory[number][inventoryoption.type]!=inventory_type.unit){
		sound_output("buzzer");
		alert("유닛만 강화할 수 있습니다.(아이템은 불가능)");
	}
	else if(rank >= maxrank && lv >= maxlv){
		sound_output("select_menu");
		alert("해당 유닛은 레벨과 랭크가 최대치이기 때문에 더이상 강화를 할 수 없습니다.");
	}
	else if(confirm("정말로 강화하시겠습니까?\n필요한 골드 : "+gold) && lv < maxlv){
		if(user.gold < gold){
			sound_output("buzzer");
			alert("골드가 부족하여 강화를 할 수 없습니다.");
		}
		else{
			sound_output("upgrade");
		    user.inventory[number][inventoryoption.lv]++;
			user.gold -= gold;
			alert("강화가 성공하였습니다.\n해당 유닛의 레벨이 "+lv+" -> "+(lv+1)+" 이 되었습니다.");
		}
	}
	else if(confirm("해당 유닛은 레벨이 최대치입니다. 골드를 사용하여 랭크를 올릴 수 있습니다. 정말로 랭크를 올리시겠습니까?\n소모되는 골드 : "+gold) && lv >= maxlv && rank < maxrank){
		if(user.gold < gold){
			sound_output("buzzer");
			alert("골드가 부족하여 강화를 할 수 없습니다.");
		}
		else{
			sound_output("upgrade");
		    user.inventory[number][inventoryoption.rank]++;
			user.gold -= gold;
			alert("강화가 성공하였습니다.\n해당 유닛의 랭크이 "+rank+" -> "+(rank+1)+" 이 되었습니다.");
		}
	}
	for(a=0;a<12;a++){
		if(user.teamunit[a][teamoption.inventory]==number){
			user.teamunit[a][teamoption.lv]=lv;
			user.teamunit[a][teamoption.rank]=rank;
		}
	}
}
function game_shop()
{
	background_shop.display();
	if(gamekey == key.esc){ // X key
		sound_output("select_back");
		gamestatus = gamemode.main;
	}
}
function game_inventory()
{
	background_inventory.display();
	var cursor = background_inventory.select - ((this.page-1)*50);
	
	if(gamekey == key.esc){ // X key
		sound_output("select_back");
		gamestatus = gamemode.main;
	}
	else if(gamekey == 13 && user.inventory[background_inventory.select][inventoryoption.code]!=0){ // ENTER key
		sound_output("select_menu");
		gamestatus = gamemode.unitview;
		background_unitview.code = background_inventory.select;
	}
	else if(gamekey == 37){ // LEFT key
		sound_output("select_move");
		background_inventory.select--;
		if(background_inventory.select%10==9){
			if(background_inventory.page > 1){
			background_inventory.page--;
			background_inventory.select-=40;
		    }
			else background_inventory.select+=10;
		}
	}
	else if(gamekey == 39){ // RIGHT key
		sound_output("select_move");
		background_inventory.select++;
		if(background_inventory.select%10==0){
			if(background_inventory.page < background_inventory.page_max){
			background_inventory.page++;
			background_inventory.select+=40;
		    }
			else background_inventory.select-=10;
		}
	}
	else if(gamekey == 38){ // UP key
		if(background_inventory.select-10 > 50*(background_inventory.page-1)){
		    background_inventory.select-=10;
		    sound_output("select_move");
		}
		else{
			//background_inventory.select = ( background_inventory.select%10 )+ 40;
		}
	}
	else if(gamekey == 40){ // DOWN key
		if(background_inventory.select+10 < 50*background_inventory.page){
		    background_inventory.select+=10;
		    sound_output("select_move");
		}
		else{
			//background_inventory.select = background_inventory.select%10;
		}
	}
}

function game_unitview()
{
	background_unitview.display();
	if(gamekey == key.esc){ // X key
		sound_output("select_back");
		gamestatus = gamemode.inventory;
	}
	else if(gamekey == key.left && background_unitview.select > 0){
		sound_output("select_move");
		background_unitview.select--;
	}
	else if(gamekey == key.right && background_unitview.select < 2){
		sound_output("select_move");
		background_unitview.select++;
	}
	else if(gamekey == key.enter){
		if(background_unitview.select==0){
			sound_output("select_back");
			gamestatus = gamemode.inventory;
		}
		else if(background_unitview.select==1){
			game_upgrade(background_unitview.code);
		}
		else if(background_unitview.select==2){
			sound_output("buzzer");
			alert("해당 기능은 지원하지 않습니다.");
		}
	}
}

function game_dungeon_select()
{
	background_dungeon_select.display();
	
	if(gamekey == key.esc){
		sound_output("select_back");
		if(background_dungeon_select.mode==1){
			background_dungeon_select.mode=0;
		}
		else{
		    gamestatus = gamemode.main;
		}
	}
	else if(gamekey == key.up){
		sound_output("select_move");
		if(background_dungeon_select.mode==0 && background_dungeon_select.roundcode > 0 )
		    background_dungeon_select.roundcode--;
		else if(background_dungeon_select.mode==1 && background_dungeon_select.select > 0) 
		    background_dungeon_select.select--;
	}
	else if(gamekey == key.down ){
		sound_output("select_move");
		if(background_dungeon_select.mode==0 && background_dungeon_select.roundcode < 9 )
		    background_dungeon_select.roundcode++;
		else if(background_dungeon_select.mode==1 && background_dungeon_select.select < 9) 
		    background_dungeon_select.select++;
	}
	else if(gamekey == key.enter && background_dungeon_select.mode==0 ){
		if(background_dungeon_select.roundcode!=0){
		    sound_output("select_menu");
		    background_dungeon_select.mode=1;
		}
		else{
		    sound_output("select_back");
		    gamestatus = gamemode.main;
		}
	}
	else if(gamekey == key.enter && background_dungeon_select.mode==1 ){
		if(background_dungeon_select.select!=0 && ( background_dungeon_select.select ==1 || background_dungeon_select.select ==2)){
			sound_effect_output("select_enter");
			gamestatus = gamemode.loading;
			enemy_create_count=3;
			time_sec=180;
			round_code=1;
		}
		else if(background_dungeon_select.select!=0 && ( background_dungeon_select.select ==3 || background_dungeon_select.select ==4)){
			sound_effect_output("select_enter");
			gamestatus = gamemode.loading;
			enemy_create_count=167;
			time_sec=213;
			round_code=2;
		}
		else if(background_dungeon_select.select!=0 && ( background_dungeon_select.select ==5 || background_dungeon_select.select ==5)){
			sound_effect_output("select_enter");
			gamestatus = gamemode.loading;
			enemy_create_count=1;
			time_sec=150;
			round_code=3;
		}
		else{
		    sound_output("select_back");
		    background_dungeon_select.mode=0;
		}
	}
}

function game_loading()
{
	background_loading.display();
	background_loading.count--;
	user.hp = user.hp_max;
	
	if(background_loading.count<=0){
		gamestatus = gamemode.dungeon;
	}
}

var delay_count=0;
var round_code=0;
function game_dungeon()
{
    //---------------
    user.status();
    //---------------
    if(round_code==1) background_round01.display();
    else if(round_code==2) background_round02.display();
	//else if(round_code==3) ctx.fillStyle = "#B1CAD8";  ctx.fillRect(0,0,640,480);
    sprite_green_cloud.display(132,92);
    sprite_green_cloud.moveX(4);
    sprite_white_cloud.display(148,86);
    sprite_white_cloud.moveX(3);
    time_down();
    display_top();
    //---------------
    if(user.hp>=user.hp_max) user.hp=user.hp_max;
    //---------------
    filed.display();
    //-----------------------------
    party_standard_total_progress();
    attack_standard_total_progress();
    enemy_standard_total_progress();
    //---------------
    //ctx.fillText(enemyunit[0][enemyoption.hp],0,70);
    //---------------
    
    if(enemy_create_count>=1){
        if(round_code==1) enemy_create(Math.floor(Math.random()*5)+0);
        else if(round_code==2) enemy_create(Math.floor(Math.random()*5)+5);
		 else if(round_code==3) enemy_create(11);
    }
    else if(enemy_create_count<=0 && time_sec>=5 && enemy_current<=0 && delay_count<=0){
    	time_sec-=5.00;
    	user.exp+=586 * 5;
    	sound_output("score");
    	delay_count=3;
    }
    else if(enemy_create_count<=0 && time_sec>0 && enemy_current<=0 && delay_count<=0){
    	user.exp+=Math.floor(586*(time_sec));
    	time_sec = 0;
    	sound_output("score");
    	delay_count=3;
    }
    else if(enemy_create_count<=0 && time_sec<=0 && enemy_current<=0){
    	gamestatus = gamemode.main;
    	user_score=0;
    	if(round_code==1) user.gold+=50000;
    	else if(round_code==2) user.gold+=110000;
    }
    delay_count--;
}

function game()
{
	display_clear();
	game_global();
	if(gamestatus == gamemode.title ){
		game_title();
	}
	else if(gamestatus == gamemode.option){
		game_option();
	}
	else if(gamestatus == gamemode.main){
		game_main();
	}
	else if(gamestatus == gamemode.party){
		game_party();
	}
	else if(gamestatus == gamemode.upgrade){
		game_upgrade();
	}
	else if(gamestatus == gamemode.inventory){
		game_inventory();
	}
	else if(gamestatus == gamemode.shop){
		game_shop();
	}
	else if(gamestatus == gamemode.combination){
		game_combination();
	}
	else if(gamestatus == gamemode.unitview){
		game_unitview();
	}
	else if(gamestatus == gamemode.unit_select){
		unit_select();
	}
	else if(gamestatus == gamemode.dungeon_select){
		game_dungeon_select();
	}
	else if(gamestatus == gamemode.loading){
		game_loading();
	}
	else if(gamestatus == gamemode.dungeon){
		game_dungeon();
	}
	
	gamekey=0;
}

// 시간 계산 // top_bottom 부분
var time_sec=1;
var time_max;
//-----------------
function time_down()
{
    if(time_sec>0)
    {
        time_sec-= 20/1000 ;
	    time_sec = time_sec.toFixed(2);
    }
    else
    {
        time_sec = 0 ;
        time_sec = time_sec.toFixed(2);
    }
}