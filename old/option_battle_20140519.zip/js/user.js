// MENU유저관련처리
function useR()
{
    this.name="user";
    this.lv=1;
    this.maxlv=20;
    this.exp=0;
    this.fuel=0;
    this.fuel_max=0;
    this.crystal=0;
    this.gold=0;
    this.teamunit = new Array(12);
    this.inventory = new Array(1000);
}
useR.prototype.status = function()
{
    document.getElementById("lv").value = "LV : "+this.lv;
    document.getElementById("exp").value = "EXP : "+this.exp+"/"+exptable[this.lv];
    document.getElementById("fuel").value = "FUEL : "+this.fuel+"/"+this.fuel_max;
    document.getElementById("exp_meter").value = this.exp;
    document.getElementById("fuel_meter").value = this.fuel;
    document.getElementById("exp_meter").max = exptable[this.lv];
    document.getElementById("fuel_meter").max = this.fuel_max;
    //-----------------------------//
    document.getElementById("name").value = this.name;
    document.getElementById("crystal").value = this.crystal;
};
useR.prototype.exp_check = function()
{
    if(this.exp > exptable[this.lv] && this.lv < this.maxlv){ 
        // LEVEL UP
	    this.exp-=exptable[this.lv]; this.lv++;
    }
    else if(this.exp > exptable[this.lv] && this.lv == this.maxlv){
	    // LEVEL NOT UP, BUT EXP RESET
	    this.exp-=exptable[this.lv];
    }
};
useR.prototype.fuel_check = function()
{
    this.fuel_max = 700 + (this.lv*10) + Math.floor(this.lv/5)*24;
    if(this.fuel > this.fuel_max) this.fuel=this.fuel_max;
};
useR.prototype.teamunitSetting = function()
{
	for(a=0; a<this.teamunit.length;a++){
		this.teamunit[a] = new Array(30);
		for(b=0; b<this.teamunit[a].length; b++){
			this.teamunit[a][b] = 0;
		}
	}
};

useR.prototype.hp_meter = function(x,y,width,height)
{
    ctx.fillStyle = "skyblue";
    ctx.strokeStyle = "black";
    ctx.strokeRect(x,y,width,height);
    var hp_percent = this.hp / this.hp_max;
    ctx.fillRect(x,y,(hp_percent*width),height);
    ctx.fillStyle = "black";
    ctx.font = "20px arial";
    ctx.fillText("HP : "+this.hp+"/"+this.hp_max,x+1,y+(height/1.5));
    //ctx.strokeText("HP : "+this.hp+"/"+this.hp_max,x,y+(height/1.5));
};
useR.prototype.inventory_make = function()
{
	for(a=0;a<1000;a++){
	    this.inventory[a] = new Array(10);
	    for(b=0;b<10;b++){
	    	this.inventory[a][b] = 0;
	    }
	}
};
user = new useR();
{
    user.name="user";
    user.lv=1;
    user.exp=400;
    user.fuel=700;
    user.fuel_max=700;
    user.gold=30000;
    user.inventory_max = 200;
    user.inventory_use = 0;
}
user.teamunitSetting();
user.inventory_make();
//------------------------//
var teamoption = { code:0, lv:1, hp_max:2, mp:3, mp_max:4, count1:5, count2:6, count3:7, delay1:8, delay2:9, delay3:10,
    attack:11, attack2:12, attack3:13, job:14, buff:15, bufftime:16, buff2:17, bufftime2:18, count4:19, count5:20, inventory:21, countwait4:22, countwait5:23 };
var exptable = new Array(100); exptable[0]=0; // 경험치 테이블
exptable[1]=181100; exptable[2]=181200; exptable[3]=181300; exptable[4]=181400; exptable[5]=181500;
exptable[6]=181600; exptable[7]=181700; exptable[8]=181800; exptable[9]=181900; exptable[10]=546000;
exptable[11]=225500; exptable[12]=226000; exptable[13]=226500; exptable[14]=227000; exptable[15]=227500;
exptable[16]=228000; exptable[17]=228500; exptable[18]=229000; exptable[19]=229500; exptable[20]=690000;