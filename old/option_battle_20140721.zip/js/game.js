//모드 이름은 상수로 정의한다.
var modeName = { title:0, option:1 , opening:2, main:3, dungeon:4, party:5, upgrade:6, combination:7, 
    inventory:8, shop:9, unitview:10, unitselect:11, dungeon:12, loading:13, round:14, play:15, round_1:16,
     };

//키를 입력받는 함수와 변수 처리
onkeydown = game_keyinput;
var keyboard = { enter:13, esc:27, z:90, x:88, up:38, down:40, left:37, right:39, p:80 };
var inputkey = 0;
function game_keyinput()
{
    inputkey = event.keyCode;
    
    //event.returnValue = false;
    if(inputkey != 116) event.preventDefault();
    if(inputkey == keyboard.z) inputkey = keyboard.enter; // ENTER key == Z
    else if(inputkey == keyboard.x) inputkey = keyboard.esc; // ESC key == X
}

//-------------------------------//
//start function Game
function Game(){ // 게임 함수...
//게임 모드 관련 설정
var mode = 0; // 게임의 모드, 타이틀, 옵션 화면등을 오갈때 사용하는 변수
function mode_change(constNumber_modeName){ mode = constNumber_modeName; }
function mode_check(){  return mode; }
this.mode_change = function(constNumber_modeName){ mode = constNumber_modeName; };

//게임 사운드 설정값
var soundVolume = 100; // 사운드 볼륨, 주의 : 브라우저에서 사용시에는 100으로 나눠야함.(범위가 0 ~ 1) 
var soundOn = true; // 사운드가 켜져있는지에 관한 변수, true일경우 켜짐
var musicVolume = 100; // 음악 볼륨, 위와 같음.
var musicOn = true; // 음악이 켜져있는지(재생중이냐와는 별개)에 관한 변수, true일경우 켜짐
this.get_soundOn = function(){  return soundOn; };
this.get_musicOn = function(){  return musicOn; };
function sound_status_change(){
    if(soundOn == true)  soundOn = false;
    else  soundOn = true;
}
function music_status_change(){
    if(musicOn == true)  musicOn = false;
    else  musicOn = true;
}
this.sound_status_change = function(){  sound_status_change(); };
this.music_status_change = function(){  music_status_change(); };

var unitUpgradeGold = [800, 800, 810, 820, 830, 840, 850, 865, 880, 895, 910,
		1100, 1140, 1180, 1220, 1260, 1400, 1440, 1480, 1520, 1560, 1600,
		1720, 1770, 1820, 1920, 1970, 2130, 2200, 2270, 2340, 2410, 2480,
		2600, 2720, 2840, 2960, 3080, 3200, 3400, 3600, 3800, 4000, 4500];
this.get_unit_upgrade_gold = function(lv){  return unitUpgradeGold[lv]; };

var unitSellGold = [2000, 2400, 2800, 3200, 3600, 4000, 4400, 4800, 5200, 5600, 6000,
		6500, 7000, 7500, 8000, 8500, 9200, 9900, 10600, 11300, 12000,
		12800, 13600, 14400, 15200, 16000, 17000, 18000, 19000, 20000, 21000,
		22000, 23000, 24000, 25000, 26000, 27500, 29000, 30500, 32000, 35000];
this.get_unit_sell_gold = function(lv){  return unitSellGold[lv];};

//화면의 메뉴에 관한 설정
var menu = 0, select = 0, select_teamunit = 0;
this.get_menu = function(){  return menu; };
this.get_select = function(){  return select; };
this.get_select_teamunit = function(){  return select_teamunit; };

//게임 타이틀 화면
function title(){
    background.display(modeName.title);
    if(inputkey == keyboard.up && menu > 0){  menu--;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.down && menu < 3){  menu++;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.enter){
        sound_play(soundName.select_enter);
        switch(menu){
            case 0: mode_change(modeName.main);  menu = 0; break;
            case 1: mode_change(modeName.option);  break;
            case 2: break;
            case 3: break;
        }
    }
}


var soundNumber = 0, musicNumber = 0;
this.get_soundNumber = function(){  return soundNumber; };
this.get_musicNumber = function(){  return musicNumber; };
//게임 옵션 화면
function option(){
    background.display(modeName.option);
    if(inputkey == keyboard.up && select > 0){  select--;  sound_play(soundName.select_move); }
    else if( inputkey == keyboard.down && select < 5){  select++;  sound_play(soundName.select_move); }
    else if( inputkey == keyboard.left){
        switch(select){
            case 0: sound_status_change(); break;
            case 1: music_status_change(); break;
            case 2: if(soundNumber > 0)  soundNumber--; break;
            case 3: break;
            case 4: if(musicNumber > 0)  musicNumber--; break;
        }
    } else if( inputkey == keyboard.right){
        switch(select){
            case 0: sound_status_change(); break;
            case 1: music_status_change(); break;
            case 2: if(soundNumber < 22)  soundNumber++; break;
            case 3: break;
            case 4: if(musicNumber < 0)  musicNumber++; break;
        }
    } else if( inputkey == keyboard.enter){
        switch(select){
            case 0: sound_status_change(); break;
            case 1: music_status_change(); break;
            case 2: sound_test(soundNumber); break;
            case 5: sound_play(soundName.select_back);
                    mode_change(modeName.title);  
                    menu = 0;  select = 0;
                    break;
        }
    }
}

// 게임 메인화면
function main(){
    background.display(modeName.main);
    if( inputkey == keyboard.up && menu != 0){  menu--;  sound_play(soundName.select_move); }
    else if( inputkey == keyboard.down && menu != 5){  menu++;  sound_play(soundName.select_move); }
    else if( inputkey == keyboard.enter){
        sound_play(soundName.select_menu);
        switch(menu){
            case 0: mode_change(modeName.dungeon); break;
            case 1: mode_change(modeName.party); break;
            case 3: mode_change(modeName.inventory); break;
            case 5: if(confirm("정말로 나가시겠습니까?")){
                        mode_change(modeName.title);
                        menu = 0;  select = 0;
                    }  break;
        }
    }
}

//게임 파티화면
function party(){
    background.display(modeName.party);
    if(inputkey == keyboard.left && (select_teamunit%3) > 0 ){  select_teamunit--;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.right && (select_teamunit%3) < 2 ){  select_teamunit++;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.up && Math.floor(select_teamunit/3) > 0 ){  select_teamunit-=3;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.down && Math.floor(select_teamunit/3) < 3 ){  select_teamunit+=3;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.esc){  mode_change(modeName.main);  sound_play(soundName.select_back); }
    else if(inputkey == keyboard.enter ){  mode_change(modeName.unitselect);  sound_play(soundName.select_menu); }
}

//유닛 선택 화면
function unitselect(){
    background.display(modeName.inventory);
    ctx.clearRect(0,0,500,50);
    ctx.font = "24px arial";
    ctx.fillText("파티에 편성할 유닛을 선택해 주세요.",20,30);
    
    if(inputkey == keyboard.esc){  mode_change(modeName.party);  sound_play(soundName.select_back); }
    else if(inputkey == keyboard.up && Math.floor(select%49) > 10){  select -= 10;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.down && Math.floor(select%49) < 40){  select += 10;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.left && select != 0){
        sound_play(soundName.select_move);
        if(select%10 == 0 && select > 50)  select -= 41;
        else  select--;
    } else if(inputkey == keyboard.right && select != 999){
        sound_play(soundName.select_move);
        if(select%10 == 9 && select < 950)  select += 41;
        else  select++;
    } else if(inputkey == keyboard.enter){
        var type_data = user.inventory_data(select);
        var type = type_data[invenconst.type];
        if(type == itemType.unit){
            var good = user.teamunit_setting(select_teamunit, select);
            if(good == true){
                sound_play(soundName.select_menu);
                mode_change(modeName.party);
            }
        } else {
            sound_play(soundName.system_notice);
            alert("유닛만 팀에 편성할 수 있습니다.\n아이템 또는 업그레이드는 팀에 편성할 수 없습니다.");
        }
    }
}

//업그레이드 처리 함수
function upgrade(){
    var data = user.inventory_data(select);
    var code = data[invenconst.code],  type = data[invenconst.type];
    var lv = data[invenconst.lv],  rank = data[invenconst.rank];
    var gold = unitUpgradeGold[lv];
    var maxlv = option_battle.unit[code].get_maxlv();
    if(type != itemType.unit){  sound_play(soundName.system_buzzer); alert("유닛만 강화할 수 있습니다.(아이템은 불가능)"); }
    else if(lv >= maxlv){  sound_play(soundName.system_buzzer); alert("해당 유닛은 레벨이 최대치이기 때문에 더이상 강화를 할 수 없습니다."); }
    else if(user.get_gold() < gold){  sound_play(soundName.system_buzzer); alert("골드가 부족하여 강화를 할 수 없습니다."); }
    else {  user.inventory_unitlvup(select);  user.minus_gold(gold);  sound_play(soundName.system_upgrade); }
}

//판매 처리 함수
function sell(){
    var data = user.inventory_data(select);
    var lv = data[invenconst.lv];
    var gold = unitSellGold[lv];
    if(data[invenconst.type] == itemType.nodata){  sound_play(soundName.system_buzzer); alert("해당 유닛 또는 아이템이 존재하지 않습니다."); }
    else{
        sound_play(soundName.system_notice);
        if(confirm("정말로 판매하시겠습니까? 이 작업은 되돌릴 수 없습니다.\n판매가격은 "+ gold +"gold 입니다.\n팀에 포함되어있을경우 유닛은 삭제할 수 없습니다.")){
            user.inventory_delete(select);
            user.inventory_clean();
            user.plus_gold(gold);
        }
    }
}

//크리스탈(현질...) 상점
function shop(){
    background_shop.display();
    if(gamekey == keyboard.esc){  mode_change(modeName.main);  sound_play(soundName.select_back); }
}

//인벤토리 함수
function inventory(){
    background.display(modeName.inventory);
    if(inputkey == keyboard.up && Math.floor(select%49) > 10){  select -= 10;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.down && Math.floor(select%49) < 40){  select += 10;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.left && select != 0){
        sound_play(soundName.select_move);
        if(select%10 == 0 && select > 50)  select -= 41;
        else  select--;
    }
    else if(inputkey == keyboard.right && select != 999){
        sound_play(soundName.select_move);
        if(select%10 == 9 && select < 950)  select += 41;
        else  select++;
    }
    else if(inputkey == keyboard.esc){  menu = 3; mode_change(modeName.main); sound_play(soundName.select_back); }
    else if(inputkey == keyboard.enter){  menu = 0; mode_change(modeName.unitview); sound_play(soundName.select_menu); }
}

//유닛 보기 함수
function unitview(){
    background.display(modeName.unitview);
    if(inputkey == keyboard.esc){  mode_change(modeName.inventory);  sound_play(soundName.select_back); }
    else if(inputkey == keyboard.left && menu > 0){  menu--;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.right && menu < 2){  menu++;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.enter){
        if(menu==0){  mode_change(modeName.inventory);  sound_play(soundName.select_back); }
        else if(menu==1){  upgrade();  }
        else if(menu==2){  sell();  }
    }
}

//던전 목록 나타내는 함수
function dungeon(){
    background.display(modeName.dungeon);
    if(inputkey == keyboard.esc){
        sound_play(soundName.select_back);
        menu = 0;  select = 0;  mode_change(modeName.main);
    }
    else if(inputkey == keyboard.up && menu > 0){  menu--;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.down && menu < 1){  menu++;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.enter){
        if(menu == 0){  menu = 0;  mode_change(modeName.main);  sound_play(soundName.select_back); }
        else{  select = -1;  mode_change(modeName.round);  sound_play(soundName.select_menu); }
    }
}

//라운드 목록 나타내는 함수
function round(){
    background.display(modeName.round);
    if(inputkey == keyboard.esc){  mode_change(modeName.dungeon);  sound_play(soundName.select_back); }
    else if(inputkey == keyboard.up && select > -1){  select--;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.down && select < 12){  select++;  sound_play(soundName.select_move); }
    else if(inputkey == keyboard.enter){
        if(select == -1){  mode_change(modeName.dungeon);  sound_play(soundName.select_back); }
        else{  mode_change(modeName.loading);  sound_play(soundName.select_enter); }
    }
}

function loading(){
    background.display(modeName.loading);
    mode_change(modeName.play);
    field.input();
}

var pausecheck = false;
function play(){
    background.display(modeName.round_1); // 배경화면 출력
    field.display(); // 필드 출력
    if(pausecheck == false){ // 로직 처리
        field.process();
    }else{
        ctx.fillStyle = "white";  ctx.fillRect(170, 200, 350, 50);
        ctx.fillStyle = "black";  ctx.font = "36px arial";  ctx.fillText("PAUSE(일시정지)", 220, 240);
    }
    if(inputkey == keyboard.p)  change_pause();
}
function change_pause(){
    if(pausecheck == true)  pausecheck = false;
    else{ pausecheck = true;  sound_play(soundName.system_pause); }
}

//게임 진행 함수//
this.process = function(){
    switch(mode_check()){
        case modeName.title: title(); break;
        case modeName.option: option(); break;
        case modeName.main: main(); break;
        case modeName.inventory: inventory(); break;
        case modeName.party: party(); break;
        case modeName.unitselect: unitselect(); break;
        case modeName.unitview: unitview(); break;
        case modeName.dungeon: dungeon(); break;
        case modeName.round: round(); break;
        case modeName.loading: loading(); break;
        case modeName.play: play(); break;
    }
    inputkey = 0; // 누른 키 초기화;
    fpscount++;
};

//---------------------//
}//function Game
var game = new Game(); // 게임 객체 생성




/*function game_combination()
{
	background_combination.display();
	inventory_check();
	if(gamekey == keyboard.esc){ // X key
		sound_output("select_back");
		if(background_combination.mode==1) background_combination.mode=0;
		else gamestatus = gamemode.main;
	}
	else if(gamekey == 38){ // UP
		sound_output("select_move");
		if(background_combination.mode==0&&background_combination.round>1) background_combination.round--;
	}
	else if(gamekey == 40){ // DOWN
		sound_output("select_move");
		if(background_combination.mode==0&&background_combination.round<7) background_combination.round++;
	}
	else if(gamekey == 37){ // LEFT
		sound_output("select_move");
		if(background_combination.mode==1&&background_combination.select>0) background_combination.select--;
	}
	else if(gamekey == 39){ // RIGHT
		sound_output("select_move");
		if(background_combination.mode==1&&background_combination.select<8) background_combination.select++;
	}
	else if(gamekey == 13){
		if(background_combination.mode==0){
			background_combination.mode=1;
		}
		else if(background_combination.mode==1){
			if(background_combination.select!=0&&confirm("정말로 조합하시겠습니까?")){
				if(user.gold < combination[background_combination.select].gold){
					alert("골드가 부족하여 조합할 수 없습니다.");
				}
				else{
				    combination_progress();
				}
			}
		}
	}
}
function combination_progress()
{
	var make=0;
	var material = new Array(6);
	var delete_item = new Array(6);
	var a=0;
	for(a=0;a<6;a++){
		material[a] = combination[background_combination.select].material[a];
		if(material[a]==0){ delete_item[a]=null; make++; continue; }
					    
		for(b=0;b<user.inventory_max;b++){
			var type = user.inventory[b][inventoryoption.type];
			if(type!=inventory_type.item) continue;
					    	
			if(material[a]==user.inventory[b][inventoryoption.code]){
			var ok=0;
			for(c=0;c<6;c++){
			    if(delete_item[c]==b) ok++;
			}
			        	    	
			if(ok>0) {}
			else { make++; delete_item[a]=b; break; }
			    }
			}
	}
			        
	if(make<=5){
		alert("재료가 부족하여 조합할 수 없습니다.");
	}
	else{
		alert("조합이 완료되었습니다.");
	var result_unit = combination[background_combination.select].result[1];
	var result_type = combination[background_combination.select].result[0];
	user.inventory[user.inventory_use+1][inventoryoption.type] = result_type;
	user.inventory[user.inventory_use+1][inventoryoption.code] = result_unit;
	user.gold -= combination[background_combination.select].gold;
			        	
	for(a=0;a<6;a++){
		if(delete_item[a]!=null){
			user.inventory[delete_item[a]][0] = 0;
			user.inventory[delete_item[a]][1] = 0;
			user.inventory[delete_item[a]][2] = 0;
			user.inventory[delete_item[a]][3] = 0;
			user.inventory[delete_item[a]][4] = 0;
		    }
	    }
    }
}  */