function Enemy(stringName, _number, _attack, _hp, _defense, _score, stringTechnical, stringSkill)//적만들기
{
	var name = stringName;
	var number = _number;
	var attack = _attack;
	var hp = _hp;
	var defense = _defense;
	var technical = stringTechnical;
	var skill = stringSkill;
	var score = _score;
	var isFirstExtendSetting = false;
	var speed_x = 10;
	var speed_y = 10;
	var speedType = "random";
	
	this.image = new Image();
	this.image.src = "";
	
	this.get_name = function(){  return name; };
	this.get_number = function(){  return number; };
	this.get_attack = function(){  return attack; };
	this.get_hp = function(){  return hp; };
	this.get_technical = function(){  return technical; };
	this.get_skill = function(){  return skill; };
	this.get_score = function(){  return score; };
	this.get_defense = function(){  return defense; };
	this.get_speed_x = function(){  return speed_x; };
	this.get_speed_y = function(){  return speed_y; };
	this.get_speed_type = function(){  return speedType; };
	
	this.extend_setting = function (_speed_x, _speed_y, _speedType){
	    speed_x = _speed_x;
	    speed_y = _speed_y;
	    speedType = speedType;
	};
}
Enemy.prototype.display = function(x, y, width, height)
{
	if( width == null || height == null )
        ctx.drawImage(this.image, x, y);
    else
        ctx.drawImage(this.image, x, y, width, height);
};

option_battle.enemy[0] = new Enemy("unused", 0, 0, 0, 0, "", "");
option_battle.enemy[0].image.src = "image/system/unused.png";
option_battle.enemy[1] = new Enemy("밝은 빛", 1, 15, 10000, 0, 100, "", "");
option_battle.enemy[1].image.src = "image/enemy/enemy[1].png";
option_battle.enemy[2] = new Enemy("약한 빛", 2, 20, 10000, 0, 100, "", "");
option_battle.enemy[2].image.src = "image/enemy/enemy[2].png";
option_battle.enemy[3] = new Enemy("하얀 빛", 3, 18, 8000, 100, 110, "", "");
option_battle.enemy[3].image.src = "image/enemy/enemy[3].png";
option_battle.enemy[4] = new Enemy("일반 운석", 4, 40, 21000, 50, 115, "", "");
option_battle.enemy[4].image.src = "image/enemy/enemy[4].png";
option_battle.enemy[5] = new Enemy("강한 운석", 5, 50, 21000, 50, 115, "", "");
option_battle.enemy[5].image.src = "image/enemy/enemy[5].png";
option_battle.enemy[6] = new Enemy("어두운 하늘색 동그라미", 6, 44, 16000, 40, 200, "", "");
option_battle.enemy[6].image.src = "image/enemy/enemy[6].png";
option_battle.enemy[7] = new Enemy("파란색 동그라미", 7, 47, 17000, 40, 208, "", "");
option_battle.enemy[7].image.src = "image/enemy/enemy[7].png";
option_battle.enemy[8] = new Enemy("남색 동그라미", 8, 41, 12000, 95, 207, "", "");
option_battle.enemy[8].image.src = "image/enemy/enemy[8].png";
option_battle.enemy[9] = new Enemy("청록색 동그라미", 9, 64, 20000, 0, 220, "", "");
option_battle.enemy[9].image.src = "image/enemy/enemy[9].png";







