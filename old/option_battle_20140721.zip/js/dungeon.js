var dungeonType = { story:1, sub:2, resource:3, item:4 };
function Dungeon(_number, stringName, constNumber_dungeonType, stringColor, createRoundCount){
var number = _number;
var name = stringName;
var type = constNumber_dungeonType;
var color = stringColor;
var round = new Array(createRoundCount);

this.get_number = function(){  return number; };
this.get_name = function(){  return name; };
this.get_type = function(){  return type; };
this.get_color = function(){  return color; };
this.get_round = function(roundNumber){  
	if(roundNumber != null)  return round[roundNumber];
	else  alert("잘못된 인수를 입력하셨습니다.");
};


function Round(number, stringName, nextround, time, createcount, clearbonus){
    this.number = number;
    this.name = stringName;
    this.nextround = nextround;
    this.time = time;
    this.createcount = createcount;
    this.clearbonus = clearbonus;
    this.enemylist = [0,0,0,0,0,0,0,0,0,0];
    this.getitem = [0,0,0,0,0,0,0,0,0,0];
    this.getunit = 0;
}
this.round_create = function(number, stringName, nextround, time, createcount, clearbonus){
    round[number] = new Round(number, stringName, nextround, time, createcount, clearbonus);
};
this.round_setting = function(number, arraymax10_enemylist, arraymax10_getitem, getunit){
    round[number].enemylist = arraymax10_enemylist;
    round[number].getitem = arraymax10_getitem;
    round[number].getunit = getunit;
};
this.get_round_name = function(roundNumber){  return round[roundNumber].name; };
this.get_round_nextround = function(roundNumber){  return round[roundNumber].nextround; };
this.get_round_time = function(roundNumber){  return round[roundNumber].time; };
this.get_round_createcount = function(roundNumber){  return round[roundNumber].createcount; };
this.get_round_clearbonus = function(roundNumber){  return round[roundNumber].clearbonus; };
this.get_round_enemylist = function(roundNumber){  return round[roundNumber].enemylist; };
this.get_round_getitem = function(roundNumber){  return round[roundNumber].getitem; };
this.get_round_getunit = function(roundNumber){  return round[roundNumber].getunit; };
	
//------------------//
};//function Dungeon end


//던전 생성
option_battle.dungeon[0] = new Dungeon(0, "", dungeonType.sub, "black");
option_battle.dungeon[1] = new Dungeon(1, "파란 행성", dungeonType.story, "darkblue", 100);
option_battle.dungeon[1].round_create(0, "우주 이동 경로 1", 1, 120, 1, 25000);
option_battle.dungeon[1].round_setting(0, [1], [1], 0);
option_battle.dungeon[1].round_create(1, "우주 이동 경로 2", 2, 140, 115, 25500);
option_battle.dungeon[1].round_setting(1, [2], [1], 0);
option_battle.dungeon[1].round_create(2, "우주 이동 경로 3", 3, 140, 120, 26100);
option_battle.dungeon[1].round_setting(2, [1,2,3], [1], 0);
option_battle.dungeon[1].round_create(3, "우주 이동 경로 4", 4, 130, 110, 23500);
option_battle.dungeon[1].round_setting(3, [1,2,3,4], [1], 0);
option_battle.dungeon[1].round_create(4, "우주 이동 경로 5", 5, 125, 90, 18200);
option_battle.dungeon[1].round_setting(4, [1,2,3,4,5], [1], 0);
option_battle.dungeon[1].round_create(5, "우주 이동 경로 6", 6, 110, 80, 17500);
option_battle.dungeon[1].round_setting(5, [4,5], [1], 0);
option_battle.dungeon[1].round_create(6, "파란행성 진입구간 1", 7, 80, 55, 13200);
option_battle.dungeon[1].round_setting(6, [4,5], [1], 0);
option_battle.dungeon[1].round_create(7, "파란행성 진입구간 2", 8, 80, 55, 13200);
option_battle.dungeon[1].round_setting(7, [4,5], [1], 0);
option_battle.dungeon[1].round_create(8, "파란행성 상공 200km", 9, 220, 200, 42000);
option_battle.dungeon[1].round_setting(8, [6,7], [1], 0);
option_battle.dungeon[1].round_create(9, "파란행성 상공 190km", 10, 220, 204, 42400);
option_battle.dungeon[1].round_setting(9, [6,7,8], [1], 0);
option_battle.dungeon[1].round_create(10, "파란행성 상공 180km", 11, 230, 208, 41700);
option_battle.dungeon[1].round_setting(10, [6,7,8,9], [1], 0);
option_battle.dungeon[1].round_create(11, "파란행성 상공 170km", 12, 200, 181, 39900);
option_battle.dungeon[1].round_setting(11, [6,7,8,9], [1], 0);

