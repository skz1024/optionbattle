function Type(stringName, hp, stringColor){
    var name = stringName; // 타입 이름
    var hp = hp; // 타입의 기준 체력
    var color = stringColor; // 타입의 컬러(문자열로 표기)
    
    //참고사항 : 여기서 정의되는 공격력의 수치는 %를 기준으로 함.
    //여기에 있는 변수 이름들은 attackPercent를 생략한것처럼 취급합니다.(사실은 타이핑 하기 귀찮음.)
    var standard = 0; // Normal + Technical + skill;
    var rangemin = 0; // 타입의 공격력 범위 최소치(기준 랭크에 해당하는 %값)
    var rangemax = 0; // 타입의 공격력 범위 최대치(값)
    var normal = 0; // 일반 공격력 수치(%)
    var technical= 0; // 테크니컬 공격력(%)
    var skill = 0; // 스킬 공격력(%)
    var attackOptionChangeCheck = false; // 공격력 옵션 변경여부
    
    this.attack_setting = function(percentRangemin, percentRangemax, percentNormal, percentTechnical, percentSkill)
    {
        if(attackOptionChangeCheck == false){
        	// 정의된 숫자를 전부 100으로 나눈다.
            rangemin = percentRangemin/100;
            rangemax = percentRangemax/100;
            standard = (percentNormal + percentTechnical + percentSkill)/100;
            normal = percentNormal/100;
            technical = percentTechnical/100;
            skill = percentSkill/100;
            attackOptionChangeCheck = true; // 공격력 옵션 변경여부를 true로 함.
            // 따라서 공격력 관련 옵션은 단 한번만 사용할 수 있음.(수정 금지!)
        }
        else  console.log("공격관련 설정을 변경할 수 없습니다. 자세한것은 함수를 살펴봐 주십시요.");
    };
    
    // 각 스탯들을 리턴하는 함수들. get메서드를 사용
    this.get_rangemin = function(){  return rangemin; };
    this.get_rangemax = function(){  return rangemax; };
    this.get_standard = function(){  return standard; };
    this.get_normal = function(){  return normal; };
    this.get_technical = function(){  return technical; };
    this.get_skill = function(){  return skill; };
    this.get_name = function(){  return name; };
    this.get_hp = function(){  return hp; };
    this.get_color = function(){  return color; };
};

// 타입의 이름
var typeName = {hyper:0, multishot:1, direct:2, splash:3, heal:4, metal:5,// defalut type
    laser:6, whiteflash:7, bombmissile:8, chaincombo:9, knight:10, magician:11, // extend type
    special:100, etc:101, critical:102 }; // another type(사용 불가);

// 타입 정의
option_battle.type[typeName.hyper] = new Type("hyper", 1000, "darkgreen"); // 하이퍼 타입 생성
option_battle.type[typeName.hyper].attack_setting(150, 250, 20, 80, 0);
option_battle.type[typeName.multishot] = new Type("multishot", 1000, "brown"); // 멀티샷 타입 생성
option_battle.type[typeName.multishot].attack_setting(30, 40, 70, 70, 0);
option_battle.type[typeName.direct] = new Type("direct", 1000, "darkblue"); // 다이렉트 타입 생성
option_battle.type[typeName.direct].attack_setting(100, 150, 60, 40, 0);
option_battle.type[typeName.splash] = new Type("splash", 500, "red"); // 스플래시 타입 생성
option_battle.type[typeName.splash].attack_setting(100, 150, 20, 0, 0);
option_battle.type[typeName.heal] = new Type("heal", 2500, "pink"); // 힐 타입
option_battle.type[typeName.heal].attack_setting(90, 110, 40, 50, 0);
option_battle.type[typeName.metal] = new Type("metal", 4000, "darkgrey"); // 메탈 타입
option_battle.type[typeName.metal].attack_setting(70, 100, 40, 40, 0);
option_battle.type[typeName.laser] = new Type("laser", 700, "gold"); // 레이져 타입
option_battle.type[typeName.laser].attack_setting(120, 170, 30, 10, 40);
option_battle.type[typeName.whiteflash] = new Type("whiteflash", 200, "lavender"); // 화이트플래시 타입
option_battle.type[typeName.whiteflash].attack_setting(50, 100, 10, 0, 0);
option_battle.type[typeName.bombmissile] = new Type("bombmissile", 1, "#3E5E7E"); // 붐미사일 타입
option_battle.type[typeName.bombmissile].attack_setting(120, 160, 15, 0, 0);
option_battle.type[typeName.chaincombo] = new Type("chaincombo", 1, "darkorange"); // 체인콤보 타입
option_battle.type[typeName.chaincombo].attack_setting(100, 120, 50, 50, 0);
option_battle.type[typeName.knight] = new Type("knight", 2000, "lightgreen"); // 나이트 타입
option_battle.type[typeName.knight].attack_setting(100, 200, 20, 30, 50);
option_battle.type[typeName.magician] = new Type("magician", 600, "lightblue"); // 매지션 타입
option_battle.type[typeName.magician].attack_setting(100, 200, 20, 40, 60);
