//배경화면, 여기에 있는 모든 객체는 이미지만 저장된다.
function Background(){ // function Background Start.
var title = {}; // 타이틀 이미지 객체 생성
title.image = new Image();  title.image.src = "image/background/title.png";
title.arrow = new Image();  title.arrow.src = "image/system/arrow.png";
title.title = new Image();  title.title.src = "image/system/title.png";
title.developer = new Image();  title.developer.src = "image/system/developer.png";
title.display = function(){ //타이틀을 출력하는 함수
    ctx.drawImage(title.image, 0, 0); // 이미지 표시
    ctx.drawImage(title.title, 100, 40); // 타이틀 표시
    ctx.drawImage(title.developer, 290, 120); // 개발자 표시
    ctx.drawImage(title.arrow,350,250+(game.get_menu()*40)); // 화살표 표시
    
    ctx.fillStyle = "#004C63";  ctx.font = "20px arial";
    ctx.fillText("START",460,280);
    ctx.fillText("OPTION",460,320);
    ctx.fillText("HELP",460,360);
    ctx.fillText("skz1024 blog",460,400);
    
    ctx.fillStyle = "black";
    ctx.fillText("ENTER or Z key to SELECT(선택)",50,350);
    ctx.fillText("X or ESC key to CANCEL(취소)",50,375);
    ctx.fillText("Arrow key to MOVE cursor(커서 이동)",50,400);
    
    ctx.fillStyle = "gold";
    ctx.fillText("created by skz1024",10,440);
    ctx.fillText("Ver 0.075, 2014/07/13(day)",10,465);
};

var option = {};
option.display = function(){ // 옵션화면을 출력하는 함수
    ctx.drawImage(title.image, 0,0); // 이미지 표시(title과 같음)
    ctx.drawImage(title.title, 100,40); // 타이틀 표시(title과 같음)
    ctx.drawImage(title.arrow, 150, 190+(game.get_select()*40) ); // 화살표 표시(title과 같음)
    
    ctx.fillStyle = "#004C63";  ctx.font = "20px arial";
    ctx.fillText("SOUND : "+game.get_soundOn(),250,220);
    ctx.fillText("MUSIC : "+game.get_musicOn(),250,260);
    ctx.fillText("SOUND TEST : "+game.get_soundNumber(),250,300);
    ctx.fillText("SOUND EFFECT : ...",250,340);
    ctx.fillText("MUSIC TEST : "+game.get_musicNumber(),250,380);
    ctx.fillText("EXIT",250,420);
};

var main = {}; // 메인 이미지 객체 생성
main.image = new Image();  main.image.src = "image/background/main.png";
main.exp_meter = new Image();  main.exp_meter.src = "image/system/user_exp.png";
main.fuel_meter = new Image();  main.fuel_meter.src = "image/system/user_fuel.png";
main.arrow = new Image();  main.arrow.src = "image/system/arrow2.png";
main.user_status = new Image();  main.user_status.src = "image/system/user_status.png";
main.menu = new Image();  main.menu.src = "image/system/menu.png";
main.keyhelp = new Image();  main.keyhelp.src = "image/system/keyhelp.png";
main.display = function(){
    var exp_percent = (user.get_exp() / user.get_exptable(user.get_lv()) );
    var fuel_percent = (user.get_fuel() / user.get_fuelmax() );
    
    ctx.drawImage(main.image,0,0); // 메인 이미지 출력
    ctx.drawImage(main.user_status,0,0); // 유저 스테더스 출력
    if(exp_percent > 0 && exp_percent < 100){
        ctx.drawImage(main.exp_meter, 0, 0, (exp_percent*100), 20, 3, 86, (exp_percent*323), 27); // 경험치 미터 출력
    }
    if(fuel_percent > 0 && fuel_percent < 100){
        ctx.drawImage(main.fuel_meter, 0, 0, (fuel_percent*100), 20, 335, 79, (fuel_percent*298), 34); // 연료 미터 출력
    }
    ctx.drawImage(main.keyhelp,380,132); // 키 도움말 출력
    ctx.drawImage(main.menu, 0, 120); // 메뉴 출력
    ctx.drawImage(main.arrow, 140, 170+(game.get_menu()*30) ); // 화살표 출력
    
    ctx.fillStyle = "#778899";  ctx.font = "44px arial";
    ctx.fillText(user.get_lv(),89,44); // 레벨 출력
    
    ctx.fillStyle = "#32CD42";  ctx.font = "24px arial";
    ctx.fillText(user.get_exp()+"/"+user.get_exptable(user.get_lv()),90,73); // 경험치 표시
    
    ctx.fillStyle = "gold";  ctx.font = "24px arial";
    ctx.fillText(user.get_gold(),418,32); // 골드 표시
    
    ctx.fillStyle = "#48D1CC";  ctx.font = "24px arial";
    ctx.fillText(user.get_fuel()+"/"+user.get_fuelmax(),418,65); // 연료 표시
    
    ctx.fillStyle = "#FEBFFF";  ctx.font = "36px arial";
    ctx.fillText(user.get_crystal(),590,63); // 크리스탈 표시
    
    ctx.fillStyle = "black";  ctx.font = "18px arial";
    ctx.fillText("던전(dungeon)",10,200);
    ctx.fillText("파티(party)",10,230);
    ctx.fillText("조합(combination)",10,260);
    ctx.fillText("인벤토리(inventory)",10,290);
    ctx.fillText("상점(shop)",10,320);
    ctx.fillText("종료(exit)",10,350);
    
    ctx.fillText("인벤토리에서 판매 또는",5,410);
    ctx.fillText("유닛 강화가 가능합니다",5,440);
};

var party = {}; // 파티 이미지 표시하는 객체 생성
party.image = new Image();  party.image.src = "image/background/main.png";
party.party = new Image();  party.party.src = "image/background/party.png";
party.select = new Image();  party.select.src = "image/system/select.png";
party.display = function(){
    ctx.drawImage(party.image,0,0); // 파티 이미지 출력
    ctx.drawImage(party.party,0,0); // 파티 파티 출력(정확하게는 파티.파티 이미지)
    var select = game.get_select_teamunit(); // 팀유닛 선택
    var unithp = 0, userhp = user.get_hp(user.get_lv()), totalhp = 0;
    
    for(var a = 0; a < 12; a++){
        var team = user.teamunit_data(a),  data = user.inventory_data(team);
        var code = data[invenconst.code],  lv = data[invenconst.lv];
        
        unithp += option_battle.unit[code].get_hp(lv);
        option_battle.unit[code].display((64*[a%3])+80,(64*[Math.floor(a/3)])+120);
    }
    ctx.drawImage(party.select, (64*(select%3))+75, (64*Math.floor(select/3))+115);
    ctx.font = "24px arial";  ctx.fillStyle = "black";  totalhp = unithp + userhp;
    ctx.fillText("TOTAL HP : " + unithp + " + " + userhp + " = " + totalhp, 50, 420);
};

var shop = {}; // 상점(현질용) 이미지 표시하는 객체 생성
shop.image = new Image();  shop.image.src = "image/background/shop.png";
shop.display = function(){  ctx.drawImage(shop.image,0,0); };

var inventory = {}; // 인벤토리 이미지 객체 생성
inventory.image = new Image();  inventory.image.src = "image/background/main.png";
inventory.select = new Image();  inventory.select.src = "image/system/select.png";
inventory.inventory = new Image();  inventory.inventory.src = "image/system/inventory.png";
inventory.keyhelp = new Image();  inventory.keyhelp.src = "image/system/keyhelp.png";
inventory.display = function(){
    ctx.drawImage(inventory.image,0,0); // 이미지 출력
    ctx.drawImage(inventory.inventory,0,0); // 인벤토리 이미지 출력
    ctx.drawImage(inventory.keyhelp,368,11); // 키 도움말 이미지 출력
    ctx.fillStyle = "black";  ctx.font = "24px arial";
    ctx.fillText(game.get_select(), 150, 120); // 현재 선택한 번호를 출력
    
    var cursor = game.get_select() % 50;
    var start = Math.floor(game.get_select()/50) * 50;
    for(var a = start, b = 0; b < 50; a++, b++){
        var data = user.inventory_data(a),  code = data[invenconst.code];
        if(data[invenconst.type] == itemType.unit){
            option_battle.unit[code].display(10+((b%10)*60), 150+( Math.floor(b/10)*60) );
        }
        else if(data[invenconst.type] == itemType.item){
            option_battle.item[code].display(10+((b%10)*60), 150+( Math.floor(b/10)*60) );
        }
    }
    ctx.drawImage(inventory.select, 4+((cursor%10)*60), 145+(Math.floor(cursor/10)*60));
};

var unitview = {}; // 유닛뷰 객체 생성
unitview.image = new Image();  unitview.image.src = "image/background/main.png";
unitview.unitview = new Image();  unitview.unitview.src = "image/system/unitview.png";
unitview.upgrade = new Image();  unitview.upgrade.src = "image/system/upgrade.png";
unitview.back = new Image();  unitview.back.src = "image/system/back.png";
unitview.sell = new Image();  unitview.sell.src = "image/system/sell.png";
unitview.button = new Image();  unitview.button.src = "image/system/button.png";
unitview.display = function(){
    ctx.drawImage(unitview.image,0,0);
    ctx.drawImage(unitview.unitview,0,0);
    ctx.drawImage(unitview.back,10,390);
    ctx.drawImage(unitview.upgrade,130,390);
    ctx.drawImage(unitview.sell,250,390);
    ctx.drawImage(unitview.button,10+(game.get_menu()*120),390);
    
    ctx.font = "18px arial";
    var data = user.inventory_data(game.get_select()),  code = data[invenconst.code];
    var rank = data[invenconst.rank],  lv = data[invenconst.lv];
    if(data[invenconst.type] == itemType.unit){
        ctx.fillStyle = "#0C0200";  ctx.fillRect(240,100,380,280);
        option_battle.unit[code].display(20,100,192,192);
        
        ctx.fillStyle = "orange";  ctx.fillText("NAME : "+option_battle.unit[code].get_name(), 250, 130);
        ctx.fillStyle = "skyblue";  ctx.fillText("TYPE : "+option_battle.unit[code].get_type_name(),250,160);
        ctx.fillStyle = "pink";  ctx.fillText("HP : "+option_battle.unit[code].get_hp(lv), 450, 160);
        ctx.fillStyle = "#6B9900";  ctx.fillText("LV : "+lv+" / "+option_battle.unit[code].get_maxlv(), 250, 190);
        ctx.fillText("RANK : "+option_battle.unit[code].get_rank(),450,190);

        ctx.fillStyle = "#A84E19";  ctx.fillText("ATTACK : "+option_battle.unit[code].get_attack(lv),250,220);
        ctx.fillStyle = "#FFBA85";  ctx.fillText("DELAY : "+option_battle.unit[code].get_delay(), 450, 220);
        
        ctx.fillStyle = "#E0B94F";  
        ctx.fillText("ATTACK2 : "+option_battle.unit[code].get_attack(lv, 1), 250, 250);
        ctx.fillText("DELAY : "+option_battle.unit[code].get_delay(1), 450, 250);
        ctx.fillText("ATTACK3 : "+option_battle.unit[code].get_attack(lv, 2), 250, 280);
        ctx.fillText("DELAY : "+option_battle.unit[code].get_delay(2), 450, 280);
        
        ctx.fillStyle = "#C0E783";
        ctx.fillText("TECHNICAL : "+option_battle.unit[code].get_technical(), 250, 310);
        ctx.fillText("SKILL : "+option_battle.unit[code].get_skill(), 250, 340);
        
        ctx.fillStyle = "white";
        ctx.fillText("UPGRADE COST(강화 비용) : ", 250, 370);
        ctx.fillText(game.get_unit_upgrade_gold(lv), 500, 370);
    }
    else if(data[invenconst.type] == itemType.item){
        var name = option_battle.item[code].stat_name();
        option_battle.item[code].display(20,100,192,192);
        ctx.fillStyle = "darkgreen";  ctx.fillText(name,10,320);
    }
    else if(data[invenconst.type] == itemType.upgrade){
        //var name = option_battle.upgrade[code].stat_name();
        //option_battle.item[code].display(20,100,192,192);
        //ctx.fillStyle = "darkgreen";
        //ctx.fillText(name,10,320);
    }
};

var dungeon = {};
dungeon.image = new Image();  dungeon.image.src = "image/background/main.png";
dungeon.select = new Image();  dungeon.select.src = "image/system/arrow2.png";
dungeon.menu = new Image();  dungeon.menu.src = "image/system/list.png";
dungeon.display = function(){
    main.display();
    ctx.clearRect(0, 120, 196, 360);
    ctx.drawImage(dungeon.menu, 0, 120);
    ctx.drawImage(dungeon.select, 150, 170+(30*game.get_menu()) );
    for(var a = 0; a < 2; a++){
        if(a == 0)  ctx.fillText("뒤로가기", 10, 200);
        else  ctx.fillText(option_battle.dungeon[1].get_name(), 10, 200+(30*a));
    }
};

var round = {};
round.display = function(){
    main.display();
    ctx.clearRect(0, 120, 196, 360);
    ctx.drawImage(dungeon.menu,0,120);
    ctx.fillText("뒤로가기", 10, 170);
    ctx.drawImage(dungeon.select, 150, 170+(30*(game.get_select()%10) ) );
    var start = (game.get_select()/10 | 0) * 10;
    for(var a = start, b = 0; b < 10 && a < 12; a++, b++){
        ctx.fillText(option_battle.dungeon[game.get_menu()].get_round_name(a), 10, 200+(30*b));
    }
};

var loading = {};
loading.image = new Image();  loading.image.src = "image/background/loading.png";
loading.display = function(){ ctx.drawImage(this.image,0,0); };

var round_1 = {};
round_1.image1_1 = new Image();  round_1.image1_1.src = "image/background/round1_image1.png";
round_1.image1_2 = new Image();  round_1.image1_2.src = "image/background/round1_image2.png";
round_1.image1_3 = new Image();  round_1.image1_3.src = "image/background/round1_image3.png";
round_1.image1_4 = new Image();  round_1.image1_4.src = "image/background/round1_image4.png";
round_1.image1_5 = new Image();  round_1.image1_5.src = "image/background/round1_image5.png";
round_1.image1_6 = new Image();  round_1.image1_6.src = "image/background/round1_image6.png";
round_1.image1_7 = new Image();  round_1.image1_7.src = "image/background/round1_image7.png";
round_1.image1_8 = new Image();  round_1.image1_8.src = "image/background/round1_image8.png";
round_1.display = function(roundNumber, stringInputOption){
    var imageX = 0;
    var imageY = 0;
    switch(roundNumber){
        case 0: case 1: case 2: case 3: case 4: case 5: ctx.drawImage(round_1.image1_1,imageX,imageY,640,480,0,0,640,480); break;
        case 6: case 7: ctx.drawImage(round_1.image1_2,imageX,imageY,640,480,0,0,640,480); break;
        case 8: case 9: ctx.drawImage(round_1.image1_3,imageX,imageY,640,480,0,0,640,480); break;
        case 10: case 11: ctx.drawImage(round_1.image1_4,imageX,imageY,640,480,0,0,640,480); break;
        case 13: case 14: ctx.drawImage(round_1.image1_5,imageX,imageY,640,480,0,0,640,480); break;
        case 10: case 11: ctx.drawImage(round_1.image1_6,imageX,imageY,640,480,0,0,640,480); break;
        case 12: case 13: ctx.drawImage(round_1.image1_7,imageX,imageY,640,480,0,0,640,480); break;
        case 14: case 15: ctx.drawImage(round_1.image1_8,imageX,imageY,640,480,0,0,640,480); break;
    }
    if( imageX >= 640 )
    {
        switch(roundNumber){
            case 0: case 1: ctx.drawImage(round_1.image1_1,0,0,640,480,(1280-imageX),0,640,480); break;
            case 2: case 3: ctx.drawImage(round_1.image1_2,0,0,640,480,(1280-imageX),0,640,480); break;
            case 4: case 5: ctx.drawImage(round_1.image1_3,0,0,640,480,(1280-imageX),0,640,480); break;
            case 6: case 7: ctx.drawImage(round_1.image1_4,0,0,640,480,(1280-imageX),0,640,480); break;
            case 8: case 9: cctx.drawImage(round_1.image1_5,0,0,640,480,(1280-imageX),0,640,480); break;
            case 10: case 11: ctx.drawImage(round_1.image1_6,0,0,640,480,(1280-imageX),0,640,480); break;
            case 12: case 13: ctx.drawImage(round_1.image1_7,0,0,640,480,(1280-imageX),0,640,480); break;
            case 14: case 15: ctx.drawImage(round_1.image1_8,0,0,640,480,(1280-imageX),0,640,480); break;
        }
    }
};

//배경화면을 지우는 함수, 1frame당 전부 지우고 계속해서 다시 그린다.
function display_clear(){ ctx.clearRect(0,0,640,480); }

this.display = function(constNumber_modeName){
    display_clear();
    switch(constNumber_modeName){
        case modeName.main: main.display(); break;
        case modeName.option: option.display(); break;
        case modeName.dungeon: dungeon.display(); break;
        case modeName.title: title.display(); break;
        case modeName.shop: shop.display(); break;
        case modeName.inventory: inventory.display(); break;
        case modeName.round: round.display(); break;
        case modeName.loading: loading.display(); break;
        case modeName.unitview: unitview.display(); break;
        case modeName.party: party.display(); break;
        case modeName.round_1: round_1.display(field.get_round_number()); break;
    }
};

//-------------------------//
}// function Background end;

var background = new Background();