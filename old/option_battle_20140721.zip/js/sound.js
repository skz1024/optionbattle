// 이 파일은 사운드와 관련되어있는 파일입니다.
var soundPlayCount = new Array(option_battle.sound.length/5); // 사운드를 플레이 한 횟수를 체크
for(var a=0, length = soundPlayCount.length; a < length; a++) soundPlayCount[a] = 0;

// 사운드 파일 이름을 그대로 쓰시고 번호는 중복되지만 않게 하면 됩니다.
var soundName = { none:0, select_move:1, select_enter:2, select_back:3, select_menu:4,
	 system_buzzer:5, system_score:6, system_upgrade:7, system_notice:8, type_hyper:9, type_heal:10,
	 arrowshot:11, bubble:12, dongrami_fail:13, highattack:14, splashdamage:15, swordattack:16,
	 전자기장:17, multishot:18, laserA:19, whiteflash:20,  bombmissile:21, bomb:22, meteorite_break:23,
	 system_pause:24
	};

// 사운드 관련 함수 선언
function sound_create(constNumber_soundName, string_src){ // 사운드 만들기 함수
	for(var a=0; a<5; a++){  // 5개의 사운드 객체 생성
		option_battle.sound[a + (constNumber_soundName*5)] = new Audio();
		option_battle.sound[a + (constNumber_soundName*5)].src = string_src;
	}
}
function sound_play(constNumber_soundName){ // 사운드 플레이 함수
	if(game.get_soundOn() == true){ // 사운드가 켜져있을 때
		var count = constNumber_soundName; // 사운드 이름(객체 상수)을 count에 대입
		option_battle.sound[count*5 + (soundPlayCount[count]%5) ].play(); // 사운드 출력
		soundPlayCount[count]++; // 플레이 카운트를 1 증가
	}
}
function sound_test(constNumber_soundName){  // 사운드 테스트시에 사용하는 함수, 소리가 켜져있는지와 상관없이 작동
	var count = constNumber_soundName; // 사운드 이름(객체 상수)을 count에 대입
	option_battle.sound[count*5 + (soundPlayCount[count]%5) ].play(); // 사운드 출력
	soundPlayCount[count]++; // 플레이 카운트를 1 증가
}
function sound_shot_type(code){
    var type = option_battle.unit[code].get_type();
    switch(type){
        case typeName.bombmissile: sound_play(soundName.bombmissile); break;
        case typeName.laser: sound_play(soundName.laserA); break;
        case typeName.whiteflash: sound_play(soundName.whiteflash); break;
        case typeName.hyper: sound_play(soundName.type_hyper); break;
    }
}
function sound_shot_technical(code){
	//
}
function sound_shot_skill(code){
	
}

//사운드 만들기
sound_create(soundName.none, "sound/select_move.wav");
sound_create(soundName.select_move, "sound/select_move.wav");
sound_create(soundName.select_enter, "sound/select_enter.wav");
sound_create(soundName.select_back, "sound/select_back.wav");
sound_create(soundName.select_menu, "sound/select_menu.wav");
sound_create(soundName.system_buzzer, "sound/system_buzzer.wav");
sound_create(soundName.system_notice, "sound/system_notice.wav");
sound_create(soundName.system_score, "sound/system_score.wav");
sound_create(soundName.system_upgrade, "sound/system_upgrade.wav");
sound_create(soundName.type_heal, "sound/type_heal.wav");
sound_create(soundName.type_hyper, "sound/type_hyper.wav");
sound_create(soundName.arrowshot, "sound/arrowshot.wav");
sound_create(soundName.bubble, "sound/bubble.wav");
sound_create(soundName.dongrami_fail, "sound/dongrami_fail.wav");
sound_create(soundName.highattack, "sound/highattack.wav");
sound_create(soundName.splashdamage, "sound/splashdamage.wav");
sound_create(soundName.swordattack, "sound/swordattack.wav");
sound_create(soundName.전자기장, "sound/전자기장.wav");
sound_create(soundName.bombmissile, "sound/bombmissile.wav");
sound_create(soundName.whiteflash, "sound/whiteflash.wav");
sound_create(soundName.multishot, "sound/multishot.wav");
sound_create(soundName.laserA, "sound/laserA.wav");
sound_create(soundName.bomb, "sound/bomb.wav");
sound_create(soundName.meteorite_break, "sound/meteorite_break.wav");
sound_create(soundName.system_pause, "sound/system_pause.wav");
