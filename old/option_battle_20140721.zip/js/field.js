function Field(){
//const name//
var forceconst = { code:0, attack:1, defense:2, hp:3, attackTechnical:4, attackSkill:5,
    delay:6, delayTechnical:7, delaySkill:8, type:9, technical:10, skill:11, count:12,
    countTechnical:13, countSkill:14, code:15, techshot:16, shotcount:17, shotdelay:18, shotcombo:19 };
var enemyconst = { x:0, y:1, life:2, die:3, code:4, attack:5, defense:6, hp:7, speed_x:8, speed_y:9,
    score:10, speedType:11 };
var damageconst = { x:0, y:1, color:2, size:3, effect:4, attack:5, count:6, code:7 };
var attackconst = { x:0, y:1, code:2, type:3, skillname:4, target:5, attack:6, mode:7, width:8, height:9,
    count:10, combo:11, chain:12};
  
//function start//
this.x = 0, this.y = 0;
var clearcheck = false;
var hero = {}; // 유저(영웅?) 관련 정보
hero.hp = 0, hero.maxhp = 0;
var force = new Array(12); // 아군 관련 정보 // 2차원 배열
var enemy = new Array(30); // 적 관련 정보 // 2차원 배열
var damage = new Array(50); // 데미지 표시 // 2차원 배열
var attack = new Array(100); // 공격 이미지 표시 // 2차원 배열
var sprite = new Array(100); // 스프라이트 이미지 // 2차원 배열
var round = {}; // 라운드 정보 // 객체로 관리
round.number = 0, round.time = 0, round.enemylistcount = 0;
round.enemycurrentcount = 0, round.enemycreatecount = 0, round.enemymax = 0;
round.enemylist = [0,0,0,0,0,0,0,0,0,0]; // enemy list 배열
this.get_round_number = function(){  return round.number; };
round.time = 0, round.timemax = 0;
var bonus = {};
bonus.clear = 0,  bonus.time = 0,  bonus.score = 0,  bonus.total = 0,  bonus.plus = 0, bonus.gold = 0;
var waitingDelay = 0,  waitingCount = 0;

// 처리용 카운트
var damageCount = 0; // 데미지 배열 카운트
var attackCount = 0; // 공격 배열 카운트
var spriteCount = 0; // 스프라이트 배열 카운트
var enemyCount = 0; // 적 배열 카운트


function time_display(){
    ctx.beginPath();
    ctx.moveTo(0,30);
    ctx.lineTo(640,30);
    ctx.strokeStyle = "black";
    ctx.stroke();
    ctx.closePath();
    
    //-------시간표시-------//
    ctx.fillStyle = "black";  ctx.font = "18px arial";  ctx.strokeStyle = "white";
    ctx.clearRect(5, 5, 115, 20); ctx.fillText("TIME : "+round.time, 5, 20);
    
    //----------------------//
    var time_percent = (round.time / round.timemax) * 100;
    if(time_percent>25)     ctx.fillStyle="#0E40A3";
    else if(time_percent>10&&time_percent<=25)  ctx.fillStyle="orange";
    else                    ctx.fillStyle="red";
    ctx.fillRect(120,5,((time_percent*(620-120)/100)),20);
}
function time_down(){
    round.time -= 0.02; // 0.02초 감소
    round.time = round.time.toFixed(2); // 소수점 2자리까지만 처리
    
    if(round.time <= 0)  round.time = 0; // 시간이 0이하인경우 남은시간은 0으로 함.
}

function arrayinit(){
	// 2차원 배열을 생성한다. 개수는 내 마음대로...
	for(var a = 0, L =  force.length; a < L; a++){
		force[a] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
	}
	for(var a = 0, L =  enemy.length; a < L; a++){
		enemy[a] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
	}
	for(var a = 0, L =  damage.length; a < L; a++){
		damage[a] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
	}
	for(var a = 0, L =  attack.length; a < L; a++){
		attack[a] = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
	}
}   arrayinit(); // 배열초기화 함수 실행.

//function hero
function hero_hp_plus(value){
	hero.hp += value;
	if(hero.hp >= hero.maxhp)  hero.hp = hero.maxhp;
	else if(hero.hp <= 0)  hero.hp = 0;
}
function hero_hp_minus(value){
	hero.hp -= value;
	if(hero.hp >= hero.maxhp)  hero.hp = hero.maxhp;
	else if(hero.hp <= 0)  hero.hp = 0;
}

this.get_roundNumber = function(){  return round.number; };

//function this
this.display = function(){ // 출력 함수
	// 유저 상태 출력
	var userhp_percent = hero.hp / hero.maxhp;
	ctx.font = "24px arial";  ctx.fillStyle = "#C4F2D3";  ctx.strokeStyle = "black";
	ctx.strokeRect(30,400,240,30);
	ctx.fillRect(30,400,userhp_percent*240,30);
	ctx.fillStyle = "black";
	ctx.fillText("HP : "+hero.hp+" / "+hero.maxhp, 30, 420);
	
	// 아군 유닛 출력
	ctx.strokeStyle = "#ADB3BF";
	ctx.strokeRect(20, 100, 230, 280);
	for(var a = 0; a < 12; a++){
		var code =  force[a][forceconst.code];
		option_battle.unit[code].display( 30+(a%3)*70, 100 + Math.floor(a/3)*70 );
		
		//카운트에 해당하는 게이지 바 그리기
		var percent1 = force[a][forceconst.count] / force[a][forceconst.delay];
		var percent2 = force[a][forceconst.countTechnical] / force[a][forceconst.delayTechnical];
		var percent3 = force[a][forceconst.countSkill] / force[a][forceconst.delaySkill];
		//if(percent1 < 0)  percent = 0;
		//if(percent2 < 0)  percent = 0;
		//if(percent3 < 0)  percent = 0;
		
		ctx.fillStyle = "#606E61";
		ctx.fillRect(30 + (a%3)*70, 150 + Math.floor(a/3)*70, 70, 5);
		ctx.fillRect(30 + (a%3)*70, 155 + Math.floor(a/3)*70, 70, 5);
		ctx.fillRect(30 + (a%3)*70, 160 + Math.floor(a/3)*70, 70, 5);
		
		ctx.fillStyle = "#DFDFDF";  ctx.fillRect(30 + (a%3)*70, 150 + Math.floor(a/3)*70, percent1*70, 5);
		ctx.fillStyle = "#BCCCFC";  ctx.fillRect(30 + (a%3)*70, 155 + Math.floor(a/3)*70, percent2*70, 5);
		ctx.fillStyle = "#BCFCBD";  ctx.fillRect(30 + (a%3)*70, 160 + Math.floor(a/3)*70, percent3*70, 5);
		
		ctx.strokeStyle = "black";
        ctx.strokeRect(30 + (a%3)*70, 150 + Math.floor(a/3)*70, 70, 5);
        ctx.strokeRect(30 + (a%3)*70, 155 + Math.floor(a/3)*70, 70, 5);
        ctx.strokeRect(30 + (a%3)*70, 160 + Math.floor(a/3)*70, 70, 5);
	}
	
	// 적군 유닛 출력
	for(var a = 0, L = enemy.length; a < L; a++){
	    // 적이 생존상태가 아닐경우 그리고 적의 죽음 에니메이션 표시 카운트가 0일경우 건너 뜀
		if(enemy[a][enemyconst.life] == false && enemy[a][enemyconst.die] == 0)  continue; 
		
		var x = enemy[a][enemyconst.x];
		var y = enemy[a][enemyconst.y];
		var code = enemy[a][enemyconst.code];
		option_battle.enemy[code].display(x, y);
	}
	
	// 공격 이미지 출력
	for(var a = 0, L = attack.length; a < L; a++){
		if(attack[a][attackconst.attack] == 0)  continue; // 공격력 0일경우 처리 취소.
		
		var x = attack[a][attackconst.x];
		var y = attack[a][attackconst.y];
		var mode = attack[a][attackconst.mode];
		var code = attack[a][attackconst.code];
		option_battle.unit[code].attackdisplay(x, y, mode);
	}
	
	// 데미지 출력
	ctx.font = "24px arial";
	for(var a = 0, L = damage.length; a < L; a++){
		var attack_ = damage[a][damageconst.attack];
		var count = damage[a][damageconst.count];
		if(attack_ == 0 || count <= 0)  continue; // 공격력 0이거나 카운트가 0이면 출력 무시.
		
		var x = damage[a][damageconst.x];
		var y = damage[a][damageconst.y];
		ctx.fillStyle = damage[a][damageconst.color];
		ctx.fillText(attack_, x, y);
	}
	
	//시간 표시
	time_display();
	
	//클리어 되었을경우 클리어 점수 표시
	if(clearcheck == true){
	    var userExp = user.get_exp();
	    var userExptable = user.get_exptable(user.get_lv());
	    ctx.fillStyle = "#C3B78F";  ctx.fillRect(320, 130, 270, 270);
	    
	    ctx.font = "20px arial";  ctx.fillStyle = "black";  ctx.strokeStyle = "black";
        ctx.fillText("ROUND CLEAR!!!", 330, 150);
        ctx.fillText("CLEAR BONUS : "+bonus.clear, 330, 180);
        ctx.fillText("TIME BONUS : "+bonus.time, 330, 210);
        ctx.fillText("USER SCORE : "+bonus.score, 330, 240);
        ctx.fillText("TOTAL BONUS : "+bonus.total, 330, 270);
        ctx.fillText("--------------------------", 330, 300);
        ctx.fillText("EXP : "+userExp+" / "+userExptable, 330, 330);
        ctx.strokeRect(330, 340, 250, 20);  ctx.fillRect(330, 340, (userExp/userExptable)*250, 20);
        ctx.fillText("GOLD(골드) : +"+bonus.gold, 330, 390);
	}
};

this.input = function(){
    //배열 초기화
    arrayinit();
    
	// 유저 설정
	var userlevel = user.get_lv();
	hero.hp = user.get_hp(userlevel); // 유저 체력 결정
	
	// 팀유닛 설정
	for(var a = 0; a < 12; a++){
		var teamunit_data = user.teamunit_data(a);
		var data = user.inventory_data(teamunit_data);
		var code = data[invenconst.code];
		var lv = data[invenconst.lv];
		force[a][forceconst.code] = code;
		force[a][forceconst.attack] = option_battle.unit[code].get_attack(lv);
		force[a][forceconst.attackTechnical] = option_battle.unit[code].get_attack(lv, 1);
		force[a][forceconst.attackSkill] = option_battle.unit[code].get_attack(lv, 2);
		force[a][forceconst.delay] = option_battle.unit[code].get_delay();
		force[a][forceconst.delayTechnical] = option_battle.unit[code].get_delay(1);
		force[a][forceconst.delaySkill] = option_battle.unit[code].get_delay(2);
		force[a][forceconst.hp] = option_battle.unit[code].get_hp(lv);
		force[a][forceconst.type] = option_battle.unit[code].get_type();
		force[a][forceconst.count] = 0 + a*10;
		force[a][forceconst.countTechnical] = 5 + a*10;
		force[a][forceconst.countSkill] = 10 + a*10;
		force[a][forceconst.techshot] = option_battle.unit[code].get_techshot();
		hero.hp += force[a][forceconst.hp]; // 유저의 체력 + 유닛의 체력
	}
	hero.maxhp = hero.hp; // 유저의 최대체력을 설정
	
	// 라운드 정보 설정
	var dungeonNumber = game.get_menu();
	round.number = game.get_select();
	
	round.enemycreatecount = option_battle.dungeon[dungeonNumber].get_round_createcount(round.number);
	round.time = option_battle.dungeon[dungeonNumber].get_round_time(round.number);
	round.timemax = round.time;
	round.enemylist = option_battle.dungeon[dungeonNumber].get_round_enemylist(round.number);
	
	damageCount = 0,  attackCount = 0,  enemyCount = 0,  spriteCount = 0; //처리용 카운트 초기화
	clearcheck = false; // 클리어 체크 false로 처리;
	waitingCount = 0,  waitingDelay = 0; // 대기 카운트 초기화
	
	bonus.clear = option_battle.dungeon[dungeonNumber].get_round_clearbonus(round.number);
	bonus.time = 0,  bonus.score = 0,  bonus.total = 0,  bonus.process = 0;
};
this.process = function(){
    if(clearcheck == true){
        if(round.time > 4.00 && waitingCount%4 == 0){  
            bonus.time += 400; round.time -= 4;
            round.time = round.time.toFixed(2);
            sound_play(soundName.system_score); 
        } else if(round.time <= 4.00 && round.time > 0 && waitingCount%4 == 0){  
            bonus.time += (round.time*100);  round.time = 0;  
            sound_play(soundName.system_score);
            bonus.plus += bonus.time + bonus.clear + bonus.score | 0;
            bonus.total = bonus.plus;
        } else if(bonus.plus > 2000 && waitingCount%4 == 0){
            user.plus_exp(2000);
            bonus.plus -= 2000;
            sound_play(soundName.system_score);
        } else if(bonus.plus <= 2000 && bonus.plus > 0 && waitingCount%4 == 0){
            user.plus_exp(bonus.plus);
            bonus.plus = 0;
            sound_play(soundName.system_score);
        } else { waitingDelay++; }
        
        
        attack_move();
        enemy_move();
        enemy_die();
        damage_process();
        waitingCount++;
        if(waitingDelay >= 300)  game.mode_change(modeName.main);
    } else {
        force_check();
        attack_move();
        enemy_create(round.enemylist[Math.floor(Math.random()*round.enemylist.length)]);
        enemy_move();
        attack_progress();
        enemy_check();
        enemy_die();
        damage_process();
        time_down();
        
        if(round.enemycurrentcount <= 0 && round.enemycreatecount <= 0){
            clearcheck = true;
            bonus.gold = (bonus.clear / 10) + (bonus.score/5) | 0;
            user.plus_gold(bonus.gold);
        }
    }
};

function damage_process(){
    for(var a = 0, L = damage.length; a < L; a++){
        damage[a][damageconst.y]--;
        damage[a][damageconst.count]--;
    }
}
function force_check(){  // 아군의 공격 체크
	for(var a = 0, L = force.length; a < L; a++){
		force[a][forceconst.count]++; // 카운트 증가
		force[a][forceconst.countTechnical]++; // 카운트 증가
		force[a][forceconst.countSkill]++; // 카운트 증가
		
		var x = 30 + (a%3)*70; // x좌표 대입
        var y = 100 + Math.floor(a/3)*70; // y좌표 대입
        var type = force[a][forceconst.type]; // 타입 대입
        var code = force[a][forceconst.code]; // 코드 대입
		
		if(force[a][forceconst.count] > force[a][forceconst.delay] && force[a][forceconst.delay] != 0){ // 카운트 체크
			force[a][forceconst.count] -= force[a][forceconst.delay]; // 카운트 감소
			var attack_ = force[a][forceconst.attack]; // 공격력 대입
			attack_input(attack_, x, y, code, type, "normal", ""); // 공격 입력
			sound_shot_type(code); // 타입에 맞는 사운드 재생
		} else if(force[a][forceconst.countTechnical] > force[a][forceconst.delayTechnical] && force[a][forceconst.delayTechnical] != 0) {
			force[a][forceconst.countTechnical] -= force[a][forceconst.delayTechnical]; // 테크니컬 카운트 감소
			var attack_ = force[a][forceconst.attackTechnical]; // 테크니컬 공격력 대입
			var technicalname = option_battle.unit[code].get_technical(); // 테크니컬의 값을 얻음
			if(technicalname == ""){
				attack_input(attack_, x, y, code, type, "technical", "");
				sound_shot_type(code);
			}
			else if(technicalname == "arrowshot_20") { force[a][forceconst.shotcombo] = 20; }
			else if(technicalname == "swordattack"){ 
			    attack_input(attack_, x, y, code, type, "technical", "");
			    sound_play(soundName.swordattack);
			}
			else if(technicalname == "전자기장"){
			    attack_input(attack_, x, y, code, type, "technical", "");
			    sound_play(soundName.전자기장);
			}
		} else if(force[a][forceconst.countSkill] > force[a][forceconst.delaySkill] && force[a][forceconst.delaySkill] != 0) {
			force[a][forceconst.countSkill] -= force[a][forceconst.delaySkill]; // 스킬 카운트 감소
			var attack_ = force[a][forceconst.attackSkill]; // 스킬 공격력 대입
			var skillname = option_battle.unit[code].get_skill(); // 스킬의 값을 얻음
			if(skillname == ""){
				attack_input(attack_, x, y, code, type, "skill", "");
			}
			sound_shot_skill(code);
		} else if(force[a][forceconst.shotcombo] >= 1){
			force[a][forceconst.shotcount]++;
			if(force[a][forceconst.shotcount] >= 10 && code == 4){
				force[a][forceconst.shotcount] -= 10;
				var attack_ = force[a][forceconst.attackTechnical];
				attack_input(attack_, x, y, code, type, "technical", "");
				sound_play(soundName.arrowshot);
				force[a][forceconst.shotcombo]--;
			}
		}
	}
}
function enemy_create(code){
	if(round.enemycreatecount >= 1 && round.enemycurrentcount <= enemy.length && code != 0){
		for(var a = 0, L = enemy.length; a < L; a++){
			if(enemy[a][enemyconst.life] == false && enemy[a][enemyconst.die] <= 0){
				enemy[a][enemyconst.code] = code;
				enemy[a][enemyconst.x] = Math.floor(Math.random()*200) + 300;
				enemy[a][enemyconst.y] = Math.floor(Math.random()*200) + 100;
				enemy[a][enemyconst.attack] = option_battle.enemy[code].get_attack();
				enemy[a][enemyconst.hp] = option_battle.enemy[code].get_hp();
				enemy[a][enemyconst.life] = true;
				enemy[a][enemyconst.die] = 100;
				enemy[a][enemyconst.speed_x] = option_battle.enemy[code].get_speed_x();
				enemy[a][enemyconst.speed_y] = option_battle.enemy[code].get_speed_y();
				enemy[a][enemyconst.speedType] = option_battle.enemy[code].get_speed_type();
				enemy[a][enemyconst.score] = option_battle.enemy[code].get_score();
				
				round.enemycreatecount--;
				round.enemycurrentcount++;
				//enemyCount++;
				//if(enemyCount >= enemy.length)  enemyCount = 0;
				break;
			}
		}
	}
}
function enemy_check(){
	for(var a = 0, L = enemy.length; a < L; a++){
		if(enemy[a][enemyconst.life] == false)  continue;
		
		if(enemy[a][enemyconst.hp] <= 0){
		    round.enemycurrentcount--;
			enemy[a][enemyconst.life] = false;
			bonus.score += enemy[a][enemyconst.score];
			
			//사운드 출력
			var code = enemy[a][enemyconst.code];
			if(code >= 0 && code <= 5)  sound_play(soundName.meteorite_break);
			else if(code >= 6)  sound_play(soundName.dongrami_fail);
		}
	}
}
function enemy_die(){
    for(var a = 0, L = enemy.length; a < L; a++){
        if(enemy[a][enemyconst.life] == false && enemy[a][enemyconst.die] > 0){
            enemy[a][enemyconst.y] += 5;
            enemy[a][enemyconst.die]--;
        }
    }
}
function enemy_move(){
	for(var a = 0, L = enemy.length; a < L; a++){
		if(enemy[a][enemyconst.life] == false)  continue; // 적이 살아있지 않은경우 continue; 패스.
		
		var move_x = enemy[a][enemyconst.speed_x];
		var move_y = enemy[a][enemyconst.speed_y];
		
		if(enemy[a][enemyconst.x] <= 250){
			enemy[a][enemyconst.x] = 650;
			hero_hp_minus(enemy[a][enemyconst.attack]);
			enemy[a][enemyconst.speed_x] = Math.random()*5 + 5 | 0;
		} else {
			enemy[a][enemyconst.x] -= move_x;
		}
		
		enemy[a][enemyconst.y] += move_y;
		if(enemy[a][enemyconst.y] <= 40){
			enemy[a][enemyconst.speed_y] = Math.random()*10 | 0;
		} else if(enemy[a][enemyconst.y] >= 400){
			enemy[a][enemyconst.speed_y] = Math.random()*-10 | 0;
		}
	}
}
function attack_input(attack_, x, y, code, unitType, attackMode, stringSkillname){
	attack[attackCount][attackconst.attack] = attack_;
	attack[attackCount][attackconst.x] = x;
	attack[attackCount][attackconst.y] = y;
	attack[attackCount][attackconst.code] = code;
	attack[attackCount][attackconst.type] = unitType;
	attack[attackCount][attackconst.mode] = attackMode;
	attack[attackCount][attackconst.skillname] = stringSkillname;
	attack[attackCount][attackconst.target] = attack_target();
	
	if(unitType == typeName.direct){
		var target = attack[attackCount][attackconst.target];
		attack[attackCount][attackconst.x] = enemy[target][enemyconst.x];
		attack[attackCount][attackconst.y] = enemy[target][enemyconst.y];
	}
	else if(unitType == typeName.bombmissile){
		attack[attackCount][attackconst.count] = 0;
		attack[attackCount][attackconst.combo] = 9;
	}
	else if(unitType == typeName.heal && attackMode == "technical"){
		var heal = attack[attackCount][attackconst.attack];
		// 유저의 체력 회복
		hero_hp_plus(heal);
		sound_play(soundName.type_heal);
		attack[attackCount][attackconst.attack] = 0; // 공격 데이터 삭제
	}
	else if(unitType == typeName.laser && attackMode == "technical"){
		var target = attack[attackCount][attackconst.target];
		attack[attackCount][attackconst.y] = enemy[target][enemyconst.y];
		attack[attackCount][attackconst.width] = 300;
		attack[attackCount][attackconst.height] = 20;
		attack[attackCount][attackconst.count] = 0;
	}
	
	attackCount++;
	if(attackCount >= attack.length)  attackCount = 0; // 배열 길이를 초과할경우 데미지 카운트를 0으로 함
}
function attack_target(){
	//공격할 유닛의 타켓을 설정한다. 기본적으로 랜덤이며, 10번의 랜덤계산으로도 적을 찾아낼 수 없을경우
	//1번부터 끝번호까지 조사하여 값을 리턴함.
	var L = enemy.length; // 적 배열의 최대값을 얻음
	var value = Math.floor(Math.random() * L); // 타겟 설정
	for(var a = 0; a < 10; a++){
		if(enemy[value][enemyconst.life] == true)  return value; // 적이 살아있을경우(타겟 번호) 값을 리턴
		else value = Math.floor(Math.random() * L); // 아닐경우 다시 랜덤으로 결정
	}
	for(var a = 0; a < L; a++){ // 만약 10번의 랜덤계산으로도 안된다면
		if(enemy[a][enemyconst.life] == true)  return a; // 앞번호부터 차례대로 검색해서 값을 리턴
	} 
	return 0; // 이마저도 실패할경우 리턴 0
}

function attack_move(){
	for(var a = 0, L = attack.length; a < L; a++){
		if(attack[a][attackconst.attack] == 0)  continue; // 공격력 0일경우 무시
		if(attack[a][attackconst.type] == typeName.laser && attack[a][attackconst.mode] == "technical"){
			attack[a][attackconst.x] += 10;  continue;
		}  else if(attack[a][attackconst.type] == typeName.whiteflash) {
			var target = attack[a][attackconst.target];
			var move_y = ( enemy[target][enemyconst.y] - attack[a][attackconst.y] ) / 4;
			attack[a][attackconst.x] += 6;
			attack[a][attackconst.y] += move_y;
			continue;
		}  else if(attack[a][attackconst.type] == typeName.bombmissile) {
			if(attack[a][attackconst.combo] <= 8)  continue;
		}
		
		var target = attack[a][attackconst.target];
		var move_x = ( enemy[target][enemyconst.x] - attack[a][attackconst.x] ) / 10;
		var move_y = ( enemy[target][enemyconst.y] - attack[a][attackconst.y] ) / 10;
		
		if(move_x <= 10 && move_x >= 4)  move_x = 10;
		else if(move_x <= 4 && move_x >= 2)  move_x = 4;
		else if(move_x <= -2 && move_x >= -4)  move_x = -4;
		else if(move_x < -4 && move_x >= -10)  move_x = -10;
		
		if(move_y <= 10 && move_y >= 4)  move_y = 10;
		else if(move_y <= 4 && move_y >= 1)  move_y = 4;
		else if(move_y <= -1 && move_y >= -4)  move_y = -4;
		else if(move_y <= -4 && move_y >= -10)  move_y = -10;
		
		attack[a][attackconst.x] += move_x;
		attack[a][attackconst.y] += move_y;
		
		//해당 좌표를 벗어날경우 공격력을 0으로 처리
		if(attack[a][attackconst.x] >= 800 || attack[a][attackconst.y] >= 600)  attack[a][attackconst.attack] = 0;
	}
}

function damage_input(attack, x, y, color){
	damage[damageCount][damageconst.attack] = attack; // 데미지
	damage[damageCount][damageconst.x] = x; // x좌표
	damage[damageCount][damageconst.y] = y; // y좌표
	damage[damageCount][damageconst.color] = color; // 색깔
	damage[damageCount][damageconst.count] = 50; // 50프레임동안 출력
	
	damageCount++; // 데미지카운트를 증가
	if(damageCount >= damage.length)  damageCount = 0; // 배열 길이를 초과할경우 데미지 카운트를 0으로 함
}

function attack_progress(){
	for(var a = 0, L = attack.length; a < L; a++){
		if(attack[a][attackconst.attack] == 0)  continue;
		
		var mode = attack[a][attackconst.mode];
		var type = attack[a][attackconst.type];
		var target = attack[a][attackconst.target];
		var attack_x = attack[a][attackconst.x];
		var attack_y = attack[a][attackconst.y];
		var enemy_x = enemy[target][enemyconst.x];
		var enemy_y = enemy[target][enemyconst.y];
		//ctx.strokeRect(enemy_x-20,enemy_y-10,50,50);
		var attack_ = attack[a][attackconst.attack]; // 공격력
		var color = option_battle.unit[attack[a][attackconst.code]].get_color(); // 타입 색깔
		
		if(type == typeName.whiteflash){
			attack[a][attackconst.count]++;
			if(attack[a][attackconst.count] % 4 != 0)  continue;
			
			for(var b = 0, I = enemy.length; b < I; b++){
				if(enemy[b][enemyconst.life] == false)  continue; // 적이 죽어있을경우 처리 무시
				
				var X = enemy[b][enemyconst.x];
				var Y = enemy[b][enemyconst.y];
				if(X-10 <= attack_x && X+40 >= attack_x && Y-10 <= attack_y && Y+40 >= attack_y){
					var color = option_battle.unit[attack[a][attackconst.code]].get_color(); // 타입 색깔
					var defense = enemy[b][enemyconst.defense]; // 방어력 체크
					enemy[target][enemyconst.hp] -= attack_ - defense; // 적의 체력 -= 공격력 - 방어력
					damage_input(attack_ - defense, X, Y, color); // 데미지 입력
				}
			} // for end
		}
		else if(type == typeName.bombmissile){
			if(attack[a][attackconst.combo] >= 9){
				if(enemy_x-20 <= attack_x && enemy_x+50 >= attack_x && enemy_y-10 <= attack_y && enemy_y+50 >= attack_y){
					var defense = enemy[target][enemyconst.defense];
					var color = option_battle.unit[attack[a][attackconst.code]].get_color();
					enemy[target][enemyconst.hp] -= attack_ - defense;
					damage_input(attack_ - defense, enemy_x, enemy_y, color);
					attack[a][attackconst.combo] = 8;
					attack[a][attackconst.count] = 11;
				}
			}
			else{
				attack[a][attackconst.count]++;
				if(attack[a][attackconst.count]%12 != 0) continue;
				attack_ = Math.floor(attack_*0.4);
				var RX = Math.floor(Math.random()*10)+100;
				var RY = Math.floor(Math.random()*10)+100;
				ctx.fillStyle = option_battle.type[typeName.bombmissile].get_color();
				ctx.fillRect(attack_x-RX,attack_y-RY,RX*2,RY*2);
				
				for(var b = 0, I = enemy.length; b < I; b++){
					if(enemy[b][enemyconst.life] == false)  continue;
					
					var X = enemy[b][enemyconst.x];
					var Y = enemy[b][enemyconst.y];
					if(X >= attack_x-RX && X <= attack_x+RX && Y >= attack_y-RY && Y <= attack_y+RY){
						var color = option_battle.unit[attack[a][attackconst.code]].get_color(); // 타입 색깔
						var defense = enemy[b][enemyconst.defense]; // 방어력 체크
						enemy[target][enemyconst.hp] -= attack_ - defense; // 적의 체력 -= 공격력 - 방어력
						damage_input(attack_ - defense, X, Y, color); // 데미지 입력
					}
				}
				sound_play(soundName.bomb);
				attack[a][attackconst.combo]--;
				if(attack[a][attackconst.combo] <= 0)  attack[a][attackconst.attack] = 0;
			}
		}
		else if(mode == "technical" && type == typeName.laser){
			attack[a][attackconst.count]++;
			if(attack[a][attackconst.count] % 7 != 0)  continue;
			
			var width = attack[a][attackconst.width];
			var height = attack[a][attackconst.height];
			for(var b = 0, I = enemy.length; b < I; b++){
				if(enemy[b][enemyconst.life] == false)  continue; // 적이 죽어있을경우 처리 무시
				
				var X = enemy[b][enemyconst.x];
				var Y = enemy[b][enemyconst.y];
				if(X-10 >= attack_x && X <= attack_x+width && Y >= attack_y && Y-10 <= attack_y+height){
					var color = option_battle.unit[attack[a][attackconst.code]].get_color(); // 타입 색깔
					var defense = enemy[b][enemyconst.defense]; // 방어력 체크
					enemy[target][enemyconst.hp] -= attack_ - defense; // 적의 체력 -= 공격력 - 방어력
					damage_input(attack_ - defense, X, Y, color); // 데미지 입력
				}
			} // for end
		}
		else if(enemy_x-20 <= attack_x && enemy_x+50 >= attack_x && enemy_y-20 <= attack_y && enemy_y+50 >= attack_y){
			if(type == typeName.splash){ // 스플래시 타입일경우
				for(var b = 0, I = enemy.length; b < I; b++){
					if(enemy[b][enemyconst.life] == false)  continue; // 적이 죽어있을경우 처리 무시
					
					var X = enemy[b][enemyconst.x];
					var Y = enemy[b][enemyconst.y];
					if(X >= attack_x-75 && X <= attack_x+75 && Y >= attack_y-75 && Y <= attack_y+75){
						var defense = enemy[target][enemyconst.defense]; // 방어력 체크
						enemy[target][enemyconst.hp] -= attack_ - defense; // 적의 체력 -= 공격력 - 방어력
						damage_input(attack_ - defense, X, Y, color); // 데미지 입력		
					}
				} // for end
				sound_play(soundName.splashdamage);
				attack[a][attackconst.attack] = 0; // 공격력을 0으로 만들어 데이터 무효화
			} else {
				var defense = enemy[target][enemyconst.defense]; // 방어력 체크
				enemy[target][enemyconst.hp] -= attack_ - defense; // 적의 체력 -= 공격력 - 방어력
				damage_input(attack_ - defense, enemy_x, enemy_y, color); // 데미지 입력
				attack[a][attackconst.attack] = 0; // 공격력을 0으로 만들어 데이터 무효화
			} // 공격 알고리즘 처리
		} // 공격 체크
	} // for end
}
//-----------------------//
}// function end
//-----------------------//
var field = new Field();