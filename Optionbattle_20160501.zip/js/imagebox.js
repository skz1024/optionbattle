function ImageBox () {
//---------------------//
this.enemy = new Array(69 + 1);
this.enemy[0] = new Image();  this.enemy[0].src = "image/system/unused.png";
for(var i = 1; i < this.enemy.length; i++){
    this.enemy[i] = new Image();
    this.enemy[i].src = "image/enemy/enemy"+i+".png";
}

this.round = new Array(38 + 1);
for(var i = 0; i < this.round.length; i++){
    this.round[i] = new Image();
    this.round[i].src = "image/round/round"+i+".png"; // 라운드
}

} //----------- function end ---//
optionbattle.imagebox = new ImageBox();