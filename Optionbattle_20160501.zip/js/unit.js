// 모든 유닛(unit)은 이 함수 내부의 create를 이용하여 만든다.
function Unit(){
// function Unit Start //
var createCount = 0;
function create(strName, number, constType, rank, attackweight, attackSound, isUsedTechnicalImage, attackTechnicalSound){
    unit[createCount] = new create_unit(strName, number, constType, rank, attackweight, attackSound, isUsedTechnicalImage, attackTechnicalSound);
    createCount++;
}


function create_unit(strName, number, constType, rank, attackweight, attackSound, isUsedTechnicalImage, attackTechnicalSound){
	this.name = strName; // 유닛의 이름
	this.number = number; // 유닛의 번호
	this.type = constType; // 유닛의 타입(또는 속성), 타입 이름을 적는게 아니라 상수로 정의된 이름을 사용해야함.
	this.typeName = "";
	this.rank = rank; // 유닛의 랭크
	this.hp = 0; // 유닛의 체력
	this.mp = 0; // 유닛의 마력(정의 안하면 0)
	this.attack = 0; // 공격력
	this.attackweight = attackweight; // 공격력가중치 
	this.attackTechnical = 0; // 테크니컬형 공격력
	this.attackSkill = 0; // 스킬형 공격력
	this.delay = 0; // 지연시간
	this.delayTechnical = 0; // 테크니컬형 지연시간
	this.delaySkill = 0; // 스킬형 지연시간
	this.defense = 0; // 방어력?
	this.attackSound = soundName.none;
	this.attackTechnicalSound = soundName.none;
	if(attackSound == null)  this.attackSound = soundName.none;  else  this.attackSound = attackSound;
	if(attackTechnicalSound == null)  this.attackTechnicalSound = this.attackSound;  else  this.attackTechnicalSound = attackTechnicalSound;
	
	
	//이미지 관련 변수
	this.image = new Image();  this.image.src = "image/unit/unit"+number+".png"; // 유닛의 이미지 경로
	this.attackImage = new Image();  this.attackImage.src = "image/attack/unit"+number+".attack.png";
	
	this.attackTechnicalImage = new Image();
	if(isUsedTechnicalImage != null && isUsedTechnicalImage != false){
		this.attackTechnicalImage.src = "image/attack/unit"+number+".technical.png"; 
	} else { 
		this.attackTechnicalImage.src = this.attackImage.src; // 일반공격시의 이미지를 사용
	}  
	
	var tempAttack = 0; // this의 문제를 해결하기 위해 임시 변수 생성
	var tempDelay = 0;
	var tempTechnicalAttack = 0;
	var tempTechnicalDelay = 0;
	var tempHp = 0;
	var tempTypeName = "";
	(function(){
	    var rankStandard = 0, rankAttack = 0, rankHp = 0;
	    switch(rank){
	        case 1: rankStandard = 12,   rankAttack = 1000,   rankHp = 1000;  break;
	        case 2: rankStandard = 24,   rankAttack = 2000;   rankHp = 2000;  break;
	        case 3: rankStandard = 48,   rankAttack = 4000;   rankHp = 3000;  break;
	        case 4: rankStandard = 96,   rankAttack = 8000;   rankHp = 4000;  break;
	    }
	    
	    var T = optionbattle.type.getType(constType);
	    var section = (T.section / 100);
	    var attackBase = section * rankAttack |0;
	    tempAttack = (attackweight/100) * attackBase |0;
	    
	    if(T.section >= 285 && tempAttack <= rankAttack * section){
	        tempAttack = section * rankAttack;
	    }  else if(T.section < 285 && (tempAttack >= section * rankAttack * 1.1 || tempAttack <= section * rankAttack * 0.9) ){
	        tempAttack = section * rankAttack;
	    }  
	    if(T.normal != 0)  tempDelay = tempAttack / ( rankStandard * T.normal / 100 ) | 0;
	    else { tempDelay = 0; }
	    
	    switch(constType){
	        case typeName.HYPER:  tempTechnicalAttack = tempAttack * 4; break;
	        default: tempTechnicalAttack = tempAttack; break;
	    }
	    if(T.technical != 0)  tempTechnicalDelay = tempTechnicalAttack / ( rankStandard * T.technical / 100 ) |0;
	    else {  tempTechnicalDelay = 0;  }
	    
	    if(constType == typeName.METAL){
	        tempHp = rankHp * 10;
	    } else if(constType == typeName.HEAL){
	        tempHp = rankHp * 2.5 | 0;
	    } else {
	        tempHp = rankHp;
	    }
	    
	    if(tempDelay == 0)  tempAttack = 0;
	    if(tempTechnicalDelay == 0)  tempTechnicalAttack = 0;
	    
	    tempTypeName = T.name;
	})();
	
	this.hp = tempHp;
	this.attack = tempAttack;
	this.delay = tempDelay;
	this.attackTechnical = tempTechnicalAttack;
	this.delayTechnical = tempTechnicalDelay;
	this.typeName = tempTypeName;
}
//----------------------------------//

var unit = new Array(100);

// 유닛 생성, 기본 유닛
create("", 0, typeName.UNUSED, 1, 100, soundName.none);
create("대포", 1, typeName.HYPER, 1, 120, soundName.type_hyper, true);
create("나무 활", 2, typeName.MULTISHOT, 1, 100, soundName.none, true, soundName.none);
create("하늘색 검", 3, typeName.DIRECT, 1, 100, soundName.none);
create("폭발공", 4, typeName.SPLASH, 1, 100, soundName.bombmissile);
create("공구상자", 5, typeName.HEAL, 1, 100, soundName.none, false, soundName.type_heal);
create("강철", 6, typeName.METAL, 1, 100, soundName.none);
create("수레차", 7, typeName.LASER, 1, 100, soundName.laserA, true);
create("폭발미사일", 8, typeName.MISSILE, 1, 107, soundName.bombmissile);
create("화이트 Ctype", 9, typeName.WHITEFLASH, 1, 95, soundName.whiteflash, false, soundName.whiteflash);
create("삼웨이 프록터", 10, typeName.WAYSHOT3, 1, 104, soundName.none);
create("더블샷 발사장치", 11, typeName.DOUBLESHOT, 1, 108, soundName.none);
create("히트타격기", 12, typeName.HITSHOT, 1, 100, soundName.none);
create("버스트샷총", 13, typeName.BURSTSHOT, 1, 104, soundName.burstshot);
create("로켓미사일", 14, typeName.ROCKET, 1, 107, soundName.bombmissile);
create("파라포1호", 15, typeName.PARAPO, 1, 180);
create("레이져사출장치", 16, typeName.BEAM, 1, 91, soundName.beam1);
//--------------------- advanced class PART 1
create("톱니바퀴", 17, typeName.SAWTOOTH, 2, 110, soundName.sawtooth_launch);
create("팔선1호", 18, typeName.PALSERN, 2, 220, soundName.palsern_wait);
create("파이어동그라미", 19, typeName.FIRE, 2, 98, soundName.fire);
create("레이져로직장치", 20, typeName.BEAMLOGIC, 2, 100, soundName.beam2);
create("레이져식스장치", 21, typeName.BEAMSIX, 2, 100, soundName.beam3);
create("머신건 A", 22, typeName.MACHINEGUN, 2, 100);
create("팔웨이링형", 23, typeName.WAYSHOT8, 2, 100);
//--------------------- donggramiclass PART 1
create("초록색동그라미", 24, typeName.HYPER, 2, 115, soundName.type_hyper, true);
create("갈색동그라미", 25, typeName.MULTISHOT, 2, 107, soundName.none);
create("파랑색동그라미", 26, typeName.DIRECT, 2, 104);
create("빨강색동그라미", 27, typeName.SPLASH, 2, 106, soundName.bombmissile);
create("주황색동그라미", 28, typeName.HITSHOT, 2, 107);
create("하늘색동그라미", 29, typeName.BURSTSHOT, 2, 105, soundName.burstshot);


this.getCreateCount = function(){  return createCount; };
this.getUnit = function(index){  return unit[index]; };
this.getImage = function(index){  return unit[index].image; };
//-------- function end---------//
};// new Unit();

optionbattle.unit = new Unit();
