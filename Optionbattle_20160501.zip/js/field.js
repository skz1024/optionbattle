function Field(){
// function start //

// 구조는 의미 없는거 같음. 무시해도 됨.
// 뒷자리가 Unit일경우 클래스(클래스는 암묵적으로 맨 앞글자가 대문자이다.)
// 뒷자리가 unit일경우 객체 배열로 간주한다.
// 뒷자리가 data일경우 단일 변수 객체로 간주한다.
// 뒷자리가 없을경우, 그와 관련한 데이터를 처리하는것으로 간주한다.
// unit객체는 필요시 상속한다.
// 그 외의 변수들은 따로 객체 내에 내장해서 사용
// unit객체는 전역 객체로 간주하고 변수는 어디든 집적 수정할 수 있다. 사용하면서 주의할것.
var NOTHING = -1;
	
function collision(obj1, obj2, y, width, height){ // object1, object2 // or // object1, x(obj2 << change), y, w(width), h(height)
  if(typeof obj1 == "object" && typeof obj2 == "object" && typeof obj1 !== null && typeof obj2 !== null){
      // left = x, right = x + imagesizeX, top = y, bottom = imagesizeY;
      if(obj1.x <= obj2.x + obj2.width && obj1.y <= obj2.y + obj2.height &&
         obj1.x + obj1.width >= obj2.x && obj1.y + obj1.height >= obj2.y ){
             return true;
      } else {
          return false;
      }
  } else if(typeof obj1 == "object" && typeof obj2 == "number" && typeof y == "number" && typeof width == "number" && typeof height == "number"){
      var obj3 = { x:obj2, y:y, width:width, height:height };
      if(obj1.x <= obj3.x + obj3.width && obj1.y <= obj3.y + obj3.height &&
         obj1.x + obj1.width >= obj3.x && obj1.y + obj1.height >= obj3.y){
             return true;
      } else {
          return false;
      }
  }
}	


function ObjectUnit(){
    // 이 이외의 변수들은 필요시 객체를 확장하여 적용.
    this.index = 0; // 배열 번호
    this.number = 0; // ?
    this.x = 0; // x좌표
    this.y = 0; // y좌표
    this.width = 0; // 가로크기
    this.height = 0; // 세로크기
    this.isusing = false; // 사용중인지 판단하는 변수
    this.type = 0; // 타입 번호
    this.code = 0; // 코드(용도에 따라서 다르게 쓰일 수 있음.)
    this.mode = 0; // 모드
    this.attack = 0; // 공격력
    this.defense = 0; // 방어력
    this.miss = 0; // 미스확률
    this.hp = 0; // 체력
    this.maxhp = 0; // 최대체력
    this.shield = 0;  // 쉴드
    this.armor = 0; // 갑옷
    this.count = 0; // 카운트
    this.delay = 0; // 딜레이(지연시간 / 프레임단위)
    this.color = "#000000"; // 색깔: html코드 또는 스트링?으로 결정
    this.speedx = 0; // x좌표 속도 기준점
    this.speedy = 0; // y좌표 속도 기준점
    this.movex = 0; // 이동되는 양
    this.movey = 0; // 이동되는 양
    this.combo = 0; // 콤보 또는 타격 수
    this.width = 0; // 가로크기
    this.height = 0; // 세로크기
    this.image = new Image(); // 이미지 복사 파일
    this.image.src = "";
    this.wait = 0;
    this.iswait = false;
    this.x2 = 0; // 제 2좌표
    this.y2 = 0; // 제 2좌표
}
// 변수 초기화 함수
ObjectUnit.prototype.init = function(){
    this.number = 0;
	this.x = 0; // x좌표
    this.y = 0; // y좌표
    this.width = 0; // 가로크기
    this.height = 0; // 세로크기
    this.isusing = false; // 사용중인지 판단하는 변수
    this.type = 0; // 타입 번호
    this.code = 0; // 코드(용도에 따라서 다르게 쓰일 수 있음.)
    this.mode = 0; // 모드
    this.attack = 0; // 공격력
    this.defense = 0; // 방어력
    this.miss = 0; // 미스확률
    this.hp = 0; // 체력
    this.maxhp = 0; // 최대체력
    this.shield = 0;  // 쉴드
    this.armor = 0; // 갑옷
    this.count = 0; // 카운트
    this.delay = 0; // 딜레이(지연시간 / 프레임단위)
    this.color = "#000000"; // 색깔: html코드 또는 스트링?으로 결정
    this.speedx = 0; // x좌표 속도 기준점
    this.speedy = 0; // y좌표 속도 기준점
    this.movex = 0; // 이동되는 양
    this.movey = 0; // 이동되는 양
    this.combo = 0; // 콤보 또는 타격 수
    this.width = 0; // 가로크기
    this.height = 0; // 세로크기
    this.image = new Image(); // 이미지 복사 파일
    this.image.src = "";
    this.wait = 0;
    this.iswait = false;
    this.x2 = 0; // 제 2좌표
    this.y2 = 0; // 제 2좌표
};


// 아군세력 유닛 관련 정보
function ForceUnit(){
	this.attack = 0;   this.attackTechnical = 0;   this.attackSkill = 0; // 공격력 관련 수치
	this.delay = 0;    this.delayTechnical = 0;    this.delaySkill = 0; // 딜레이 관련 수치
	this.count = 0;    this.countTechnical = 0;    this.countSkill = 0; // 카운트 관련 수치
	this.shotCount = 0;  this.techCount = 0;

	this.isstackshot = false,  this.stackshot = 0,  this.stackshotCount = 0, this.stackshotDelay = 0;
} ForceUnit.prototype = new ObjectUnit();

// 아군세력 유닛 관련 함수
var force = {};
force.stat = new Image();  force.stat.src = "image/field/forcestat.png";
force.data = new Array(  optionbattle.user.getTeamunit().length  );
for(var a = 0; a < force.data.length; a++)  force.data[a] = new ForceUnit();

force.setForce = function(){
    var teamunit = optionbattle.user.getTeamunit();
	for(var a = 0; a < force.data.length; a++){
	    if(teamunit[a] == -1){
	        force.data[a] = null;
	        force.data[a] = new ForceUnit(); // 세력의 데이터 초기화
	        continue; // 건너뜀
	    }
		var I = optionbattle.user.getInventoryData(teamunit[a]);
		var U = optionbattle.unit.getUnit(I.code);
		var T = optionbattle.type.getType(U.type);
		var outputBasex = 0;
		var outputBasey = 340;
		
		force.data[a].isusing         = true;
		force.data[a].attack          = U.attack * (I.lv * 0.02 + 1)|0;
		force.data[a].attackTechnical = U.attackTechnical * (I.lv * 0.02 + 1)|0;
		force.data[a].attackSkill     = 0;
		force.data[a].delay           = U.delay;
		force.data[a].delayTechnical  = U.delayTechnical;
		force.data[a].delaySkill      = 0;
		force.data[a].techshot        = 0;
		force.data[a].delayTechshot   = 0;
		force.data[a].techshotLeft    = 0;
		force.data[a].countTechshot   = 0;
		force.data[a].count           = a * 2 + 1;
		force.data[a].countTechnical  = a * 2 + 2;
		force.data[a].countSkill      = 0;
		force.data[a].hp              = U.hp * (I.lv * 0.02 + 1)|0;
		force.data[a].type            = U.type;
		force.data[a].x               = outputBasex + (128 * (a%5))|0;
		force.data[a].y               = outputBasey + (20 * Math.floor(a/5))|0;
		force.data[a].code            = I.code;
		force.data[a].shotCount       = T.shotCount;
		force.data[a].techCount       = T.techCount;
		force.data[a].image           = U.image;
		force.data[a].stackshot       = 0;
		
		if(T.iswait == true){
			force.data[a].isstackshot = true;
			force.data[a].stackshotDelay = T.delay;
		}
		
		// 탐사선 체력 추가
		tamsaseon.hp += force.data[a].hp;
		tamsaseon.maxhp += force.data[a].hp;
	}
};
force.countUp = function(forceData){  // 해당 유저의 유닛의 카운트 증가, 단 딜레이가 카운트보다 작을경우 카운트는 증가하지 않음.
  // 참고: 딜레이가 0일경우, 카운트는 0에서부터 시작하므로 조건에 맞지 않아서 카운트가 증가하지 않음.
	if(forceData.count          < forceData.delay)         {  forceData.count += 1; }
	if(forceData.countTechnical < forceData.delayTechnical){  forceData.countTechnical += 1; }
	if(forceData.stackshotCount < forceData.stackshotDelay){  forceData.stackshotCount++; }
	
	if(forceData.delay == 0)  forceData.count = 0;
	if(forceData.delayTechnical == 0)  forceData.countTechnical = 0;
};
force.attackCheck = function(forceData){	
    if(forceData.isusing == false)  return;
    
	// 일반 공격 처리, 지연시간이 0인경우, 공격을 할 수 없음.
	var U = optionbattle.unit.getUnit(forceData.code);
	
	if(forceData.count >= forceData.delay && forceData.delay != 0){
		forceData.count -= forceData.delay;
		if(forceData.isstackshot == true){
			forceData.stackshot += forceData.shotCount;
		} else {
			for(var i = 0; i < forceData.shotCount; i++){
			    attack.create(forceData, "normal", i);
			}
			optionbattle.sound.play(U.attackSound);
		}
	}
	
	
	
	// 테크니컬 공격 처리
	if(forceData.countTechnical >= forceData.delayTechnical && forceData.delayTechnical != 0){  
		forceData.countTechnical -= forceData.delayTechnical;
		if(forceData.type == typeName.HEAL){
		    tamsaseon.hp += forceData.attackTechnical;
		    if(tamsaseon.hp >= tamsaseon.maxhp)  tamsaseon.hp = tamsaseon.maxhp;
		} else{
		    for(var i = 0; i < forceData.techCount; i++){
		        attack.create(forceData, "technical", i);
		    }
		}
		optionbattle.sound.play(U.attackTechnicalSound);
	}
	
	// 스택형태의 샷 처리용
	if(forceData.stackshot >= 1 && forceData.stackshotCount >= forceData.stackshotDelay){
		forceData.stackshotCount = 0;
		forceData.stackshot--;
		attack.create(forceData, "normal", 0);
		optionbattle.sound.play(U.attackSound);
	}
};

force.init = function(){  force.setForce();  }; // 초기화 함수
force.process = function(){
    for(var i = 0; i < force.data.length; i++){
        if(force.data[i].isusing == true){
            force.attackCheck(force.data[i]);
            if(tamsaseon.recovery == false && enemy.getCurrentCount() >= 1)  force.countUp(force.data[i]);
        }
    }
}; // 진행, 처리 함수
force.display = function(){ // 출력함수
    if(system.pause == false)  return;  // 일시정지상태가 아니면 출력 안함.
    
    ctx.drawImage(force.stat, 0, 340);
	for(var a = 0; a < force.data.length; a++){
	    if(force.data[a].isusing == false)  continue;
		ctx.drawImage(force.data[a].image, force.data[a].x, force.data[a].y, 16, 16);
		var percentNormal = 0, percentTechnical = 0;
		
		if(force.data[a].delay != 0) percentNormal = force.data[a].count / force.data[a].delay;
		if(force.data[a].delayTechnical != 0) percentTechnical = force.data[a].countTechnical / force.data[a].delayTechnical;
		
		ctx.strokeStyle = "black";
		ctx.fillStyle = "orange";
		ctx.strokeRect(force.data[a].x+20, force.data[a].y+3, 90, 5);  ctx.fillRect(force.data[a].x+20, force.data[a].y+3, 90*percentNormal, 5);
		ctx.fillStyle = "skyblue";
		ctx.strokeRect(force.data[a].x+20, force.data[a].y+8, 90, 5);  ctx.fillRect(force.data[a].x+20, force.data[a].y+8, 90*percentTechnical, 5);
	}
};	


//---------------------------------//


function AttackUnit(index){
	this.target = 0; // 적을 타겟할 대상의 번호(적의 코드가 아님)
	this.istarget = true; // 타겟을 추적하는 방식. 이게 false일경우 적을 추적하지 않음.
	this.isfollow = true; // 적을 쫓아가는 방식
	this.mode = ""; // 공격을 한 유닛의 공격 정의 패턴(normal, technical, skill, enemy)
	this.combo = 0;
	this.ismoveon = true;
	this.waittime = 0; // 무기가 표시되기까지 대기시간
	this.compulsion = 0;  // 해당 지연시간동안 히트에 실패하면 적을 무조건 강제로 타격, 단 타겟이 true인경우만 적용
	this.index = index;
}  AttackUnit.prototype = new ObjectUnit(); // 서브 클래스 상속
// class Attack
var attack = {};
attack.data = new Array(200);
attack.usingCount = 0;
for(var index = 0; index < attack.data.length; index++)  attack.data[index] = new AttackUnit(index);
attack.create = function (U, mode, option) {
    if (mode == null) mode = "normal";
    var number = 0;
    for (var a = 0; a < attack.data.length; a++) {
        if (attack.data[a].isusing == false) { number = a; break; }
    }
    var attackUnitData = attack.data[number]; // 간편하게 작성하기 위해 attackUnitData로 취급을 해버림.
    attackUnitData.x = tamsaseon.x + 24; attackUnitData.y = tamsaseon.y + 24;

    var I = optionbattle.unit.getUnit(U.code);
    var T = optionbattle.type.getType(U.type);
    if (mode == "normal") {
        attackUnitData.image = I.attackImage;
        attackUnitDatawidth = attackUnitData.image.width; attackUnitData.height = attackUnitData.image.height;
        attackUnitData.attack = U.attack;
    } else if (mode == "technical") {
        attackUnitData.image = I.attackTechnicalImage;
        attackUnitData.width = attackUnitData.image.width; attackUnitData.height = attackUnitData.image.height;
        attackUnitData.attack = U.attackTechnical;
    }

    attackUnitData.type = U.type;
    attackUnitData.code = U.code;
    attackUnitData.mode = mode;
    attackUnitData.isusing = true;
    attackUnitData.istarget = T.istarget;
    attackUnitData.isfollow = T.isfollow;
    attackUnitData.delay = T.delay;
    attackUnitData.combo = T.combo;
    attackUnitData.count = 0;
    attackUnitData.speedx = 10;
	attackUnitData.speedy = 0;
    attackUnitData.waittime = 0;
    attackUnitData.compulsion = 0;

    switch (U.type) {
        case typeName.WHITEFLASH: attackUnitData.speedx = 15; break;
        case typeName.LASER:
            if (mode == "technical") {
                attackUnitData.x = -640;
                attackUnitData.speedx = 10; attackUnitData.speedy = 0;
                attackUnitData.width = 600; attackUnitData.height = 10;
            } else {
                attackUnitData.istarget = true;
                attackUnitData.delay = 0;
            } break;
        case typeName.WAYSHOT3:
            switch (option) {
                case 0: attackUnitData.speedy = -2; break;
                case 1: attackUnitData.speedy = 0; break;
                case 2: attackUnitData.speedy = 2; break;
            } break;
        case typeName.DOUBLESHOT:
            switch (option) {
                case 0: attackUnitData.y = attackUnitData.y - 10;  attackUnitData.speedx = 10; break;
                case 1: attackUnitData.y = attackUnitData.y + 10;  attackUnitData.speedx = 10; break;
            } break;
        case typeName.FIRE:
            attackUnitData.x = tamsaseon.x + 48; attackUnitData.y = tamsaseon.y;
            effect.create(effectName.FIRE, attackUnitData.x, attackUnitData.y);
            attackUnitData.delay = 1; attackUnitData.combo = 10;
            switch (option) {
                case 0: attackUnitData.speedy = -8; attackUnitData.speedx = 20; break;
                case 1: attackUnitData.speedy = -4; attackUnitData.speedx = 20; break;
                case 2: attackUnitData.speedy = 0; attackUnitData.speedx = 20; break;
                case 3: attackUnitData.speedy = 4; attackUnitData.speedx = 20; break;
                case 4: attackUnitData.speedy = 8; attackUnitData.speedx = 20; break;
            } break;
        case typeName.PALSERN:
            optionbattle.sound.play(soundName.palsern_wait); // 사운드가 여기서 재생되는 이유는 공격시에 재생하면 8번재생하기 때문
            attackUnitData.delay = 40; attackUnitData.combo = 2;
            attackUnitData.speedx = 0; attackUnitData.speedy = 0;
            attackUnitData.y = tamsaseon.y + 24 + (option * 20) - 80; break;
        case typeName.ROCKET: attackUnitData.combo = 1; attackUnitData.speedx = -4; attackUnitData.speedy = Math.random() * 8 - 4 | 0; break;
        case typeName.MACHINEGUN: attackUnitData.speedx = 0; attackUnitData.speedy = 0; break;
        case typeName.BEAM:
            attackUnitData.x = 0; attackUnitData.speedx = 0; attackUnitData.speedy = 0;
            attackUnitData.width = 640; attackUnitData.height = 40; break;
        case typeName.BEAMLOGIC:
            if (mode == "normal") {
                if (option == 0) {
                    attackUnitData.x = 0; attackUnitData.y = 0;
                    attackUnitData.speedx = 0; attackUnitData.speedy = 10;
                    attackUnitData.width = 640; attackUnitData.height = 40;
                } else if (option == 1) {
                    attackUnitData.x = 0; attackUnitData.y = 0;
                    attackUnitData.speedx = 10; attackUnitData.speedy = 0;
                    attackUnitData.width = 40; attackUnitData.height = 480;
                }
            } else if (mode == "technical") {
                if (option == 0) {
                    attackUnitData.x = 0; attackUnitData.y = tamsaseon.y + 24;
                    attackUnitData.speedx = 0; attackUnitData.speedy = 0;
                    attackUnitData.width = 640; attackUnitData.height = 40;
                } else if (option == 1) {
                    attackUnitData.x = tamsaseon.x + 24; attackUnitData.y = 0;
                    attackUnitData.speedx = 0; attackUnitData.speedy = 0;
                    attackUnitData.width = 40; attackUnitData.height = 480;
                }
            } break;
        case typeName.BEAMSIX:
            attackUnitData.x = 0; attackUnitData.speedx = 0; attackUnitData.speedy = 0;
            attackUnitData.width = 640; attackUnitData.height = 20; break;
    } // switch end

    if (attackUnitData.istarget == true) {
        attackUnitData.target = attack.setTarget();
    }

    if (attackUnitData.isfollow == false && attackUnitData.istarget == true) {
        attackUnitData.speedx = (enemy.data[attackUnitData.target].x - attackUnitData.x + (enemy.data[attackUnitData.target].width / 2)) / 10 | 0;
        attackUnitData.speedy = (enemy.data[attackUnitData.target].y - attackUnitData.y + (enemy.data[attackUnitData.target].height / 2)) / 10 | 0;
    }
};
attack.setTarget = function(){
    if(enemy.livelistCount == NOTHING)  return 0;
    
    var target = Math.round(Math.random() * enemy.livelistCount);
	return enemy.livelist[target];
};
attack.target = function (attackData) {
    // 타겟을 결정할 필요가 없는 타입들은 타겟을 정하지 않음.
    if (attackData.isusing == false && attackData.istarget == false)  return;

    if (enemy.data[attackData.target].isusing == false || enemy.data[attackData.target].died == true) {  // 적이 죽었을 경우 타겟 재설정
        if (enemy.livelistCount == NOTHING) {  // 적이 아무도 없을경우 타겟설정을 취소함.
            attackData.istarget = false;
            attackData.isfollow = false;
            attackData.speedy = 0;
            attackData.speedx = 10;
        } else if (attackData.type == typeName.HITSHOT && attackData.combo < 4) {
            attack.deleteData(attackData);
        } else if (attackData.type == typeName.SAWTOOTH && attackData.combo < 6) {
            attackData.istarget = false;
        } else {
            attackData.target = attack.setTarget();
        }
    }
};
attack.damageCheck = function(A, E){ // A: Attack, E: Enemy
    // 이 함수는 적에게 데미지를 주는 함수입니다. 이걸 한번쓸때마다 적의 체력이 감소하니 참고바람.
    // 그리고 데미지도 표시합니다.
    var enemyDefnsedown = E.defensedown > 100 ? 100 : E.defensedown; // 삼항연산자 사용, 방어력감소의 최대치는 100%
    var enemyWeakness = E.weakness > 100 ? 100 : E.weakness; // 약점의 최대치는 100%
    // 적용되는 데미지값 = 공격력 - 적의 방어력 - ( 적의 방어력 * 적의 방어감소율 / 100);
    var enemyDefense = E.defense - (E.defense * E.defensedown / 100);
    var percent = (Math.random() * 100) |0;
    if(enemyDefense <= 0)  enemyDefense = 0;
    var damageValue = A.attack - enemyDefense;
    switch(A.type){
        case typeName.DIRECT: damageValue = A.attack;  break; // 다이렉트는 자기 공격력의 데미지가 그대로 들어감
        case typeName.HITSHOT:  E.weakness += 2;  break;  // 히트샷은 약점 2개를 추가함
        case typeName.SAWTOOTH:  if(A.combo > 8)  E.defensedown += 8;
        						 else  E.defensedown += 4;  break;  // 톱니는 방어력감소 8개를 추가함.
        case typeName.FIRE:  E.fire += 1;  E.firedamage = ( E.firedamage + A.attack ) / 2 |0; break; // 파이어는 파이어디버프를 2개 추가함 그리고 파이어 데미지 결정
        case typeName.PARAPO: damageValue = A.attack + E.defense;  break;  // 파라포 = 자기공격력 + 적의 방어력 합산 데미지
        case typeName.BURSTSHOT:  effect.create(effectName.BURSTSHOT, A.x, A.y);  E.defensedown += 5;   optionbattle.sound.play(soundName.burstshot_saw);  break;
        						  // 버스트는 35%확률로 방어력17% 감소
    }
    
    if(damageValue < 1)  damageValue = 1; // 데미지값이 1 미만인경우, 1로 적용
    // 최종데미지 = 적용되는 데미지값 + (적용되는 데미지값 * 약점수 / 100);
    var totalDamage = damageValue + (damageValue * enemyWeakness / 100) |0; // 최종데미지는 정수로 처리
    E.hp -= totalDamage;
    
    damage.create(totalDamage, A.type, E.x, E.y - (E.damagecount*10));
    E.damagecount++;
};
attack.countCheck = function(A){ // A: Attack. 이 함수는 카운트와 딜레이를 체크하는 함수, 귀찮아서 countCheck 라고 씀.
    A.count++;
    if(A.count >= A.delay){
        A.count -= A.delay;
        return true;
    }
};

attack.move_notarget = function(attackData){
    attackData.x += attackData.speedx;
    attackData.y += attackData.speedy;
    if(attackData.x >= 900 || attackData.compulsion >= 250)  attack.deleteData(attackData);
};

attack.move_istarget = function(attackData){
    attackData.x += attackData.speedx;
    attackData.y += attackData.speedy;
    /*if(attackData.compulsion >= 10){
        attackData.x = enemy.data[attackData.target].x;
        attackData.y = enemy.data[attackData.target].y;
    }*/
    
    if(attackData.x >= 900 || attackData.compulsion >= 100)  attack.deleteData(attackData);
};

attack.move_followtarget = function(attackData){
    var movesizeX = (enemy.data[attackData.target].x + (enemy.data[attackData.target].width / 2) - attackData.x) / 10;
    var movesizeY = (enemy.data[attackData.target].y + (enemy.data[attackData.target].height / 2) - attackData.y) / 10;
    
    if(movesizeX < 10 && movesizeX >= 1)  movesizeX = 10;
    else if(movesizeX <= -1 && movesizeX >= -10)  movesizeX = -10;
    if(movesizeY < 10 && movesizeY >= 1)  movesizeY = 10;
    else if(movesizeY <= -1 && movesizeY >= -10)  movesizeY = -10;
    
    if(attackData.type == typeName.WHITEFLASH)  movesizeX = attackData.speedx;

    attackData.x += movesizeX;
    attackData.y += movesizeY;
    if(movesizeX == 0 && movesizeY == 0){
        attackData.x = enemy.data[attackData.target].x;
        attackData.y = enemy.data[attackData.target].y;
    }
    
    switch(attackData.type){
    case typeName.DIRECT:  attackData.compulsion = 240;  break;
    case typeName.HITSHOT: attackData.compulsion = 240;  break;
    case typeName.SAWTOOTH:
        if(attackData.combo > 8)  attackData.x = enemy.data[attackData.target].x;  attackData.y = enemy.data[attackData.target].y;  break;
    case typeName.BEAMSIX:
        attackData.x = 0;  attackData.y = enemy.data[attackData.target].y;  break;
    default: break;
    }
    if(attackData.x >= 900 || attackData.compulsion >= 250)  attack.deleteData(attackData);
};

attack.move = function(attackData){
    if(attackData.istarget == false){
        attack.move_notarget(attackData);
    } else if(attackData.istarget == true && attackData.isfollow == false){ // 타겟이 있지만 추적방식이 아닌 조준방식일경
    	attack.move_istarget(attackData);
    } else if(attackData.istarget == true && attackData.isfollow == true) { // 타겟이 있을경우에만 이 구문 실행
        attack.move_followtarget(attackData);
    }
};

//attack.logic_typeName
//공격 타입에 대한 여러 요소들을 처리하는 함수.
//default의 경우도 있다.
attack.logic_whiteflash = function (attackData) {
    if (attack.countCheck(attackData)) {
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(attackData, enemy.data[i])) attack.damageCheck(attackData, enemy.data[i]);
        }
    }
};
attack.logic_laser = function (attackData) {
    if (attackData.mode == "normal") {
        if (collision(attackData, enemy.data[attackData.target])) {
            attack.damageCheck(attackData, enemy.data[attackData.target]);
            attack.deleteData(attackData);
        }
    } else {  // 일반공격모드가 아닐경우 테크니컬로 간주함.
        if (attack.countCheck(attackData)) {
            for (var i = 0; i < enemy.data.length; i++) {
                if (enemy.data[i].isusing == false) continue;
                if (collision(attackData, enemy.data[i])) {
                    attack.damageCheck(attackData, enemy.data[i]);
                } 
            }
        }

        if (attack.data[a].x >= 1280) attack.deleteData(attackData);
    }
};
attack.logic_missile = function (attackData) {
    if (attackData.combo == 5 && collision(attackData, enemy.data[attackData.target])) {
        attackData.combo = 4;
        attackData.moveon = false;
        attack.damageCheck(attackData, enemy.data[attackData.target]);
        optionbattle.sound.play(soundName.bombattack);
        attackData.speedx = 0;  attackData.speedy = 0;  attackData.istarget = false;
    } else if (attack.countCheck(attackData) && attackData.combo <= 4) {
        effect.create(effectName.MISSILE, attackData.x - 90, attackData.y - 90);
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(enemy.data[i], attackData.x - 90, attackData.y - 90, 180, 180)) attack.damageCheck(attackData, enemy.data[i]);
        }
        optionbattle.sound.play(soundName.bomb);
        attackData.combo--;
        if (attackData.combo <= 0) attack.deleteData(attackData);
    }
};
attack.logic_splash = function (attackData) {
    if (collision(attackData, enemy.data[attackData.target])) {
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(enemy.data[i], attackData.x - 200, attackData.y - 200, 400, 400)) attack.damageCheck(attackData, enemy.data[i]);
        }
        optionbattle.sound.play(soundName.splashdamage);
        effect.create(effectName.SPLASH, attackData.x - 200, attackData.y - 200);
        attack.deleteData(attackData);
    }
};
attack.logic_rocket = function (attackData) {
    if (attackData.combo == 1) {
        if (attackData.x >= 1) attackData.speedx--;
        else {
            attackData.combo = 0;  attackData.speedx = 4;
            attackData.delay = 8;  attackData.count = 0;
        }
    } else if (attackData.combo == 0 && attack.countCheck(attackData)) {
        for (var i = 0 ; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(enemy.data[i], attackData.x - 90, attackData.y - 90, 180, 180)) attack.damageCheck(attackData, enemy.data[i]);
        }

        effect.create(effectName.MISSILE, attackData.x - 90, attackData.y - 90);
        optionbattle.sound.play(soundName.bomb);
        attackData.speedx += 2;
        attackData.delay--;
        if (attackData.delay <= 4) attackData.delay = 4;
        if (attackData.x >= 720) attack.deleteData(attackData);
    }
};
attack.logic_hitshot = function (attackData) {
    if (attackData.combo >= 4 && attack.countCheck(attackData) && collision(attackData, enemy.data[attackData.target])) {
        if (attackData.combo == 4) optionbattle.sound.play(soundName.hitshot);
        attack.damageCheck(attackData, enemy.data[attackData.target]);
        attackData.combo--;
        effect.create(effectName.HITSHOT, attackData.x, attackData.y);
    } else if(attackData.combo <= 3 && attack.countCheck(attackData)){
        attack.damageCheck(attackData, enemy.data[attackData.target]);
        attackData.combo--;
        effect.create(effectName.HITSHOT, attackData.x, attackData.y);
        
        if(attackData.combo <= 0)  attack.deleteData(attackData);
    }
};
attack.logic_sawtooth = function (attackData) {
    if (attack.countCheck(attackData) && attackData.combo > 8 && collision(attackData, enemy.data[attackData.target])) {
        attack.damageCheck(attackData, enemy.data[attackData.target]);
        attackData.combo--;
        optionbattle.sound.play(soundName.sawtooth_attack);
        if (attackData.combo <= 8) {
            attackData.istarget = false;
            attackData.speedx = 12;
            attackData.delay = 6;
            attackData.count = -12;
            attackData.attack = attackData.attack * 0.5 | 0;
        }
    } else if (attackData.istarget == false && attack.countCheck(attackData)) {
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(attackData, enemy.data[i])) {
                attack.damageCheck(attackData, enemy.data[i]);
                optionbattle.sound.play(soundName.sawtooth_attack);
                attackData.combo--;
                break;
            }
        }
        if (attackData.combo <= 0) attack.deleteData(attackData);
    }
};
attack.logic_fire = function (attackData) {
    attackData.combo--;
    effect.create(effectName.FIRE, attackData.x, attackData.y);
    if (attack.countCheck(attackData)) {
        for (var i = 0; i < enemy.data.length; i++) {
            if (collision(attackData, enemy.data[i])) {
                attack.damageCheck(attackData, enemy.data[i]);
            }
        }
    }
    if (attackData.combo <= 0) attack.deleteData(attackData);
};
attack.logic_palsern = function (attackData) {
    if (attackData.combo == 2 && attack.countCheck(attackData)) {
        attackData.combo = 1;
        attackData.target = attack.setTarget();
        attackData.delay = 11;
        attackData.count = 0;
        attackData.speedx = (enemy.data[attackData.target].x - attackData.x) / 10;
        attackData.speedy = (enemy.data[attackData.target].y - attackData.y) / 10;
    } else if (attackData.combo == 1 && attack.countCheck(attackData)) {
        var typeX1 = Math.abs(enemy.data[attackData.target].x + enemy.data[attackData.target].width - attackData.x);
        var typeX2 = Math.abs(enemy.data[attackData.target].x - attackData.x);
        var typeY1 = Math.abs(enemy.data[attackData.target].y + enemy.data[attackData.target].height - attackData.y);
        var typeY2 = Math.abs(enemy.data[attackData.target].y - attackData.y);
        var distance_x = Math.min(typeX1, typeX2);
        var distance_y = Math.min(typeY1, typeY2);
        var distance = distance_x + distance_y / 2 | 0;  /// 거리에 따라 미스확률 결정, distance = miss_percent
        if ((Math.random() * 100 | 0) >= distance) {  // 적을 히트한 경우
            attack.damageCheck(attackData, enemy.data[attackData.target]);
            optionbattle.sound.play(soundName.palsern_hit);
        } else {
            attackData.attack = 1;
            attackData.type = typeName.UNUSED; // 색깔 변경용
            attack.damageCheck(attackData, enemy.data[attackData.target]);
            optionbattle.sound.play(soundName.palsern_miss);
        }

        attack.deleteData(attackData);
    }
};
attack.logic_machinegun = function (attackData) {
    if (!attack.countCheck(attackData))  return;

    for (var i = 0; i < enemy.data.length; i++) {
        if (enemy.data[i].isusing == false) continue;
        if (collision(enemy.data[i], tamsaseon.x, tamsaseon.y - 70, 350, 140)) {
            if ((Math.random() * 100 | 0) <= 35) {  // 1발 발사당 35%확률로 히트
                attack.damageCheck(attackData, enemy.data[i]);
                break;
            }
        }
    }

    if (/*attackData.combo % 0 == 0*/true) {
        var randomSelect = (Math.random() * 3) | 0;
        var random_x = (Math.random() * 50) | 0;
        var random_y = (Math.random() * 60) | 0;
        switch (randomSelect) {
            case 0: effect.create(effectName.MACHINEGUN_CENTER, tamsaseon.x + random_x, tamsaseon.y + random_y);
            case 1: effect.create(effectName.MACHINEGUN_UP, tamsaseon.x + random_x, tamsaseon.y + random_y + 0);
            case 2: effect.create(effectName.MACHINEGUN_DOWN, tamsaseon.x + random_x, tamsaseon.y + random_y - 30);
        }
        optionbattle.sound.play(soundName.machinegun);
    }

    attackData.combo--;
    if (attackData.combo <= 0) attack.deleteData(attackData);
};
attack.logic_beam = function (attackData) {
    attackData.y = tamsaseon.y;
    if (attack.countCheck(attackData)) {
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false)  continue;
            if (collision(attackData, enemy.data[i])) {
                attack.damageCheck(attackData, enemy.data[i]);
            }
        }

        attackData.combo--;
        if (attackData.combo <= 0) attack.deleteData(attackData);
    }
};
attack.logic_beamlogic = function (attackData) {
    if (attackData.mode == "technical") {
        if (attackData.x == 0) {
            attackData.y = tamsaseon.y;
        } else {
            attackData.x = tamsaseon.x;
        }
    }

    if (attack.countCheck(attackData)) {
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(attackData, enemy.data[i])) {
                attack.damageCheck(attackData, enemy.data[i]);
        }   }

        attackData.combo--;
        if (attackData.combo <= 0) attack.deleteData(attackData);
    }             
};
attack.logic_beamsix = function(attackData){
    if (attack.countCheck(attackData)) {
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(attackData, enemy.data[i])) {
                attack.damageCheck(attackData, enemy.data[i]);
            }
        }

        if (attackData.type == typeName.BEAMSIX) {
            attackData.x = 0;
            attackData.y = enemy.data[attackTarget].y;
        }

        attackData.combo--;
        if (attackData.combo <= 0) attack.deleteData(attackData);
    }
};
attack.logic_default = function(attackData){
    if (attackData.istarget == false) {  // 타겟이 정해지지 않은경우의 충돌처리
        for (var i = 0; i < enemy.data.length; i++) {
            if (enemy.data[i].isusing == false) continue;
            if (collision(attackData, enemy.data[i])) {
                attack.damageCheck(attackData, enemy.data[i]);
                attack.deleteData(attackData);
            }
        }
    } else {  // 타겟이 정해진 경우의 충돌처리
        if (collision(attackData, enemy.data[attackData.target])) {
            attack.damageCheck(attackData, enemy.data[attackData.target]);
            if (attackData.type == typeName.PARAPO) optionbattle.sound.play(soundName.parapo);

            attack.deleteData(attackData);
        }
    }
};
attack.processLogic = function (attackData) {
    switch (attackData.type) {
        case typeName.WHITEFLASH: attack.logic_whiteflash(attackData); break;
        case typeName.LASER: attack.logic_laser(attackData); break;
        case typeName.MISSILE: attack.logic_missile(attackData); break;
        case typeName.SPLASH: attack.logic_splash(attackData); break;
        case typeName.ROCKET: attack.logic_rocket(attackData); break;
        case typeName.HITSHOT: attack.logic_hitshot(attackData); break;
        case typeName.SAWTOOTH: attack.logic_sawtooth(attackData); break;
        case typeName.FIRE: attack.logic_fire(attackData); break;
        case typeName.PALSERN: attack.logic_palsern(attackData); break;
        case typeName.MACHINEGUN: attack.logic_machinegun(attackData); break;
        case typeName.BEAM: attack.logic_beam(attackData); break;
        case typeName.BEAMLOGIC: attack.logic_beamlogic(attackData); break;
        case typeName.BEAMSIX: attack.logic_beamsix(attackData); break;
        default:  attack.logic_default(attackData); break;
    } // switch end
};
attack.compulsionAction = function (attackData) {
    attackData.compulsion++;
    if( (attackData.istarget == true && attackData.isfollow == false && attackData.compulsion > 10) 
     || (attackData.istarget == true && attackData.isfollow == true && attackData.compulsion > 240) ){
        attackData.x = enemy.data[attackData.target].x + (enemy.data[attackData.target].width / 2);  
        attackData.y = enemy.data[attackData.target].y + (enemy.data[attackData.target].height / 2);
    }
};
attack.process = function(){
    for(var i = 0; i < attack.data.length; i++){
        if(attack.data[i].isusing == true){
            attack.target(attack.data[i]);
            attack.compulsionAction(attack.data[i]);
            attack.processLogic(attack.data[i]);
            attack.move(attack.data[i]);
        }
    }
};
attack.display = function(){
    for(var a = 0; a < attack.data.length; a++){
        if(attack.data[a].isusing == false)  continue;
        var A = attack.data[a];
        
        switch(attack.data[a].type){
        	case typeName.LASER:
        		if(attack.data[a].mode == "technical")  ctx.drawImage(A.image, 0, 0, A.image.width, A.image.height, A.x, A.y, A.width, A.height );
        		else  ctx.drawImage(attack.data[a].image, attack.data[a].x, attack.data[a].y);  break;
        	case typeName.BEAM:
        	case typeName.BEAMLOGIC:
        	case typeName.BEAMSIX:
        		ctx.drawImage(A.image, 0, 0, A.image.width, A.image.height, A.x, A.y, A.width, A.height );  break;
        	default:  ctx.drawImage(attack.data[a].image, attack.data[a].x, attack.data[a].y);  break;
        }
        
    }
};

// 객체의 데이터를 삭제한것처럼(실제 삭제가 아님) 처리한다.
// 인덱스 번호를 넣으면 해당 배열번호에 있는 데이터가 사라지고, 객체를 넣으면 해당 객체의 데이터가 사라진다.
attack.deleteData = function (index) {
    if(typeof index == "number"){
        attack.data[index].isusing = false;// = null;
        //attack.data[index] = new AttackUnit();
    } else {
        var deleteIndex = index.index;
        attack.data[deleteIndex].isusing = false;
        //attack.data[deleteIndex] = null;
        //attack.data[deleteIndex] = new AttackUnit();
        //index.isusing = false;
        //index = new AttackUnit();
    }
};
attack.init = function(){
    for(var a = 0; a < attack.data.length; a++){
        attack.deleteData(a);
    }
};

//--------------------------------//
var damage = {};
damage.data = new Array(100);
for(var a = 0; a < damage.data.length; a++)  damage.data[a] = new ObjectUnit();
damage.create = function(attack, attackType, x, y){ // U: 데미지를 받는 대상, attackType: 공격의 타입, value:데미지 값
    var number = 0;
    for(var a = 0; a < damage.data.length; a++){
        if(damage.data[a].isusing == false){
            number = a;  break;
    }   }
    
    damage.data[number].isusing = true;
    damage.data[number].count = 50;
    damage.data[number].attack = attack;
    damage.data[number].color = optionbattle.type.getColor(attackType);
    damage.data[number].x = x;
    damage.data[number].y = y;
};
damage.display = function(){
    ctx.font = "20px arial";
    for(var a = 0; a < damage.data.length; a++){
        if(damage.data[a].isusing == false)  continue;
        var D = damage.data[a];
        ctx.fillStyle = D.color;
        ctx.fillText(D.attack, D.x, D.y);
    }
};
damage.process = function(){
    for(var a = 0; a < damage.data.length; a++){
        if(damage.data[a].isusing == false)  continue;
        
        damage.data[a].count--;
        damage.data[a].y--;
        if(damage.data[a].count <= 0)  damage.data[a].isusing = false;
    }
};
damage.init = function(){
    for(var a = 0; a < damage.data.length; a++){
        damage.data[a].isusing = false;
    }
};

//--------------------------------//
function EnemyUnit(index){
    this.index = index;
    this.attackdelay = 0;
	this.score = 0;
	this.speedType = "";
	this.diecount = 0;
	this.diemotion = "";
	this.diemotiontime = 0;
	this.diesound = 0;
	this.died = false;
	this.imagenumber = 0;
	this.group = 0;
	this.damagecount = 0; // 데미지 처리용 카운트, 여러줄 표시용
	this.damagecountdelay = 0; // 일정시간후 초기화용
	this.shot = false; // 적이 총으로 공격하는지 여부
	this.shotcount = 0;
	this.shotAttack = 0;
	this.shotDelay = 0;
	this.shotType = "";
	this.shitOption = 0;
	
	// 버프 관련 요소
	this.weakness = 0; // 약점, 퍼센트로 증가
	this.weaknesstime = 250; // 약점시간, 5초당 처리
	this.defensedown = 0; // 방어력감소, 퍼센트로 증가
	this.defensedowntime = 250; // 방어력감소시간, 5초당 처리
	this.fire = 0; // 파이어 중첩 계수, 퍼센트로 증가
	this.firetime = 250; // 파이어시간, 5초당 처리
	this.firedamage = 0; // 파이어데미지, 당한 파이어의 평균데미지로 결정
}  EnemyUnit.prototype = new ObjectUnit();
function EnemyAttack(){
    this.index = index;
	this.target = false;
	this.shotType = "";
	this.useTime = 0;
	this.exit = false;
	this.exitDelay = 50;
	this.ai = new Array();
	this.aiTime = new Array();
	this.baseSpeedx = 0;
	this.baseSpeedy = 0;
	this.baseSpeedType = "";
}  EnemyAttack.prototype = new ObjectUnit();


var enemy = {};
enemy.statusImage = new Image();  enemy.statusImage.src = "image/field/enemystatus.png";
enemy.data = new Array(150);
enemy.attack = new Array(500);
for(var index = 0; index < enemy.data.length; index++){  enemy.data[index] = new EnemyUnit(index); }
for(var index = 0; index < enemy.attack.length; index++){  enemy.attack[index] = new EnemyAttack(index);  }
enemy.createCount = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
enemy.currentCount = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
enemy.livelist = [0, ];
enemy.livelistCount = NOTHING;
enemy.attackImage = new Array(100);
for(var i = 0; i < enemy.attackImage.length; i++)  enemy.attackImage[i] = new Image();
enemy.setAttackImage = function(number, filename, shotCount, baseSpeedx, baseSpeedy, baseSpeedType){
    enemy.attackImage[number].src = "image/enemyattack/"+filename+".png";
    enemy.attackImage[number].shotCount = shotCount;
    enemy.attackImage[number].baseSpeedx = baseSpeedx;
    enemy.attackImage[number].baseSpeedy = baseSpeedy;
    enemy.attackImage[number].baseSpeedType = baseSpeedType;
};
enemy.setAttackImage(enemyAttackName.shot, "shot", 1, 7, 7, "target");
enemy.setAttackImage(enemyAttackName.laser1, "laser1", 1, 8, 0, "");
enemy.setAttackImage(enemyAttackName.laser2, "laser2", 1, 6, 0, "");
enemy.setAttackImage(enemyAttackName.laser3, "laser3", 1, 10, 0, "");
enemy.setAttackImage(enemyAttackName.laser4, "laser4", 1, 4, 0, "");
enemy.setAttackImage(enemyAttackName.antilaserboss_part1, "antilaserboss", 5, 8, 0, "randomy");
enemy.setAttackImage(enemyAttackName.antilaserboss_part2, "antilaserboss", 8, 11, 0, "");
enemy.setAttackImage(enemyAttackName.antilaserboss_part3, "antilaserboss2", 6, 17, 0, "randomy");
enemy.setAttackImage(enemyAttackName.antilaserboss_part4, "antilaserboss2", 17, 10, 0, "");
enemy.setAttackImage(enemyAttackName.antilaserboss_part5, "antilaserboss3", 16, 8, 0, "");
enemy.setAttackImage(enemyAttackName.antilaserboss_part6, "antilaserboss3", 15, 20, 0, "");

enemy.createAttack = function(E, option){  // 생성하는 적공격
	var number = 0;
	for(var a = 0; a < enemy.attack.length; a++){
		if(enemy.attack[a].isusing == false){
			number = a;  break;
		}
	}
	var enemyAttack = enemy.attack[number];
	
	enemy.attack[number].isusing = true;
	enemy.attack[number].shotType = E.shotType;
	enemy.attack[number].x = E.x + (E.width / 2) |0;
	enemy.attack[number].y = E.y + (E.height / 2) |0;
	enemy.attack[number].attack = E.shotAttack;
	enemy.attack[number].useTime = 0;
	enemy.attack[number].width = enemy.attackImage[E.shotType].width;
	enemy.attack[number].height = enemy.attackImage[E.shotType].height;
	enemy.attack[number].speedx = enemy.attackImage[E.shotType].baseSpeedx * -1;
	enemy.attack[number].speedy = enemy.attackImage[E.shotType].baseSpeedy;
	
	var baseSpeedType = enemy.attackImage[E.shotType].baseSpeedType;
    switch(baseSpeedType){
    case "target":
        enemyAttack.speedx = (tamsaseon.x - enemyAttack.x) / 50;
        enemyAttack.speedy = (tamsaseon.y - enemyAttack.y) / 50;
        if(enemyAttack.speedx >= 7){
            enemyAttack.speedx = 7;  enemyAttack.speedy = enemyAttack.speedy * (7 / Math.abs(enemyAttack.speedx) );
        } else if(enemyAttack.speedx <= -7){
            enemyAttack.speedx = -7;  enemyAttack.speedy = enemyAttack.speedy * (7 / Math.abs(enemyAttack.speedx) );
        }
        if(enemyAttack.speedy >= 7){
            enemyAttack.speedy = 7;  enemyAttack.speedx = enemyAttack.speedx * (7 / Math.abs(enemyAttack.speedy) );
        } else if(enemyAttack.speedy <= -7){
            enemyAttack.speedy = -7;  enemyAttack.speedx = enemyAttack.speedx * (7 / Math.abs(enemyAttack.speedy) );
        }
        break;
    case "randomy":
        enemyAttack.speedy += (Math.random() * 4) - 2;  break;
    }
    
    switch(enemy.attack[number].shotType){
    case enemyAttackName.antilaserboss_part1:
        switch(option){
        case 0: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + ((E.height / 4) * 0) |0;  break;
        case 1: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + ((E.height / 4) * 1) |0;  break;
        case 2: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + ((E.height / 4) * 2) |0;  break;
        case 3: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + ((E.height / 4) * 3) |0;  break;
        case 4: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + ((E.height / 4) * 4) |0;  break;
        }  break;
    case enemyAttackName.antilaserboss_part2:
        switch(option){
        case 0: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + ((E.height / 4) * 0) |0;  break;
        case 1: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + ((E.height / 4) * 1.3) |0;  break;
        case 2: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + ((E.height / 4) * 2.6) |0;  break;
        case 3: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + ((E.height / 4) * 4) |0;  break;
        case 4: enemy.attack[number].x = E.x + (E.width / 2) + 180;
                enemy.attack[number].y = E.y + ((E.height / 4) * 0) |0;  break;
        case 5: enemy.attack[number].x = E.x + (E.width / 2) + 180;
                enemy.attack[number].y = E.y + ((E.height / 4) * 1.3) |0;  break;
        case 6: enemy.attack[number].x = E.x + (E.width / 2) + 180;
                enemy.attack[number].y = E.y + ((E.height / 4) * 2.6) |0;  break;
        case 7: enemy.attack[number].x = E.x + (E.width / 2) + 180;
                enemy.attack[number].y = E.y + ((E.height / 4) * 4) |0;  break;
        }  break;
    case enemyAttackName.antilaserboss_part3:
        switch(option){
        case 0: enemy.attack[number].x = E.x + (E.width / 2) + 20;
                enemy.attack[number].y = E.y + ((E.height / 5) * 0) |0;  break;
        case 1: enemy.attack[number].x = E.x + (E.width / 2) + 40;
                enemy.attack[number].y = E.y + ((E.height / 5) * 1) |0;  break;
        case 2: enemy.attack[number].x = E.x + (E.width / 2) + 60;
                enemy.attack[number].y = E.y + ((E.height / 5) * 2) |0;  break;
        case 3: enemy.attack[number].x = E.x + (E.width / 2) + 80;
                enemy.attack[number].y = E.y + ((E.height / 5) * 3) |0;  break;
        case 4: enemy.attack[number].x = E.x + (E.width / 2) + 100;
                enemy.attack[number].y = E.y + ((E.height / 5) * 4) |0;  break;
        case 5: enemy.attack[number].x = E.x + (E.width / 2) + 120;
                enemy.attack[number].y = E.y + ((E.height / 5) * 5) |0;  break;
        }  break;
    case enemyAttackName.antilaserboss_part4:
        switch(option){
        case 0: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + ((E.height / 4) * 1) |0;  
                enemy.attack[number].speedy = 1.5;  break;
        case 1: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + ((E.height / 4) * 1.5) |0;
                enemy.attack[number].speedy = 0.7;  break;
        case 2: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + ((E.height / 4) * 2) |0;
                enemy.attack[number].speedy = 0;  break;
        case 3: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + ((E.height / 4) * 2.5) |0;
                enemy.attack[number].speedy = -0.7;  break;
        case 4: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + ((E.height / 4) * 3) |0;
                enemy.attack[number].speedy = -1.4;  break;
        //-------------------//
        case 5: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y - 20;  break;
        case 6: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y - 60;  break;
        case 7: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y - 100;  break;
        case 8: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y - 140;  break;
        case 9: enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y - 180;  break;
        case 10:enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y - 220;  break;
        case 11:enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + E.height + 20;  break;
        case 12:enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + E.height + 60;  break;
        case 13:enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + E.height + 100;  break;
        case 14:enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + E.height + 140;  break;
        case 15:enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + E.height + 180;  break;
        case 16:enemy.attack[number].x = E.x + (E.width / 2);
                enemy.attack[number].y = E.y + E.height + 220;  break;
        }  break;
    case enemyAttackName.antilaserboss_part5:
        if(option >= 0 && option <= 1) {  enemy.attack[number].speedy = (Math.random() * 6) - 3; }
        switch(option){
        case 0: enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y - 40 |0;  break;
        case 1: enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y + 40 |0;  break;
        //---------------------//
        case 2: enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y + 200 |0;  break;
        case 3: enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y - 200 |0;  break;
        case 4: enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y - 240 |0;  break;
        case 5: enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y - 280 |0;  break;
        case 6: enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y - 320 |0;  break;
        case 7: enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y - 360 |0;  break;
        case 8: enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y - 400 |0;  break;
        case 9: enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y - 440 |0;  break;
        case 10:enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y + 240 |0;  break;
        case 11:enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y + 280 |0;  break;
        case 12:enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y + 320 |0;  break;
        case 13:enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y + 360 |0;  break;
        case 14:enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y + 400 |0;  break;
        case 15:enemy.attack[number].x = E.x + E.width;  enemy.attack[number].y = E.y + 440 |0;  break;
        }  break;
    case enemyAttackName.antilaserboss_part6:
        switch(option){
        case 0: enemy.attack[number].x = E.x + E.width;
                enemy.attack[number].y = 0;  break;
        case 1: enemy.attack[number].x = E.x + E.width;
                enemy.attack[number].y = 40;  break;
        case 2: enemy.attack[number].x = E.x + E.width;
                enemy.attack[number].y = 80;  break;
        case 3: enemy.attack[number].x = E.x + E.width;
                enemy.attack[number].y = 120;  break;
        case 4: enemy.attack[number].x = E.x + E.width;
                enemy.attack[number].y = 160;  break;
        case 5: enemy.attack[number].x = E.x + E.width;
                enemy.attack[number].y = 200;  break;
        case 6: enemy.attack[number].x = E.x + E.width;
                enemy.attack[number].y = 240;  break;
        case 7: enemy.attack[number].x = E.x + E.width;
                enemy.attack[number].y = 280;  break;
        case 8: enemy.attack[number].x = E.x + E.width;
                enemy.attack[number].y = 320;  break;
        case 9: enemy.attack[number].x = E.x + E.width;
                enemy.attack[number].y = 360;  break;
        case 10:enemy.attack[number].x = E.x + E.width;
                enemy.attack[number].y = 400;  break;
        case 11:enemy.attack[number].x = E.x + E.width;
                enemy.attack[number].y = 440;  break;
        case 12:enemy.attack[number].x = E.x + E.width;
                enemy.attack[number].y = 480;  break;
        case 13:enemy.attack[number].x = E.x + E.width;
                enemy.attack[number].y = 520;  break;
        case 14:enemy.attack[number].x = E.x + E.width;
                enemy.attack[number].y = -40;  break;         
        }
    }
	
};

enemy.attackCheck = function(enemyData){
    enemyData.shotcount++;
    if(enemyData.shotcount >= enemyData.shotDelay && enemyData.shot == true){
        enemyData.shotcount = 0;
        var shotcount = enemy.attackImage[enemyData.shotType].shotCount;
        
        for(var k = 0; k < shotcount; k++){
            enemy.createAttack(enemyData, k);
        }
    }
};

enemy.displayAttack = function(){
	for(var a = 0; a < enemy.attack.length; a++){
		if(enemy.attack[a].isusing == false)  continue;
        ctx.drawImage(enemy.attackImage[enemy.attack[a].shotType], enemy.attack[a].x, enemy.attack[a].y);
	}
};
enemy.moveAttack = function(){
    for(var i = 0; i < enemy.attack.length; i++){
        enemy.attack[i].x += enemy.attack[i].speedx;
        enemy.attack[i].y += enemy.attack[i].speedy;
        enemy.attack[i].useTime++;
        
        if(enemy.attack[i].useTime >= 500){
            enemy.deleteAttack(i);
        }
    }
};

enemy.init = function(){
    for(var a = 0; a < enemy.data.length; a++){
        enemy.deleteData(a);
    }
    
    enemy.createCount = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    enemy.currentCount = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
    for(var a = 0; a < system.group.length; a++){
        enemy.createCount[a] = system.group[a].enemycount;
        enemy.currentCount[a] = 0;
    }
    
    for(var a = 0; a < enemy.attack.length; a++){
        enemy.attack[a].isusing = false;
    }
};
enemy.create = function(E, G){
	if(E == -1)  return; // 적을 잘못생성하는 코드번호를 작성하는경우 강제로 함수 종료.
	
    var number = 0;
    for(var a = 0; a < enemy.data.length; a++){
        if(enemy.data[a].isusing == false){
            number = a;  break;
        }
    }
    
    //enemy.data[number] = null;
    //enemy.data[number] = new EnemyUnit(number); 
    
    enemy.data[number].group = G;
    enemy.data[number].isusing = true;
    enemy.data[number].hp = E.hp;
    enemy.data[number].imagenumber = E.imagenumber;
    enemy.data[number].image = optionbattle.imagebox.enemy[enemy.data[a].imagenumber];
    enemy.data[number].exit = false;
    enemy.data[number].exitDelay = 50;
    enemy.data[number].attack = E.attack;
    enemy.data[number].attackdelay = 0;
    enemy.data[number].defense = E.defense;
    enemy.data[number].speedx = -E.speedx;
    enemy.data[number].speedy = -E.speedy;
    enemy.data[number].speedType = E.speedType;
    enemy.data[number].moveType = E.moveType;
    enemy.data[number].diesound = E.diesound;
    enemy.data[number].width = enemy.data[number].image.width;
    enemy.data[number].height = enemy.data[number].image.height;
    enemy.data[number].x = 640 + enemy.data[number].width;
    enemy.data[number].y = Math.random() * 480|0;
    enemy.data[number].died = false;
    enemy.data[number].diecount = 50;
    enemy.data[number].score = E.score;
    enemy.data[number].shot = E.shot;
    enemy.data[number].shotType = E.shotType;
    enemy.data[number].shotAttack = E.shotAttack;
    enemy.data[number].shotDelay = E.shotDelay;
    enemy.currentCount[G]++;
    enemy.createCount[G]--;
    
    switch(enemy.data[number].speedType){
    case "random":
        enemy.data[number].speedx += (Math.random() * 4) + -2 |0;
        if(enemy.data[number].speedx == 0)  enemy.data[number].speedx = 1;
        enemy.data[number].speedy += (Math.random() * 4) + -2 |0;
        if(enemy.data[number].speedy == 0)  enemy.data[number].speedy = 1;
        break;
    }
    switch(enemy.data[number].moveType){
    case "up":
        enemy.data[number].x = (Math.random() * 640) - enemy.data[number].width;
        enemy.data[number].y = 480;
        break;
    }
};
enemy.process = function(){
    enemy.livelistCheck(); // 현재 적의 수 표시
    enemy.moveAttack(); // 적의 공격 이동 처리
    for(var i = 0; i < enemy.data.length; i++){
        if(enemy.data[i].isusing == true){
            enemy.move(enemy.data[i]);
            enemy.dieCheck(enemy.data[i]);
            enemy.dieEnimation(enemy.data[i]);
            enemy.buffCheck(enemy.data[i]);
            enemy.attackCheck(enemy.data[i]);
        } 
    }
    
    // 적 생성
    var E = optionbattle.dungeon.getEnemy(system.dungeon);
    for(var a = 0; a < system.group.length; a++){
        if(enemy.createCount[a] >= 1 && enemy.currentCount[a] < system.group[a].enemymax){
            var R = Math.random() * system.group[a].enemylist.length|0;
            enemy.create(E[ system.group[a].enemylist[R] ], a);
        }
    }
};
enemy.livelistCheck = function(){
    enemy.livelistCount = NOTHING;
    for(var a = 0; a < enemy.data.length; a++){
        if(enemy.data[a].isusing == true && enemy.data[a].died == false){
            enemy.livelistCount++;
            enemy.livelist[enemy.livelistCount] = a;
        }
    }
};
enemy.move = function(enemyData){
    if(enemyData.isusing == false || enemyData.died == true)  return;
    if(enemyData.exit == true && enemyData.exitDelay > 0){
        enemyData.exitDelay--;  return;
    }
    
    enemyData.x += enemyData.speedx;
    enemyData.y += enemyData.speedy;
    
    if(enemyData.exit) {
        if(enemyData.x <= -10-enemyData.width)   enemy.deleteData(enemyData);
        else if(enemyData.y <= -10-enemyData.height)  enemy.deleteData(enemyData);
        else if(enemyData.x >= 650+enemyData.width)   enemy.deleteData(enemyData);
        else if(enemyData.y >= 490+enemyData.height)  enemy.deleteData(enemyData);
    } else {
        switch(enemyData.moveType){
        case "noexit":
            if(enemyData.x <= 0){  enemyData.speedx = Math.abs(enemyData.speedx) * 1; }
            if(enemyData.x >= 640 - enemyData.width){  enemyData.speedx = Math.abs(enemyData.speedx) * -1;  enemyData.x -= 2;  };
            if(enemyData.y <= 0){  enemyData.speedy = Math.abs(enemyData.speedy) * 1; }
            if(enemyData.y >= 480 - enemyData.height){  enemyData.speedy = Math.abs(enemyData.speedy) * -1;  enemyData.y -= 2; };  break;
        case "up_xrandom":
            if(enemyData.x <= 0){  enemyData.speedx = Math.abs(enemyData.speedx) * 1; }
            if(enemyData.x >= 650+enemyData.width)   {enemyData.speedx = Math.abs(enemyData.speedx) * -1;  enemyData.x -= 2;}
            if(enemyData.y <= -10-enemyData.height)  { enemyData.y = 490; enemyData.x = Math.random() * (640 - enemyData.width);  }
            if(enemyData.y >= 490)  {enemyData.speedy = Math.abs(enemyData.speedy) * -1;  enemyData.x = Math.random() * (640 - enemyData.width); }  break;
        default:
            if(enemyData.x <= -10-enemyData.width){ enemyData.x = enemyData.width + 650;  enemyData.speedx = Math.abs(enemyData.speedx) * -1;   }
            if(enemyData.x >= 650+enemyData.width)  {enemyData.speedx = Math.abs(enemyData.speedx) * -1;  }
            if(enemyData.x >= 640 - enemyData.width && enemyData.speedx == 0){  enemyData.x -= 2; }
            if(enemyData.y <= -10)  enemyData.speedy = Math.abs(enemyData.speedy) * 1;
            if(enemyData.y >= 490)  enemyData.speedy = Math.abs(enemyData.speedy) * -1;  break;
        }
    }
};

enemy.dieCheck = function(enemyData){
    if(enemyData.isusing == false || enemyData.died == true)  return;
    if(enemyData.hp <= 0){
    	tamsaseon.killcount++;
        system.scoreBonus += enemyData.score;
        enemyData.died = true;
        enemyData.fire = 0;
        enemyData.defensedown = 0;
        enemyData.weakness = 0;
        optionbattle.sound.play(enemyData.diesound);
    }
};
enemy.dieEnimation = function(enemyData){
    if(enemyData.isusing == true && enemyData.died == true){
        enemyData.y += 10;
        enemyData.diecount--;
        
        if(enemyData.diecount <= 0){
            enemy.deleteData(enemyData);
        }  
    }
};
enemy.buffCheck = function(enemyData){
    if(enemyData.isusing == false)  return;
    
    // 버프 최대치 재설정
    if(enemyData.weakness > 100)  enemyData.weakness = 100;
    if(enemyData.defensedown > 100)  enemyData.defensedown = 100;
    if(enemyData.fire > 200)  enemyData.fire = 200;
    
    // 파이어 버프 처리
    if(enemyData.fire != 0 && enemyData.firetime%100 == 0){
        var firepoint = enemyData.fire; // 파이어의 적용값을 처리
        if(firepoint >= 200)  firepoint = 200;
        var damageValue = (firepoint * enemyData.firedamage * 20) / 100 |0;
        enemyData.hp -= damageValue;
        damage.create(damageValue, typeName.FIRE, enemyData.x, enemyData.y);
    }
    
    // 버프가 적용되었을경우, 버프체크시간을 감소시킴. 버프가 없을경우 버프체크시간을 최대로 유지.
    if(enemyData.weakness != 0)  enemyData.weaknesstime--;
    else  enemyData.weaknesstime = 250;
    if(enemyData.defensedown != 0)  enemyData.defensedowntime--;
    else  enemyData.defensedowntime = 250;
    if(enemyData.fire != 0)  enemyData.firetime--;
    else  enemyData.firetime = 300;
    
    // 시간이 0이될경우, 버프에 적용되었던 값 감소
    if(enemyData.weaknesstime <= 0){
        enemyData.weaknesstime = 350; // 시간 초기화 
        if(enemyData.weakness <= 10)  enemyData.weakness -= 4;
        else if(enemyData.weakness >= 11 && enemyData.weakness <= 20)  enemyData.weakness -= 8;
        else if(enemyData.weakness >= 21 && enemyData.weakness <= 35)  enemyData.weakness -= 13;
        else if(enemyData.weakness >= 36 && enemyData.weakness <= 50)  enemyData.weakness -= 21;
        else if(enemyData.weakness >= 51 && enemyData.weakness <= 70)  enemyData.weakness -= 30;
        else if(enemyData.weakness >= 71 && enemyData.weakness <= 90)  enemyData.weakness -= 42;
        else if(enemyData.weakness >= 91 && enemyData.weakness <= 100)  enemyData.weakness -= 55;
    }
    if(enemyData.defensedowntime <= 0){
        enemyData.defensedowntime = 200;
        if(enemyData.defensedown <= 10)  enemyData.defensedown -= 8;
        else if(enemyData.defensedown >= 11 && enemyData.defensedown <= 20)  enemyData.defensedown -= 16;
        else if(enemyData.defensedown >= 21 && enemyData.defensedown <= 35)  enemyData.defensedown -= 24;
        else if(enemyData.defensedown >= 36 && enemyData.defensedown <= 50)  enemyData.defensedown -= 36;
        else if(enemyData.defensedown >= 51 && enemyData.defensedown <= 70)  enemyData.defensedown -= 55;
        else if(enemyData.defensedown >= 71 && enemyData.defensedown <= 90)  enemyData.defensedown -= 70;
        else if(enemyData.defensedown >= 91 && enemyData.defensedown <= 100)  enemyData.defensedown -= 80;
    }   
    if(enemyData.firetime <= 0){  
    	enemyData.firetime = 300;  enemyData.fire -= 12;
    }
    
    // 음수값이 있을경우 0으로 변경
    if(enemyData.weakness <= 0)  enemyData.weakness = 0;
    if(enemyData.defensedown <= 0)  enemyData.defensedown = 0;
    if(enemyData.fire <= 0)  enemyData.fire = 0;
    
    
    // 데미지 출력 표시 관련 수정
    enemyData.damagecountdelay++;
    if(enemyData.damagecountdelay > 2){
    	enemyData.damagecountdelay = 0;
    	enemyData.damagecount = 0;
    }
};
enemy.display = function(){
    ctx.drawImage(enemy.statusImage, 640 - enemy.statusImage.width, 0);
    var enemyCurrent = 0,  enemyCreate = 0;
    for(var a = 0; a < enemy.currentCount.length; a++){
        enemyCurrent += enemy.currentCount[a];
    }
    for(var a = 0; a < enemy.createCount.length; a++){
        enemyCreate += enemy.createCount[a];
    }
    
    numberDisplay(enemyCurrent, 640 - enemy.statusImage.width + 80, 5);
    numberDisplay(enemyCreate, 640 - enemy.statusImage.width + 230, 5);
    for(var a = 0; a < enemy.data.length; a++){
        if(enemy.data[a].isusing == false)  continue;
        ctx.drawImage(enemy.data[a].image, enemy.data[a].x, enemy.data[a].y);
        
        ctx.font = "12px consolas";  ctx.fillStyle = "orange";
        if(enemy.data[a].weakness >= 1)  ctx.fillText(enemy.data[a].weakness, enemy.data[a].x+5, enemy.data[a].y+20);
        ctx.fillStyle = "cyan";
        if(enemy.data[a].defensedown >= 1)  ctx.fillText(enemy.data[a].defensedown, enemy.data[a].x+5, enemy.data[a].y+30);
        ctx.fillStyle = "salmon";
        if(enemy.data[a].fire >= 1)  ctx.fillText(enemy.data[a].fire, enemy.data[a].x+5, enemy.data[a].y+40);
    }
    
    enemy.displayAttack();
};
enemy.deleteData = function(index){
    if(typeof index == "number"){
        enemy.currentCount[enemy.data[index].group]--;
        enemy.data[index] = null;
        enemy.data[index] = new EnemyUnit(index);
    } else {
        var deleteIndex = index.index;
        if(enemy.data[deleteIndex].isusing == true){
            enemy.currentCount[enemy.data[deleteIndex].group]--;
            enemy.data[deleteIndex] = null;
            enemy.data[deleteIndex] = new EnemyUnit(deleteIndex);
        }
    }
};
enemy.deleteAll = function(){
    for(var i = 0; i < enemy.data.length; i++){
        if(enemy.data[i].isusing)  enemy.deleteData(i);
    }
    for(var i = 0; i < enemy.createCount.length; i++){
        enemy.createCount[i] = 0;
    }
};

enemy.deleteAttack = function(index){
    if(typeof index == "number"){
        enemy.attack[index] = null;
        enemy.attack[index] = new EnemyAttack(); //.isusing = false;
    } else {
        var deleteIndex = index.index;
        enemy.attack[deleteIndex] = null;  
        
        enemy.attack[deleteIndex] = new EnemyAttack();k
    }
};

enemy.clearCheck = function(){
    return enemy.nothingEnemy();
    // if(notEnemy == true){ // 적이 모두 죽은상태의 경우
    	// for(var a = 0; a < enemy.data.length; a++){  
    		// if(enemy.data[a].isusing == true){
    			// return false; // 적 객체 데이터를 사용중인경우 클리어처리를 미룸.
    		// }
    	// }
    // } else {
        // return false;
    // }
//     
    // return true;
};

enemy.nothingEnemy = function(){
	var createCount = 0,  currentCount = 0;
    for(var a = 0; a < enemy.createCount.length; a++){
        createCount += enemy.createCount[a];
    }
    for(var a = 0; a < enemy.currentCount.length; a++){
        currentCount += enemy.currentCount[a];
    }
    
    if(currentCount <= 0 && createCount <= 0)  return true;
    else  return false;
};

enemy.getCurrentCount = function(){
	var currentCount = 0;
	for(var a = 0; a < enemy.currentCount.length; a++){
        currentCount += enemy.currentCount[a];
    }
    
    return currentCount;
};
enemy.getCreateCount = function(){
	var createCount = 0;
	for(var a = 0; a < enemy.createCount.length; a++){
        createCount += enemy.createCount[a];
    }
    
    return createCount;
};

//--------------------------------
var tamsaseon = {
    warning50:false, warning25:false, warningTime:0, warningDelay:0,
    recovery:false,  recoveryTime:0,  recoveryCount:0,  recoveryDelay:0,
    shieldHp:0,  shieldMovePoint:0,  shieldEnergy:0,  shieldEnergyUsePoint:1000,  shieldValue:0.2,
    hp:0,  maxhp:0,  x:0,  y:0,  width:48,  height:48,  killcount:0,
};
tamsaseon.image = new Image();  tamsaseon.image.src = "image/field/tamsaseon.png";
tamsaseon.hpImage = new Image();  tamsaseon.hpImage.src = "image/field/tamsaseonhp.png";
tamsaseon.hpMeter = new Image();  tamsaseon.hpMeter.src = "image/field/hpmeter.png";
tamsaseon.hpWarning = new Image();  tamsaseon.hpWarning.src = "image/field/hpwarning.png";
tamsaseon.shieldImage = new Image();  tamsaseon.shieldImage.src = "image/field/shield.png";
tamsaseon.shieldMeter = new Image();  tamsaseon.shieldMeter.src = "image/field/shieldmeter.png";
tamsaseon.shieldEnergyImage = new Image();  tamsaseon.shieldEnergyImage.src = "image/field/shieldenergy.png";

tamsaseon.process_shield = function(){
    if(tamsaseon.shieldEnergy <= tamsaseon.shieldEnergyUsePoint*6)  tamsaseon.shieldEnergy++;
};
tamsaseon.process_collision = function(){
    if(tamsaseon.recovery == true)  return;
    
    for(var i = 0; i < enemy.data.length; i++){
        if(enemy.data[i].isusing == false)  continue;
        
        enemy.data[i].attackdelay--;
        if(collision(enemy.data[i], tamsaseon) && enemy.data[i].attackdelay <= 0){
            if(tamsaseon.shieldHp >= 1){
                tamsaseon.shieldHp -= enemy.data[i].attack;
                if(enemy.data[i].attack >= tamsaseon.shieldHp/25|0 )  optionbattle.sound.play(soundName.shielddamage);
            } else {
                tamsaseon.hp -= enemy.data[i].attack;
                if(enemy.data[i].attack >= tamsaseon.hp/100|0 )  optionbattle.sound.play(soundName.damage);
            }
            
            enemy.data[i].attackdelay = 50;
            enemy.data[i].speedx = -enemy.data[i].speedx;
            enemy.data[i].speedy = -enemy.data[i].speedy;
        }
    }
    
    for(var i = 0; i < enemy.attack.length; i++){
        if(enemy.attack[i].isusing == false)  continue;
        
        if(collision(tamsaseon, enemy.attack[i])){
            if(tamsaseon.shieldHp >= 1){
                tamsaseon.shieldHp -= enemy.attack[i].attack;
                if(enemy.attack[i].attack >= tamsaseon.shieldHp/25|0 )  optionbattle.sound.play(soundName.shielddamage);
            } else {
                tamsaseon.hp -= enemy.attack[i].attack;
                if(enemy.attack[i].attack >= tamsaseon.hp/100|0 )  optionbattle.sound.play(soundName.damage);
            }
            enemy.deleteAttack(i);
        }
        
        if(enemy.attack[i].x <= -500 || enemy.attack[i].y <= -500 && enemy.attack[i].x >= 1280 && enemy.attack[i].y >= 960){
            enemy.deleteAttack(i);
        }
    }
};
tamsaseon.process_warning = function(){
    if(tamsaseon.hp <= tamsaseon.maxhp * 0.5 && tamsaseon.warning50 == false){
        tamsaseon.warningTime = 80;
        tamsaseon.warningDelay = 0;
        tamsaseon.warning50 = true;
        optionbattle.sound.play(soundName.tamsaseonwarning);
    }
    
    if(tamsaseon.hp <= tamsaseon.maxhp * 0.25 && tamsaseon.warning25 == false){
        tamsaseon.warningTime = 80;
        tamsaseon.warningDelay = 0;
        tamsaseon.warning25 = true;
        optionbattle.sound.play(soundName.tamsaseonwarning);
    }
    
    if(tamsaseon.hp >= tamsaseon.maxhp * 0.51){
        tamsaseon.warningDelay++;
        if(tamsaseon.warningDelay >= 500){
            tamsaseon.warning25 = false;
            tamsaseon.warning50 = false;
        }
    }
};
tamsaseon.process_recovery = function(){
    if(tamsaseon.hp <= 0 && tamsaseon.recovery == false){
        tamsaseon.recovery = true;
        optionbattle.sound.play(soundName.wall_break);
        tamsaseon.recoveryTime = 30;
        tamsaseon.recoveryDelay = 2;
        tamsaseon.recoveryCount = -100;
    }
    
    if(tamsaseon.recovery == true){
        tamsaseon.recoveryCount++;
        //system.time += 0.02;
        if(tamsaseon.recoveryCount >= tamsaseon.recoveryDelay){
            tamsaseon.recoveryCount = 0;
            tamsaseon.recoveryTime--;
            system.time--;
            optionbattle.sound.play(soundName.tamsaseon_recoverytime);
        }
        
        if(tamsaseon.recoveryTime <= 0){
            tamsaseon.recovery = false;
            tamsaseon.hp = tamsaseon.maxhp;
            tamsaseon.warning50 = false;
            tamsaseon.warning25 = false;
        }
    }
};

tamsaseon.process = function(){
    if(inputpush[keyboard.up] == true && tamsaseon.y > 0)  tamsaseon.y -= 8;
    if(inputpush[keyboard.down] == true && tamsaseon.y < 480 - 48)  tamsaseon.y += 8;
    if(inputpush[keyboard.left] == true && tamsaseon.x > 0){  tamsaseon.x -= 8; } //tamsaseon.viewright = false; }
    if(inputpush[keyboard.right] == true && tamsaseon.x < 640 - 48) {  tamsaseon.x += 8;  tamsaseon.viewright = true; }
    if(inputkey == keyboard.z && tamsaseon.shieldHp <= 0 && tamsaseon.shieldEnergy >= tamsaseon.shieldEnergyUsePoint){
        tamsaseon.shieldEnergy -= tamsaseon.shieldEnergyUsePoint;
        tamsaseon.shieldHp = tamsaseon.maxhp * tamsaseon.shieldValue |0;
        optionbattle.sound.play(soundName.shielduse);
    }
    
    tamsaseon.process_shield();
    tamsaseon.process_collision();
    tamsaseon.process_warning();
    tamsaseon.process_recovery();
};
tamsaseon.display = function(){
    // 탐사선의 체력 및 수치 정보는  force.display 에서 처리
    
    if(tamsaseon.recovery == false)  ctx.drawImage(tamsaseon.image, 0, 0, 48, 48, tamsaseon.x, tamsaseon.y, 48, 48);
    if(tamsaseon.shieldHp >= 1)  ctx.drawImage(tamsaseon.shieldImage, tamsaseon.x-6, tamsaseon.y-6);
    
    
    if(tamsaseon.hp >= 1){
    	var percent = tamsaseon.hp / tamsaseon.maxhp;
    	ctx.drawImage(tamsaseon.hpMeter, 0, 0, percent * 640, 20, 0, 460, percent * 640, 20);
    }
    if(tamsaseon.shieldHp >= 1){
        var percent = tamsaseon.shieldHp / (tamsaseon.maxhp * tamsaseon.shieldValue);
        ctx.drawImage(tamsaseon.shieldMeter, 0, 0, percent * 640, 20, 0, 460, percent * 640, 20);
    }
    
    tamsaseon.warningTime--;
    if(tamsaseon.warningTime >= 1 && tamsaseon.warningTime % 2 == 0){
    	ctx.drawImage(tamsaseon.hpWarning, 0, 0, percent * 640, 20, 0, 460, percent * 640, 20);
    }
    
    ctx.drawImage(tamsaseon.hpImage, 0, 440);
    numberDisplay(tamsaseon.hp, 110, 440, true);
    numberDisplay(tamsaseon.maxhp, 140, 440);
    var percent = (tamsaseon.shieldEnergy%tamsaseon.shieldEnergyUsePoint / tamsaseon.shieldEnergyUsePoint);
    ctx.drawImage(tamsaseon.shieldEnergyImage, 0, 0, percent * 250, 10, 229, 450, percent * 250, 10);
    numberDisplay((tamsaseon.shieldEnergy/tamsaseon.shieldEnergyUsePoint)|0, 465, 440);
    if(tamsaseon.shieldHp >= 1)  numberDisplay(tamsaseon.shieldHp, 625, 440, true);
};
tamsaseon.init = function(){
    tamsaseon.hp = 30000 + ( 100 * optionbattle.user.getlv() );
    tamsaseon.maxhp = tamsaseon.hp;
    tamsaseon.x = 100;  tamsaseon.y = 240;
    tamsaseon.warning50 = false;  tamsaseon.warning25 = false;  tamsaseon.recovery = false;
    tamsaseon.warningDelay = 0;  tamsaseon.warningTime = 0;
    tamsaseon.killcount = 0;  tamsaseon.recovery = false;  tamsaseon.recoveryTime = 0;  tamsaseon.recoveryDelay = 0;
    tamsaseon.shieldHp = 0;  tamsaseon.shieldEnergy = 0;
};

// class System
var system = {
    boss:NOTHING,  bosskill:false,  goldBonus:0,  select:0,
    gameover:false, giveup:false, time:0, pause:false, timeuse:"default",
    clearImpossible:false, clear:false, clearinit:false, clearDelay:0,
    processPoint:0, processMax:0, waitTime:0, dungeon:0, round:0,
    mapscore:0, mapgold:0, clearBonus:0, timeBonus:0, scoreBonus:0, totalBonus:0, scoreEnimation:0, scoreEnimationCount:0,
};
system.pauseImage = new Image();  system.pauseImage.src = "image/field/pause.png";
system.arrow = new Image();  system.arrow.src = "image/field/arrow2.png";
system.on = new Image();  system.on.src = "image/field/on.png";
system.off = new Image();  system.off.src = "image/field/off.png";
system.timeImage = new Image();  system.timeImage.src = "image/field/fieldtime.png";
system.resultImage = new Image();  system.resultImage.src = "image/field/result.png";
system.gameoverImage = new Image();  system.gameoverImage.src = "image/field/gameover.png";
system.scoreImage = new Image();  system.scoreImage.src = "image/field/score.png";
system.group = new Array();

system.init = function(){
    system.dungeon = optionbattle.game.getDungeonSelect();
    system.round = optionbattle.game.getRoundSelect();
    var D = optionbattle.dungeon.getRound(system.dungeon, system.round);
    var E = optionbattle.dungeon.getEnemy(system.dungeon);
    
    background.imageNumber = D.map[0].imageNumber;
    background.setImage();
    background.x = 0;  background.y = 0;
    background.isScrollLoopX = D.map[0].loopx;
    background.isScrollLoopY = D.map[0].loopy;
    background.scrollX = D.map[0].speedx;
    background.scrollY = D.map[0].speedy;
    
    system.mapscore = D.mapscore;
    system.clearBonus = D.mapscore * D.time;
    system.time = D.time;
    system.timedown = true;  system.pause = false;  system.timeuse = "default";
    system.gameover = false;  system.giveup = false;  system.clear = false;  system.clearinit = false;
    system.clearDelay = 0;  system.processPoint = 0;  system.processMax = 0; system.scoreBonus = 0;  system.goldBonus = 0;
    system.clearImpossible = false;
    system.mapgold = D.mapgold;
    if(D.boss == NOTHING)  system.boss = NOTHING;
    else  system.boss = E[D.boss];
    
    system.group = null;
    system.group = D.group;
    for(var a = 0; a < D.group.length; a++){
        system.processMax += D.group[a].enemyCount;
    }
    
    system.waitTime = 0;
    optionbattle.music.play(D.musicNumber);
    
    event.script = D.script; // 스크립트 얻기
};

system.process_pause = function(){
    optionbattle.music.stop();
    if(inputkey == keyboard.up && system.select > 0){
        system.select--;  optionbattle.sound.play(soundName.select_move);
    } else if(inputkey == keyboard.down && system.select < 3){
        system.select++;  optionbattle.sound.play(soundName.select_move);
    } else if(inputkey == keyboard.z){
        switch(system.select){
            case 0: system.pause = false;  optionbattle.sound.play(soundName.system_pause);  optionbattle.music.continueMusic();  break;
            case 1: optionbattle.game.musicStatusChange(); break;
            case 2: optionbattle.game.soundStatusChange(); break;
            case 3: system.pause = false;  system.giveup = true; break;
        }
    }
};
system.process_running = function(){
    if(system.timeuse == "default" && enemy.getCurrentCount() >= 1 && tamsaseon.recovery == false){
        system.time -= 0.02;
    } else if(system.timeuse == "true" && tamsaseon.recovery == false){
        system.time -= 0.02;
    }
    system.time = Number(system.time.toFixed(2));
    
    //클리어 조건 체크 후, 클리어 처리
    if(system.clearImpossible == false && enemy.clearCheck() && system.boss == NOTHING){
        if(system.clearDelay <= 40){
            system.clearDelay++;
        } else {
            system.clear = true;
        }
    } else if(enemy.clearCheck() && system.bosskill == false && system.boss != NOTHING){
        enemy.create(system.boss, 0);
        system.bosskill = true;
        system.boss = NOTHING;
    } else {
        system.clearDelay = 0;
    }
    
    // 실패
    if(system.time <= 0){
        system.gameover = true;
    }
};
system.process_clearinit = function(){
    if(system.clear){  optionbattle.music.play(musicName.roundclear);  system.goldBonus += system.mapgold;  }
    else if(system.gameover)  optionbattle.music.play(musicName.roundfail);
    else  optionbattle.music.stop();
    
    system.clearBonus = system.clearBonus;
    if(system.mapscore/100|0 < 1)  system.timeBonus = system.time * 100 |0;
    else  system.timeBonus = system.time * (system.mapscore/100|0) * 100 |0;
    
    if(system.giveup || system.gameover){ // 게임오버나 게임을 포기할경우 클리어보너스와 타임보너스가 없음.
        system.clearBonus = 0;  system.timeBonus = 0;
    }
    system.totalBonus = system.clearBonus + system.timeBonus + system.scoreBonus;
    system.scoreEnimation = system.totalBonus;
    system.clearinit = true; // 이 값을 변경하여 시슽
    system.goldBonus += (system.scoreBonus * 0.1) |0;
    optionbattle.user.plusgold(system.goldBonus);
};
system.process_result = function(){
    system.scoreEnimationCount++;
    if(system.scoreEnimationCount%4 == 0&& system.scoreEnimation > 0){
        var getPoint = system.totalBonus * 0.05 |0;
        if(getPoint <= 100)  getPoint = 100;
        if(system.scoreEnimation > getPoint){
            system.scoreEnimation -= getPoint;
            optionbattle.user.plusexp(getPoint);
        } else if(system.scoreEnimation <= getPoint){
            optionbattle.user.plusexp(system.scoreEnimation);
            system.scoreEnimation = 0;
        }
        optionbattle.sound.play(soundName.system_score);
    }
    
    if(system.scoreEnimation <= 0){
        system.waitTime++;
    }
    
    if(system.giveup && system.waitTime >= 50)  optionbattle.game.modeChangeToMenu();
    else if(system.waitTime >= 100)  optionbattle.game.modeChangeToMenu();
};

system.process = function(){
    if(inputkey == keyboard.enter && system.clear == false && system.gameover == false && system.giveup == false){
        optionbattle.sound.play(soundName.system_pause);
        if(system.pause){  optionbattle.music.continueMusic();  system.pause = false; }  
        else  system.pause = true;
    }
    if(enemy.getCurrentCount() == 0 && system.clearImpossible == false){  system.clearDelay++; }
    else  {  system.clearDelay = 0; }
    
    if(system.pause == true){
        system.process_pause();
    } else if(system.pause == false && system.clear == false && system.gameover == false && system.giveup == false) {
        system.process_running();
    } else {
    	if(system.clearinit == false)  system.process_clearinit();
    	system.process_result();
    }
};
system.display = function(){
    ctx.drawImage(system.timeImage, 0, 0);
    numberDisplay(system.time, 60, 5);
    if(system.pause){
        ctx.drawImage(system.pauseImage, 230, 30);
        ctx.drawImage(system.arrow, 220, 60+(30*system.select));
        if(optionbattle.game.getmusicOn() == true)  ctx.drawImage(system.on, 410, 90);
        else  ctx.drawImage(system.off, 410, 90);
        if(optionbattle.game.getsoundOn() == true)  ctx.drawImage(system.on, 410, 120);
        else  ctx.drawImage(system.off, 410, 120);
        
        ctx.drawImage(system.scoreImage, 0, 30);
        numberDisplay(system.scoreBonus, 150, 35, true);
    } else if(system.clear || system.gameover || system.giveup){
        var alignY = 185,  alignX = 500;
        if(system.clear == true)  ctx.drawImage(system.resultImage, 0, 0);
        else  ctx.drawImage(system.gameoverImage, 0, 0);
        
        numberDisplay(system.clearBonus, alignX, alignY, true);
        numberDisplay(system.timeBonus, alignX, alignY+30, true);
        numberDisplay(system.scoreBonus, alignX, alignY+60, true);
        numberDisplay(system.totalBonus, alignX, alignY+90, true);
        numberDisplay(optionbattle.user.getlv(), 180, alignY+120, true);
        numberDisplay(optionbattle.user.getexp(), 360, alignY+120, true);
        numberDisplay(system.goldBonus, alignX, alignY+150, true);
        var expTable = optionbattle.user.getexpTable();
        var needexp = expTable[optionbattle.user.getlv()];
        numberDisplay(needexp, 400, alignY+120);
        ctx.fillStyle = "blue";
        var expPercent = optionbattle.user.getexp() / needexp;
        ctx.fillRect(120, 360, expPercent*410, 10);
    }
};


var background = {};
background.imageBlack = new Image();  background.imageBlack.src = "image/background/black.png";
background.imageNumber = 0;
background.imageChangeNumber = 0;
background.image = new Image();
background.imageChange = new Image();
background.isChange = false;
background.changeCount = 0;
background.changeDelay = 150;
background.x = 0;
background.speedx = 0;
background.speedy = 0;
background.isScrollLoopX = false;
background.isScrollLoopY = false;
background.scrollX = 0;
background.scrollY = 0;
background.y = 0;
background.setImage = function(){
	background.image = optionbattle.imagebox.round[background.imageNumber];
};
background.changeImage = function(changeNumber){
	background.changeCount = background.changeDelay;
	background.isChange = true;
	background.imageChangeNumber = changeNumber;
	background.imageChange = optionbattle.imagebox.round[changeNumber];
};
background.display = function(){
    var sizex = background.image.width;
    var sizey = background.image.height;
    var x = background.x;
    var y = background.y;
    var wx = sizex - x;
    var hy = sizey - y;
    var nonex = 0;
    var noney = 0;
    //if(wx >= 640)  wx = 640;
    //if(hy >= 480)  hy = 480;
    //if(x >= 640) px = x - 640;
    //if(y >= 480) py = y - 480;
    
    
    /* ctx.drawImage(image, x, y, sizex - x, sizey - y, 0, 0, sizex - x, sizey - y);
    ctx.drawImage(image, 0, 0, x, sizey, sizex - x, y, x, sizey);
    ctx.drawImage(image, 0, 0, sizex, y, x, sizey - y, sizex, y); */
    
    //고작 이미지 스크롤 처리하는데 4번씩이나 그려야 한다니 헐... 빌어먹을 파이어폭스, IE
    //하지만 어느게 표준인거지? 도무지 알수없군...
    //crop 크기가 0, 0 이면 에러가 나서 일일히 이래야 한다니 멘붕
    
    // ie, firefox, chrome, opera // y is 0 or x is 0
    // ie and firefox have zero size error.

    if(x == 0 && y == 0){
        ctx.drawImage(background.image, 0, 0); // 이미지 출력, x좌표 and y좌표가 0일경우
    } else if(x == 0 && y != 0) { // x좌표가 0일경우(y좌표 스크롤)
        if(y != 0)  ctx.drawImage(background.image, 0, 0, sizex, y, nonex, hy, sizex, y);
        if(hy != 0)  ctx.drawImage(background.image, nonex, y, sizex, hy, 0, 0, sizex, hy);
    } else if(x != 0 && y == 0) { // y좌표가 0일경우(x좌표 스크롤)
        if(wx != 0)  ctx.drawImage(background.image, x, noney, wx, sizey, 0, 0, wx, sizey);
        if(x != 0)  ctx.drawImage(background.image, 0, 0, x, sizey, wx, noney, x, sizey);
    } else if(x != 0 && y != 0) { // x와 y좌표가 0이 아닐경우(x, y 다 스크롤)
        if(wx != 0  && hy != 0) ctx.drawImage(background.image, x, y, wx, hy, 0, 0, wx, hy); // 그림 1
        if(x != 0  && hy != 0)  ctx.drawImage(background.image, 0, y, x, hy, wx, 0, x, hy); // x축 그림 2
        if(wx != 0  && y != 0)  ctx.drawImage(background.image, x, 0, wx, y, 0, hy, wx, y); // y축 그림 3
        if(wx != 0 && hy != 0)  ctx.drawImage(background.image, 0, 0, x, y, wx, hy, x, y); // x, y축 그림 4
    }
    
    if(background.isChange == true){
    	if(background.changeCount >= background.changeDelay / 2){
    		ctx.globalAlpha = 1 - (background.changeCount - (background.changeDelay / 2) ) / (background.changeDelay / 2);
    		ctx.drawImage(background.imageBlack, 0, 0);
    	} else {
    		ctx.globalAlpha = (background.changeCount) / (background.changeDelay / 2);
    		ctx.drawImage(background.imageBlack, 0, 0);
    	}
    }
    // 투명값 원래대로
    ctx.globalAlpha = 1;
    
};
background.process = function(){
    background.x += background.scrollX;
    background.y += background.scrollY;
    background.changeCount--;
    if(background.changeCount <= 0 && background.isChange == true){
    	background.isChange = false;
    } else if(background.changeCount == background.changeDelay / 2|0 ){
    	background.image = background.imageChange;
    	background.x = 0;
    	background.y = 0;
    }
    
    if(background.x >= background.image.width && background.isScrollLoopX == true)  background.x = 0;
    else if(background.x >= background.image.width - 640 && background.isScrollLoopX == false)  background.x -= background.scrollX;
    else if(background.x <= -1 && background.isScrollLoopX == true)  background.x = background.image.width;
    else if(background.x <= -1 && background.isScrollLoopX == false) background.x = 0;
    if(background.y >= background.image.height && background.isScrollLoopY == true)  background.y = 0;
    else if(background.y >= background.image.height - 480 && background.isScrollLoopY == false)  background.y -= background.scrollY;
    else if(background.y <= -1 && background.isScrollLoopY == true)  background.y = background.image.height;
    else if(background.y <= -1 && background.isScrollLoopY == false)  background.y = 0;
};
//-----------------------------//
function SpriteUnit(){
    this.spriteNumber = 0;
    this.displayTime = 0;
} SpriteUnit.prototype = new ObjectUnit();
var sprite = {};
sprite.picture = new Array(10);
for(var i = 0; i < sprite.picture.length; i++)  sprite.picture[i] = new SpriteUnit();
sprite.setPicture = function(spriteNumber, fileName){
    sprite.picture[spriteNumber].image = new Image();
    sprite.picture[spriteNumber].image.src = "image/sprite/"+fileName+".png";
};
sprite.setPicture(spriteName.enemy_stone, "enemy_stone");
sprite.setPicture(spriteName.enemy_stonered, "enemy_stonered");

sprite.data = new Array(150);
for(var i = 0; i < sprite.data.length; i++)  sprite.data[i] = new SpriteUnit();
sprite.create = function(arrayNumber, spriteNumber, x, y, displayTime){
    sprite.data[arrayNumber].isusing = true;
    sprite.data[arrayNumber].spriteNumber = spriteNumber;
    sprite.data[arrayNumber].x = x;
    sprite.data[arrayNumber].y = y;
    if(displayTime == null)  displayTime = 50000;
    sprite.data[arrayNumber].displayTime = displayTime;
};
sprite.display = function(){
    for(var i = 0; i < sprite.data.length; i++){
        if(sprite.data[i].isusing == false)  continue;
        
        var spriteNumber = sprite.data[i].spriteNumber;
        ctx.drawImage(sprite.picture[spriteNumber].image, sprite.data[i].x, sprite.data[i].y);
        sprite.data[i].displayTime--;
        if(sprite.data[i].displayTime <= 0){
            sprite.data[i].isusing = false;
        }
    }
};
sprite.deleteData = function(arrayNumber){
    sprite.data[arrayNumber].isusing = false;
};
sprite.deleteAll = function(){
    for(var i = 0; i < sprite.data.length; i++){
        sprite.data[i].isusing = false;
    }
};
sprite.init = function(){
    for(var i = 0; i < sprite.data.length; i++){
        sprite.data[i].isusing = false;
    }
};

//-----------------------------//
function EffectUnit(){
    this.countNumber = 0;
    this.imageCount = 0;
    this.effectNumber = 0;
    this.width = 0;
    this.height = 0;
    this.outputWidth = 0;
    this.outputHeight = 0;
} EffectUnit.prototype = new ObjectUnit();
var effect = {};
effect.picture = new Array(50);
for(var a = 0; a < effect.picture.length; a++)  effect.picture[a] = new EffectUnit();
effect.data = new Array(150);
for(var a = 0; a < effect.data.length; a++)  effect.data[a] = new EffectUnit();

effect.setEffect = function(number, filename, imageCount, delay, width, height, outputWidth, outputHeight){
    effect.picture[number].imageCount = imageCount;
    effect.picture[number].image = new Image();
    effect.picture[number].image.src = "image/effect/"+filename+".png";
    effect.picture[number].delay = delay;
    effect.picture[number].width = width;
    effect.picture[number].height = height;
    effect.picture[number].outputWidth = outputWidth;
    effect.picture[number].outputHeight = outputHeight;
};
effect.setEffect(effectName.SPLASH, "splash", 10, 1, 40, 40, 400, 400);
effect.setEffect(effectName.MISSILE, "missile", 10, 1, 40, 40, 180, 180);
effect.setEffect(effectName.HITSHOT, "hitshot", 10, 0, 40, 40, 40, 40);
effect.setEffect(effectName.FIRE, "fire", 10, 0, 60, 60, 60, 60);
effect.setEffect(effectName.MACHINEGUN_DOWN, "machinegun_down", 10, 0, 40, 40, 20, 400);
effect.setEffect(effectName.MACHINEGUN_UP, "machinegun_up", 10, 0, 40, 40, 20, 400);
effect.setEffect(effectName.MACHINEGUN_CENTER, "machinegun_center", 10, 0, 40, 40, 20, 400);
effect.setEffect(effectName.BURSTSHOT, "burstshot", 10, 0, 40, 40, 40, 40);
effect.setEffect(effectName.jemulstar, "jemulstar", 10, 3, 60, 60, 120, 120);
effect.setEffect(effectName.exclamation_mark, "exclamation_mark", 20, 1, 5, 20, 10, 40);
effect.setEffect(effectName.boss_warning, "boss_warning", 8, 2, 160, 60, 160, 60);

effect.create = function(effectNumber, x, y){
    var number = 0;
    for(var a = 0; a < effect.data.length; a++){
        if(effect.data[a].isusing == false){
            number = a;  break;
        }
    }
    
    effect.data[number].countNumber = 0;
    effect.data[number].x = x;
    effect.data[number].y = y;
    effect.data[number].isusing = true;
    effect.data[number].effectNumber = effectNumber;
    effect.data[number].delay = effect.picture[effectNumber].delay;
    effect.data[number].imageCount = effect.picture[effectNumber].imageCount;
    effect.data[number].width = effect.picture[effectNumber].width;
    effect.data[number].height = effect.picture[effectNumber].height;
    effect.data[number].outputWidth = effect.picture[effectNumber].outputWidth;
    effect.data[number].outputHeight = effect.picture[effectNumber].outputHeight;
};
effect.deleteData = function(index){
    effect.data[index] = new EffectUnit();
};
effect.display = function(index){
    for(var a = 0; a < effect.data.length; a++){
        if(effect.data[a].isusing == false)  continue;
        
        var EF = effect.data[a].effectNumber;
        var CN = effect.data[a].countNumber;
        var E = effect.data[a];
        
        var basex = 0;
        var basey = 0;
        for(var i = 0; i < effect.data[a].countNumber; i++){
        	basex += E.width;
        	if(basex >= effect.picture[EF].image.width){
        		basey += E.height;
        		basex = 0;
        	}
        }
        
        if(CN < effect.data[a].imageCount){
        	ctx.drawImage(effect.picture[EF].image, basex, basey, E.width, E.height, E.x, E.y, E.outputWidth, E.outputHeight);
        }  
    }
};
effect.process = function(){
    for(var a = 0; a < effect.data.length; a++){
        if(effect.data[a].isusing == false)  continue;
        
        if(effect.data[a].count >= effect.data[a].delay){
            effect.data[a].count = 0;
            if(effect.data[a].countNumber < effect.data[a].imageCount){
                effect.data[a].countNumber++;
            } else {
                effect.deleteData(a);
            }
        }
        effect.data[a].count++;
    }
};
effect.init = function(){
	for(var a = 0; a < effect.data.length; a++){
		effect.data[a].isusing = false;
	}
};
//-----------------------------//
// 스크립트와 같은 특수한 이벤트 처리를 위해 만든 객체
/*function Script(){
	this.condition = new Array(10);
	this.action = new Array(10);
	for(var a = 0; a < this.action.length; a++){
		this.condition[a] = "";
		this.action[a] = "";
	}
}*/

var event = {};
event.script  = new Array(101);
event.variable= new Array(101);
event.switch_ = new Array(101);
event.used    = new Array(101);
event.timer   = new Array(101);
for(var a = 0; a < event.script.length; a++){
	event.variable[a] = 0;
	event.switch_[a] = false;
	event.used[a] = false;
	event.timer[a] = 0;
}

event.condition_timer = function(textData, timerNumber){
//timer / time(frame) interval / timerNumber is use to script number. do not use it(timeNumber).
    var timeInterval = Number(textData[1]);
    if(event.timer[timerNumber] >= timeInterval){
        event.timer[timerNumber] = 0;
        return true;
    } else {
        event.timer[timerNumber]++;
        return false;
    }
};

event.condition_random = function(textData){
//random / percent
    var random = (Math.random() * 101) |0;
    var percent = Number(textData[1]);
    if(percent >= random){
        return true;
    } else {
        return false;
    }
};

event.condition_system = function(textData){
//system / type / operator / value

    var type = textData[1];
    var operator = textData[2];
    var value = Number(textData[3]);
    switch(type){
    case "time":
        switch(operator){
            case "=":  if(system.time == value)  return true;  else break;
            case "<":  if(system.time <  value)  return true;  else break;
            case ">":  if(system.time >  value)  return true;  else break;
            case "<=": if(system.time <= value)  return true;  else break;
            case ">=": if(system.time >= value)  return true;  else break;
        }
    }
};

event.condition_variable = function(textData){
//variable(command) / index / operator / value
//변수(명령어) / 인덱스 / 연산자 / 값
//index: 0 ~ 100
//operator: =, <, >, <=, >=
    var index = Number(textData[1]);
    var operator = textData[2];
    var value = Number(textData[3]);
    
    switch(operator){
    case "=":  if(event.variable[index] == value)  return true;  else break;
    case "<":  if(event.variable[index] <  value)  return true;  else break;
    case ">":  if(event.variable[index] >  value)  return true;  else break;
    case "<=": if(event.variable[index] <= value)  return true;  else break;
    case ">=": if(event.variable[index] >= value)  return true;  else break;
    }
    
    return false;
};
event.condition_enemy = function(textData){
//enemy(command) / type / operator / value
//적(명령어) / 타입 / 값
//type: current(currentcount), create(createcount)
//타입: 현재(현재카운트), 생성(생성카운트), 아무것도 없음
//operator: =, <, >, <=, >=
    
    var type = textData[1];
    var operator = textData[2];
    var value = Number(textData[3]);
    switch(type){
    case "current":
        switch(operator){
            case "=":  if(enemy.getCurrentCount() == value)  return true;  else break;
            case "<":  if(enemy.getCurrentCount() <  value)  return true;  else break;
            case ">":  if(enemy.getCurrentCount() >  value)  return true;  else break;
            case "<=": if(enemy.getCurrentCount() <= value)  return true;  else break;
            case ">=": if(enemy.getCurrentCount() >= value)  return true;  else break;
        } break;
    case "create":
        switch(operator){
            case "=":  if(enemy.getCreateCount() == value)  return true;  else break;
            case "<":  if(enemy.getCreateCount() <  value)  return true;  else break;
            case ">":  if(enemy.getCreateCount() >  value)  return true;  else break;
            case "<=": if(enemy.getCreateCount() <= value)  return true;  else break;
            case ">=": if(enemy.getCreateCount() >= value)  return true;  else break;
        } break;
    }
    
    return false;
};
event.condition_nothing = function(textData){
//nothing(command) / type
//아무것도없음(명령어) / 타입
//type: enemy
//타입: 적    
    var type = textData[1];
    switch(type){
    case "enemy":  if(enemy.nothingEnemy() == true)  return true;
    }
    
    return false;
};

event.action_music = function(textData){
//music / action / number
//음악 / 액션 / 번호
//action: play, change, stop
    var action = textData[1];
    var number = Number(textData[2]);
    switch(action){
    case "play":  optionbattle.music.play(number);  break;
    case "change":optionbattle.music.change(number);  break;
    case "stop":  optionbattle.music.off();  break;
    }
};
event.action_system = function(textData){
//system / type / action
//시스템 / 타입 / 액션
//type: clear -> action: true(즉시 해당 라운드 클리어), impossible(어떠한경우도 클리어 불가능), possible(클리어 불가능 해제)
//type: timeuse -> action: false(시간 감소 없음), true(무조건 시감 감소), default(기본값/적이 있을때만 감소)
    var type = textData[1];
    var action = textData[2];
    switch(type){
    case "clear":
        if(action == "true"){
            system.clear = true;  system.clearImpossible = false;
        } else if(action == "impossible"){
            system.clearImpossible = true;
        } else if(action == "possible"){
            system.clearImpossible = false;
        }  break;
    case "timeuse":
        if(action == "false"){
            system.timeuse = "false";
        } else if(action == "true"){
            system.timeuse = "true";
        } else if(action == "default"){
            system.timeuse = "default";
        }
    }
};
event.action_time = function(textData){
//time / operator / value
    var operator = textData[1];
    var value = Number(textData[2]);
    switch(operator){
    case "+":  system.time += time;
    }
};
event.action_enemy = function(textData){
//enemy / numberof / type / value
    var numberof = Number(textData[1]);
    var type = textData[2];
    var value = textData[3];
    if(type == "movetype" && value == "exit")  optionbattle.sound.play(soundName.exclamation_mark);
    for(var i = 0; i < numberof; i++){
        var random = attack.setTarget();
        switch(type){
        case "movetype":
            if(value == "exit"){
                enemy.data[random].moveType = "exit";
                enemy.data[random].exit = true;
                effect.create(effectName.exclamation_mark, enemy.data[random].x, enemy.data[random].y);
            }
            break;
        case "speedtype":
            break;
        }
    }
};

event.action_group = function(textData){
//group / number / action / operator / value
//그룹 / 번호 / 액션 / 연산자 / 값
//action: createcount
//operator: +, -, =
    
    var number = Number(textData[1]);
    var action = textData[2];
    var operator = textData[3];
    var value = Number(textData[4]);
    switch(action){
    case "create":
        switch(operator){
        case "=":  enemy.createCount[number] = value;  break;
        case "+":  enemy.createCount[number] += value; break;
        case "-":  enemy.createCount[number] -= value; break;
        }  break;
    }
};
event.action_variable = function(textData){
//variable / index / operator / value
//변수 / 인덱스 / 연산자 / 값
//operator: +, -, =
    var index = Number(textData[1]);
    var operator = textData[2];
    var value = Number(textData[3]);
    switch(operator){
    case "=":  event.variable[index] = value;  break;
    case "+":  event.variable[index] += value; break;
    case "-":  event.variable[index] -= value; break;
    }
};
event.action_map = function(textData){
//map / type / value
//type: loopx, loopy, speedx, speedy, change, position
    var type = textData[1];
    var value = Number(textData[2]);
    switch(type){
    case "change": background.changeImage(value); break;
    case "speedx": background.scrollX = value;  break;
    case "speedy": background.scrollY = value;  break;
    case "loopx":  
        if(textData[2] == "true")  background.isScrollLoopX = true;
        else  background.isScrollLoopX = false;  break;
    case "loopy":
        if(textData[2] == "true")  background.isScrollLoopY = false;
        else  background.isScrollLoopY = false;  break;
    case "position":  background.x = value;  background.y = value;  break;
    }
};
event.action_sound = function(textData){
//sound / playnumber
//사운드 / 플레이번호
    var playnumber = Number(textData[1]);
    optionbattle.sound.play(playnumber);
};
event.action_delete = function(textData){
//delete / type
    var type = textData[1];
    switch(type){
    case "enemy":  enemy.deleteAll();
    case "sprite":  sprite.deleteAll();
    } 
};
event.action_effect = function(textData){
//effect / effectName(effectNumber) / x / y
    var number = Number(textData[1]);
    var x = Number(textData[2]);
    var y = Number(textData[3]);
    effect.create(number, x, y);
};
event.action_sprite = function(textData){
//sprite / create / arrayNumber / spriteNumber / x / y
//sprite / delete / arrayNumber
    var menu = textData[1];
    var arrayNumber = Number(textData[2]);
    switch(menu){
    case "create":  
        var spriteNumber = Number(textData[3]);
        var x = Number(textData[4]);
        var y = Number(textData[5]);
        sprite.create(arrayNumber, spriteNumber, x, y);
        break;
    case "delete":
        sprite.deleteData(arrayNumber);
        break;
    }
};

event.process = function(){
  for(var a = 0; a < event.script.length; a++){ // 모든 스크립트를 매 프레임마다 조사
  	if(event.used[a] == true)  continue; // 스크립트를 사용했다면 건너 뜀
  	var scriptTrue = [false, false, false, false, false, false, false, false, false, false];
  	
  	// 스크립트의 조건 체크
  	for(var b = 0; b < event.script[a].condition.length; b++){
  		var scriptCondition = event.script[a].condition[b].split(" ");
  		var command = scriptCondition[0];
  		switch(command){
  		case "timer":  scriptTrue[b] = event.condition_timer(scriptCondition, a);  break;
  		case "variable":  scriptTrue[b] = event.condition_variable(scriptCondition);  break;
  		case "enemy":  scriptTrue[b] = event.condition_enemy(scriptCondition);  break;
  		case "nothing":  scriptTrue[b] = event.condition_nothing(scriptCondition);  break;
  		case "system":  scriptTrue[b] = event.condition_system(scriptCondition);  break;
  		case "random":  scriptTrue[b] = event.condition_random(scriptCondition);  break;
  		case "always":  scriptTrue[b] = true;  break;
  		default:
  		}
  	}
  	
  	var realTrue = false; // 모든 조건이 맞는지 체크하는 변수
  	for(var c = 0; c < event.script[a].condition.length; c++){
  		if(scriptTrue[c] == true){ // 조건이 맞는경우
  			realTrue = true;  continue;
  		} else {  // 조건이 안맞는경우
  			realTrue = false;  break;
  		}
  	}
  	
  	// 조건이 맞지 않는경우 해당 포문을 건너뛰고 다음 스크립트로 넘어감.
  	if(realTrue == false)  continue;
  	else  event.used[a] = true; // 조건이 맞는경우 해당 스크립트를 사용한다.
  	
  	// 스크립트의 조건이 맞으므로  액션 체크
  	for(b = 0; b < event.script[a].action.length; b++){
  		var scriptAction = event.script[a].action[b].split(" ");
        var command = scriptAction[0];
        switch(command){
        case "music":  event.action_music(scriptAction); break;
        case "system":  event.action_system(scriptAction); break;
        case "group":  event.action_group(scriptAction); break;
        case "variable": event.action_variable(scriptAction); break;
        case "enemy":  event.action_enemy(scriptAction); break;
        case "map":  event.action_map(scriptAction); break;
        case "sound":  event.action_sound(scriptAction); break;
        case "delete":  event.action_delete(scriptAction); break;
        case "effect":  event.action_effect(scriptAction); break;
        case "sprite":  event.action_sprite(scriptAction); break;
  		case "infinity":  event.used[a] = false;  break; // 스크립트를 무한으로 쓸 때 사용
		}
  	}
  }
};
event.init = function(){
	for(var a = 0; a < event.variable.length; a++){
		// 스크립트값을 얻는것은 시스템에서 처리
		// event.script[a] = optionbattle.dungeon.getScript();
		event.variable[a] = 0;
		event.switch_[a] = false;
		event.used[a] = false;
		event.timer[a] = 0;
	}
};

//-----------------------------//
var unusedImage = new Image();  unusedImage.src = "image/system/unused.png";
// function process
this.init = function(){
    tamsaseon.init();
    force.setForce();
    system.init();
    enemy.init();
    attack.init();
    damage.init();
    effect.init();
    event.init();
    sprite.init();
};

this.process = function(){
    if(system.pause == true){
	    system.process();
	} else if(system.clear == false && system.gameover == false && system.giveup == false) {
	    system.process();
	    tamsaseon.process();
	    enemy.process();
	    attack.process();
	    force.process();
	    damage.process();
	    effect.process();
	    background.process();
	    event.process();
	} else if(system.clear == true || system.gameover == true || system.giveup == true) {
	    system.process();
	}
};
this.display = function(){
    background.display();
    sprite.display();
    attack.display();
    enemy.display();
    tamsaseon.display();
    effect.display();
    damage.display();
    force.display();
    system.display();
};


var numberPng = new Image();
numberPng.src = "image/system/numberPng.png";
this.numberDisplay = function(number, x, y, isAlignRight){
    numberDisplay(number, x, y, isAlignRight);
};

function numberDisplay(number, x, y, isAlignRight){
    // 여기에 있는 const 변수는 이미지 출력 좌표를 간단히 하기 위해 만든 변수임
    // 위 함수와 다른점은 이 함수는 해당 객체 내부에서 사용할 수 있게 한 함수임.
    cw = 12, ch = 20, sw = 12, sh = 20; // c = crop, s = imagesize, w = width, h = height
    var strnumber = number.toString();
    
    if(isAlignRight == true){ // 오른쪽 정렬일때, length에서 1을 빼주는것은 스트링 배열은 0번부터 시작하기때문
        for(var a = strnumber.length-1 , b = 0 ; a >= 0; a--, b++){
            var outputnumber = strnumber.charAt(a);
            switch(outputnumber){
                case '0': ctx.drawImage(numberPng, cw*0, ch*0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '1': ctx.drawImage(numberPng, cw*1, ch*0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '2': ctx.drawImage(numberPng, cw*2, ch*0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '3': ctx.drawImage(numberPng, cw*3, ch*0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '4': ctx.drawImage(numberPng, cw*4, ch*0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '5': ctx.drawImage(numberPng, cw*5, ch*0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '6': ctx.drawImage(numberPng, cw*6, ch*0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '7': ctx.drawImage(numberPng, cw*7, ch*0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '8': ctx.drawImage(numberPng, cw*8, ch*0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '9': ctx.drawImage(numberPng, cw*9, ch*0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '.': ctx.drawImage(numberPng, cw*10,ch*0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '-': ctx.drawImage(numberPng, cw*11,ch*0, sw, sh, x-(b*sw), y, sw, sh);  break;
            }
        }
    } else {
        for(var a = 0; a < strnumber.length; a++){
            var outputnumber = strnumber.charAt(a);
            switch(outputnumber){
                case '0': ctx.drawImage(numberPng, cw*0, ch*0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '1': ctx.drawImage(numberPng, cw*1, ch*0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '2': ctx.drawImage(numberPng, cw*2, ch*0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '3': ctx.drawImage(numberPng, cw*3, ch*0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '4': ctx.drawImage(numberPng, cw*4, ch*0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '5': ctx.drawImage(numberPng, cw*5, ch*0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '6': ctx.drawImage(numberPng, cw*6, ch*0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '7': ctx.drawImage(numberPng, cw*7, ch*0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '8': ctx.drawImage(numberPng, cw*8, ch*0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '9': ctx.drawImage(numberPng, cw*9, ch*0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '.': ctx.drawImage(numberPng, cw*10,ch*0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '-': ctx.drawImage(numberPng, cw*11,ch*0, sw, sh, x+(a*sw), y, sw, sh);  break;
            }
        }
    }
    
}
//-----------------------//
}// function end
//-----------------------//
optionbattle.field = new Field();