function Dungeon(){
const dungeonName = { 파란행성_Part1:0,  파란행성_Part2:1, 파란행성_Part3:2 };
const NOTHING = -1;
var data = new Array(); // 던전의 데이터
var dungeonCount = NOTHING;

function createDungeon(number, name){
    dungeonCount++;
    this.number = number;
    this.name = name;
    
    this.round = new Array();
    var roundCount = NOTHING;
    this.getRoundCount = function(){  return roundCount; };
    function Group(number, enemyList, enemyCount, enemyMax, enemyMap){
        this.number = number;
        this.enemylist = enemyList;
        this.enemycount = enemyCount;
        this.enemymax = enemyMax;
        if(enemyMap == null)  this.enemymap = enemyMap;   else  this.enemymap = 0;
        
    }
    
    function Round(name, time, mapscore, mapgold, musicNumber){
        this.name = name;
        this.time = time;
        this.mapscore = mapscore;
        this.mapgold = mapgold;
        this.musicNumber = musicNumber;
        this.boss = NOTHING;
        
        this.group = new Array();
        this.groupCount = NOTHING;
        
        this.map = new Array();
        this.mapCount = NOTHING;
        
        this.script = new Array();
        this.scriptCount = NOTHING;
    }
    this.createRound = function(name, time, mapscore, mapgold, musicNumber){
        roundCount++;
        this.round[roundCount] = new Round(name, time, mapscore, mapgold, musicNumber);
    };
    this.addRoundEnemy = function(enemyList, enemyCount, enemyMax){
        this.round[roundCount].groupCount++;
        var groupCount = this.round[roundCount].groupCount;
        this.round[roundCount].group[groupCount] = new Group(groupCount, enemyList, enemyCount, enemyMax);
    };
    this.setBoss = function(boss){
        this.round[roundCount].boss = boss;
    };
    //------------------------
    function Map(imageNumber, speedx, speedy, loopx, loopy, option){
    	this.imageNumber = imageNumber;
    	this.speedx = speedx;
    	this.speedy = speedy;
    	this.loopx = loopx;
    	this.loopy = loopy;
    	this.option = option;
    }
    this.setMap = function(imageNumber, speedx, speedy, loopx, loopy, array_groupNumber, option){
        this.round[roundCount].mapCount++;
        var mapCount = this.round[roundCount].mapCount;
        this.round[roundCount].map[mapCount] = new Map(imageNumber, speedx, speedy, loopx, loopy, option);
    };
    //------------------------
    function Script(condition, action){
    	this.condition = new Array();
    	this.action = new Array();
    	// 모든 스크립트는 한번만 사용 가능
    	
    	if(typeof condition != "object"){  // 스크립트가 1개만 있는경우 강제로 객체로 만듬
    		this.condition[0] = condition;
    	} else {  // 스크립트가 여러개 있는경우 배열을 복사
    		this.condition = condition; 
    	}
    	
    	// 이건 액션도 마찬가지
    	if(typeof action != "object"){
    		this.action[0] = action;
    	} else {
    		this.action = action;
    	}
    }
    this.addScript = function(conditon, action){
    	this.round[roundCount].scriptCount++;
    	var scriptCount = this.round[roundCount].scriptCount;
    	this.round[roundCount].script[scriptCount] = new Script(conditon, action);
    };
    
    //------------------------
    this.enemy = new Array();
    var enemyCount = NOTHING;
    function Enemy(number, name, hp, attack, defense, imagenumber){
        this.number = number;
        this.name = name;
        this.hp = hp;
        this.attack = attack;
        this.defense = defense;
        this.imagenumber = imagenumber;
        this.score = (hp/1000) + (attack/10) + (defense/10) |0;
        this.shot = false;
        this.shotAttack = 0;
        this.shotDelay = 0;
        this.shotType = "";
        this.ai = new Array();
        
        this.diesound = soundName.dongrami_fail; // soundNumber, default: donggrami_fail
        this.diemotion = "";
        this.speedx = 0;
        this.speedy = 0;
        this.speedType = "";
        this.moveType = "";
    }
    this.createEnemy = function(number, name, hp, attack, defense, imagenumber){
        enemyCount++;
        this.enemy[number] = new Enemy(number, name, hp, attack, defense, imagenumber);
    };
    this.setEnemy = function(number, speedx, speedy, speedType, moveType, diesound, diemotion){
        this.enemy[number].speedx = speedx;
        this.enemy[number].speedy = speedy;
        this.enemy[number].speedType = speedType;
        this.enemy[number].moveType = moveType;
        this.enemy[number].diesound = diesound;
        this.enemy[number].diemotion = diemotion;
    };
    this.setAttack = function(number, attack, delay, type){
    	this.enemy[number].shot = true;
    	this.enemy[number].shotAttack = attack;
    	this.enemy[number].shotDelay = delay;
    	this.enemy[number].shotType = type;
    };
}


//---------------------------------//
data[0] = new createDungeon(0, "파란행성 part1: 동그라미 마을");
data[0].createRound("듀토리얼", 120, 100, 100, musicName.none);
data[0].addRoundEnemy([0,1,2,3,4], 115, 20);
data[0].setMap(29, 0, 0, false, false);
data[0].createRound("우주 여행 1, 정거장 출발", 120, 100, 100, musicName.music01);
data[0].addRoundEnemy([0,1,2,3,4], 350, 20);
data[0].setMap(1, 3, 0, true, false);
data[0].addScript(["variable 1 = 0","nothing enemy"], ["map change 2", "variable 1 = 1", "system clear impossible"]);
data[0].addScript(["variable 1 = 1", "variable 2 < 200"], ["variable 2 + 1", "infinity"]);
data[0].addScript(["variable 2 = 200"], ["group 0 create + 80", "system clear possible"]);
data[0].createRound("우주 여행 2, 센티멘탈행성계 가는길 1", 180, 104, 100, musicName.music01);
data[0].addRoundEnemy([0,1,2,3,4], 1100, 50);
data[0].setMap(2, 7, 0, true, false);
data[0].createRound("우주 여행 3, 센티멘탈행성계 가는길 2", 180, 104, 100, musicName.music01);
data[0].addRoundEnemy([0,1,2,3,4], 1020, 65);
data[0].addRoundEnemy([5,6,7,8,9], 0, 37);
data[0].addScript(["variable 1 = 0","nothing enemy"], ["music change "+musicName.music08+"", "map change 3", "variable 1 = 1", "system clear impossible"]);
data[0].addScript(["variable 1 = 1", "variable 2 <= 200"], ["variable 2 + 1", "infinity"]);
data[0].addScript(["variable 2 = 200"], ["group 1 create + 55", "system clear possible"]);
data[0].setMap(2, 7, 0, true, false);
data[0].createRound("운석지대 1", 170, 110, 400, musicName.music08);
data[0].addRoundEnemy([0,1,2,3,4], 170, 9);
data[0].addRoundEnemy([5,6,7,8,9], 240, 32);
data[0].setMap(3, 4, 0, true, false);
data[0].createRound("운석지대 2, 무인기 충돌 구역?", 170, 110, 400, musicName.music08);
data[0].addRoundEnemy([5,6,7,8,9], 80, 44);
data[0].addRoundEnemy([29], 0, 1);
data[0].addScript(["variable 1 = 0","nothing enemy"], ["music change "+musicName.music09+"", "variable 1 = 1", "group 1 create + 1"]);
data[0].addScript(["variable 1 = 1","nothing enemy"], ["music change "+musicName.music08+"", "variable 1 = 2", "group 0 create + 50"]);
data[0].addScript(["variable 1 = 2","nothing enemy"], ["music change "+musicName.music09+"", "variable 1 = 3", "group 1 create + 1" ]);
data[0].addScript(["variable 1 = 3","nothing enemy"], ["music change "+musicName.music08+"", "variable 1 = 4", "group 0 create + 40"]);
data[0].setMap(3, 4, 0, true, false);
data[0].createRound("운석지대 3, 자주 충돌하는 무인기 ", 220, 120, 700, musicName.music08);
data[0].addRoundEnemy([5,6,7,8,9], 25, 51);
data[0].addRoundEnemy([29], 0, 1);
data[0].addScript(["variable 1 = 0","nothing enemy"], ["music change "+musicName.music09+"", "variable 1 = 1", "group 1 create + 1"]);
data[0].addScript(["variable 1 = 1","nothing enemy"], ["music change "+musicName.music08+"", "variable 1 = 2", "group 0 create + 25"]);
data[0].addScript(["variable 1 = 2","nothing enemy"], ["music change "+musicName.music09+"", "variable 1 = 3", "group 1 create + 1" ]);
data[0].addScript(["variable 1 = 3","nothing enemy"], ["music change "+musicName.music08+"", "variable 1 = 4", "group 0 create + 30"]);
data[0].addScript(["variable 1 = 4","nothing enemy"], ["music change "+musicName.music09+"", "variable 1 = 5", "group 1 create + 1"]);
data[0].addScript(["variable 1 = 5","nothing enemy"], ["variable 1 = 6", "group 1 create + 1", "group 0 create + 60", "system clear impossible" ]);
data[0].addScript(["variable 1 = 6","nothing enemy"], ["variable 2 + 1", "infinity"]);
data[0].addScript(["variable 1 = 6","variable 2 >= 200"], ["variable 1 = 7", "variable 2 = 0", "map change 30", "music change "+musicName.music10+""]);
data[0].addScript(["variable 1 = 7","variable 2 >= 200"], ["system clear true"]);
data[0].addScript(["variable 1 = 7","nothing enemy"], ["variable 2 + 1", "infinity"]);
data[0].setMap(3, 4, 0, true, false);
data[0].createRound("운석지대 4, 숨겨진 미스터리 구역", 210, 120, 800, musicName.music10);
data[0].addRoundEnemy([5,6,7,8,9], 17, 13);
data[0].addRoundEnemy([29], 0, 1);
data[0].addRoundEnemy([31, 32, 33], 0, 19);
data[0].addScript(["variable 1 = 0","nothing enemy"], ["music change "+musicName.music09+"", "variable 1 = 1", "group 1 create + 1"]);
data[0].addScript(["variable 1 = 1","nothing enemy"], ["music change "+musicName.music10+"", "variable 1 = 2", "group 0 create + 49"]);
data[0].addScript(["variable 1 = 2","nothing enemy"], ["variable 1 = 3", "group 0 create + 32", "group 2 create + 55"]);
data[0].setMap(30, 4, 0, true, false);
data[0].createRound("운석지대 5, 알수없는 의식의 공간", 190, 132, 600, musicName.music09);
data[0].addRoundEnemy([5,6,7,8,9], 0, 51);
data[0].addRoundEnemy([30], 1, 1);
data[0].addRoundEnemy([31,32,33], 0, 32);
data[0].addScript(["variable 1 = 0","nothing enemy"], ["variable 1 = 1", "system clear impossible", "music stop", "system timeuse false"]);
data[0].addScript(["variable 1 = 1"], ["variable 2 + 1", "infinity"]);
data[0].addScript(["variable 2 = 400"], ["sprite create 0 "+spriteName.enemy_stone+" 280 220"]);
data[0].addScript(["variable 2 = 800"], ["map change 31"]);
data[0].addScript(["variable 2 = 1000"], ["sound "+soundName.meteorite_zone_mystery_message1+""]);
data[0].addScript(["variable 2 = 1220"], ["sound "+soundName.meteorite_zone_mystery_message2+""]);
data[0].addScript(["variable 2 = 1440"], ["sound "+soundName.meteorite_zone_mystery_message3+""]);
data[0].addScript(["variable 2 = 1760"], ["sound "+soundName.meteorite_zone_mystery_message4+""]);
data[0].addScript(["variable 2 = 2000"], ["sound "+soundName.jemulstar+"", "effect "+effectName.jemulstar+" 280 220"]);
data[0].addScript(["variable 2 = 2030"], ["effect "+effectName.jemulstar+" 280 220"]);
data[0].addScript(["variable 2 = 2060"], ["effect "+effectName.jemulstar+" 280 220"]);
data[0].addScript(["variable 2 = 2090"], ["effect "+effectName.jemulstar+" 280 220"]);
data[0].addScript(["variable 2 = 2120"], ["sprite delete 0"]);
data[0].addScript(["variable 2 = 2200"], ["map change 8"]);
data[0].addScript(["variable 2 = 2400"], ["sound "+soundName.jemulstarend+"", "sprite create 0 "+spriteName.enemy_stonered+" 280 220", "effect "+effectName.jemulstar+" 280 220"]);
data[0].addScript(["variable 2 = 2430"], ["effect "+effectName.jemulstar+" 280 220"]);
data[0].addScript(["variable 2 = 2700"], ["system clear true"]);
data[0].setMap(8, 0, 0, true, false);
data[0].createRound("운석지대 6", 210, 125, 400, musicName.music10);
data[0].addRoundEnemy([5,6,7,8,9], 130, 23);
data[0].addRoundEnemy([31, 32, 33], 90, 14);
data[0].addScript(["nothing enemy"], ["variable 1 = 1", "system clear impossible"]);
data[0].addScript(["variable 1 = 1"], ["variable 5 + 1", "infinity"]);
data[0].addScript(["variable 5 > 100"], ["map change 3", "music change "+musicName.music08+""]);
data[0].addScript(["variable 5 > 500"], ["system clear true"]);
data[0].setMap(30, 4, 0, true, false);
data[0].createRound("운석지대 7", 170, 125, 400, musicName.music08);
data[0].addRoundEnemy([5,6,7,8,9], 310, 36);
data[0].setMap(3, 4, 0, true, false);
data[0].addScript(["variable 1 = 0","nothing enemy"], ["music change "+musicName.music01+"", "variable 1 = 1", "system clear impossible", "map change 2"]);
data[0].addScript(["variable 1 = 1"], ["variable 2 + 1", "infinity"]);
data[0].addScript(["variable 2 >= 250"], ["system clear true"]);
data[0].createRound("우주 여행 4, 센티멘탈 은하계 여행", 180, 133, 200, musicName.music01);
data[0].addRoundEnemy([0,1,2,3,4], 1000, 48);
data[0].setMap(2, 5, 0, true, false);
data[0].createRound("우주 여행 5, 파란행성 진입구간", 110, 125, 100, musicName.music01);
data[0].addRoundEnemy([0,1,2,3,4], 182, 12);
data[0].addRoundEnemy([11,12,13,14], 22, 2);
data[0].setMap(2, 3, 0, true, false);
data[0].addScript(["timer 1500"], ["map change 4"]);
//---------------------------------//
data[0].createRound("파란 행성 1, 높이: 300km ~ 290km", 120, 140, 500, musicName.music02);
data[0].addRoundEnemy([11,12,13,14], 1, 4);
data[0].addScript(["always"], ["system clear impossible", "system timeuse true"]);
data[0].addScript(["always"], ["variable 5 + 1", "infinity"]);
data[0].addScript(["timer 500", "random 65", "system time >= 30"], ["group 0 create + 1", "variable 5 = 0" , "infinity"]);
data[0].addScript(["timer 150", "variable 5 >= 500" ,"nothing enemy", "system time >= 30"], ["group 0 create + 1", "variable 5 = 0", "infinity"]);
data[0].addScript(["system time <= 30"], ["system clear possible", "group 0 create + 1"]);
data[0].setMap(5, 0, 4, false, true);
data[0].createRound("파란 행성 2, 높이: 290km ~ 280km", 120, 142, 500, musicName.music02);
data[0].addRoundEnemy([11,12,13,14], 17, 7);
data[0].addScript(["always"], ["system clear impossible", "system timeuse true"]);
data[0].addScript(["always"], ["variable 5 + 1", "infinity"]);
data[0].addScript(["timer 500", "random 55"], ["group 0 create + 3", "variable 5 = 0" , "infinity"]);
data[0].addScript(["timer 150", "variable 5 >= 500" ,"nothing enemy"], ["group 0 create + 3", "variable 5 = 0", "infinity"]);
data[0].addScript(["system time <= 30"], ["system clear possible", "group 0 create + 1"]);
data[0].setMap(6, 0, 4, false, true);
data[0].createRound("파란 행성 3, 높이: 280km ~ 270km", 180, 142, 500, musicName.music02);
data[0].addRoundEnemy([11,12,13,14], 16, 10);
data[0].addScript(["always"], ["system clear impossible", "system timeuse true"]);
data[0].addScript(["always"], ["variable 5 + 1", "infinity"]);
data[0].addScript(["timer 200", "random 35", "system time >= 30", "enemy current <= 11"], ["group 0 create + 3", "variable 5 = 0" , "infinity"]);
data[0].addScript(["timer 200", "random 40", "system time >= 30", "enemy current <= 11"], ["group 0 create + 3", "variable 5 = 0" , "infinity"]);
data[0].addScript(["timer 200", "random 55", "system time >= 30", "enemy current <= 11"], ["group 0 create + 4", "variable 5 = 0" , "infinity"]);
data[0].addScript(["timer 100", "random 47", "system time >= 30", "variable 5 >= 201" ,"enemy current <= 4"], ["group 0 create + 3", "variable 5 = 0", "infinity"]);
data[0].addScript(["timer 100", "random 53", "system time >= 30", "variable 5 >= 201" ,"enemy current <= 4"], ["group 0 create + 4", "variable 5 = 0", "infinity"]);
data[0].addScript(["system time <= 30"], ["system clear possible", "group 0 create + 4"]);
data[0].setMap(6, 0, 4, false, true);
data[0].createRound("파란 행성 4, 높이: 270km ~ 260km", 180, 144, 540, musicName.music02);
data[0].addRoundEnemy([11,12,13,14], 156, 17);
data[0].setMap(7, 4, 4, true, true);
data[0].createRound("파란 행성 5, 높이: 260km ~ 250km", 180, 144, 540, musicName.music02);
data[0].addRoundEnemy([11,12,13,14], 185, 28);
data[0].setMap(7, 4, 4, true, true);
//---------------------------------//
data[0].createRound("동그라미 마을 1, 마을 입구와 통로", 180, 150, 700, musicName.music03);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18], 32, 32);
data[0].addRoundEnemy([19,20,21,22,23,24,25,26], 32, 32);
data[0].setMap(9, 1, 0, false, false);
data[0].addScript(["variable 1 = 0","nothing enemy"], ["variable 1 = 1", "system clear impossible", "system timeuse true"]);
data[0].addScript(["variable 1 = 1", "variable 2 < 800"], ["variable 2 + 1", "infinity"]);
data[0].addScript(["variable 2 = 200"], ["variable 3 = 1", "map change 10"]);
data[0].addScript(["variable 2 = 350"], ["map speedx 2", "map loopx true"]);
data[0].addScript(["variable 2 >= 400"], ["group 0 create + 73", "group 1 create + 73", "system clear possible", "system timeuse default"]);
data[0].createRound("동그라미 마을 2, 동그라미 아파트 1, 2단지", 177, 155, 700, musicName.music03);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 210, 60);
data[0].setMap(11, 2, 0, true, false);
data[0].createRound("동그라미 마을 3, 동그라미 아파트 3, 4단지", 177, 155, 700, musicName.music03);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 227, 72);
data[0].setMap(12, 2, 0, true, false);
data[0].createRound("동그라미 마을 4, 동그라미 아파트 공원", 191, 158, 700, musicName.music03);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 0, 60);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 0, 40);
data[0].setMap(13, 2, 0, true, false);
data[0].addScript(["always"], ["system clear impossible", "system timeuse true"]);
data[0].addScript(["always"], ["variable 2 + 1", "infinity"]);
data[0].addScript(["variable 2 >= 350"], ["variable 2 = 0", "group 0 create + 160", "group 1 create + 100"]);
data[0].addScript(["variable 2 >= 600", "nothing enemy"], ["system clear possible"]);
data[0].createRound("동그라미 마을 5, 마을 회관 복도", 160, 171, 500, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 0, 20);
data[0].setMap(14, 2, 0, true, false);
data[0].addScript(["always"], ["system clear impossible", "system timeuse true"]);
data[0].addScript(["always"], ["variable 1 + 1", "infinity"]);
data[0].addScript(["variable 2 = 0", "variable 1 > 500"], ["variable 2 = 1", "variable 1 = 0", "group 0 create + 5", "map loopx false", "map speedx 2"]);
data[0].addScript(["variable 2 = 1", "variable 1 >= 200", "nothing enemy"], ["map change 32", "map speedx 2", "variable 2 = 2", "variable 1 = 0"]);
data[0].addScript(["variable 2 = 2", "variable 1 >= 200"], ["group 0 create + 52", "map loopx false", "variable 2 = 3"]);
data[0].addScript(["variable 2 = 3", "nothing enemy"], ["variable 2 = 4", "variable 1 = 0"]);
data[0].addScript(["variable 2 = 4", "variable 1 >= 200"], ["variable 2 = 5", "variable 1 = 0"]);
data[0].addScript(["variable 2 = 5", "variable 1 >= 10"], ["group 0 create + 56", "map loopx true", "variable 2 = 6"]);
data[0].addScript(["variable 2 = 6", "nothing enemy"], ["variable 2 = 7", "variable 1 = 0"]);
data[0].addScript(["variable 2 = 7", "variable 1 >= 100"], ["map change 15", "system timeuse false", "map loopx false", "map speedx 0"]);
data[0].addScript(["variable 2 = 7", "variable 1 >= 400"], ["system clear true"]);
data[0].createRound("동그라미 마을 6, 마을 회관 중앙", 160, 180, 500, musicName.none);
data[0].addRoundEnemy([28], 1, 1);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 0, 20);
data[0].setMap(15, 0, 0, true, false);
data[0].addScript(["nothing enemy"], ["system clear impossible", "system timeuse true"]);
data[0].addScript(["nothing enemy"], ["variable 2 + 1", "infinity"]);
data[0].addScript(["variable 1 = 0", "variable 2 >= 200"], ["variable 1 = 1", "variable 2 = 0", "map change 32"]);
data[0].addScript(["variable 1 = 1", "variable 2 >= 200"], ["map loopx true", "map speedx 2", "group 1 create + 40"]);
data[0].addScript(["variable 1 = 1", "variable 2 >= 300"], ["variable 1 = 2", "variable 2 = 0", "map loopx false", "map speedx 0", "map change 14"]);
data[0].addScript(["variable 1 = 2", "variable 2 >= 200"], ["variable 1 = 3", "group 1 create + 21", "variable 2 = 0", "map speedx 2", "map loopx true"]);
data[0].addScript(["variable 1 = 3", "variable 2 >= 200"], ["variable 1 = 4", "map change 33", "variable 2 = 0", "map speedx 0", "system timeuse false"]);
data[0].addScript(["variable 1 = 4", "variable 2 >= 100"], ["sound "+soundName.donggrami_maeul_viliage_hall_computer_sound+""]);
data[0].addScript(["variable 1 = 4", "variable 2 >= 400"], ["variable 1 = 5", "system clear true"]);
data[0].createRound("동그라미 마을 7, 수많은 동그라미", 190, 151, 500, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 150, 100);
data[0].addRoundEnemy([28], 1, 1);
data[0].setMap(33, 0, 0, true, false);
data[0].createRound("동그라미 마을 8, 상가 지역", 193, 186, 1350, musicName.music04);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 220, 44);
data[0].setMap(16, 2, 0, true, false);
data[0].createRound("동그라미 마을 9, 동그라미 아파트 5, 6단지", 177, 186, 1350, musicName.music04);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 195, 30);
data[0].setMap(17, 2, 0, true, false);
data[0].createRound("동그라미 마을 10, 건물지대 1", 140, 186, 1420, musicName.music04);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 25, 100);
data[0].setMap(18, 2, 0, true, false);
data[0].addScript(["always"], ["system clear impossible", "system timeuse true", "variable 1 = 1"]);
data[0].addScript(["nothing enemy"], ["variable 3 + 1", "infinity"]);
data[0].addScript(["timer 200", "variable 1 = 1"], ["enemy 100 movetype exit", "variable 1 = 0","infinity"]);
data[0].addScript(["timer 200", "variable 3 >= 200", "nothing enemy", "system time >= 21"], ["group 0 create + 25", "variable 3 = 0", "variable 1 = 1", "infinity"]);
data[0].addScript(["system time <= 20"], ["system clear possible"]);
data[0].createRound("동그라미 마을 11, 건물지대 2", 140, 186, 1420, musicName.music04);
data[0].addRoundEnemy([25, 22, 17, 13, 52, 57], 10, 100);
data[0].setMap(19, 2, 0, true, false);
data[0].addScript(["always"], ["system clear impossible", "system timeuse true", "variable 1 = 1"]);
data[0].addScript(["nothing enemy"], ["variable 3 + 1", "infinity"]);
data[0].addScript(["timer 100", "variable 1 = 1"], ["enemy 100 movetype exit", "variable 1 = 0","infinity"]);
data[0].addScript(["timer 100", "variable 3 >= 500", "nothing enemy", "system time >= 21"], ["group 0 create + 8", "variable 3 = 0", "variable 1 = 1", "infinity"]);
data[0].addScript(["system time <= 20"], ["system clear possible"]);
data[0].createRound("동그라미 마을 12, 조용한 도로", 178, 191, 1440, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 40, 6);
data[0].addRoundEnemy([52,53,54,55,56,57], 43, 11);
data[0].addRoundEnemy([28], 0, 1);
data[0].addScript(["nothing enemy"], ["group 2 create + 1"]);
data[0].setMap(20, 2, 0, true, false);
data[0].createRound("동그라미 마을 13, 동그라미마을의 끝지점, 다운 타워 입구", 120, 191, 1440, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 17, 17);
data[0].addRoundEnemy([52,53,54,55,56,57], 11, 11);
data[0].addRoundEnemy([34,35,36], 0, 2);
data[0].setMap(21, 2, 0, false, false);
data[0].addScript(["always"], ["system clear impossible"]);
data[0].addScript(["always"], ["variable 1 + 2", "infinity"]);
data[0].addScript(["variable 1 >= 2800", "nothing enemy"], ["group 2 create + 8"]);
data[0].addScript(["variable 1 >= 3000"], ["system clear possible"]);
//---------------------------------//
data[0].createRound("다운타워 1, 50km 지점", 280, 240, 2200, musicName.music05);
data[0].addRoundEnemy([34,35,36], 1, 11);
data[0].setMap(22, 1, 4, true, true);
data[0].addScript(["always"], ["system clear impossible"]); // 91마리(90+1)
data[0].addScript(["timer 100", "variable 1 <= 90"], ["variable 1 + 1", "group 0 create + 1", "infinity"]);
data[0].addScript(["variable 1 >= 90"], ["system clear possible"]);
data[0].createRound("다운타워 2, 45km 지점", 280, 244, 2270, musicName.music05);
data[0].addRoundEnemy([34, 35, 36], 1, 8);
data[0].addRoundEnemy([37, 38, 39], 1, 4);
data[0].setMap(22, 1, 4, true, true);
data[0].addScript(["always"], ["system clear impossible"]); // 92마리(90+2)
data[0].addScript(["timer 100", "variable 1 <= 50"], ["variable 1 + 1", "group 0 create + 1", "infinity"]);
data[0].addScript(["timer 100", "variable 2 <= 40"], ["variable 2 + 1", "group 1 create + 1", "infinity"]);
data[0].addScript(["variable 1 >= 50", "variable 2 >= 40"], ["system clear possible"]);
data[0].createRound("다운타워 3, 40km 지점", 280, 248, 2340, musicName.music05);
data[0].addRoundEnemy([34, 35, 36], 1, 4);
data[0].addRoundEnemy([37, 38, 39], 1, 4);
data[0].addRoundEnemy([40, 41, 42], 1, 4);
data[0].setMap(23, 1, 4, true, true);
data[0].addScript(["always"], ["system clear impossible"]); // 90마리(87+3)
data[0].addScript(["timer 150", "variable 1 <= 29"], ["variable 1 + 1", "group 0 create + 1", "group 1 create + 1", "group 2 create + 1", "infinity"]);
data[0].addScript(["variable 1 >= 30"], ["system clear possible"]);
data[0].createRound("다운타워 4, 35km 지점", 280, 252, 2420, musicName.music05);
data[0].addRoundEnemy([34, 35, 36], 1, 3);
data[0].addRoundEnemy([37, 38, 39], 0, 3);
data[0].addRoundEnemy([40, 41, 42], 0, 3);
data[0].addRoundEnemy([43, 44, 45], 1, 4);
data[0].addScript(["always"], ["system clear impossible"]); // 90마리(88+2)
data[0].addScript(["timer 200", "variable 1 <= 22"], ["variable 1 + 1", "group 0 create + 1", "group 1 create + 1", "group 2 create + 1", "group 3 create + 1", "infinity"]);
data[0].addScript(["variable 1 >= 23"], ["system clear possible"]);
data[0].setMap(23, 1, 4, true, true);
data[0].createRound("다운타워 5, 30km 지점", 280, 256, 2460, musicName.music05);
data[0].setMap(24, 1, 4, true, true);
data[0].addRoundEnemy([34, 35, 36], 1, 3);
data[0].addRoundEnemy([37, 38, 39], 1, 2);
data[0].addRoundEnemy([40, 41, 42], 0, 2);
data[0].addRoundEnemy([43, 44, 45], 0, 3);
data[0].addRoundEnemy([46, 47, 48, 49, 50, 51], 1, 6);
data[0].addScript(["always"], ["system clear impossible"]); // 108마리(60+48)
data[0].addScript(["timer 200", "variable 1 <= 15"], ["variable 1 + 1", "group 0 create + 1", "group 1 create + 1", "group 2 create + 1", "group 3 create + 1", "infinity"]);
data[0].addScript(["timer 200", "variable 2 <= 24"], ["variable 2 + 1", "group 4 create + 2", "infinity"]);
data[0].addScript(["variable 1 >= 15", "variable 2 >= 24"], ["system clear possible"]);
data[0].createRound("다운타워 6, 25km 지점", 280, 260, 2500, musicName.music05);
data[0].setMap(24, 1, 4, true, true);
data[0].addRoundEnemy([34, 35, 36], 1, 2);
data[0].addRoundEnemy([37, 38, 39], 1, 1);
data[0].addRoundEnemy([40, 41, 42], 0, 1);
data[0].addRoundEnemy([43, 44, 45], 0, 2);
data[0].addRoundEnemy([46, 47, 48, 49, 50, 51], 1, 16);
data[0].addScript(["always"], ["system clear impossible"]); // 112마리(40+72)
data[0].addScript(["timer 100", "variable 1 <= 10"], ["variable 1 + 1", "group 0 create + 1", "group 1 create + 1", "group 2 create + 1", "group 3 create + 1", "infinity"]);
data[0].addScript(["timer 150", "variable 2 <= 72"], ["variable 2 + 1", "group 4 create + 1", "infinity"]);
data[0].addScript(["variable 1 >= 10", "variable 2 >= 72"], ["system clear possible"]);
data[0].createRound("다운타워 7, 23km 지점, 안티 레이져 보스 처치", 380, 300, 4000, musicName.music05);
data[0].addRoundEnemy([34,35,36], 6, 6);
data[0].addRoundEnemy([37,38,39], 5, 5);
data[0].addRoundEnemy([58], 0, 1);
data[0].addRoundEnemy([59], 0, 1);
data[0].addRoundEnemy([60], 0, 1);
data[0].addRoundEnemy([61], 0, 1);
data[0].addRoundEnemy([62], 0, 1);
data[0].addRoundEnemy([63], 0, 1);
data[0].setMap(24, 1, 4, true, true);
data[0].addScript(["always"], ["system clear impossible"]);
data[0].addScript(["nothing enemy", "variable 1 = 0"], ["music stop", "variable 1 = 1"]);
data[0].addScript(["variable 1 = 1"], ["variable 2 + 1", "variable 9 + 1", "variable 3 + 1", "infinity"]);
//경고 이펙트 출력
data[0].addScript(["variable 1 = 1", "variable 2 >= 100", "variable 2 <= 400", "variable 3 >= 16"], 
    ["effect "+effectName.boss_warning+" 0 60", "effect "+effectName.boss_warning+" 160 60", "effect "+effectName.boss_warning+" 320 60", "effect "+effectName.boss_warning+" 480 60",
     "effect "+effectName.boss_warning+" 0 360", "effect "+effectName.boss_warning+" 160 360", "effect "+effectName.boss_warning+" 320 360", "effect "+effectName.boss_warning+" 480 360",
     "variable 3 = 0", "infinity"]);
data[0].addScript(["variable 9 >= 50", "variable 2 >= 100", "variable 2 <= 400"], ["variable 9 = 0", "sound "+soundName.boss_warning, "infinity"]);
//보스 출현
data[0].addScript(["nothing enemy", "variable 1 = 1", "variable 2 >= 600"], ["variable 4 = 1", "variable 1 = 2", "group 2 create + 1", "music play "+musicName.music07, "map change 25", "map speedy 1"]);
data[0].addScript(["nothing enemy", "variable 4 = 1"], ["variable 4 = 2", "group 3 create + 1"]);
data[0].addScript(["nothing enemy", "variable 4 = 2"], ["variable 4 = 3", "group 4 create + 1", "music change "+musicName.music11, "map speedy 0", "map speedx 0"]);
data[0].addScript(["nothing enemy", "variable 4 = 3"], ["variable 4 = 4", "group 5 create + 1"]);
data[0].addScript(["nothing enemy", "variable 4 = 4"], ["variable 4 = 5", "group 6 create + 1", "music change "+musicName.music12, "map speedx 40", "map speedy 20", "map change 34"]);
data[0].addScript(["nothing enemy", "variable 4 = 5"], ["variable 4 = 6", "group 7 create + 1", "map speedx 80", "map speedy 40"]);
data[0].addScript(["nothing enemy", "variable 4 = 6"], ["variable 4 = 7", "map speedx 0", "map speedy 0", "music stop", "map change 25"]);
data[0].addScript(["variable 4 = 7"], ["variable 5 + 1", "infinity"]);
data[0].addScript(["variable 4 = 7", "variable 5 >= 250"], ["sound "+soundName.antilaserboss_clear]);
data[0].addScript(["variable 4 = 7", "variable 5 >= 500"], ["system clear true"]);
data[0].createRound("다운 타워 코어 1, 코어 이동 통로 1", 160, 240, 1900, musicName.music13);
data[0].addRoundEnemy([64,65,66], 108, 20);
data[0].setMap(35, 2, 0, true, true);
data[0].createRound("다운 타워 코어 2, 코어 이동 통로 2", 160, 243, 1900, musicName.music13);
data[0].addRoundEnemy([64,65,66], 114, 21);
data[0].setMap(35, 2, 0, true, true);
data[0].createRound("다운 타워 코어 3, 내려가는 계단 1", 170, 248, 2370, musicName.music06);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].setMap(27, 22, 11, true, true);
data[0].createRound("다운 타워 코어 4, 내려가는 계단 2", 170, 251, 2370, musicName.music06);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].setMap(27, 22, 11, true, true);
data[0].createRound("다운 타워 코어 5, 알 수 없는 공간과 막다른길", 166, 266, 2660, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].setMap(28, 0, -3, true, true);
data[0].createRound("다운 타워 코어 6, 컴퓨터 공간의 비밀", 217, 266, 2660, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].setMap(28, 0, -3, true, true);
data[0].createRound("다운 타워 통로 1, 23km 지점 ", 217, 266, 2660, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].setMap(28, 0, -3, true, true);
data[0].createRound("다운 타워 통로 2, 17km 지점", 217, 266, 2660, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].setMap(28, 0, -3, true, true);
data[0].createRound("다운 타워 통로 3, 10km 지점", 217, 266, 2660, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].setMap(28, 0, -3, true, true);
data[0].createRound("다운 타워 통로 4, 3km 지점", 217, 266, 2660, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].setMap(28, 0, -3, true, true);
data[0].createRound("다운 타워 통로 5, 끊겨진 길, 바깥으로 나가는 통로", 217, 266, 2660, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].setMap(28, 0, -3, true, true);
data[0].createRound("다운 타워 바깥, 동그라미 마을로..., END OF PART 1", 217, 266, 2660, musicName.none);
data[0].addRoundEnemy([11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26], 224, 45);
data[0].setMap(28, 0, -3, true, true);
//---------------------------------//
data[0].createRound("Test", 100, 100, 100, musicName.none);
data[0].addRoundEnemy([62], 1, 1);
data[0].setMap(28, 0, 0, true, true);
//---------------------------------// part 1의 적
data[0].createEnemy(0, "약한 빨간색 빛", 18000, 2, 0, 1); // 0
data[0].createEnemy(1, "약한 주황색 빛", 18000, 2, 0, 2); // 1
data[0].createEnemy(2, "약한 초록색 빛", 18000, 2, 0, 3);
data[0].createEnemy(3, "약한 파란색 빛", 18000, 2, 0, 4);
data[0].createEnemy(4, "약한 노란색 빛", 18000, 2, 0, 5);
for(var a = 0; a <= 4; a++)  data[0].setEnemy(a, 10, 10, "", "", soundName.light_break, "");
//------------------//
data[0].createEnemy(5, "하얀색 운석", 43000, 131, 244, 6);
data[0].createEnemy(6, "갈색 운석",   44000, 137, 250, 7);
data[0].createEnemy(7, "회색 운석",   45000, 140, 255, 8);
data[0].createEnemy(8, "분홍색 운석", 46000, 135, 240, 9);
data[0].createEnemy(9, "하늘색 운석", 47000, 129, 253, 10);
data[0].createEnemy(10, "대형 운석",  48000, 136, 844, 11);
for(var a = 5; a <= 10; a++)  data[0].setEnemy(a, 7, 7, "random", "", soundName.meteorite_break, "");
//------------------//
data[0].createEnemy(11, "파랑색 동그라미", 75000, 232, 109, 12);
data[0].createEnemy(12, "검파랑 동그라미", 75440, 242, 111, 13);
data[0].createEnemy(13, "하늘색 동그라미", 76180, 251, 113, 14);
data[0].createEnemy(14, "검하늘 동그라미", 76655, 260, 115, 15);
for(var a = 11; a <= 14; a++)  data[0].setEnemy(a, 5, 5, "random", "", soundName.dongrami_fail, "");
//------------------//
data[0].createEnemy(15, "초록색 동그라미", 77000, 270, 120, 16);
data[0].createEnemy(16, "검초록 동그라미", 77232, 274, 122, 17);
data[0].createEnemy(17, "연두색 동그라미", 77966, 278, 123, 18);
data[0].createEnemy(18, "검연두 동그라미", 78410, 282, 124, 19);
for(var a = 15; a <= 18; a++)  data[0].setEnemy(a, 4, 4, "random", "", soundName.dongrami_fail, "");
//------------------//
data[0].createEnemy(19, "노랑색 동그라미", 79000, 286, 125, 20);
data[0].createEnemy(20, "검노랑 동그라미", 79230, 290, 128, 21);
data[0].createEnemy(21, "주황색 동그라미", 79550, 294, 129, 22);
data[0].createEnemy(22, "검주황 동그라미", 80110, 298, 131, 23);
for(var a = 19; a <= 22; a++)  data[0].setEnemy(a, 4, 4, "random", "", soundName.dongrami_fail, "");
//------------------//
data[0].createEnemy(23, "빨강색 동그라미", 81150, 300, 132, 24);
data[0].createEnemy(24, "검빨강 동그라미", 81420, 303, 134, 25);
data[0].createEnemy(25, "분홍색 동그라미", 81770, 306, 136, 26);
data[0].createEnemy(26, "검분홍 동그라미", 82000, 309, 138, 27);
data[0].createEnemy(27, "???", 444444, 0, 1555, 27);  data[0].setEnemy(27, 2, 2, "noexit", soundName.dongrami_fail, "");
for(var a = 23; a <= 26; a++)  data[0].setEnemy(a, 4, 4, "", "", soundName.dongrami_fail, "");
//------------------//
data[0].createEnemy(28, "대형 동그라미", 1273500, 4000, 2500, 34);      data[0].setEnemy(28, 5, 5, "", "noexit", soundName.dongrami_fail, "");
data[0].createEnemy(29, "무인기 탐사선", 1024250, 2469, 1732, 54);      data[0].setEnemy(29, 0, 2, "updown", "noexit", soundName.wall_break, "");  data[0].setAttack(29, 1092, 40, enemyAttackName.shot);
data[0].createEnemy(30, "무인기 탐사선 금색", 3224250, 3469, 3087, 55);   data[0].setEnemy(30, 0, 1, "updown", "noexit", soundName.wall_break, "");  data[0].setAttack(30, 1130, 15, enemyAttackName.shot);
//------------------//
data[0].createEnemy(31, "공포의운석1", 92700, 855, 100, 56);
data[0].createEnemy(32, "공포의운석2", 96500, 897, 100, 57);
data[0].createEnemy(33, "공포의운석3", 98200, 846, 100, 58);
for(var a = 31; a <= 33; a++)  data[0].setEnemy(a, 5, 5, "", "", soundName.meteorite_break, "");
//------------------//
data[0].createEnemy(34, "레이져발사장치A", 281200, 1929, 266, 35);
data[0].createEnemy(35, "레이져발사장치B", 283300, 2027, 273, 36);
data[0].createEnemy(36, "레이져발사장치C", 285600, 2027, 281, 37);
data[0].createEnemy(37, "레이져중형장치A", 290700, 2137, 295, 38);
data[0].createEnemy(38, "레이져중형장치B", 293700, 2177, 305, 39);
data[0].createEnemy(39, "레이져중형장치C", 295700, 2221, 311, 40);
data[0].createEnemy(40, "레이져연사장치A", 268700, 1897, 283, 41);
data[0].createEnemy(41, "레이져연사장치B", 262700, 1933, 302, 42);
data[0].createEnemy(42, "레이져연사장치C", 266700, 1956, 326, 43);
data[0].createEnemy(43, "레이져대형장치A", 310700, 3050, 330, 44);
data[0].createEnemy(44, "레이져대형장치B", 313700, 3175, 356, 45);
data[0].createEnemy(45, "레이져대형장치C", 315700, 3300, 373, 46);
for(var a = 34; a <= 39; a++)  data[0].setEnemy(a, 0, 2, "updown", "noexit", soundName.enemy_laser_die, "");
for(var a = 40; a <= 42; a++)  data[0].setEnemy(a, 0, 5, "updown", "noexit", soundName.enemy_laser_die, "");
for(var a = 43; a <= 45; a++)  data[0].setEnemy(a, 0, 2, "updown", "noexit", soundName.enemy_laser_die, "");
for(var i = 34; i <= 36; i++)  data[0].setAttack(i, 1000, 75, enemyAttackName.laser1);
for(var i = 37; i <= 39; i++)  data[0].setAttack(i, 1350, 84, enemyAttackName.laser2);
for(var i = 40; i <= 42; i++)  data[0].setAttack(i,  782, 41, enemyAttackName.laser3);
for(var i = 43; i <= 45; i++)  data[0].setAttack(i, 3299, 297,enemyAttackName.laser4);
//------------------//
data[0].createEnemy(46, "노랑색막대기", 149200, 1095, 114, 47);
data[0].createEnemy(47, "주황색막대기", 151000, 1107, 115, 48);
data[0].createEnemy(48, "빨강색막대기", 153500, 1113, 116, 49);
data[0].createEnemy(49, "파랑색막대기", 154200, 1119, 117, 50);
data[0].createEnemy(50, "보라색막대기", 154700, 1135, 118, 51);
data[0].createEnemy(51, "연회색막대기", 156000, 1144, 119, 52);
for(var i = 46; i <= 51; i++)  data[0].setEnemy(i, 0, 2, "", "up_xrandom", soundName.enemy_laser_die, "");
//------------------//
data[0].createEnemy(52, "하얀색 동그라미", 104700, 511, 192, 28);
data[0].createEnemy(53, "회색의 동그라미", 105600, 514, 193, 29);
data[0].createEnemy(54, "검은색 동그라미", 106800, 517, 194, 30);
data[0].createEnemy(55, "분파색 동그라미", 110200, 544, 211, 31);
data[0].createEnemy(56, "보초색 동그라미", 111400, 548, 212, 32);
data[0].createEnemy(57, "노갈색 동그라미", 112600, 552, 213, 33);
for(var i = 52; i <= 57; i++)  data[0].setEnemy(i, 4, 4, "random", "", soundName.dongrami_fail, "");
//------------------//
data[0].createEnemy(58, "안티레이져보스1", 3270000, 10000, 1100, 53);  data[0].setEnemy(58, 0, 1, "", "noexit", soundName.enemy_laser_die, "");  data[0].setAttack(58, 3200, 40, enemyAttackName.antilaserboss_part1);
data[0].createEnemy(59, "안티레이져보스2", 3270000, 10000, 1100, 53);  data[0].setEnemy(59, 0, 1, "", "noexit", soundName.enemy_laser_die, "");  data[0].setAttack(59, 3200, 40, enemyAttackName.antilaserboss_part2);
data[0].createEnemy(60, "안티레이져보스3", 3270000, 10000, 1100, 60);  data[0].setEnemy(60, 0, 2, "", "noexit", soundName.enemy_laser_die, "");  data[0].setAttack(60, 2400, 50, enemyAttackName.antilaserboss_part3);
data[0].createEnemy(61, "안티레이져보스4", 3270000, 10000, 1100, 60);  data[0].setEnemy(61, 0, 2, "", "noexit", soundName.enemy_laser_die, "");  data[0].setAttack(61, 2400, 32, enemyAttackName.antilaserboss_part4);
data[0].createEnemy(62, "안티레이져보스5", 1770000, 10000, 1100, 61);  data[0].setEnemy(62, 0, 4, "", "noexit", soundName.enemy_laser_die, "");  data[0].setAttack(62, 900 , 14, enemyAttackName.antilaserboss_part5);
data[0].createEnemy(63, "안티레이져보스6", 1270000, 10000, 1100, 61);  data[0].setEnemy(63, 0, 12,"", "noexit", soundName.antilaserboss_die, "");data[0].setAttack(63, 300 , 14, enemyAttackName.antilaserboss_part6);
//------------------//
data[0].createEnemy(64, "앞전공격대포", 113200, 2500, 100, 62);
data[0].createEnemy(65, "하전공격대포", 113200, 2500, 100, 63);
data[0].createEnemy(66, "폭발공격대포", 116846, 2172, 100, 64);
data[0].createEnemy(67, "노란색쉴드막대기", 102402, 2132, 414, 65);
data[0].createEnemy(68, "파란색쉴드막대기", 107317, 2166, 433, 66);
data[0].createEnemy(69, "보라색R박스", 174000, 4500, 0, 67);
data[0].createEnemy(70, "주황색R박스", 177000, 4750, 0, 68);
data[0].createEnemy(71, "초록색R박스", 180000, 5000, 0, 69);
//------------------//
for(var i = 64; i <= 71; i++)  data[0].setEnemy(i, 4, 4, "random", "", soundName.enemy_laser_die, "");

this.getDungeonCount = function(){  return dungeonCount; };
this.getDungeonName = function(index){  return data[index].name; };
this.getRoundCount = function(D){  return data[D].getRoundCount(); };
this.getRoundName = function(D, R){  return data[D].round[R].name; };

this.getRound = function(D, R){  return data[D].round[R]; };
this.getEnemy = function(D){  return data[D].enemy; };
};//function Dungeon end
optionbattle.dungeon = new Dungeon(); //던전 생성
