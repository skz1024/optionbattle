function Enemy(){
//function start
var createCount = -1; // Enemy 객체 내에서 create로 적을 생성한 개수, -1은 적을 하나도 생성하지 않았다는 의미
function create(strName, attack, defense, hp, constDiesound, strDiemotion){
	createCount++;
	this.name = strName;
	this.number = createCount;
	this.attack = attack;
	this.defense = defense;
	this.hp = hp;
	this.score = (hp / 1000) + (attack / 50) + (defense / 20) |0;
	this.diesound = constDiesound;
	this.diemotion = strDiemotion || "out";
	
	this.image = new Image();
	this.image.src = "";
	
	this.speedx = 5; 
	this.speedy = 5;
	this.technical = "";
	this.skill = "";
}
create.prototype.display = function(x, y, width, height)
{
	if( width == null || height == null )
        ctx.drawImage(this.image, x, y);
    else
        ctx.drawImage(this.image, x, y, width, height);
};
create.prototype.advanced = function(speedx, speedy, moveType, technical, skill){
	this.speedx = speedx;
	this.speedy = speedy;
	this.moveType = moveType || "";
	this.technical = technical || "";
	this.skill = skill || "";
};

var data = new Array();
/*
data[0] = new create("unused", 0, 0, 0, 0, 0, soundName.select_none, "");
data[0].image.src = "image/system/unused.png";
//-------------------------------------//  우주 이동 경로, 파란행성
data[1] = new create("약한 빨간색 빛", 20, 0, 25000, soundName.light_break, "out");  
data[2] = new create("약한 주황색 빛", 20, 0, 25000, soundName.light_break, "out");  
data[3] = new create("약한 초록색 빛", 20, 0, 25000, soundName.light_break, "out");  
data[4] = new create("약한 파란색 빛", 20, 0, 25000, soundName.light_break, "out");  
data[5] = new create("약한 노란색 빛", 20, 0, 25000, soundName.light_break, "out");
for(var a = 1; a <= 5; a++)  data[a].advanced(12, 12);
data[6]  = new create("하얀 운석", 35, 30, 26000, soundName.light_break, "out");  
data[7]  = new create("회색 운석", 37, 35, 27000, soundName.light_break, "out");  
data[8]  = new create("갈색 운석", 39, 40, 28000, soundName.light_break, "out");  
data[9]  = new create("핑크 운석", 41, 40, 29000, soundName.light_break, "out");  
data[10] = new create("청록 운석", 43, 40, 31000, soundName.light_break, "out");  
data[11] = new create("대형 운석", 598,120,923000,soundName.light_break, "out");  
//-------------------------------// 파란행성, 동그라미 마을
data[12] = new create("평범한 파란색 동그라미", 50, 60, 41024, soundName.dongrami_fail);
data[13] = new create("어두운 파란색 동그라미", 52, 62, 41173, soundName.dongrami_fail);
data[14] = new create("평범한 하늘색 동그라미", 53, 64, 42462, soundName.dongrami_fail);
data[15] = new create("어두운 하늘색 동그라미", 53, 65, 43208, soundName.dongrami_fail);
data[16] = new create("평범한 초록색 동그라미", 55, 69, 43754, soundName.dongrami_fail);
data[17] = new create("어두운 초록색 동그라미", 57, 70, 44199, soundName.dongrami_fail);
data[18] = new create("평범한 연두색 동그라미", 58, 73, 44562, soundName.dongrami_fail);
data[19] = new create("어두운 연두색 동그라미", 60, 74, 45000, soundName.dongrami_fail);
//-------------------------------//
data[20] = new create("평범한 노란색 동그라미", 70, 76, 46535, soundName.dongrami_fail);
data[21] = new create("어두운 노란색 동그라미", 77, 77, 47169, soundName.dongrami_fail);
data[22] = new create("평범한 주황색 동그라미", 83, 80, 47700, soundName.dongrami_fail);
data[23] = new create("어두운 주황색 동그라미", 88, 82, 48080, soundName.dongrami_fail);
data[24] = new create("평범한 분홍색 동그라미", 82, 85, 48430, soundName.dongrami_fail);
data[25] = new create("어두운 분홍색 동그라미", 77, 86, 48830, soundName.dongrami_fail);
data[26] = new create("평범한 주황색 동그라미", 74, 89, 49550, soundName.dongrami_fail);
data[27] = new create("어두운 주황색 동그라미", 76, 90, 50157, soundName.dongrami_fail);
//-------------------------------//
data[28] = new create("하얀색 동그라미", 80,  110, 51000, soundName.dongrami_fail);
data[29] = new create("회색 동그라미  ", 80,  115, 52430, soundName.dongrami_fail);
data[30] = new create("검은색 동그라미", 80,  120, 53470, soundName.dongrami_fail);
data[31] = new create("분파색 동그라미", 105, 130, 54030, soundName.dongrami_fail);
data[32] = new create("보초색 동그라미", 105, 135, 55257, soundName.dongrami_fail);
data[33] = new create("노갈색 동그라미", 105, 140, 56000, soundName.dongrami_fail);
//-------------------------------//
data[34] = new create("대형 동그라미", 1492, 804, 1071000, soundName.dongrami_fail);
data[34].advanced(5, 5);
//-------------------------------// 다운 타워
data[35] = new create("레이져 발사장치 A", 240, 210, 270000, soundName.meteorite_break);
data[36] = new create("레이져 발사장치 B", 255, 218, 273000, soundName.meteorite_break);
data[37] = new create("레이져 발사장치 C", 270, 225, 276000, soundName.meteorite_break);
data[38] = new create("강력레이져 XL-A", 1360, 140, 280000, soundName.meteorite_break);
data[39] = new create("강력레이져 XL-B", 1400, 147, 284500, soundName.meteorite_break);
data[40] = new create("강력레이져 XL-C", 1440, 154, 289000, soundName.meteorite_break);
//-------------------------------//
data[41] = new create("연사레이져 COLOR", 89, 265, 265300, soundName.meteorite_break);
data[42] = new create("연사레이져 RED",   94, 275, 277300, soundName.meteorite_break);
data[43] = new create("연사레이져 GREY",  99, 285, 284300, soundName.meteorite_break);
data[44] = new create("중형레이져 G", 773, 0, 325500, soundName.meteorite_break);
data[45] = new create("중형레이져 A", 792, 0, 331000, soundName.meteorite_break);
data[46] = new create("중형레이져 B", 814, 0, 335500, soundName.meteorite_break);
for(var a = 35; a <= 46; a++)  data[a].advanced(0, 5, "fixed");
//-------------------------------//
data[47] = new create("노랑색 레이져 막대기", 305, 400, 211400, soundName.laserA);
data[48] = new create("주황색 레이져 막대기", 323, 405, 213300, soundName.laserA);
data[49] = new create("빨강색 레이져 막대기", 339, 411, 215800, soundName.laserA);
data[50] = new create("파랑색 레이져 막대기", 352, 416, 217900, soundName.laserA);
data[51] = new create("보라색 레이져 막대기", 367, 423, 220200, soundName.laserA);
data[52] = new create("검정색 레이져 막대기", 380, 428, 222600, soundName.laserA);
//for(var a = 47; a <= 52; a++)  data[a].advanced(1, 1, "fixed");
//-------------------------------//
data[53] = new create("알티레이", 400, 150, 4510240, soundName.laserA);
data[53].advanced(0, 5, "fixed");

//-------------------------------//
for(var a = 1; a <= createCount; a++)  data[a].image.src = "image/enemy/enemy"+"["+a+"]"+".png";
*/

this.getname = function(code){  return data[code].name; };
this.getnumber = function(code){  return data[code].number; };
this.getattack = function(code){  return data[code].attack; };
this.getdefense = function(code){  return data[code].defense; };
this.gethp = function(code){  return data[code].hp; };
this.getscore = function(code){  return data[code].score; };
this.gettechnical = function(code){  return data[code].technical; };
this.getskill = function(code){  return data[code].skill; };
this.getdiesound = function(code){  return data[code].diesound; };
this.getdiemotion = function(code){  return data[code].diemotion; };
this.getspeedx = function(code){  return data[code].speedx; };
this.getspeedy = function(code){  return data[code].speedy; };
this.display = function(code, x, y, width, height){  data[code].display(x, y, width, height); };
this.getimage = function(code){  return data[code].image; };
this.getcount = function(){  return createCount; };
//-------------------------//
}//function Enemy end

optionbattle.enemy = new Enemy();




