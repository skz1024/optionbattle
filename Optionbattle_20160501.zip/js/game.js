//키를 입력받는 함수와 변수 처리
onkeydown = game_keyinput;
var keyboard = { enter:13, z:90, x:88, up:38, down:40, left:37, right:39, a:65, s:83 };
var inputkey = 0;
function game_keyinput(event){
    inputkey = event.keyCode;
    
    //event.returnValue = false;
    // F5키를 제외한 나머지 키는 브라우저에서 해당 키를 눌럿을때 브라우저 기능이 동작하지 않게 함.
    if(inputkey != 116) event.preventDefault();
    inputpush[inputkey] = true;
}
var inputpush = new Array();
onkeyup = game_keyup;
function game_keyup(event){
	var keyup = event.keyCode;
	
	//event.returnValue = false;
    if(keyup != 116) event.preventDefault();
    if(keyup == keyboard.z) keyup = keyboard.enter; // ENTER key == Z
    else if(keyup == keyboard.x) keyup = keyboard.esc; // ESC key == X
    
    inputpush[keyup] = false;
}

//-------------------------------//
//start function Game
function Game(){ // 게임 함수...
//게임 모드 관련 설정
var mode = 0;
var modeName = { TITLE:0, OPTION:1, MENU:2, DUNGEON:3, ROUND:4, INVENTORY:5, UNITINFO:6, PARTY:7, FIELD:8 };

// 외부에서 사용하기 위한 함수들
this.soundStatusChange = function(){  soundStatusChange(); };
this.musicStatusChange = function(){  musicStatusChange(); };
this.getDungeonSelect = function(){  return dungeon.select; };
this.getRoundSelect = function(){  return round.select; };
this.modeChangeToMenu = function(){  mode = modeName.MENU; };

var backgroundImage = {};
backgroundImage.title = new Image();  backgroundImage.title.src = "image/background/title.png";
backgroundImage.optionbattle = new Image();  backgroundImage.optionbattle.src = "image/background/optionbattle.png";
backgroundImage.option = new Image();  backgroundImage.option.src = "image/background/option.png";
backgroundImage.main = new Image();  backgroundImage.main.src = "image/background/main.png";
backgroundImage.menu = new Image();  backgroundImage.menu.src = "image/background/menu.png";
backgroundImage.party = new Image();  backgroundImage.party.src = "image/background/party.png";
backgroundImage.inventory = new Image();  backgroundImage.inventory.src = "image/background/inventory.png";
backgroundImage.dungeonselect = new Image();  backgroundImage.dungeonselect.src = "image/background/dungeonselect.png";
backgroundImage.roundselect = new Image();  backgroundImage.roundselect.src = "image/background/roundselect.png";
backgroundImage.unitinfo = new Image();  backgroundImage.unitinfo.src = "image/background/unitinfo.png";


var title = {};
title.select = 0;
title.arrow = new Image();  title.arrow.src = "image/system/arrow.png";
title.process = function(){
	if(inputkey == keyboard.up && title.select > 0){  title.select--;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.down && title.select < 3){  title.select++;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.enter || inputkey == keyboard.z){
        optionbattle.sound.play(soundName.select_enter);
        switch(title.select){
            case 0: mode = modeName.MENU; break;
            case 1: mode = modeName.OPTION; break;
            case 2:
            case 3:
    }	}
};
title.display = function(){
	ctx.drawImage(backgroundImage.title, 0, 0);
	ctx.drawImage(backgroundImage.optionbattle, 0, 0);
	ctx.drawImage(title.arrow, 320, title.select*30 + 210);
};


var option = {}; // 옵션에 있는 정보중 일부는 저장할때 필요함.
// 저장되는 정보는 사운드 ON/OFF, 음악 ON/OFF, resultTime
option.soundOn = true;  option.musicOn = true;  
option.soundTest = 0;   option.musicTest = 0;
option.resultTime = 6;  option.select = 0;
option.on = new Image();   option.on.src = "image/system/on.png";
option.off = new Image();  option.off.src = "image/system/off.png";
option.musicmeter = new Image();  option.musicmeter.src = "image/system/musicmeter.png";
option.meter = [0,0,0,0,0,0,0,0,0,0];
option.count = 0;
option.process = function(){
	if(inputkey == keyboard.up && option.select > 0){
		option.select--;  optionbattle.sound.play(soundName.select_move);
	} else if(inputkey == keyboard.down && option.select < 5){
		option.select++;  optionbattle.sound.play(soundName.select_move);
	} else if(inputkey == keyboard.left){
		switch(option.select){
		case 0: soundStatusChange(); break;
		case 1: musicStatusChange(); break;
		case 2: if(option.soundTest > 0)  option.soundTest--; break;
		case 3: if(option.musicTest > 0)  option.musicTest--; break;
		case 4: if(option.resultTime > 2)  option.resultTime--; break;
		case 5: break;
		}
	} else if(inputkey == keyboard.right){
		switch(option.select){
		case 0: soundStatusChange(); break;
		case 1: musicStatusChange(); break;
		case 2: if(option.soundTest < optionbattle.sound.getCount())  option.soundTest++; break;
		case 3: if(option.musicTest < optionbattle.music.getCount())  option.musicTest++; break;
		case 4: if(option.resultTime < 10)  option.resultTime++; break;
		case 5: break;
		}
	} else if(inputkey == keyboard.enter){
		switch(option.select){
		case 0: soundStatusChange(); break;
		case 1: musicStatusChange(); break;
		case 2: optionbattle.sound.play(option.soundTest); break;
		case 3: optionbattle.music.play(option.musicTest); break;
		case 4: break;
		case 5: optionbattle.music.stop(); option.select = 0;
		    optionbattle.sound.play(soundName.select_back); mode = modeName.TITLE; break;
		}
	} else if(inputkey == keyboard.x){
	    optionbattle.music.stop();
	} else if(inputkey == keyboard.a){
	    optionbattle.music.minus5();
	} else if(inputkey == keyboard.s){
	    optionbattle.music.plus5();
	} else if(inputkey == keyboard.z){
	    switch(option.select){
        case 0: soundStatusChange(); break;
        case 1: musicStatusChange(); break;
        case 2: optionbattle.sound.play(option.soundTest); break;
        case 3: optionbattle.music.continueMusic(); break;
        case 4: break;
        case 5: optionbattle.music.stop(); option.select = 0;
            optionbattle.sound.play(soundName.select_back); mode = modeName.TITLE; break;
        }
	}
};
option.display = function(){ // 옵션화면을 출력하는 함수
    ctx.drawImage(backgroundImage.title, 0, 0);
    ctx.drawImage(backgroundImage.option, 0, 0);
    var align = 90;
    var alignLastX = 570;
    ctx.drawImage(title.arrow, 250, option.select*30 + align);
    
    if(option.soundOn == true)  ctx.drawImage(option.on, alignLastX, align);
    else  ctx.drawImage(option.off, alignLastX, align);
    
    if(option.musicOn == true)  ctx.drawImage(option.on, alignLastX, align+30);
    else  ctx.drawImage(option.off, alignLastX, align+30);
    
    numberDisplay(option.soundTest, alignLastX+40, align+60+4, true);
    numberDisplay(option.musicTest, alignLastX+40, align+90+4, true);
    numberDisplay(option.resultTime, alignLastX+40, align+120+4, true);
    numberDisplay(optionbattle.music.time(), 450, 440, true);
    numberDisplay(optionbattle.music.duration(), 490, 440);
    
    
    // 뮤직미터 그리기
    for(var i = 0; i < option.meter.length; i++){
    	ctx.drawImage(option.musicmeter, option.meter[i]*30, 0, 30, 120, 30*i, 360, 30, 120);
    }
    
    option.count++;
    if(option.count >= 0 && optionbattle.music.getmusicStopCheck() == false){
    	option.count = 0;
    	for(var a = 0; a < option.meter.length; a++){
        	var z = (Math.random() * 6) - 3 | 0;
    		if(option.meter[a] + z <= 12 && option.meter[a] + z >= 0)  option.meter[a] += z;
        }
    } else if(option.count >= 2 && optionbattle.music.getmusicStopCheck() == true){
    	option.count = 0;
    	for(var a = 0; a < option.meter.length; a++){
        	if(option.meter[a] > 0)  option.meter[a]--;
        }
    }
};
option.saveData = function(){
    
};
option.loadData = function(){
    
};

this.getsoundOn = function(){  return option.soundOn; };
this.getmusicOn = function(){  return option.musicOn; };
function soundStatusChange(){
    if(option.soundOn == true)  option.soundOn = false;
    else  option.soundOn = true;
}
function musicStatusChange(){
    if(option.musicOn == true)  option.musicOn = false;
    else  option.musicOn = true;
}

var main = {};
main.select = 0;
main.exp_meter = new Image();  main.exp_meter.src = "image/system/user_exp.png";
main.arrow = new Image();  main.arrow.src = "image/system/arrow2.png";
main.process = function(){
    if( inputkey == keyboard.up && main.select != 0){  main.select--;  optionbattle.sound.play(soundName.select_move); }
    else if( inputkey == keyboard.down && main.select != 7){  main.select++;  optionbattle.sound.play(soundName.select_move); }
    else if( inputkey == keyboard.enter || inputkey == keyboard.z ){
        optionbattle.sound.play(soundName.select_menu);
        switch(main.select){
            case 0: mode = modeName.DUNGEON; break; // 던전
            case 1: mode = modeName.PARTY; break; // 파티
            case 2: mode = modeName.INVENTORY; break; // 인벤토리
            case 3: break; // 조합
            case 4: break;
            case 5: break; // 마을
            case 6: break; // 캐시 상점
            case 7: mode = modeName.TITLE;  main.select = 0; break;
        }
    }
};
main.display = function(){
    var expTable = optionbattle.user.getexpTable();
    var exp_percent = optionbattle.user.getexp() / expTable[optionbattle.user.getlv()];
    var align = 30;
    var alignY = 90;
    
    ctx.drawImage(backgroundImage.main,0,0); // 메인 이미지 출력
    ctx.drawImage(backgroundImage.menu,0,0); // 메인 메뉴 출력
    if(exp_percent > 0)  ctx.drawImage(main.exp_meter, 0, 0, (exp_percent*300), 25, 2, 29, (exp_percent*635), 9); // 경험치 미터 출력 
    ctx.drawImage(main.arrow, 300, alignY + (main.select*align) ); // 화살표 출력
    
    var expTable = optionbattle.user.getexpTable();
    var userLv = optionbattle.user.getlv();
    
    numberDisplay(optionbattle.user.getlv(), 40, 5);
    numberDisplay(optionbattle.user.getexp(), 380, 5, true);
    numberDisplay(expTable[userLv], 410, 5);
    numberDisplay(optionbattle.user.getgold(), 200, alignY+4, true);
    numberDisplay(optionbattle.user.getfuel(), 180, alignY+align+4, true);
    numberDisplay(optionbattle.user.getcrystal(), 180, alignY+64, true);
};


var dungeon = {};
dungeon.select = 0;
dungeon.selectImage = new Image();  dungeon.selectImage.src = "image/system/select2.png";
dungeon.process = function(){
    if(inputkey == keyboard.x){  optionbattle.sound.play(soundName.select_back);  mode = modeName.MENU; }
    else if(inputkey == keyboard.up && dungeon.select > -1){  dungeon.select--;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.down && dungeon.select < optionbattle.dungeon.getDungeonCount()){  dungeon.select++;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.enter || inputkey == keyboard.z ){
        if(dungeon.select == -1){  mode = modeName.MENU;  optionbattle.sound.play(soundName.select_back);  }
        else{  mode = modeName.ROUND; optionbattle.sound.play(soundName.select_menu);  }
    }
};
dungeon.display = function(){
    ctx.drawImage(backgroundImage.main, 0, 0);
    ctx.drawImage(backgroundImage.dungeonselect, 0, 0);
    ctx.drawImage(dungeon.selectImage, 0, 90+(30*dungeon.select));
    ctx.font = "18px Batang";
    ctx.fillStyle = "black";
    
    var textAlign = 80;
    ctx.fillText("뒤로가기", 40, 80);
    for(var a = 0; a <= optionbattle.dungeon.getDungeonCount(); a++){
        numberDisplay(a, 10, 90+(a*30)+5);
        ctx.fillText(optionbattle.dungeon.getDungeonName(a), 40, textAlign+30+(a*30));
    }
};



var round = {};
round.select = 0;
round.process = function(){
    var roundMax = optionbattle.dungeon.getRoundCount(dungeon.select);
    if(inputkey == keyboard.x){  mode = modeName.DUNGEON;  optionbattle.sound.play(soundName.select_back); }
    else if(inputkey == keyboard.up && round.select > -1){  round.select--;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.down && round.select < roundMax){  round.select++;  optionbattle.sound.play(soundName.select_move); }
    else if(inputkey == keyboard.enter || inputkey == keyboard.z ){
        if(round.select == -1){  mode = modeName.DUNGEON;  optionbattle.sound.play(soundName.select_back); }
        else{  mode = modeName.FIELD;  optionbattle.field.init();  optionbattle.sound.play(soundName.select_enter); }
    }
};

round.display = function(){
    ctx.font = "18px Batang";
    ctx.fillStyle = "black";
    ctx.drawImage(backgroundImage.main, 0, 0);
    ctx.drawImage(backgroundImage.roundselect, 0, 0);
    if(round.select <= 9){  ctx.fillText("뒤로가기(back)", 140, 80);  }
    else  ctx.fillText("△△△△△△△△", 140, 80);
    
    var textAlign = 80;
    
    ctx.drawImage(dungeon.selectImage, 0, 90+(30*(round.select%10) ) );
    var start = (round.select/10 | 0) * 10;
    var end = optionbattle.dungeon.getRoundCount(dungeon.select);
    for(var a = start, b = 0; b < 10 && a <= end; a++, b++){
        numberDisplay(a, 45, 90+(b*30)+5, true);
        var roundName = optionbattle.dungeon.getRoundName(dungeon.select, a);
        ctx.fillText(roundName, 140, textAlign+(b*30)+30);
    }
    if(end >= start+10){
        ctx.fillText("▽▽▽▽▽▽▽▽", 150, 406);
    }
};



var inventory = {};
inventory.select = 0;
inventory.selectImage = new Image();  inventory.selectImage.src = "image/system/select.png";

inventory.process = function(){
    var page = (inventory.select / 60) | 0;
    var selectX = (inventory.select % 10);
    var selectY = (inventory.select / 10) - (page * 6) | 0;
    var I = optionbattle.user.getInventory();
    
    
    if(inputkey == keyboard.up && selectY > 0){
        inventory.select -= 10;  optionbattle.sound.play(soundName.select_move);
    } else if(inputkey == keyboard.down && selectY < 5){
        inventory.select += 10;  optionbattle.sound.play(soundName.select_move);
    } else if(inputkey == keyboard.left && selectX > 0){
        inventory.select--;  optionbattle.sound.play(soundName.select_move);
    } else if(inputkey == keyboard.right && selectX < 9){
        inventory.select++;  optionbattle.sound.play(soundName.select_move);
    } else if(inputkey == keyboard.x) {
        mode = modeName.MENU;  optionbattle.sound.play(soundName.select_back);
    } else if(inputkey == keyboard.a && page > 0) {
        inventory.select -= 60;  optionbattle.sound.play(soundName.select_move);
    } else if(inputkey == keyboard.s && page < (I.maxLimit / 60|0) ) {
        inventory.select += 60;  optionbattle.sound.play(soundName.select_move);
    } else if((inputkey == keyboard.z || inputkey == keyboard.enter) && inventory.select >= I.maxLimit){
        optionbattle.sound.play(soundName.system_buzzer);
    } else if((inputkey == keyboard.z || inputkey == keyboard.enter) && inventory.select < I.maxLimit && I.data[inventory.select].type == "unit"){
        optionbattle.sound.play(soundName.select_menu);
        mode = modeName.UNITINFO;  unitinfo.returnPosition = modeName.INVENTORY;
    }
    
};

inventory.display = function(){
    ctx.drawImage(backgroundImage.main, 0, 0);
    ctx.drawImage(backgroundImage.inventory, 0, 0);
    
    var page = (inventory.select / 60) | 0;
    var selectX = (inventory.select % 10);
    var selectY = (inventory.select / 10) - (page * 6) | 0;
    ctx.drawImage(inventory.selectImage, selectX*64, (selectY*60) + 120 );
    
    var I = optionbattle.user.getInventory();
    for(var a = page*60, b = 0; a < page*60+60 && a < I.maxLimit; a++, b++){
        var Z;
        if(I.data[a].type == "unit"){
            Z = optionbattle.unit.getUnit(I.data[a].code);
            var X = b % 10;
            var Y = b / 10 |0;
            ctx.drawImage(Z.image, X*64+2, Y*60+122);
        }
    }
    
    numberDisplay(inventory.select, 620, 4, true);
    numberDisplay(page, 620, 34, true);
    numberDisplay(I.maxLimit, 620, 64, true);
    numberDisplay(I.useCount, 620, 94, true);
};

var unitinfo = {};
unitinfo.selectImage = new Image();  unitinfo.selectImage.src = "image/system/arrow2.png";
unitinfo.impossible = new Image();  unitinfo.impossible.src = "image/system/impossible.png";
unitinfo.levelmax = new Image();  unitinfo.levelmax.src = "image/system/levelmax.png";
unitinfo.teamunitCancel = new Image();  unitinfo.teamunitCancel.src = "image/system/teamunitcancel.png";
unitinfo.select = 0;
unitinfo.levelBonus = 0.02;
unitinfo.backPosition = modeName.INVENTORY;
unitinfo.process = function(){
    if(inputkey == keyboard.x){
        unitinfo.select = 0;  optionbattle.sound.play(soundName.select_back);
        mode = unitinfo.backPosition;
    } else if(inputkey == keyboard.up && unitinfo.select > 0){
        unitinfo.select--;  optionbattle.sound.play(soundName.select_move);
    } else if(inputkey == keyboard.down && unitinfo.select < 7){
        unitinfo.select++;  optionbattle.sound.play(soundName.select_move);
    } else if(inputkey == keyboard.z || inputkey == keyboard.enter){
        var I = optionbattle.user.getInventory();
        var U = optionbattle.unit.getUnit(I.data[inventory.select].code);
        var T = optionbattle.user.getTeamunit();
        var lv = I.data[inventory.select].lv;
        var rank = U.rank;
        var usergold = optionbattle.user.getgold();
        var maxLv = 0;
        var up10 = 0;
        var extend = I.data[inventory.select].extend;
        switch(rank){
            case 1: maxLv = 40; break;
            case 2: maxLv = 50; break;
            case 3: maxLv = 60; break;
            case 4: maxLv = 70; break;
        }  maxLv += (extend* 10);
        for(var a = lv, b = 0; a < maxLv && b < 10; a++,b++){
            up10 += upgradeGold.data[rank][a];
        }
    
        switch(unitinfo.select){
            case 0: if(usergold > upgradeGold.data[rank][lv] && lv < maxLv){
                        optionbattle.sound.play(soundName.system_upgrade);
                        optionbattle.user.minusgold(upgradeGold.data[rank][lv]);
                        I.data[inventory.select].lv++;
                    } else {
                        optionbattle.sound.play(soundName.system_buzzer);
                    } break;
            case 1: if(usergold > up10 && lv < maxLv){
                        optionbattle.sound.play(soundName.system_upgrade);
                        for(var a = lv, b = 0; a < maxLv && b < 10; a++, b++){
                            if(optionbattle.user.getgold() > upgradeGold.data[rank][lv]){
                                optionbattle.user.minusgold(upgradeGold.data[rank][lv]);
                                I.data[inventory.select].lv++;
                            } else  break;
                        }
                    } else {
                        optionbattle.sound.play(soundName.system_buzzer);
                    } break;
            case 2: if(lv >= maxLv && usergold > upgradeGold.extendlv[I.data[inventory.select].extend] && I.data[inventory.select].extend < 5){
                        optionbattle.sound.play(soundName.system_upgrade);
                        optionbattle.user.minusgold(upgradeGold.extendlv[I.data[inventory.select].extend]);
                        I.data[inventory.select].extend++;
                    } else {
                        optionbattle.sound.play(soundName.system_buzzer);
                    } break;
            case 3: break;
            case 4: if(I.data[inventory.select].teamunit == -1){
                        var checkTeam = optionbattle.user.setTeamunit(inventory.select);
                        if(checkTeam == true){
                            optionbattle.sound.play(soundName.select_menu);
                        } else {
                            optionbattle.sound.play(soundName.select_back);
                        }
                    } else {
                        optionbattle.sound.play(soundName.select_menu);
                        optionbattle.user.deleteTeamunit(I.data[inventory.select].teamunit);
                    }
                break;
        }
    }
};
unitinfo.display = function(){
    ctx.drawImage(backgroundImage.main, 0, 0);
    ctx.drawImage(backgroundImage.unitinfo, 0, 0);
    var I = optionbattle.user.getInventory();
    var U = optionbattle.unit.getUnit(I.data[inventory.select].code);
    ctx.drawImage(U.image, 0, 60, 196, 196);
    ctx.drawImage(unitinfo.selectImage, 180, 240+(unitinfo.select*30) );
    
    ctx.fillStyle = "black";
    ctx.font = "18px 돋움체";
    ctx.fillText(U.name, 300, 80);
    ctx.fillText(U.typeName, 300, 110);
    
    var lv = I.data[inventory.select].lv;
    var levelBonus = 1 + (unitinfo.levelBonus * lv);
    var align = 90 + 5;
    var rank = U.rank;
    var maxLv = 0;
    var extendlv = I.data[inventory.select].extend;
    switch(rank){
        case 1: maxLv = 40; break;
        case 2: maxLv = 50; break;
        case 3: maxLv = 60; break;
        case 4: maxLv = 70; break;
    }  maxLv += (extendlv * 10);
    
    var alignL = 440;
    var alignR = 620;
    numberDisplay(U.hp*levelBonus|0, alignR, align, true);
    numberDisplay(lv, 380, align+30, true);
    numberDisplay(maxLv, alignL, align+30, true);
    numberDisplay(rank, alignR, align+30, true);
    numberDisplay(U.attack*levelBonus|0, alignL, align+60, true);
    numberDisplay(U.delay, alignR, align+60, true);
    numberDisplay(U.attackTechnical*levelBonus|0, alignL, align+90, true);
    numberDisplay(U.delayTechnical, alignR, align+90, true);
    
    var up10 = 0;
    for(var a = lv, b = 0; a < maxLv && b < 10; a++,b++){
        up10 += upgradeGold.data[rank][a];
    }
    var alignD = 575;
    var alignDY = 240 + 5;
    numberDisplay(upgradeGold.data[rank][lv], alignD, alignDY, true);
    numberDisplay(up10, alignD, alignDY+30, true);
    numberDisplay(upgradeGold.extendlv[I.data[inventory.select].extend], alignD, alignDY+60, true);
    numberDisplay(upgradeGold.evolution[rank], alignD, alignDY+90, true);
    
    if(lv >= maxLv){
        ctx.drawImage(unitinfo.levelmax, 440, 240);
        ctx.drawImage(unitinfo.levelmax, 440, 270);
    }
    if(U.evolution == 0 && lv < maxLv)  ctx.drawImage(unitinfo.impossible, 440, 300);
    if(U.evolution == 0)  ctx.drawImage(unitinfo.impossible, 440, 330);
    if(I.data[inventory.select].teamunit != -1)  ctx.drawImage(unitinfo.teamunitCancel, 200, 360);
};



var upgradeGold = {};
upgradeGold.base = [0, 800, 2400, 7200, 20000];
upgradeGold.basebonus = [0, 132, 432, 832, 1632];
upgradeGold.add = [0, 8, 12, 16, 25];
upgradeGold.addbonus = [0, 3, 5, 7, 10];
upgradeGold.multiple = [0, 0.004, 0.008, 0.012, 0.025];
upgradeGold.extendlv = [10000, 14000, 17000, 23000, 30000];
upgradeGold.evolution = [0, 4000, 20000, 80000];
upgradeGold.data = [];
for(var a = 0; a < 5; a++){  upgradeGold.data[a] = []; };
(function(){
    for(var rank = 0; rank < upgradeGold.data.length; rank++){
        for(var lv = 0; lv < 121; lv++){
            var base = upgradeGold.base[rank] + ((lv/10|0)*upgradeGold.basebonus[rank]);
            var add = (upgradeGold.add[rank] + (lv/10|0)*upgradeGold.addbonus[rank]) * lv;
            var multiple = (upgradeGold.multiple[rank] * lv) + 1;
            
            upgradeGold.data[rank][lv] = (base + add) * multiple |0;
        }
    }
})();


var party = {};
party.selectImage = new Image();  party.selectImage.src = "image/system/select.png";
party.select = 0;

party.process = function(){
    var I = optionbattle.user.getInventory();
    var T = optionbattle.user.getTeamunit();
    
    if(inputkey == keyboard.x){
        mode = modeName.MENU;  optionbattle.sound.play(soundName.select_back);
    } else if(inputkey == keyboard.up && (party.select/10|0) > 0){
        party.select -= 10;  optionbattle.sound.play(soundName.select_move);
    } else if(inputkey == keyboard.down && (party.select+10) < 22){
        party.select += 10;  optionbattle.sound.play(soundName.select_move);
    } else if(inputkey == keyboard.left && party.select%10 > 0){
        party.select--;  optionbattle.sound.play(soundName.select_move);
    } else if(inputkey == keyboard.right && party.select%10 < 9 && party.select <= 20){
        party.select++;  optionbattle.sound.play(soundName.select_move);
    } else if((inputkey == keyboard.z || inputkey == keyboard.enter) && T[party.select] != -1 && party.select < T.length){
        mode = modeName.UNITINFO;  unitinfo.backPosition = modeName.PARTY;
        inventory.select = T[party.select];
        optionbattle.sound.play(soundName.select_menu);
    }
};
party.display = function(){
    ctx.drawImage(backgroundImage.main, 0, 0);
    ctx.drawImage(backgroundImage.party, 0, 0);
    ctx.drawImage(party.selectImage, (party.select%10)*60, (party.select/10|0)*60 + 300);
    
    var I = optionbattle.user.getInventory();
    var T = optionbattle.user.getTeamunit();
    var levelBonus = 0.02;
    
    var tamHp = 30000 + (optionbattle.user.getlv() * 100);
    var unitHp = 0;
    for(var a = 0; a < T.length; a++){
        if(T[a] == -1)  continue;
        
        var D = I.data[T[a]];
        var U = optionbattle.unit.getUnit(D.code);
        unitHp += (U.hp) * (levelBonus * D.lv + 1)|0;
        ctx.drawImage(U.image, (a%10)*60, (a/10|0)*60 + 300);
    }
    numberDisplay(tamHp, 340, 425, true);
    numberDisplay(unitHp, 340, 455, true);
    numberDisplay(tamHp + unitHp, 620, 425, true);
};



var numberPng = new Image();
numberPng.src = "image/system/numberPng.png";
function numberDisplay(number, x, y, isAlignRight){
    // 여기에 있는 const 변수는 이미지 출력 좌표를 간단히 하기 위해 만든 변수임
    // 위 함수와 다른점은 이 함수는 해당 객체 내부에서 사용할 수 있게 한 함수임.
    var cw = 12, ch = 20, sw = 12, sh = 20; // c = crop, s = imagesize, w = width, h = height
    var strnumber = number.toString();
    if(isAlignRight == true){ // 오른쪽 정렬일때, length에서 1을 빼주는것은 스트링 배열은 0번부터 시작하기때문
        for(var a = strnumber.length-1 , b = 0 ; a >= 0; a--, b++){
            var outputnumber = strnumber.charAt(a);
            switch(outputnumber){
                case '0': ctx.drawImage(numberPng, cw*0,  0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '1': ctx.drawImage(numberPng, cw*1,  0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '2': ctx.drawImage(numberPng, cw*2,  0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '3': ctx.drawImage(numberPng, cw*3,  0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '4': ctx.drawImage(numberPng, cw*4,  0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '5': ctx.drawImage(numberPng, cw*5,  0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '6': ctx.drawImage(numberPng, cw*6,  0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '7': ctx.drawImage(numberPng, cw*7,  0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '8': ctx.drawImage(numberPng, cw*8,  0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '9': ctx.drawImage(numberPng, cw*9,  0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '.': ctx.drawImage(numberPng, cw*10, 0, sw, sh, x-(b*sw), y, sw, sh);  break;
                case '-': ctx.drawImage(numberPng, cw*11, 0, sw, sh, x-(b*sw), y, sw, sh);  break;
            }
        }
    } else {
        for(var a = 0; a < strnumber.length; a++){
            var outputnumber = strnumber.charAt(a);
            switch(outputnumber){
                case '0': ctx.drawImage(numberPng, cw*0,  0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '1': ctx.drawImage(numberPng, cw*1,  0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '2': ctx.drawImage(numberPng, cw*2,  0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '3': ctx.drawImage(numberPng, cw*3,  0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '4': ctx.drawImage(numberPng, cw*4,  0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '5': ctx.drawImage(numberPng, cw*5,  0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '6': ctx.drawImage(numberPng, cw*6,  0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '7': ctx.drawImage(numberPng, cw*7,  0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '8': ctx.drawImage(numberPng, cw*8,  0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '9': ctx.drawImage(numberPng, cw*9,  0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '.': ctx.drawImage(numberPng, cw*10, 0, sw, sh, x+(a*sw), y, sw, sh);  break;
                case '-': ctx.drawImage(numberPng, cw*11, 0, sw, sh, x+(a*sw), y, sw, sh);  break;
            }
        }
    }
    
}

//게임 진행 함수//
this.process = function(){
    switch(mode){
        case modeName.TITLE: title.process(); break;
        case modeName.OPTION: option.process(); break;
        case modeName.MENU: main.process(); break;
        case modeName.DUNGEON: dungeon.process(); break;
        case modeName.ROUND: round.process(); break;
        case modeName.INVENTORY: inventory.process(); break;
        case modeName.UNITINFO: unitinfo.process(); break;
        case modeName.PARTY: party.process(); break;
        case modeName.FIELD: optionbattle.field.process(); break;
    }
    inputkey = 0; // 누른 키 초기화;
};
this.display = function(){
    ctx.clearRect(0, 0, 640, 480);
    switch(mode){
        case modeName.TITLE: title.display(); break;
        case modeName.OPTION: option.display(); break;
        case modeName.MENU: main.display(); break;
        case modeName.DUNGEON: dungeon.display(); break;
        case modeName.ROUND: round.display(); break;
        case modeName.INVENTORY: inventory.display(); break;
        case modeName.UNITINFO: unitinfo.display(); break;
        case modeName.PARTY: party.display(); break;
        case modeName.FIELD: optionbattle.field.display(); break;
    }
};

//---------------------//
}//function Game
optionbattle.game = new Game(); // 게임 객체 생성




/*
function combination_progress()
{
	var make=0;
	var material = new Array(6);
	var delete_item = new Array(6);
	var a=0;
	for(a=0;a<6;a++){
		material[a] = combination[background_combination.select].material[a];
		if(material[a]==0){ delete_item[a]=null; make++; continue; }
					    
		for(b=0;b<user.inventory_max;b++){
			var type = user.inventory[b][inventoryoption.type];
			if(type!=inventory_type.item) continue;
					    	
			if(material[a]==user.inventory[b][inventoryoption.code]){
			var ok=0;
			for(c=0;c<6;c++){
			    if(delete_item[c]==b) ok++;
			}
			        	    	
			if(ok>0) {}
			else { make++; delete_item[a]=b; break; }
			    }
			}
	}
			        
	if(make<=5){
		alert("재료가 부족하여 조합할 수 없습니다.");
	}
	else{
		alert("조합이 완료되었습니다.");
	var result_unit = combination[background_combination.select].result[1];
	var result_type = combination[background_combination.select].result[0];
	user.inventory[user.inventory_use+1][inventoryoption.type] = result_type;
	user.inventory[user.inventory_use+1][inventoryoption.code] = result_unit;
	user.gold -= combination[background_combination.select].gold;
			        	
	for(a=0;a<6;a++){
		if(delete_item[a]!=null){
			user.inventory[delete_item[a]][0] = 0;
			user.inventory[delete_item[a]][1] = 0;
			user.inventory[delete_item[a]][2] = 0;
			user.inventory[delete_item[a]][3] = 0;
			user.inventory[delete_item[a]][4] = 0;
		    }
	    }
    }
}  */