function NAMESPACE_OPTION_BATTLE(){
	this.unit = new Array(100); // 유닛의 정보를 저장하는 배열 생성
	this.item = new Array(100); // 아이템의 정보를 저장하는 배열 생성
	this.combination = new Array(100); // 아이템의 조합 정보를 저장하는 배열 생성
	this.dungeon = new Array(100); // 던전의 정보를 저장하는 배열 생성
	this.enemy = new Array(100); // 적의 정보를 저장하는 배열 생성
	this.story = new Array(100);
	this.game = {};
	this.sound = {};
	this.music = {};
	this.background = {};
	this.user = {};
	this.imagebox = {};
}

// 네임스페이스 사용하기
var optionbattle = new NAMESPACE_OPTION_BATTLE();// namespace 선언
var canvas = document.getElementById("canvas");
function fullScreenMode(){
    if  ( canvas . requestFullscreen )  { 
      canvas . requestFullscreen ( ) ; 
    }  else  if  ( canvas . msRequestFullscreen )  { 
      canvas . msRequestFullscreen ( ) ; 
    }  else  if  ( canvas . mozRequestFullScreen )  { 
      canvas . mozRequestFullScreen ( ) ; 
    }  else  if  ( canvas . webkitRequestFullscreen )  { 
      canvas . webkitRequestFullscreen ( ) ; 
    }
    
    
    /*var heightMultiple = window.innerWidth * (canvas.height / 480);
    canvas.style.width = heightMultiple+"px"; 
    canvas.style.height = window.innerHeight+"px";*/
}

function exitFullscreen() {
  if(document.exitFullscreen) {
    document.exitFullscreen();
  } else if(document.mozCancelFullScreen) {
    document.mozCancelFullScreen();
  } else if(document.webkitExitFullscreen) {
    document.webkitExitFullscreen();
  }
  
  canvas.style.width = 640;
  canvas.style.height = 480;
}

/*canvas.addEventListener("click",function () {
canvas.style.width = ""+window.innerWidth+"px";
//canvas.style.height= ;
if  ( canvas . requestFullscreen )  { 
  canvas . requestFullscreen ( ) ; 
}  else  if  ( canvas . msRequestFullscreen )  { 
  canvas . msRequestFullscreen ( ) ; 
}  else  if  ( canvas . mozRequestFullScreen )  { 
  canvas . mozRequestFullScreen ( ) ; 
}  else  if  ( canvas . webkitRequestFullscreen )  { 
  canvas . webkitRequestFullscreen ( ) ; 
}  }, false);
*/
try{
    var ctx = canvas.getContext('2d'); // canvas 기능 사용
    delete NAMESPACE_OPTION_BATTLE;
} catch(e) {
    
}

// 사운드 파일 이름을 그대로 쓰시고 번호는 중복되지만 않게 하면 됩니다.
var soundName = { none:0, select_move:1, select_enter:2, select_back:3, select_menu:4,
    system_buzzer:5, system_score:6, system_upgrade:7, system_notice:8, type_hyper:9, type_heal:10,
    arrowshot:11, bubble:12, dongrami_fail:13, highattack:14, splashdamage:15, swordattack:16,
    jeonjagijang:17, multishot:18, laserA:19, whiteflash:20,  bombmissile:21, bomb:22, light_break:23,
    system_pause:24, bombattack:25, meteorite_break:26, levelup:27, wall_break:28, warning_strong_missile_detected:29,
    strong_missile_detected:30, strong_missile_bomb:31, blackhole:32, linelaser:33, damage:34,
    hitshot:35, sawtooth_attack:36, sawtooth_launch:37, parapo:38, fire:39, palsern_wait:40, palsern_hit:41, palsern_miss:42,
    machinegun:43, beam1:44, beam2:45, beam3:46, burstshot:47, burstshot_hit:48, burstshot_saw:49, enemyshot:50,
    tamsaseonwarning:51, tamsaseon_recoverytime:52, shielddamage:53, shielduse:54,
    meteorite_zone_mystery_message1:55, meteorite_zone_mystery_message2:56,
    meteorite_zone_mystery_message3:57, meteorite_zone_mystery_message4:58,
    enemy_laser_die:59, enemy_laser1:60, enemy_laser2:61, enemy_laser3:62, enemy_lser4:63, jemulstar:64, jemulstarend:65,
    donggrami_maeul_viliage_hall_computer_sound:66, exclamation_mark:67, antilaserboss_die:68, antilaserboss_clear:69, boss_warning:70,
};

var musicName = { none:0, title:1, roundclear:2, roundfail:3, 
    music01:4, music02:5, music03:6, music04:7, music05:8, music06:9,
    music07:10, music08:11, music09:12, music10:13, music11:14, music12:15, music13:16
};

var effectName = {SPLASH:0, MISSILE:1, HITSHOT:2, FIRE:3, MACHINEGUN_UP:4, MACHINEGUN_DOWN:5, MACHINEGUN_CENTER:6,
    BURSTSHOT:7, jemulstar:8, exclamation_mark:9, boss_warning:10 };

var spriteName = {enemy_stone:0, enemy_stonered:1 };

var enemyAttackName = { shot:0, laser1:1, laser2:2, laser3:3, laser4:4, 
    antilaserboss_part1:5, antilaserboss_part2:6, antilaserboss_part3:7, antilaserboss_part4:8, antilaserboss_part5:9, antilaserboss_part6:10 };
